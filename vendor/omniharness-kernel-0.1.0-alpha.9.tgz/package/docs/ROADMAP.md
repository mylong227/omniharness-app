# 路线图（唯一规划源）

> **性质**：现行规划，不是提案。本文件回答三个问题：**做到哪了、下一件是什么、凭什么说做完了**。
> **机检**：`npm run plan:check`（已并入 `npm run verify`）。状态账与代码事实不一致即红。
> **边界事实**见 [BOUNDARY.md](BOUNDARY.md)；**变更历史**见 [../CHANGELOG.md](../CHANGELOG.md)；**每日动作**见 git log。

---

## 1. 规划怎么闭环

```text
目标 → 判据 → 工作项 → 证据 → 状态回写 → plan:check 对账 → （下一轮）
```

四条纪律，每条都可执行、可复核：

1. **状态只有两种**：`✅ done` / `⏳ open`。「做到一半」一律记 `open`，不发明第三种状态。
2. **双向对账**（`scripts/planCheck.mjs`）：
   - 标 `done` ⇒ 该里程碑判据**全部**通过（禁止提前记账）；
   - 标 `open` ⇒ 判据**至少一条不通过**（禁止做完不记账）。
3. **判据分两类**：`auto` 由脚本读仓库事实（文件 / 数字 / 边界机检）；`manual` 必须在
   [§6 人工复核记录](#6-人工复核记录)留下 `日期 + 判据 id + 证据` 行，否则视为未通过。
4. **一项工作 = 一个判据 + 一条证据**：没有证据的改动不进状态账；判据不通过就不许翻 ✅。

> 为什么这样设计：这个项目最容易犯的两个错，是「文档说做完了但代码没跟上」和「代码做完了但文档停在旧状态」。
> 单向门禁只能防前者；双向对账把后者也变成红灯。

---

## 2. 北极星（D90 / D180）

以 2026-11-03 为起点（`10 h/周`预算，与切分方案一致）：

| 时点 | 判据 | 当前 |
| ---- | ---- | ---- |
| **D90（2027-02-01）** | 至少 1 个**外部**安装或使用反馈（npm 下载 / issue / 下游仓库钉版本） | ⏳ 0（尚未发布到 npm） |
| **D90** | OmniHarness 钉内核版本并跑通全量回归 | ✅ vendored tgz 钉版 alpha.6 + 全量回归绿（2026-11-05，§6 m2-consumer） |
| **D180（2027-05-02）** | 公开面仍 ≤60；按行为分面的契约测试 ≥30 例；`npm run verify` 全绿不靠人肉 | ✅ 60 / 60；契约 124 例（单元总 564） |
| **D180** | 适配器归属裁决执行完（`laya` 移出、`@beta` 组复核） | ✅ laya 已迁出；`@beta` 三组 9 文件 |

北极星不达标时的**默认动作是收缩，不是加功能**：不拆仓、不加公开面、不写第二套 CLI。

---

## 3. 状态账

> `plan:check` 直接解析下表。改状态 = 改这一行；判据 id 必须在 §5 有实现。

| 里程碑 | 状态 | 预算 | 判据 |
| ------ | ---- | ---- | ---- |
| M0 切分收口 | ✅ done | 68 h（已完成） | m0-boundary, m0-no-compat, m0-public-cap, m0-tests, m0-headless-imports |
| M1 发布就绪（alpha.1） | ✅ done | 10 h | m1-publishable, m1-files, m1-changelog, m1-readme, m1-ci, m1-dist |
| M2 第一个外部消费（D90） | ✅ done | 20 h | m2-consumer |
| M3 beta 硬化（alpha.2） | ✅ done | 30 h | m3-laya-migrated, m3-adapters-beta-marked, m3-support-surface, m3-contract-coverage |
| M5 立信（回执链） | ✅ done | 40 h | m5-jcs-conformance, m5-receipts-contract-suite, m6-provenance-public |
| M6 通电与沙箱收口 | ✅ done | 30 h | m6-mcp-server-wired, m6-mcp-capability-honest, m6-sandbox-failclosed, m6-examples-public, m6-workbench-bridge |
| M4 切片收口（盘点并账） | ✅ done | 20 h | m4-metaphor-zero, m4-zero-inbound, m4-source-lines, m4-unreachable-lines, m4-gate-bypass, m4-maturity-evidence, m4-public-45 |
| M8 效率与内存收口（调研底稿 [RESEARCH-2026-11.md](RESEARCH-2026-11.md)） | ✅ done | 16 h | m8-bench-harness, m8-research-doc, m8-memory-multipliers, m8-serialization-shortcircuit, m8-eventlog-snapshot |
| M9 硬化收口（接线审计 [WIRING.md](WIRING.md) + 毛边 + 压力） | ✅ done | 14 h | m9-wiring-audit, m9-polish, m9-stress |
| M10 缺口补完（取消 / 尾摘要 / mcpServers） | ✅ done | 8 h | m10-cancel-propagation, m10-signed-summary, m10-mcp-servers-wired |
| M11 一次接入收口（`./embed`） | ✅ done | 10 h | m11-embed-entry, m11-embed-evidence, m11-embed-minimal, m11-embed-receipts-persist, m11-embed-execution-certificate, m11-embed-audit-bundle, m11-embed-full-audit-bundle |
| M12 架构图谱与数学不变量 | ✅ done | 10 h | m12-arch-graph, m12-math-invariants |
| M13 数学覆盖二期（调度/估算/覆盖率/回执并发） | ✅ done | 6 h | m13-math-expansion |
| M14 执行证书（运行级可复核） | ✅ done | 12 h | m14-execution-certificate |
| M15 执行图谱系（多智能体可验证） | ✅ done | 8 h | m15-execution-graph |
| M16 审计包（单文件离线交付） | ✅ done | 6 h | m16-audit-bundle |
| M17 审计包运行时闭环（`kernel.exportAuditBundle`） | ✅ done | 6 h | m17-runtime-audit-bundle |
| M18 选择性披露（最小披露仍可验） | ✅ done | 8 h | m18-selective-disclosure |
| M19 核心循环韧性（任务解决能力一大步） | ✅ done | 10 h | m19-loop-resilience |
| M20 审计交付编码（压缩 / 口令加密 / 分片） | ✅ done | 8 h | m20-audit-delivery |
| M21 迁移桥显式化（通配 → 承诺闭包，底稿 [RESEARCH-2026-11C.md](RESEARCH-2026-11C.md)） | ⏳ open | 8 h | m21-explicit-exports, m21-generator-source |

> M8 复盘（2026-11-06）：调研先行两次修正了直觉——内存「4-6 份转录副本」被加固后的
> 仪器证伪大半（真值 2.04×，首版 5.1× 是首跑混入语料索引的仪器污染）；效率大头不在每步
> 管线（热稳态本就 ~1 ms）而在冷索引（3.1s 一次性）与稳态重复序列化（指纹 14.2×、
> schema 137×）。P3 五项按「实测过关才做」全部不做，理由记录在调研底稿 §4。

### M9 硬化收口 ✅

**目标**：把「文档说已通电」与「代码里真的接上」之间的差距变成可执行的红灯。

| 工作项 | 结果 |
| ------ | ---- |
| 接线审计 | 可达性根从单入口修正为 8 个公开入口（旧口径 19,858 → 正确口径 8,303 行不可达）；`npm run wiring:check` 机检入口完整 / 预算 / 零入边落账 / 文档不悬空；处置表见 [WIRING.md](WIRING.md) |
| 声明未接线修复 | 遥测链 + 晋升台账（README「可审计」的两条声明）接进 `governance`；隔离阶梯 + 内置 wasm 执行器接进 `sandbox`；MRTR 三个 handler 接进 `mcp` 并给 `McpHttpAssemblyOptions.inputRequired` 注入口（缺省关闭，显式接线） |
| 毛边打磨 | 16 条回归判据：回执链异步 signer 分叉、工作台非法 request-target 崩进程、配置端口被忽略、SSE 回放重复投递与无背压、错位回答、500→400、close 幂等、MemoryStorage 空桶 append、JCS 孤立代理项、MCP 预检/显式 CORS、fallback 门禁丢失、装配器绕过 runtime.gate、深嵌套参数打崩回合、sessionId 冲突/超长、尾篡改带外绑定 |
| 压力测试 | `tests/stress` 三文件 9 用例（20k 事件 / 40 会话 / 350 回执 / 20 并发 SSE / 100 投影 / 1 MiB 边界 / 200 步会话 / 10 MiB 载荷），`npm run stress` 并入 `verify` |
| 盘点清账 | 12 个零引用、零判据、注释指向已删模块的文件删除（见 WIRING §3「M9 删除」）；`m4-zero-inbound` 改用全部入口口径 |

> M9 复盘：旧审计工具本身是最大的「声明未接线」——只从 `src/index.ts` 起算，7 个公开
> 子路径入口整棵被判成死代码，于是数字长期显示「MCP/沙箱/工作台不可达」，与事实相反。
> 修正测量口径后，真正的缺口只剩 5 个宿主侧/通配模块（全部在 WIRING 落账）。压力测试
> 另外证明了「同步路径 100 并发零分叉」是**假绿**：注入异步 signer 后 8 个并发 append
> 全部拿到同一 seq——现有判据恰好只测了同步路径。

### M10 缺口补完 ✅

**目标**：把 M9 明确记录、未在本轮修的三项缺口补成可执行判据。

| 工作项 | 结果 |
| ------ | ---- |
| 取消传播 | `StepToolExecutor` 与工具执行竞速（取消即抛 `CancelledError`，不再等 60s 工具跑完）；`ToolScheduler` 不再把取消吞成 failed ToolResult；`ask_user` 等待期取消会清理 `WorkbenchHub` 挂起提问并释放会话锁；取消原因 `timeout/custom` 原样透传 |
| 尾条可信摘要签发 | `ReceiptChain.summary()` 产出 `{issuerId, receiptCount, tailHash}`，`signSummary()` 用回执同一 signer 对 `JCS(summary)` 签名；`AuditPacks.verify(pack, trustStore, signedSummary)` 验签并比对条数/尾哈希——尾条被改/被删由 `EXPECTED_MISMATCH` 检出，改摘要由 `SIGNATURE_INVALID` 检出；无 signer 时拒绝签发 |
| `config.mcpServers` 装配 | 字段进入 `OmniHarnessConfig`/`ResolvedConfig` 并由 `ConfigFactory` 透传；新增 `startMcpServers(runtime)`（`mcp` 子路径）用 `SdkMcpConnector`（stdio/远端 + auth）逐台连接，经 `McpGateway` 把远端工具注册进工具面，`close()` 反注册；`auth` 的 bearer/oauth 令牌由 `McpAuthProvider` 真正变成 `Authorization` 头 |

> M10 复盘：三项缺口的共同形态都是「信号/配置到了，消费者没到」——取消信号已下传却没人竞速、
> 摘要参数已支持却没人签发、`mcpServers` 已校验却没人读取。补完后，WIRING §6 只剩「通配桥收窄 /
> 行数口径」两项测量层待办，以及「摘要分发通道」这一产品决策。

### M11 一次接入收口 ✅

**目标**：把「宿主为了用上内核全部能力而必须自己写的那一层」收进内核，宿主只剩一次调用。

| 工作项 | 结果 |
| ------ | ---- |
| 一次接入入口 | 顶层新增 `OmniKernel.create()`（腾出 `AgentFactory` 的第 60 位；后者下沉为内部件），并保留 `@omniharness/kernel/embed` 作为完整选项/句柄类型面：主循环 + 内置工具/记忆/技能 + 工作台 HTTP/SSE（含历史会话发现）+ MCP 客户端 + MCP 服务端（可选）+ 遥测（可选）+ 回执链一次装配；`examples/embed.mjs` 只留 6 行核心；公开面仍 60/60 |
| 能力可核对 | `kernel.capabilities()` 实时列出工具数 / 工作台地址 / 回执条数 / MCP 工具 / 审批 / 沙箱 / embedding / evolution / native / telemetry；「全部能力」不再靠读代码猜 |
| 生命周期与安全默认 | `close()` 幂等（取消回合 → 关 MCP → 落回执 → 冲刷事件 → 关工作台）；模型缺省 `MockModel` 且不读本机凭据，审批/沙箱保持 fail-closed，工作台回环绑定，MCP 未配置零连接 |
| 审计闭环 | `receipts.persist` 落 append-only JSONL + 0600 私钥；重启 `ReceiptChain.adopt` 逐条校验后续写，启动即复核既有链；坏链/丢钥/降级签名一律 fail-closed（[RECEIPTS.md](RECEIPTS.md) §1.1） |
| 运行级证书接入 | `receipts.certificates` 每次回合自动签发执行证书（M14 资产）并落盘；显式 `kernel.certificate(sessionId)` 同实现；篡改/链尾不符由 `ExecutionCertificates.verify` 检出（[API.md §1.8](API.md)） |
| 审计分发 | `receipts.exportBundle(dir?)` 一次导出 `pack.json` + `trust.json` + `summary.json`，第三方可零出网复核；尾条改/删由 `summary` 检出（[API.md §1.9](API.md)） |
| 单文件运行证明 | `kernel.exportAuditBundle([sessionId])` 交付 `bundle.json`（事件 + 证书 + 回执 + 整包签名）+ trust + digest；`AuditBundles.verify` 一次复核全部层（[API.md §1.10](API.md)） |
| 判据 | `tests/contract/embedOneCall.test.ts`（12 例）：工具回合 + 工作台投影 + 审计包真实验签 + MCP 客户端/服务端 + 事件扇出 + 未签名语义 + config 透传 + fail-closed + 回执续链/篡改/丢钥；`m11-embed-minimal` 机检示例 ≤60 行且只经顶层；文档 [API.md §1](API.md) / README 快速开始 / [WIRING.md](WIRING.md) 声明对照 |

> M11 复盘：M9 接线审计把「声明未接线」变成了红灯，但**宿主侧的重复接线**不在它的口径里——
> 应用仓库仍要用 17 个生成域文件把内核内部路径收敛起来。`OmniKernel.create()` 的取舍是：**把组合根
> 之上的组合根留在内核**（顶层一个符号 + 一份测试），而不是继续让每个消费者各写一层；顶层稳定面
> 以「移出 `AgentFactory`」腾位，`api:check` 仍 60/60，`wiring:check` 入口数 8 → 9。

### M12 架构图谱与数学不变量 ✅

**目标**：让「架构」和「数学」也从口头承诺变成可执行判据。

| 工作项 | 结果 |
| ------ | ---- |
| 架构机检 | 新增 `npm run arch:check`（`scripts/archCheck.mjs`）：运行时依赖图 Tarjan SCC 无环、跨层边规则（contracts 叶子 / protocols 单一支撑面 / kernel→protocols 仅声明例外）、[ARCHITECTURE.md](ARCHITECTURE.md) 依赖快照与代码一致；`arch:update` 重新生成快照 |
| 契约层收口 | `OmniError`/`ErrorCode` 与 `API_VERSION` 从根实现迁到 `contracts/`（根文件保留兼容再导出），消除 `contracts → 根入口` 回指；kernel→根入口的同类边归零（只余版本兼容路径） |
| 数学覆盖 | 新增确定性属性测试骨架 `tests/property/harness.ts`（mulberry32 + 固定 seed + seed/trial 失败定位）；5 文件 / 20 属性覆盖 JCS、0/1 背包、UCB1、BM25、哈希链、事件日志；[MATH.md](MATH.md) 记录覆盖矩阵、诚实边界（属性测试 ≠ 证明）与未覆盖项 |
| 判据 | `m12-arch-graph`（archCheck 全绿 + 快照一致 + 并入 verify）、`m12-math-invariants`（≥4 文件 / ≥12 属性 + 覆盖矩阵在位） |

> M12 复盘：运行时依赖图此前**没有任何机检**——`boundary:check` 只看文本 import 规则，
> 类型依赖与真实回指混在一起。加入「只算运行时边」的图分析后发现：运行时环为 0，
> 但 `contracts → 根入口` 有 4 条回指（错误目录/版本常量住在根实现里）——已迁到契约层。
> 数学侧的最大收获不是多测了几个函数，而是**把「哪些只是工程近似」写进了文档**：
> 背包有精确最优对拍，UCB1 只钉骨架不声称 regret 界，公平调度不声称偏差界。

### M13 数学覆盖二期 ✅

**目标**：把属性测试从「算法样例」扩到**并发/调度/计量/估算**四类容易被直觉骗过的面。

| 工作项 | 结果 |
| ------ | ---- |
| 新增属性套件 | `fairScheduler`（等权服务量差额 ≤2、并发 ≤ limit、排队取消）、`tokenEstimator`（单调/可加/开销/缓存不变性）、`rewardCoverage`（计数自洽/差分可加/异常归口）、`receiptsConcurrency`（异步 signer 任意 N 并发线性 + 摘要=链尾） |
| 规模 | 属性测试 5 → **9 文件 / 20 → 32 属性**，全部固定 seed、失败可复现 |
| 文档 | [MATH.md](MATH.md) 覆盖矩阵新增 4 行；SFQ 从「示例级判据」升级为属性判据；诚实边界不变（仍不声称 regret/偏差界证明） |
| 判据 | `m13-math-expansion`（≥8 文件 / ≥28 属性 + 4 个新套件均在矩阵中） |

> M13 复盘：这四类算法的共同点是「单点用例很容易全绿，但性质在边界上会破」——
> 调度器在 40 个任务下是否真的不让某会话饿死、Token 估算在混合中英文时是否单调、
> 覆盖率在 0 样本时是否除零、回执链在异步签名下是否还线性。属性测试把它们变成
> 「任意 N + 固定 seed」的断言，同时不引入第三方向量库。

### M14 执行证书（运行级可复核）✅

**研究目标**：把「可审计」从动作级回执推进到**运行级离线证明**，形成难替代的护城河。

| 工作项 | 结果 |
| ------ | ---- |
| 事件 Merkle | `eventMerkle.ts`：叶子/内部域分离、奇数上提（不做末项复制）、JCS 规范化；空流固定根；包含证明 |
| 执行证书 | `executionCertificate.ts`：`{sessionId, eventCount, eventRoot, receipt?, toolSurfaceDigest?, issuedAt}`；签名/复核；单事件包含证明 |
| 安全边界 | 证明完整性/顺序/条数 + 与回执链尾互相咬合；**不**证明内容为真、无外部 witness 时不能防整体重写（如实记录） |
| 实测 | 10k 事件建树/证书约 0.8–0.9 s（一次性、宿主显式导出时付），单条验证 ~0.5 ms；篡改矩阵 5/5 + 回执尾绑定检出；底稿 [RESEARCH-2026-11B.md](RESEARCH-2026-11B.md) |
| 判据 | `m14-execution-certificate`：契约/属性判据 + receipts 子路径导出 + 研究底稿与 MATH 矩阵 |

> M14 复盘：回执链解决「动作是否被签发」，但回答不了「事件流是否完整、顺序是否签发时、
> 某事件是否属于这次运行」。Merkle 化把这三个问题变成可复核的密码学承诺；把回执链尾
> 绑进证书，使攻击者不能只伪造一边。最大的取舍是**不做** witness 网络/公共透明日志：
> 那需要外部运维与信任根，超出内核边界，已列为后续研究问题。

### M15 执行图谱系（多智能体可验证）✅

**目标**：单次运行可复核之后，让「哪次运行由谁委派」也可离线验证——子代理/工作流历史
不能被悄悄挪到别的父会话名下，也不能凭空多出一个子运行。

| 工作项 | 结果 |
| ------ | ---- |
| 结构 | `ExecutionGraph = nodes(执行证书) + edges(parent, child, delegationEventHash?)`；整图签名 |
| 锚定 | 边可锚定到父事件流里的真实委派事件（叶子哈希 + 子会话 id 出现）；否则只能靠图签名保证完整性（如实记录） |
| 结构判据 | 单根（恰一个）、无环（Kahn）、每个子节点恰一个父；多父/环/多根分别报可读问题码 |
| 判据 | `m15-execution-graph`：契约 4 例 + 属性 1 条（随机树、删边、加环、改事件） |

> M15 复盘：多智能体系统的审计难点不是「有没有日志」，而是「日志之间的因果关系是否可信」。
> 把委派边锚定到父事件哈希后，攻击者要伪造谱系必须同时改父事件、子证书与图签名；这比
> 只给每个会话一份独立证书强一个量级。仍未解决：跨图引用（图与图之间的因果链）与
> 外部 witness。

### M16 审计包（单文件离线交付）✅

**目标**：把 M14/M15 的零件变成收证方真正能消费的**单文件交付物**。

| 工作项 | 结果 |
| ------ | ---- |
| 打包 | `AuditBundles.build({runs, graph?, exportedAt})`：逐会话生成/复用执行证书，回执链自动绑定链尾 |
| 复核 | `AuditBundles.verify`：事件证书 → 回执链（含绑定比对/验签）→ 执行图 → 整包签名，一次报告全部问题码 |
| 交付 | 可选整包签名；`AuditBundles.digest` 供公告/锚定；`scripts/verifyBundle.mjs bundle.json trust.json` 零出网复核 |
| 判据 | `m16-audit-bundle`：契约 4 例（roundtrip/事件篡改/回执篡改/图缺失/签名伪造） |

> M16 复盘：证书/图再强，收证方不会拼装就没有价值。审计包把「先验哪一层、缺哪份事件流」
> 这类装配知识收进内核；交付边界也写清了——大包适合归档取证，不适合每步传输，
> 压缩/加密/分片留作后续。

### M17 审计包运行时闭环（`kernel.exportAuditBundle`）✅

**目标**：宿主不再手工拼 events/certificates/receipts——一次 `exportAuditBundle([sessionId])`
产出 `bundle.json + trust.json + digest.txt`，第三方用一条 CLI 离线复核。

| 工作项 | 结果 |
| ------ | ---- |
| 运行时导出 | `kernel.exportAuditBundle(sessionIds, directory?)`：逐会话取事件 + 签执行证书（绑定全局回执链当前尾）+ 打包 + 整包签名 + 落盘 |
| 链作用域修正 | 回执链是 **issuer 单链跨会话共享**：证书绑定的是「签发时链尾前缀」；复核按 count 在全局链里比对尾哈希，**不再按会话过滤回执**（过滤会破坏 `previousReceiptHash` 连续性） |
| 产物 | `bundle.json`（已签名审计包）、`trust.json`（kid → SPKI）、`digest.txt`（JCS SHA-256） |
| 判据 | `m17-runtime-audit-bundle`：embed 契约（单会话 + 多会话同 issuer 链）+ `AuditBundles.verify` 复核 + CLI |

> M17 复盘：M16 的包级 `receipts` 设计在这里救了一次——最初按会话过滤回执会让
> `previousReceiptHash` 断裂、证书链尾对不上；改成包级全局链 + 前缀校验后，
> 多会话共享一个 issuer 的语义才自洽。验证也补了「多会话同链」用例，防止回归。

### M18 选择性披露（最小披露仍可验）✅

**目标**：审计包交付全量事件流——收证方拿到全部内容，披露方失去最小化披露能力。
把 M14 的 Merkle 包含证明从证书内部升格为**交付语义**：只交子集事件（每条附证明）
仍可离线复核，未选事件不出包。

| 工作项 | 结果 |
| ------ | ---- |
| 披露包契约 | `DisclosurePack`：会话 = 证书 + `disclosed[]`（事件 + 包含证明）；包级回执链**必需前缀**（第 1 条到最大绑定条数）；`kind: 'disclosure-pack'` 供 CLI 判别 |
| 构建 | `DisclosurePacks.build({runs, receipts})`：全量流只做证明源不出包；下标升序去重；回执按绑定裁剪（绑定超出链长即抛）；无绑定时回执整项省略 |
| 复核 | `DisclosurePacks.verify`：形状 → 证书自洽 → 逐条包含证明（叶子重算 + 根/条数比对）→ 前缀链 → 绑定比对 → 整包签名；绑定存在而前缀缺失即红（悬空承诺） |
| 内核导出 | `kernel.exportDisclosurePack([{sessionId, indices}], directory?)` 产出 `disclosure.json + trust.json + digest.txt`；CLI `verifyBundle.mjs` 按 `kind` 自动识别审计包/披露包 |
| 判据 | `m18-selective-disclosure`：契约 6 例（roundtrip/最小化/篡改矩阵 7 项/回执前缀/签名/叶子不变式）+ embed 内核级 1 例 + 属性 2 条 |

> 诚实边界：包含证明不证明「未披露事件存在/不存在」——收证方只知道证书承诺了
> `eventCount` 条、可验其中 K 条；回执链前缀含未披露会话的动作回执（单链固有泄露面）。
> 复核器比审计包更严一处：证书绑定回执而包内无前缀 ⇒ `RECEIPT_BINDING_MISMATCH`
> （审计包对该状态沉默，披露包把它当篡改检出）。

### M19 核心循环韧性（任务解决能力一大步）✅

**研究目标**：主循环是任务解决能力的本体。调研（agentLoopAudit + 全量代码走读）发现六处
「安全关键逻辑零专属测试 / 文档-行为矛盾 / 死代码」——本里程碑把它们逐个变成可执行判据。

| 工作项 | 结果 |
| ------ | ---- |
| 重试/熔断默认开（M19-a） | `modelRetry`/`modelCircuitBreaker` 判定 `===true` → `!==false`——修「注释/文档宣称默认开、代码 opt-in」矛盾：此前裸 429/超时直接杀死整个 runTask，与宣称的韧性相反；配置文档同步「默认开，显式 false 关」 |
| 步级可重试恢复（M19-b） | `stepOnce` 接住 `ModelCallError.retryable`（模型层退避已耗尽）——回合内限额重试 2 次（重建上下文重新调用），转录留【模型瞬时错误】；超限仍走【回合失败】fail-closed 不变 |
| 过载降级装配（M19-c） | `fallbackModel` 此前被声明（stepTypes）、被消费（stepRunner LR-04）、唯独无人赋值——纯死代码。现 config 字段 → ConfigFactory 透传 → buildTurnRunner 注入，529/503 即切备用模型并留痕 |
| 毒工具反馈（M19-d） | supervisor 早就统计失败率但循环从不消费。现 StepToolExecutor 记每工具连败（成功清零；门禁拒绝/解析失败不计——那是策略/参数问题非工具故障），达阈值 3 在下一步上下文动态尾段注入【工具异常】点名提示 + 错误摘要 + 改道建议（与 repo-map 合并同一条 system，不多断前缀缓存） |
| 工具看门狗（M19-e） | 挂死且无视取消信号的工具此前冻结整回合（LoopGuard 只在步间采样）。现单次 JS 工具执行与墙钟竞速（缺省 600s，`toolCallTimeoutMs` 可调/0 关），超时补可读失败结果（中文文案避开只读重试的英文瞬态判据）；取消竞速保持内层即时穿透 |
| 测试债收口（M19-f） | 新增 `tests/unit/loopResilience.test.ts`（9 例）：LoopGuard 四检测器（先劝后熔/健康复位/失败不参与冗余/软硬两段）、ToolScheduler（读批真并发 + model-order + 写屏障）、RetryingModel（退避成功/不可重试即抛/耗尽上抛/退避期取消穿透/分类表）；agentLoopAudit 扩 G/G2/H/I/J 五例 |
| 判据 | `m19-loop-resilience`：六项事实（默认开判定、步级重试常量与留痕、降级三点接线、毒工具阈值与注入、看门狗竞速、回归网在位）全部机检 |

> M19 复盘：六个缺陷的共同形态是「韧性能力被**宣称**了但没有**接通**」——文档说默认开
> 代码却 opt-in、字段被声明被消费却无人赋值、supervisor 有统计循环却不读。修法全部是
> 接线而非新造：每项 ≤60 行实现 + 对应判据。最有价值的一课是 M19-f：安全关键件
> （失控检测/调度屏障/重试分类）此前零定向断言，「被别的用例路过」不等于「被钉住」。

### M20 审计交付编码（压缩 / 口令加密 / 分片）✅

**目标**：把 M16 复盘明确留作后续的交付三件套收掉——审计包/披露包是单文件 JSON，
大运行动辄数十 MB 且可能含敏感载荷；交付物要经得起不可信信道与归档场景。

| 工作项 | 结果 |
| ------ | ---- |
| 编码层 | `AuditDeliveries.encode/decode`（receipts 子路径，不占顶层 60 位）：JCS → gzip（缺省开，重复性事件流实测 >50% 收缩）→ 口令加密（scrypt N=2^15/r=8/p=1 + AES-256-GCM 认证加密，参数随 manifest 记录）→ 分片（每片独立 sha256）→ `manifest.json(kind=audit-delivery) + part-*.bin` |
| 分层口径 | **编码不复核**：decode 只做传输完整性（分片摘要/字节数/内容摘要/GCM 认证，问题码 `AUDIT_DELIVERY_*`），语义复核仍走 `AuditBundles/DisclosurePacks.verify` 同一路径；两个摘要口径分开写（`digest.txt` 对外锚定不受编码影响；manifest `contentDigest` 是含签名信封的传输级完整性锚） |
| 运行时接通 | `kernel.exportAuditBundle(sessionIds, dir?, delivery?)` 交付模式直出 manifest+分片（不再写裸 bundle.json），trust/digest 照常；embed 契约钉住落盘形态 |
| CLI 接通 | `verifyBundle.mjs` 新增 manifest（`--passphrase`）与 gzip 魔数两条路径，退出码语义不变；口令经带外交付 |
| 判据 | `m20-audit-delivery`：编码三要素 + 问题码 + barrel/kernel/CLI 接线 + 契约 6 例（roundtrip 摘要不变 / 分片篡改 / 口令错误与缺失 / 压缩真实收益 / 裸包语义 / CLI 两形态）+ embed 1 例，全部机检 |

> M20 复盘：诚实边界与 M14 同风格——加密护**机密性**，完整性与来源仍由签名 + 信任根
> 承担；口令强度是宿主责任。踩坑一则：Node scrypt 缺省 maxmem 恰好等于 128·N·r（32 MiB），
> 内部开销一加即溢出（`memory limit exceeded`）——两侧显式 `maxmem: 64 MiB` 解决，
> 已写进实现注释。迁移桥收窄（M2 工作项 4）按决策另行立项：先做域生成器解析源设计
> （顶层 60 位已满是硬约束），不在本里程碑。

---

## 4. 里程碑

### M0 切分收口 ✅

从 OmniHarness 切出独立内核并证明「删掉应用它还能跑」。判据与复现命令见
[BOUNDARY.md §当前状态](BOUNDARY.md#当前状态可复现判据)，这里只留结论：边界五条规则全绿、
`src/compat` 清零、公开面 59/60、切分时 25 文件 140 用例（M3 扩容后 29 文件 170 用例）、
headless 示例只经公开入口。

### M1 发布就绪（alpha.1）✅

**目标**：让「发一个 alpha」成为一个可重复的动作，而不是一次手工事故。

| 工作项 | 产出 |
| ------ | ---- |
| 规划闭环 | 本文件 + `scripts/planCheck.mjs` + `npm run plan:check` 并入 `verify` |
| 发布元数据 | `private: false`、`publishConfig.access: public`、`files[]` 覆盖路线图 |
| 版本纪律 | 版本 `0.1.0-alpha.1`；CHANGELOG 顶条与 `package.json` 同版本 |
| 使用者入口 | README 首屏即可跑通；四不变量 + 快速开始 + 指向本路线图 |
| CI | `.github/workflows/verify.yml`：`npm ci` → `npm run verify` → headless 冒烟 |

**退出条件**：§3 的六条 `m1-*` 判据全过；`npm pack` 后空目录安装可跑（见 §7 发布记录）。
**不在 M1**：真正执行 `npm publish`（需要凭据，记在 §7）。

> `m1-ci` 只证明**工作流存在且调用同一条命令**，不伪装成「CI 已经绿」。双平台首跑结论在
> 首次推送后回填 §6，作为人工复核而不是 auto 判据——执行器的结果不是本地可复现事实。

### M2 第一个外部消费（D90）✅

**目标**：证明内核不是只有作者能用的库。

> **收口（2026-11-05，证据在 §6）**：npm registry 无凭据，改走 **vendored tgz 钉版**路径——
> 应用钉 `file:vendor/omniharness-kernel-0.1.0-alpha.6.tgz`（tag `v0.1.0-alpha.6` = f362434），
> 应用 verify 全链绿（typecheck×3 + kernel:check 6/6 + web:test + build + smoke + desktop 25/25）。
> 下方「现状」是 11-03 分支迁移路径（`migration/kernel-package`）的历史记录，该分支未合并，
> 已被 vendored 路径取代；工作项 4（迁移桥删除）仍 open——应用仍有
> `@omniharness/kernel/kernel/*` 等深路径导入，删除条件未满足（[BOUNDARY 迁移桥](BOUNDARY.md)）。

**现状（2026-11-03 深夜，实测；历史记录）**：

- 内核侧已就绪：`npm pack` 3.09 MB / 3474 文件，空目录安装 + headless 跑通；
- **阻塞 1（发布）**：本机未登录 npm（`npm whoami` → `ENEEDAUTH`，无 `NPM_TOKEN` / `~/.npmrc`）。
  已尝试 `npm login --auth-type=web`，流程需要浏览器确认，无头会话无法完成 ⇒ 只能停在
  「发布就绪 + 本地 tag / tarball」；
- **应用接入已推进到分支**：OmniHarness 的 `migration/kernel-package` 分支完成 6,529 处导入重写、
  删除 1,914 个文件 / **143,883 行**内嵌副本；`tsc`（含 web）、`build`、`arch:gate` 全绿。
  **未合并**：75 个测试文件 / 93 例失败待分流（内核源码级不变量测试回迁内核、CLI 子进程测试按新布局
  调整、`check.mjs` 导入铁律放行包路径）。顺序与判据见 [M2_APP_MIGRATION.md](M2_APP_MIGRATION.md)。

工作项（按顺序，不并行）：

1. 发布 alpha 到 registry（需要凭据）后，应用改为**钉版本依赖**（替换 `file:../omniharness-kernel`）；
2. 完成分支上的 75 个测试文件分流，`check.mjs` 放行包路径，再合并应用 main 并跑全量回归；
3. 收集第一批反馈：装不上 / 类型不对 / 文档看不懂，各记一条 issue 模板；
4. 合并后删除内核的**迁移桥**子路径导出（BOUNDARY「迁移桥」），把应用剩余导入收敛到顶层。

**退出条件**：`m2-consumer`（人工判据）——应用钉版本 + 全量回归绿 + 日期与证据写入 §6。

### M3 beta 硬化（alpha.2）✅

**目标**：把「能跑」变成「敢用」。四件事全部落地（2026-11-03）：

| 工作项 | 结果 | 证据 |
| ------ | ---- | ---- |
| 归属裁决执行 | `adapters/laya`（9 文件 + Python 资产）与 `decisionEngineResolver` 移出内核；应用仓库保留实现 | `m3-laya-migrated`；内核只留 `decisionEnginePort` 注入缝，`mode` 非 off 却未注入即**构建期报错** |
| @beta 组复核 | 三组 9 文件全部带 `@beta 归属裁决`，符号仍不进公开面 | `m3-adapters-beta-marked` |
| 支撑面收窄 | `protocolsSupport` 21 符号（15 值 + 6 类型） | `m3-support-surface` |
| 契约覆盖面 | `tests/contract` 6 文件 **32 例**：事件顺序 / 回放 / 压缩 / 审批语义 / 沙箱语义 / 门禁接线，只经公开入口 | `m3-contract-coverage`；`npm test` 29 文件 170 例 |

**行为变更（alpha 破坏性，已记 CHANGELOG）**：配置 `decisionEngine.mode` 非 `off` 时必须注入
`decisionEnginePort`；此前由内核直接 new 出 `LayaDecisionEngine`，现在内核不再持有厂商绑定实现。

---

## 5. 判据实现映射

| 判据 id | 类别 | 判什么 | 实现在哪 |
| ------- | ---- | ------ | -------- |
| `m0-boundary` | auto | 五条分层规则 | `scripts/boundaryCheck.mjs` |
| `m0-no-compat` | auto | `src/compat` 不存在 | `scripts/planCheck.mjs` |
| `m0-public-cap` | auto | 公开面 ≤60 | `scripts/publicSurface.mjs` |
| `m0-tests` | auto | ≥20 测试文件 / ≥100 用例 | `scripts/planCheck.mjs` |
| `m0-headless-imports` | auto | 示例只 import 公开入口 | `scripts/planCheck.mjs` |
| `m1-publishable` | auto | 非 private + public access + engines | `scripts/planCheck.mjs` |
| `m1-files` | auto | `files[]` 每项存在 | `scripts/planCheck.mjs` |
| `m1-changelog` | auto | CHANGELOG 顶条 = 包版本 | `scripts/planCheck.mjs` |
| `m1-readme` | auto | 四不变量 + 快速开始 + 指向本文件 | `scripts/planCheck.mjs` |
| `m1-ci` | auto | 工作流跑 `npm run verify` | `scripts/planCheck.mjs` |
| `m1-dist` | auto | `dist` 入口与声明可加载 | `scripts/planCheck.mjs` |
| `m2-consumer` | manual | 应用钉版本 + 全量回归 | 本文件 §6 |
| `m3-laya-migrated` | auto | `adapters/laya` 已移出 | `scripts/planCheck.mjs` |
| `m3-adapters-beta-marked` | auto | 三组 9 文件带裁决标记 | `scripts/planCheck.mjs` |
| `m3-support-surface` | auto | 支撑面 ≤21 符号 | `scripts/planCheck.mjs` |
| `m3-contract-coverage` | auto | `tests/contract` 用例 ≥30 | `scripts/planCheck.mjs` |
| `m8-bench-harness` | auto | bench 脚本在位且 `npm run bench` 带 `--expose-gc` | `scripts/planCheck.mjs` |
| `m8-research-doc` | auto | 调研底稿在位（基线数字 + retention 口径 + 前后对照表） | `scripts/planCheck.mjs` |
| `m8-memory-multipliers` | auto | TokenEstimator 单例共享（压缩器 ↔ 容量分解器） | `scripts/planCheck.mjs` |
| `m8-serialization-shortcircuit` | auto | 游标/指纹/schema 三处每步序列化短路（行为测试同行） | `scripts/planCheck.mjs` |
| `m8-eventlog-snapshot` | auto | 事件日志读路径走失效即重建快照 | `scripts/planCheck.mjs` |
| `m9-wiring-audit` | auto | 8 个公开入口为根、可达预算、零入边逐条落账（[WIRING.md](WIRING.md)） | `scripts/wiringCheck.mjs` |
| `m9-polish` | auto | 毛边判据 ≥12 条，每条有回归用例 | `tests/contract/hardeningPolish.test.ts` |
| `m9-stress` | auto | 压力套件在位（≥3 文件 / ≥8 用例）且 `npm run stress` 并入 verify | `tests/stress/` + `vitest.stress.config.ts` |
| `m10-cancel-propagation` | auto | 工具执行/ask_user 等待与取消竞速，Hub 清理挂起提问 | `StepToolExecutor` / `WorkbenchHub` + `tests/contract/cancellationPropagation.test.ts` |
| `m10-signed-summary` | auto | 链尾摘要签发 + 复核器验签/比对（尾篡改可检出） | `ReceiptChain.signSummary` + `tests/contract/receiptSummary.test.ts` |
| `m10-mcp-servers-wired` | auto | `config.mcpServers` 透传并真正连接/注册（auth 生效） | `mcpServersBridge` + `tests/contract/mcpServersWiring.test.ts` |
| `m11-embed-entry` | auto | 顶层 `OmniKernel.create()` + `./embed` 类型面 + 示例/README 使用 + 公开面仍 ≤60 | `scripts/planCheck.mjs` |
| `m11-embed-evidence` | auto | 一次接入的证据：工具回合 / 工作台投影 / 审计包验签 / MCP 双向 / 事件扇出 / 未签名语义 / config 透传由同一契约测试钉住 | `tests/contract/embedOneCall.test.ts` |
| `m11-embed-minimal` | auto | 最小接入可机检：示例只经顶层、非注释代码 ≤60 行、只调一次 `OmniKernel.create()` | `scripts/planCheck.mjs` |
| `m11-embed-receipts-persist` | auto | 回执闭环：持久化跨重启续链 / 密钥复用 / 存档篡改与丢钥 fail-closed（两条判据同行） | `tests/contract/embedOneCall.test.ts` |
| `m11-embed-execution-certificate` | auto | 运行级执行证书接入：自动落盘 / 显式签发 / 离线复核 / 事件篡改检出（判据同行） | `tests/contract/embedOneCall.test.ts` |
| `m11-embed-audit-bundle` | auto | 审计分发：pack + trust + summary 三件套导出并离线复核（尾条改/删可检出） | `tests/contract/embedOneCall.test.ts` |
| `m11-embed-full-audit-bundle` | auto | 单文件审计包：事件 + 证书 + 回执 + 整包签名，`AuditBundles.verify` 复核/篡改检出 | `tests/contract/embedOneCall.test.ts` |
| `m12-arch-graph` | auto | 运行时依赖无环 + 跨层边合法 + [ARCHITECTURE.md](ARCHITECTURE.md) 快照一致 | `scripts/archCheck.mjs` |
| `m12-math-invariants` | auto | 属性测试 ≥4 文件 / ≥12 属性 + 覆盖矩阵与诚实边界在案 | `tests/property/` + [MATH.md](MATH.md) |
| `m13-math-expansion` | auto | 属性测试 ≥8 文件 / ≥28 属性，调度/估算/覆盖率/回执并发四套件在矩阵中 | `tests/property/` + [MATH.md](MATH.md) |
| `m14-execution-certificate` | auto | 执行证书：Merkle 完整性/包含证明/回执绑定/签名复核 + 研究底稿 | `src/kernel/receipts/executionCertificate.ts` + `tests/contract/executionCertificate.test.ts` |
| `m15-execution-graph` | auto | 执行图谱系：节点证书/委派锚定/单根无环/图签名 | `src/kernel/receipts/executionGraph.ts` + `tests/contract/executionGraph.test.ts` |
| `m16-audit-bundle` | auto | 审计包：事件证书/回执链/执行图/整包签名一次复核 + CLI | `src/kernel/receipts/auditBundle.ts` + `tests/contract/auditBundle.test.ts` |
| `m17-runtime-audit-bundle` | auto | 运行时闭环：`kernel.exportAuditBundle` 产出 bundle/trust/digest，第三方 CLI 可复核 | `src/kernel/bootstrap/createOmniKernel.ts` + `tests/contract/embedOneCall.test.ts` |
| `m18-selective-disclosure` | auto | 选择性披露：子集事件 + 包含证明 + 必需前缀可离线复核，未选事件不出包 | `src/kernel/receipts/disclosurePack.ts` + `tests/contract/disclosurePack.test.ts` |
| `m19-loop-resilience` | auto | 核心循环韧性：重试/熔断默认开 + 步级恢复 + 过载降级装配 + 毒工具反馈 + 工具看门狗 + LoopGuard/Scheduler/RetryingModel 回归网 | `src/kernel/core/turnRunner.ts` + `src/kernel/core/stepToolExecutor.ts` + `tests/unit/agentLoopAudit.test.ts` + `tests/unit/loopResilience.test.ts` |
| `m20-audit-delivery` | auto | 审计交付编码：gzip / scrypt+AES-256-GCM 口令加密 / 分片 manifest + 运行时与 CLI 接通 + 传输级篡改与口令错误 fail-closed | `src/kernel/receipts/auditDelivery.ts` + `tests/contract/auditDelivery.test.ts` + `scripts/verifyBundle.mjs` |
| `m21-explicit-exports` | auto | 迁移桥显式化：`exports` 无 `"./*"` 通配、每条深路径导出指向存在的 dist 文件 | `package.json` + `scripts/planCheck.mjs` |
| `m21-generator-source` | manual | 域生成器（app 侧）解析源对齐内核承诺清单：exports 清单第一优先 + 回退黄标 + 17 域文件再生成一致 | 本文件 §6 |

---

## 6. 人工复核记录

> `manual` 判据**只认这张表**：没有行 = 未通过。一行 = 一次复核，写日期、判据 id、可复核的证据（链接 / 命令输出摘要）。

| 日期 | 判据 | 证据 |
| ---- | ---- | ---- |
| 2026-11-04 | m4-metaphor-zero | 3b9a977（隐喻栈+燧+Genesis 拆线）与 df80bed/1328fd2（孤儿清扫）；登记于 ExperimentalPaths |
| 2026-11-04 | m5-receipts-contract-suite | 869c647（JCS）+ 4ae8f1c（链/锚/复核器，变异判据四连全红自证）+ 6572c5d（RECEIPTS.md）|
| 2026-11-04 | m6-mcp-server-wired | cffe5e0（McpHttpAssembly 端到端 + capability 谎报修正 + provenance/governance 通电）+ 8684bbe（沙箱 fail-closed）|
| 2026-11-04 | m6-workbench-bridge | e8c1457（Hub+投影）+ 123da76（SSE/续传/审计端点）+ c09548f（端到端示例：提问桥真机闭环）|
| 2026-11-05 | m2-consumer | OmniHarness-app（D:deepseekomniharness-app，f3b36e1）钉 file:vendor/omniharness-kernel-0.1.0-alpha.6.tgz（内核 tag v0.1.0-alpha.6 = f362434）；app verify 全链绿（typecheck×3 + kernel:check 6/6 + web:test + build + smoke + desktop 25/25）；Runtime 收敛为内核薄扩展，被删能力 app 自有化（kernel-compat 122 文件）|
| 2026-11-07 | m2-consumer | alpha.7 首次升级回归：OmniHarness-app（feat/kernel-package，21f946c）钉 vendored alpha.7（tag v0.1.0-alpha.7 = e6cb909，vendorKernel.mjs 重建含 native）；M9 清账删除的 11 个模块（approval 适配器 ×5 / mcp ×3 / sdk socket ×2 / plugin 权限契约）随迁 app kernel-compat，业务消费点重接 + 17 域文件再生成；app verify 全链绿（kernel:check 360 文件 + typecheck×3 零错 + web 748 用例 + build + smoke 原生实载 + desktop 30/30）|

---

## 7. 发布记录

| 版本 | 日期 | 动作 | 证据 |
| ---- | ---- | ---- | ---- |
| 0.1.0-alpha.9 | 2026-11-07 | 发布**就绪**（未 `npm publish`，无凭据） | **BREAKING：exports 通配删除 → 251 条显式深路径闭包**（M21 Phase 2）；空目录安装 + headless 冒烟跑通；verify 全绿（108 文件 / 601 用例 + 压力 9 + 公开面 60/60 + `plan:check` 21 里程碑 / 61 判据，`m21-explicit-exports` 首次转绿） |
| 0.1.0-alpha.8 | 2026-11-07 | 发布**就绪**（未 `npm publish`，无凭据） | `npm pack` 2.74 MB / 2695 文件（M19 核心循环韧性 + M20 交付编码 + receipts OOP Phase A 首次入版）；空目录安装 + headless 冒烟跑通；verify 全绿（108 文件 / 601 用例 + 压力 9 + 公开面 60/60 + `plan:check` 20 里程碑 / 59 判据） |
| 0.1.0-alpha.7 | 2026-11-07 | 发布**就绪**（未 `npm publish`，无凭据） | `npm pack` 2.72 MB / 2692 文件（M8–M18 首次入版）；空目录安装 + headless 冒烟跑通；`verify` 全绿（106 文件 / 580 用例 + 压力 9 + 公开面 60/60 + `plan:check` 18 里程碑 / 57 判据） |
| 0.1.0-alpha.1 | 2026-11-03 | 发布**就绪**（未 `npm publish`，无凭据） | `npm pack` + 空目录安装 + `node examples/headless.mjs` 跑通 |
| 0.1.0-alpha.2 | 2026-11-03 | 发布**就绪**（未 `npm publish`：`npm whoami` → `ENEEDAUTH`，无 token） | `npm pack` 3.14 MB / 3529 文件（laya 已不在包内、tests 零泄漏）；空目录安装 + headless 跑通；`npm publish --dry-run` 通过 |
| 0.1.0-alpha.3 | 2026-11-03 | 发布**就绪**（同上，无凭据） | 应用形状清零（19 文件 / 2.5K 行）；`npm pack` 后空目录安装 + headless 跑通；`verify` 29 文件 170 例、59 / 60 |

> 纪律：发布记录只写**已经发生**的事。「就绪」与「已发布」分开写，避免把 `npm pack` 成功说成已上线。
> **待执行**（有凭据时，一条命令）：`npm publish --tag alpha`（`publishConfig` 已钉 `access: public` + `tag: alpha`，
> 不会误发到 `latest`）。

---

## 8. 不在计划内（以及什么条件下才考虑）

| 不做 | 触发条件 |
| ---- | -------- |
| 拆独立 git 仓库 / 上 npm workspaces | 出现真实外部消费者，且它要求独立版本节奏；否则只是把目录换成 `package.json` |
| 新增顶层导出 | 公开面先回到 ≤55 再谈；每个新增必须写「谁会用」 |
| 第二套 CLI / Web / TUI | 内核不做体验层；应用需要时在内核开 issue |
| 重写内核 | 债务在结构不在代码；重写只消除理解成本，不消除维护成本 |
| 自动发布流水线 | 先有 ≥2 次人工发布记录，且发布事故为 0 |

---

## 9. 风险

| 风险 | 症状 | 对策 |
| ---- | ---- | ---- |
| 账实再次漂移 | 文档写 ✅、`plan:check` 红 | 双向对账；翻状态必须同一 commit 带判据证据 |
| 公开面偷偷长回 | `api:check` 顶到 60 | 新符号先进子路径；`@beta` 组不得上顶层 |
| 判据变脆（重构即红） | 判据依赖具体文件名/措辞 | 判据只钉**事实**（文件存在、数字上限、命令退出码），不钉实现细节 |
| 单人 10 h/周 排期失真 | 里程碑连续两轮无进展 | 砍工作项而不是砍判据；必要时把里程碑拆小 |
| alpha 被当成稳定版 | 下游直接上生产 | README 与 CHANGELOG 首行同步标注「不承诺兼容」 |

---

## 10. 决策日志

| 日期 | 决策 | 理由 |
| ---- | ---- | ---- |
| 2026-11-07 | 迁移桥收窄（M2 工作项 4）**单独立项**，先做域生成器解析源设计 | 应用侧 311 处导入已全部收敛于 17 个生成域文件，删除条件接近满足；但域生成器靠 `dist` 深路径解析符号——删 `"./*"` 通配前必须先给生成器换解析源（顶层 60 位已满是硬约束）。设计先行，不在 M20 顺带做 |
| 2026-11-03 | 本文件是**唯一规划源**；BOUNDARY 只记边界事实 | 规划与事实分离，避免两份文档各说各话 |
| 2026-11-03 | `plan:check` 采用**双向对账** | 单向门禁只能防提前记账，防不了做完不记账 |
| 2026-11-03 | M1 只到「发布就绪」，不含 `npm publish` | 无发布凭据；把「就绪」和「已发布」分开写才诚实 |
| 2026-11-03 | `adapters/laya` 迁出，改 `decisionEnginePort` 注入 | 第三方 venv 绑定不进通用内核；注入缝让应用保留实现，内核不静默丢弃配置 |
| 2026-11-03 | 契约覆盖由人工判据改为机检（`tests/contract` ≥30 例） | 人工判据容易写成愿望；用例数可数、可回归 |
| 2026-11-03 | **应用形状清零**：TUI / license / server-audit / enterprise / SDK / codegen / CLI 帮助整棵删除 | 「切出来」只保证能跑，不保证只剩内核；零引用 + 编译与全量测试是唯一裁判 |
| 2026-11-03 | 应用迁移**先行**：先删重复副本、用子路径桥接，测试分流随后 | 公开面只有 59 符号，一次性收敛到顶层不可行；先拿到「单一源码」再逐步收窄，桥有删除条件 |
| 2026-11-06 | `m4-source-lines` 预算 114K → 115K | M11 `./embed` 组合根新增约 0.9K 行；交换条件是宿主侧不再各写一层接线，顶层公开面仍 60/60。与 M5/M6 时「+2K 合法新增预算」同一处置，不冻结后续工作 |
| 2026-11-06 | `m4-source-lines` 预算 115K → 117K | M11 回执持久化（append-only 存档 + 密钥管理 + 续链校验）与同期执行证书接线新增约 2K 行；两者都是「审计闭环」的必要实现，不以删功能换数字 |
| 2026-11-07 | `m4-source-lines` 预算 117K → 118K | M18 选择性披露（契约 + envelope 签名抽取 + 构建复核器）新增约 0.6K 行；「最小披露仍可验」是审计闭环的必要能力，处置与 M11 两次调整一致 |
| 2026-11-02 | 先同仓独立包，不拆双仓 | 10 h/周下双仓必然漂移（切分方案 §4） |

---

## 11. 迭代节奏

- **每轮开始（30 min）**：`npm run plan:check` 对账 → 只挑一个里程碑 → 只做它的一条工作项。
- **每轮结束（10 min）**：判据证据 + 翻状态 + CHANGELOG（若对外可见）+ 同一 commit。
- **每月**：复核 §2 北极星；连续两轮无进展就砍范围，不延期。
- **每个 alpha**：应用侧升一次依赖并跑全量回归，回归结果记入 §6。

