# 接线审计

> **一句话**：回答「声明的东西，代码里到底接没接」——只记结构事实，不记会过期的数字。
>
> 机检：`npm run wiring:check`（`npm run verify` 内）。
> 复现：`node scripts/reachability.ts .`（摘要）；`--write` 才落 `.audit/reach.json`。

---

## 1. 口径

模块图由 `scripts/reachability.ts` 从 `src/**/*.ts` 的静态 `import` / `export ... from` /
字面量 `import()` 构建；**根 = `package.json` exports 的 18 条显式键**（2 根 + 16 curated；深路径闭包 0）。

- 行数按 `split('\n').length` 计（每文件比 `wc -l` 多 1）；
- 零入边只由 `src` 内导入边计算：**「零入边」= src 内没有导入者**，不排除它有独立判据；
- 不可达行数**不在本文档写死**（会随每次重构变化）：唯一读数在 `npm run drift:check`
  的 `reach.indexUnreachableLines` 行，预算只降不升。

---

## 2. 零入边处置

> 判定 = `src` 内零导入者 **且** 从全部显式公开入口不可达。每条必须给出去向；
> `wiring:check` 逐条核对（文档引用的路径必须真实存在，防旧账悬空）。

| 路径 | 处置 | 依据 |
| ---- | ---- | ---- |
| `src/protocols/mcp/mcpAuthFlow.ts` | **内部保留（交互式 OAuth 回环）** | `auth` 已由 `McpAuthProvider` 消费成 Authorization 头；浏览器授权码流需宿主显式跑 `mcp auth` |
| `src/protocols/acp/index.ts` | **协议桶成员** | 经 `@omniharness/kernel/protocols` 语义桶导出；由编辑器宿主直接装配，内核不自动启动；判据 `tests/unit/acpServer.test.ts` |
| `src/kernel/adapters/tool/code/codeSandboxWorker.ts` | **Worker 入口（运行时加载）** | `CodeInterpreter.run` 经 `WorkerEntryUrl` 拉起；静态图看不见 `new Worker(URL)` |
| `src/kernel/eval/decompositionBench.ts` | **内部保留（评测基准）** | 由 `scripts/eval/decompositionBench.ts` 直接读 dist 文件（不经包 exports） |
| `src/kernel/eval/longTaskAgentRunner.ts` | **内部保留（评测执行器）** | 由 `scripts/eval/longTasksRun.ts` 动态 import；`eval:longtasks` 的入口 |
| `src/omniError.ts` | **公开入口（omniError 子路径）** | 应用经 `@omniharness/kernel/omniError.js` 或顶层取 `OmniError` / `ErrorCode`；实现已迁 `src/contracts/errors/omniError.ts` |
| `src/kernel/adapters/media/sharpImageResizer.ts` | **内部保留（可选适配器）** | sharp 的 `ImageResizerPort` 实现；`ViewImageTool` 构造器显式注入才生效，内核不默认装配第三方依赖 |
| `src/kernel/eval/longMemEval.ts` | **内部保留（评测口径库）** | LongMemEval-S 检索命中代理；由评测脚本消费，不进公开面 |
| `src/kernel/eval/tracePatchPlanner.ts` | **内部保留（评测口径库）** | trace→patch 提案器；纯逻辑，由评测脚本消费 |
| `src/kernel/plugin/sandbox.ts` | **内部保留（宿主驱动库面）** | node:vm 自包含插件沙箱；`PluginLoader` 远程路径按需调用 |
| `src/contracts/ports/context/vectorStorePort.ts` | **端口契约** | 外部向量库对齐面；内核只认端口，不内置实现 |

其余零入边都是公开入口本身（`src/index.ts`、`src/embed.ts`、`src/tools.ts` 等）——
入口没有导入者是正常形态，不是孤儿。

---

## 3. 复现

```bash
node scripts/reachability.ts .   # 入口/可达性摘要（不写盘）
npm run wiring:check             # 入口完整 / 零入边落账 / 文档路径不悬空
npm run drift:check              # 不可达行等 13 项预算（只降不升）
```

---

## 4. 已知边界（宿主职责，不是内核缺口）

| 项 | 状态 | 说明 |
| -- | ---- | ---- |
| 摘要分发通道 | **宿主产品决定** | `signSummary()` 能签发、`AuditPacks.verify` 能验签；渠道由部署方选 |
| 交互式 OAuth | **宿主职责** | 浏览器授权码回环由宿主显式跑 `mcp auth`；`mcpAuthFlow` 是可用实现，不在启动时自动开回调 |
