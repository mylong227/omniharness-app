# 边界与分工（2026-11-02，收口版）

## 这个项目是什么

从 OmniHarness 切出的**独立内核**：`contracts`（契约）+ `kernel`（执行内核）+ `protocols`（协议）。
一句话定位：**可嵌入的 agent 内核：可审计、fail-closed、模型中立。**
OmniHarness 是它的第一个消费者。

## 当前状态（可复现判据）

| 判据 | 状态 | 怎么验 |
| ---- | ---- | ------ |
| `src/compat` 清零 | ✅ 目录已删除 | `Test-Path src/compat` → False |
| 内核不依赖应用层 | ✅ `src` 内零 `apps/` import | `rg "apps/" src` |
| 独立安装 | ✅ 实体 `node_modules` + `package-lock.json` | `npm ci` |
| 测试 | ✅ 248 文件 / 1200 用例全绿（契约只经公开入口；门禁变异自证 5 例）。上游 `@maturityEvidence` 判据已全部回迁：`L0-unverified` **0 件**（16 件补齐本仓判据后升 L1，见 AUDIT-2026-11-08 §7.4） | `npm test` |
| 契约零反向依赖 | ✅ 规则 1 归零 | `rg "from '\..*(kernel\|protocols)/" src/contracts` |
| 协议穿透收口 | ✅ 单一支撑面 | `npm run boundary:check` |
| 公开面 ≤60 | ✅ 60 / 60（M11 用 `createOmniKernel` 换下 `AgentFactory`，未超上限） | `npm run api:check` |
| headless 可跑 | ✅ 只用公开入口 | `node examples/headless.mjs` |
| `npm pack` 冒烟 | ✅ 空目录安装并跑通 | 见 §5 |
| 规划闭环 | ✅ 状态账与代码事实一致 | `npm run plan:check` |

> 这张表就是「切成功」的机检（原方案 §8）：删掉应用层后，内核仍能独立安装、启动、跑测试。
> **一键复现：`npm run verify`**（typecheck ×2 + boundary + arch + style + maturity + wiring + build +
> coverage + doc + stress + api + view + plan）。
> 本表只记**边界事实**；「下一版做什么、凭什么算做完」见 [ROADMAP.md](ROADMAP.md)（唯一规划源）。

## 目录

| 目录 | 行数（约） | 说明 |
| ---- | ---------- | ---- |
| `src/contracts` | 10.5K | ports / schema / errors / sdk —— 类型与端口为主 |
| `src/kernel` | 119K | 主循环、上下文、工具、门禁、审计、存储、编排、组合根 |
| `src/protocols` | 11.5K | ACP / MCP / AG-UI（A2A 协议树已于 2026-11-04 删除，历史见 §迁移记录） |
| `tests/` | — | 从应用仓库筛出的纯内核用例（无 CLI / Web 夹具） |
| `scripts/` | — | `build.mjs`（tsc + 资产复制）、`apiSurface.mjs`（公开面门禁） |
| `defaults/` | — | 随包发布的策略 / 厂商 / 限制数据 |
| `examples/` | — | 20 行 headless 示例 |

## `compat/` 清零记录

原 10 个「从应用层借来的共享件」全部下沉或删除，`src/compat` 已不存在：

| 原文件 | 去向 |
| ------ | ---- |
| `apps/server/core/jsonRpc.ts` | `kernel/rpc/jsonRpc.ts` |
| `apps/server/transport/lineTransport.ts` | `kernel/transport/lineTransport.ts` |
| `apps/server/transport/wsFrameCodec.ts` / `wsConnection.ts` | `kernel/transport/` |
| `apps/server/transport/serverAuthGuard.ts` | `kernel/security/serverAuthGuard.ts` |
| `apps/server/services/safeFs.ts` | `kernel/util/safeFs.ts` |
| `apps/cli/serveInstance.ts` | `kernel/util/serveInstance.ts` |
| `apps/composition/serviceKeys.ts` | `kernel/composition/serviceKeys.ts` |
| `apps/enterprise/oidcClient.ts` | **删除（2026-11-03）**：企业 SSO 属应用层；内核无一处引用，见下节「应用形状清零」 |
| `apps/tui/tuiRenderer.ts` | **删除**：内核只需要两个纯 ANSI 片段，已内联进 `ConsoleLiveView`（终端渲染留在应用层） |

另外两处切分时漏掉的「应用形状」也一并收口：

- `contracts/sdk/sdkClient.ts` → 曾下沉 `kernel/sdk/sdkClient.ts`，**2026-11-03 删除**：
  外部 SDK 客户端不是内核能力，且零引用（见下节）；
- `apps/composition/runtime.ts` → `kernel/composition/runtime.ts`：**内核自己的组合根**。
  没有它，`Agent` 只有端口没有装配，`import { Agent }` 无法独立构造——这是「内核独立存在」缺口。

## 应用形状清零（2026-11-03）

「切出来」只保证内核能独立跑，不保证内核里只剩内核。第二遍按**谁会用**清理了一遍，
把「应用领域」的残留整体删除（编译与全量测试为裁判，无一处被引用）：

| 删除项 | 为什么不是内核 |
| ------ | -------------- |
| `contracts/ports/tui/`（3） | TUI 是应用层渲染，内核只提供事件流 |
| `contracts/ports/license/`（2） | 商业授权是应用/发行版概念 |
| `contracts/ports/server/audit{Format,Query}.ts`（2） | 审计导出格式属于 server 层；内核只保证事件可回放 |
| `contracts/ports/enterprise/`（5）+ `kernel/adapters/enterprise/`（3）+ `kernel/security/oidcClient.ts` | 企业 SSO 是应用能力；本轮连同端口实现整棵子树移除 |
| `kernel/sdk/sdkClient.ts` | 外部 SDK 客户端（零引用、不在公开面） |
| `contracts/schema/codeGenerator.ts` | 代码生成器属模型/应用工具链 |
| `defaults/cliHelp.json` | CLI 帮助文案（`omniharness exec`），随 CLI 留在应用仓库 |

合计 19 个文件、约 2.5K 行；`npm run verify` 与 `api:check`（59/60）不变。

## 依赖规则

```
apps ──▶ kernel ──▶ contracts
  │         │
  └────────▶└──────▶ protocols（可选反向：protocols ──▶ kernel 的公开入口）
```

1. **禁止回指**：`contracts` 不得 import `kernel`/`apps`；`kernel` 不得 import `apps`。
2. **禁止穿透**：应用不得 import `kernel/内部路径`，只能 `@omniharness/kernel`。
3. **契约纯净**：`contracts` 内不得出现 `fs` / `http` / `child_process` 等实现符号
   （机检：只许相对路径导入，`boundary:check` 规则 5 把守）。
4. **协议隔离**：`protocols` 不得 import `apps`；`kernel` 不得 import `protocols`
   （已声明例外仅两处：组合根 `kernel/composition` —— 装配层天然要构造协议实现类；
   `kernel/adapters/mcp` → `protocols/mcp` —— SDK 桥适配器）；`protocols` 取用内核能力
   **只经** `kernel/protocolsSupport.ts`（唯一支撑面，纯 re-export）。
   四条规则全部由 `npm run boundary:check` 机检把守（fail-closed）。

当前状态（2026-11-03）：`kernel → apps` 与 `contracts → kernel/protocols` 均**已清零**（规则 1 归零）。下沉方式：

- **limits**：类型族（`RuntimeLimitsConfig` 等 10 个接口）住 `contracts/ports/config/runtimeLimits.ts`，
  解析器与 fail-closed 语义（`RuntimeLimits.resolve`）留内核；
- **Spectrum**：契约唯一声明本就在 `contracts/ports/util/spectrum.ts`，3 个 memory 端口改直引，
  删除 `eigenspectrum.ts` 的再导出别名（单一引入路径）；
- **A2A**：`a2aProtocol.ts`（纯类型 + 方法名/错误码常量）与 `TaskHandler` 移入 `contracts/ports/a2a/`，
  新增 `A2aServerPort` / `A2aClientPort` 端口——`OmniHarnessRuntime.a2a` 只认端口，
  实现类（`A2aServer` / `A2aClient`）在 protocols 侧 `implements`。

穿透已收口（2026-11-03）：`protocols` 的 76 条散点 kernel import 收敛为唯一支撑面
`kernel/protocolsSupport.ts`（30 个文件改走该边；纯 re-export、零逻辑；`npm run boundary:check` 把守）。
支撑面已收窄（同日）：协议桥符号（`Agent` / `subagentRuntimeFactory` / `SubagentPorts` /
`FilteredToolPort` / `MUTATING_TOOLS` / `RegistryToolPort`）移出支撑面——生产默认挪到
`kernel/composition/a2aBridge.ts`（经 a2aTaskExecutor 的 `buildSubagent` / `runTask` /
`filterTools` 注入缝装配，**fail-closed 工具收窄策略留在协议层**、机制注入），协议层改认
contracts 端口（`AgentPort` 扩展 `eventsOf` / `cancelCurrentRun` / 可选 `sessionId`；
新增 `ToolRegistryPort`）。现支撑面 **23 个符号 = 17 值 + 6 类型**，全部为基础设施，
协议层对 `core` / `subagent` 的感知归零。

> 后续（2026-11-04 / M9）：`kernel/composition/a2aBridge.ts` 随 A2A 协议树删除；
> 其名下的 `FilteredToolPort` 无任何调用方（子代理侧等价实现是 `subagent/toolSubset.ts`），
> M9 接线审计将其删除。2026-11-08 增 `ErrorMessage`（McpClient 结构化错误面）；
> 2026-11-09 增 `KernelTexts`（协议层统一文案出口，避免直插 `kernel/util`）。
> 现支撑面 **23 个符号 = 17 值 + 6 类型**（`wiring:check` + `boundary:check` 把守）。

## 适配器归属裁决（2026-11-03，授权自主裁决；同日执行 laya 迁出）

四组「应用形状」适配器按**保留内核 + 标 `@beta`** 收口。**`adapters/laya` 已于 2026-11-03 执行迁出**
（应用仓库保留同名实现；内核改由配置项 `decisionEnginePort` 注入，`mode` 非 off 却未注入即启动报错）：
其余三组标注不变，`rg -l "@beta 归属裁决" src/kernel/adapters/user src/kernel/adapters/monitoring src/kernel/adapters/live`
共 9 文件（`m3-adapters-beta-marked` 机检）：

| 组 | 规模 | 裁决 | 理由与迁移路径 |
| -- | ---- | ---- | -------------- |
| `adapters/laya` | ~~9 文件 / 约 1.1K 行~~ | **✅ 已迁出（2026-11-03）** | 第三方 venv 绑定（厂商集成），不属于内核长期面。实现已回到应用仓库；内核只保留 `DecisionEngineConfig` + `decisionEnginePort` 注入缝，不内置厂商实现 |
| `adapters/user` | 3 文件 | **@beta，保留** | `UserResponder` 端口的默认实现（console / default / memory），与 MockModel 同类的零依赖默认件 |
| `adapters/monitoring` | 3 文件 | **@beta，保留观察** | 实验算子（`@maturity L0`），被 config / spark 内部装配；未上公开面，等对抗集验证后再定去留 |
| `adapters/live` | 3 文件 | **@beta，保留** | `ToolInputSink` 端口的默认实现（console / composite / web），零依赖 |

纪律：这三组目录的符号**不得**进入 `src/index.ts` 公开面（`npm run api:check` 把守）；
组内任何导出变更按破坏性变更对待（alpha 本不承诺兼容，`@beta` 额外标注「实现可能整体迁移」）。

## 公开面（60 / 60）

`src/index.ts` 是唯一稳定入口，只 re-export 两个桶：

- `src/contracts/index.ts`：30 个端口 / 类型 / 错误（零实现，新增 `RuntimeLimitsConfig`）；
- `src/kernel/index.ts`：26 个组合根、主循环、默认适配器；另有 `createOmniKernel`（M11）与
  3 个回执运行时符号从 `src/index.ts` 直接导出。`AgentFactory` 于 M11 下沉为内部件
  （构造 `Agent` 直接 `new Agent(runtime)` 即可），为 `createOmniKernel` 腾出第 60 个符号位。

需要「一次装好全部能力」时用顶层 `createOmniKernel`；`@omniharness/kernel/embed` 只承载
它的完整选项/句柄**类型**（同一实现），不另算顶层符号。`wiring:check` 把两者都作为显式入口。

`npm run api:check` 用 TypeScript AST 统计 `export *` 展开后的真实符号数，超 60 即红。
新增导出的纪律：先写「谁会用」，再决定放顶层还是子路径。

## 迁移桥（2026-11-03 起；alpha.9 起**通配已删、改为显式闭包**；alpha.10 起**生成器解析源 = 承诺面**）

> 状态（2026-11-07，M21 全部落地 / M26 终盘收编）：`"./*.js"` / `"./*"` 通配已删除——内部路径不再自动
> 公开。现状：`exports` 显式列出 **324 条深路径闭包** + **11 个 curated 子路径**（唯一已知消费者
> OmniHarness-app 的全部实际导入 + M26 预置承诺，由 `scripts/exportsClosure.mjs` 从应用源码生成，
> curated 子路径保留；M26 起「应用消费点改写前置」成为常态——内核先把迁移能力的深路径列入
> 承诺，应用升级时改写导入）。
> 双向机检防漂移：内核侧每条导出必须指向存在的 dist 产物（`plan:check`
> `m21-explicit-exports`）；应用侧实际导入 ⊆ 显式清单（app `kernel:check`）——新增消费
> 未列条目或内核删条目，都在 install/CI 期红。应用域生成器解析源 = 本承诺清单
> （exports 第一优先 + dist 回退黄标，M21 Phase 3）。

`package.json#exports` 的深路径条目（alpha.4 起通配、alpha.9 起显式）。背景：第一个消费者
从「内嵌内核副本」迁到包依赖——应用已完成 6,529 处导入重写、删除 1,914 个文件 /
**143,883 行**重复副本，全部包导入收敛于其 17 个生成域文件。

约束：

- 顶层 60 符号仍是**唯一稳定面**；子路径与深路径不承诺兼容（能力语义稳定，路径按
  alpha 纪律可变），新代码不得依赖内部路径；
- 深路径条目是**生成产物**：应用消费变化时跑 `OMNI_APP_ROOT=… node scripts/exportsClosure.mjs`
  重新生成；手工增删无效（下次生成即对账）；
- 逐域 barrel 化是**可选优化**（不设时间表）：某域深路径数量过阈值且语义稳定时逐域评估
  （[RESEARCH-2026-11C.md](RESEARCH-2026-11C.md)）；
- 历史：分支迁移路径的「75 个测试文件待分流」工作项随 vendored 路径收口而消失
  （应用 tests 对内核深路径导入实测为 0，2026-11-07 全量扫描）。
- **curated 子路径是稳定入口**（2026-11-08 补充）：`./sandbox` / `./mcp` / `./agui` /
  `./maintenance` 这类装配面的 `.d.ts` 是**再导出桶**，桶里承诺的符号（`IsolationLadderFactory` /
  `SdkPreferredMcpConnector` / `SessionGc` / `TmpSweep` / `SessionStorageLocation`）与应用侧
  影子扫描都必须**穿透桶**解析——只扫 `export class` 直接声明会让整类承诺漏检。应用消费
  这类能力时落 curated 子路径，不必为它倒逼深路径承诺膨胀。

## 跨仓消费契约（2026-11-08 巡检 §6.3）

`npm run cross:check`（`verify` 末段）现在有**两层**，两层都 fail-closed：

| 层 | 对象 | 判据 | 缺仓语义 |
| -- | ---- | ---- | -------- |
| Rust 真源层 | 兄弟仓 `../omniharness`（`crates/omni-core`） | 真源 JSON 形状 / `build.rs` 真源解析 / `sandbox.rs` 结构规则 / `cargo test -p omni-core` | SKIP；`OMNI_CROSS_REPO_REQUIRED=1` 时失败 |
| TS 消费层 | `../omniharness-app`（或 `OMNI_APP_REPO`） | 钉定形态 `file:vendor/*.tgz` / 已安装版本 = 钉定 / 导入 ⊆ 内核 `exports` 且只经 `src/host/kernel/` / `src/host/extensions/**` 无已承诺同名实现（穿透再导出桶） | SKIP；显式设 `OMNI_APP_REPO` 或 `OMNI_APP_CONTRACT_REQUIRED=1` 时失败。CI 可用 `workflow_dispatch` 的 `app_repo` 输入显式 checkout（私有仓配 `APP_REPO_TOKEN`） |

为什么内核仓要管消费层：应用自己的 `kernel:check` 只能看到**已安装的包**，看不到内核工作树
（下一版）的承诺面。内核侧主动核对，才能在任何一次「删导出 / 改语义 / 应用长回影子」时先红，
而不是等消费者装包后 404。版本钉定落后于内核工作树只记 note（应用只能消费已发布 tag），
发版后跑 `kernel:vendor` 对齐。判据实现 `scripts/lib/appContractCheck.mjs`，用例
`tests/unit/appContractCheck.test.ts`（6 例）+ `tests/unit/crossRepoCheck.test.ts`（9 例）。

## 下一步（下一版）

规划与验收判据已迁到 [ROADMAP.md](ROADMAP.md)：M1 发布就绪已完成（`0.1.0-alpha.1` 可 `npm pack`
并在空目录安装），M2 是「第一个外部消费」（应用钉版本 + 全量回归），M3 是 beta 硬化。
本文件不再维护计划，只维护边界事实——避免同一件事写两遍。

## 与 OmniHarness 的关系

```
OmniHarness (应用)  ──依赖──▶  OmniKernel (本项目)
        │                          │
        └── CLI / Web / Desktop    └── contracts + kernel + protocols
```

- 应用可以随便改，内核不感知；
- 内核公开面只从 `src/index.ts` 出；
- 两边版本各自独立：内核发 `@omniharness/kernel`，应用钉版本；
- **交汇点**：内核每发一个 alpha，应用升一次依赖并跑一次全量回归；应用需要改内核内部时，先在内核开 issue。

## 复现

```bash
npm ci
npm run verify   # typecheck×2 + boundary + arch + style + maturity + wiring + build + coverage + doc + stress + api + view + plan
npm pack
```

切分脚本在应用仓库 `tools/extractKernel.mjs`（一次性）；重切后仍需重跑本文件的「compat 清零」与「测试筛选」两步。

