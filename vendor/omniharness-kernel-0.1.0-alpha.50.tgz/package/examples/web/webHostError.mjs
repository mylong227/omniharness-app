export class WebHostError extends Error {
  /**
   * @param {number} status HTTP 状态码。
   * @param {string} message 可行动说明。
   */
  constructor(status, message) {
    super(message);
    this.name = 'WebHostError';
    this.status = status;
  }
}
