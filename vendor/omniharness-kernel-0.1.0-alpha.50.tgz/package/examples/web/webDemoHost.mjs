import { WebHostError } from "./webHostError.mjs";
import { ScriptedAskModel } from "./scriptedAskModel.mjs";
/**
 * 宿主侧 SSE/Web 对接面（M74）——**应用形状，不属于内核导出面**。
 *
 * 内核已经提供 `WorkbenchServer`（SSE 直播 / state 投影 / answers 提问桥 / audit 复核），
 * 但「谁把 UI 端上去、谁提供启动任务的入口」是宿主职责（§8：内核不做体验层）。本文件就是
 * 那层最小宿主：
 *
 *  - `GET  /`、`/app.js`、`/styles.css`  静态 UI（EventSource 客户端）；
 *  - `GET  /api/config`                  告诉浏览器 workbench 地址与访问令牌；
 *  - `POST /api/tasks`                   `{prompt}` → 启动一次 `agent.runTask`，返回 sessionId；
 *  - 其余 `/api/sessions/:id/*` 直接走内核 `WorkbenchServer`（本文件不重复实现）。
 *
 * 诚实边界：演示用脚本模型（先 ask_user、再收尾）与 `PassthroughSandbox`/`AutoApproval`
 * 只适合本机演示；生产宿主应注入真实 `ModelPort` 与 fail-closed 的审批/沙箱。
 */
import { randomBytes } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

import { Agent, AutoApproval, ConfigFactory, MemoryStorage, PassthroughSandbox, Runtime } from '@omniharness/kernel';
import { WorkbenchServer } from '@omniharness/kernel/workbench';

const HERE = dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = join(HERE, 'public');
const BODY_LIMIT_BYTES = 1_048_576;

/** 静态资源 MIME 表（只服务本目录三个文件，不引入依赖）。 */
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
};

/** 静态 UI 服务器 + 任务入口。 */
export class WebDemoHost {
  /**
   * @param {object} [options] 宿主选项。
   * @param {string} [options.workspaceRoot] 工作区根（缺省当前目录）。
   * @param {number} [options.port] 静态 UI 端口（0 = 内核分配）。
   */
  constructor(options = {}) {
    this.workspaceRoot = options.workspaceRoot ?? process.cwd();
    /** @type {number} */
    this.requestedPort = options.port ?? 0;
    this.token = randomBytes(24).toString('base64url');
    this.model = new ScriptedAskModel();
    this.storage = new MemoryStorage();
    this.agent = undefined;
    this.runtime = undefined;
    this.workbench = undefined;
    this.workbenchPort = undefined;
    this.http = undefined;
    this.running = undefined;
    this.lastError = undefined;
  }

  /**
   * 启动宿主（内嵌 workbench + 静态 UI）。
   * @returns {Promise<{url: string, port: number, workbenchUrl: string, token: string}>} 监听信息。
   */
  async listen() {
    this.workbench = WorkbenchServer.create({
      storage: this.storage,
      http: { host: '127.0.0.1', port: 0, token: this.token },
      corsOrigin: 'loopback',
    });
    const workbenchAddress = await this.workbench.listen();
    this.workbenchPort = workbenchAddress.port;
    const config = ConfigFactory.build({
      workspaceRoot: this.workspaceRoot,
      maxSteps: 4,
      model: this.model,
      storage: this.storage,
      events: this.workbench.hub,
      userResponder: this.workbench.hub,
      approvals: new AutoApproval(),
      sandbox: new PassthroughSandbox(),
    });
    this.runtime = Runtime.createRuntime(config);
    this.agent = new Agent(this.runtime);
    await this.startStaticServer();
    const address = this.http.address();
    const port = typeof address === 'object' && address !== null ? address.port : this.requestedPort;
    return {
      url: `http://127.0.0.1:${String(port)}/`,
      port,
      workbenchUrl: `http://127.0.0.1:${String(workbenchAddress.port)}`,
      token: this.token,
    };
  }

  /**
   * 启动一次任务（同一宿主串行：已有在跑任务时 409）。
   * @param {string} prompt 用户任务文本。
   * @returns {string} 会话 id（UI 用它订阅 SSE）。
   * @throws {WebHostError} 空 prompt（400）或已有在跑任务（409）时抛出。
   */
  startTask(prompt) {
    if (typeof prompt !== 'string' || prompt.trim() === '') {
      throw new WebHostError(400, 'prompt 不能为空');
    }
    if (this.running !== undefined) {
      throw new WebHostError(409, '已有任务在跑（演示宿主串行执行；生产宿主应按 session 隔离）');
    }
    if (this.agent === undefined) {
      throw new WebHostError(503, '宿主尚未 listen');
    }
    this.model.reset();
    this.lastError = undefined;
    const sessionId = `sess-web-${Date.now().toString(36)}-${randomBytes(3).toString('hex')}`;
    const promise = this.agent
      .runTask(prompt, undefined, undefined, sessionId)
      .catch((error) => {
        this.lastError = error instanceof Error ? error.message : String(error);
        return undefined;
      })
      .finally(() => {
        this.running = undefined;
      });
    this.running = promise;
    return sessionId;
  }

  /**
   * 等待当前任务收尾（无任务时立即返回）。
   * @returns {Promise<void>} 任务结束（含失败）后 resolve。
   */
  async waitForIdle() {
    const current = this.running;
    if (current !== undefined) await current;
  }

  /** 关闭宿主（先取消在跑回合，再关 workbench / 静态服务器；幂等）。 */
  async close() {
    if (this.closePromise !== undefined) return this.closePromise;
    this.closePromise = this.doClose();
    return this.closePromise;
  }

  /** 实际关闭步骤（并发 close 共用同一个 promise）。 */
  async doClose() {
    this.agent?.cancelCurrentRun('shutdown');
    await Promise.race([
      this.waitForIdle(),
      new Promise((resolve) => setTimeout(resolve, 2_000)),
    ]);
    await this.workbench?.close();
    await this.runtime?.dispose?.();
    if (this.http !== undefined) {
      this.http.closeAllConnections?.();
      await new Promise((resolve) => this.http.close(() => resolve(undefined)));
    }
  }

  /** 建静态服务器（只绑定回环）。 */
  async startStaticServer() {
    this.http = createServer((request, response) => {
      this.handle(request, response).catch((error) => {
        const status = error instanceof WebHostError ? error.status : 500;
        this.sendJson(response, status, { error: error instanceof Error ? error.message : String(error) });
      });
    });
    await new Promise((resolve) => {
      this.http.listen(this.requestedPort, '127.0.0.1', () => resolve());
    });
  }

  /**
   * 路由分发。
   * @param {import("node:http").IncomingMessage} request 请求。
   * @param {import("node:http").ServerResponse} response 响应。
   * @returns {Promise<void>} 响应写完。
   */
  async handle(request, response) {
    const url = new URL(request.url ?? '/', 'http://127.0.0.1');
    if (request.method === 'GET' && url.pathname === '/api/config') {
      const port = this.http.address();
      const ownPort = typeof port === 'object' && port !== null ? port.port : this.requestedPort;
      this.sendJson(response, 200, {
        workbenchUrl: `http://127.0.0.1:${String(this.workbenchPort ?? 0)}`,
        token: this.token,
        ui: `http://127.0.0.1:${String(ownPort)}/`,
      });
      return;
    }
    if (request.method === 'GET' && url.pathname === '/api/health') {
      this.sendJson(response, 200, {
        ok: this.running === undefined,
        running: this.running !== undefined,
        lastError: this.lastError ?? null,
      });
      return;
    }
    if (request.method === 'POST' && url.pathname === '/api/tasks') {
      const body = /** @type {{ prompt?: string }} */ (await WebDemoHost.readJsonBody(request));
      const sessionId = this.startTask(/** @type {string} */ (body.prompt));
      this.sendJson(response, 202, { sessionId });
      return;
    }
    if (request.method === 'GET') {
      await this.serveStatic(url.pathname, response);
      return;
    }
    this.sendJson(response, 405, { error: '方法不支持' });
  }

  /**
   * 服务静态资源（仅 public 目录内固定三文件；路径穿越一律 404）。
   * @param {string} pathname 请求路径。
   * @param {import("node:http").ServerResponse} response 响应。
   * @returns {Promise<void>} 响应写完。
   */
  async serveStatic(pathname, response) {
    const file = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/u, '');
    if (!Object.hasOwn(MIME, `.${file.split('.').pop() ?? ''}`) || file.includes('..') || file.includes('/')) {
      this.sendJson(response, 404, { error: 'not found' });
      return;
    }
    try {
      const content = await readFile(join(PUBLIC_DIR, file));
      const type = MIME[`.${file.split('.').pop() ?? ''}`];
      response.writeHead(200, { 'content-type': type, 'cache-control': 'no-store' });
      response.end(content);
    } catch {
      this.sendJson(response, 404, { error: 'not found' });
    }
  }

  /**
   * 读 JSON 请求体（1 MiB 上限，坏 JSON 400）。
   * @param {import("node:http").IncomingMessage} request 请求。
   * @returns {Promise<Record<string, unknown>>} 解析后的对象。
   */
  static async readJsonBody(request) {
    const chunks = [];
    let total = 0;
    for await (const chunk of request) {
      total += chunk.length;
      if (total > BODY_LIMIT_BYTES) {
        throw new WebHostError(413, '请求体超过 1 MiB');
      }
      chunks.push(chunk);
    }
    try {
      return JSON.parse(Buffer.concat(chunks).toString('utf8'));
    } catch {
      throw new WebHostError(400, '请求体不是合法 JSON');
    }
  }

  /**
   * 发送 JSON 响应。
   * @param {import("node:http").ServerResponse} response 响应。
   * @param {number} status 状态码。
   * @param {unknown} value 载荷。
   * @returns {void}
   */
  sendJson(response, status, value) {
    if (response.headersSent) return;
    response.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    response.end(`${JSON.stringify(value)}\n`);
  }
}
