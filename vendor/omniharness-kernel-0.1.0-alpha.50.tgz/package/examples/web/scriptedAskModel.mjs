export class ScriptedAskModel {
  /** 适配器名（与 ModelPort 契约同形）。 */
  name = 'scripted-web-ask';
  /** 当前步（1 = 提问，≥2 = 收尾）。 */
  step = 0;

  /** 重置步数（宿主开始新任务时调用）。 */
  reset() {
    this.step = 0;
  }

  /**
   * 生成脚本化响应。
   * @param {{messages?: readonly {content: string}[]}} request 模型请求。
   * @returns {Promise<object>} 工具调用或最终文本。
   */
  async generate(request) {
    this.step += 1;
    if (this.step === 1) {
      return {
        toolCalls: [
          {
            id: 'web-ask-1',
            name: 'ask_user',
            arguments: {
              questions: [
                {
                  id: 'env',
                  question: '部署到哪个环境？',
                  options: [{ label: 'A（推荐）' }, { label: 'B' }],
                },
              ],
            },
          },
        ],
      };
    }
    const sawAnswer = JSON.stringify(request.messages ?? []).includes('A');
    return { text: sawAnswer ? '完成：已按用户选择 A 部署。' : '完成（未收到选择——提问桥断了）。' };
  }
}
