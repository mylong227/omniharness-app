# API

> 对象：把 OmniKernel 嵌进宿主进程、为它造 UI、或对它的执行做离线复核的开发者。
> 口径：签名与行为以本仓源码为准；顶层 60 符号由 golden 快照锁定（`npm run api:check`），子路径不承诺
> 兼容（见 [BOUNDARY.md](BOUNDARY.md)）；端到端脚本见 [examples/embed.mjs](../examples/embed.mjs)、[examples/headless.mjs](../examples/headless.mjs)。

## 1. 安装与最小示例

```bash
npm i @omniharness/kernel     # Node.js ≥ 22.14（engines 声明）
node examples/embed.mjs       # 一次接入全部能力
node examples/headless.mjs    # 手动挑端口接线
```

仓库内跑示例先 `npm run build`：示例用包名 `@omniharness/kernel` 自引用 `dist/`。

### 1.1 一次接入：`OmniKernel.create` 六行装配

```js
import { mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { AutoApproval, MemoryStorage, MockModel, OmniKernel, PassthroughSandbox } from '@omniharness/kernel';

const kernel = await OmniKernel.create({
  workspaceRoot: await mkdtemp(join(tmpdir(), 'omni-embed-example-')),
  model: new MockModel(),            // 生产换 OpenAiCompatibleModel / AnthropicModel / 自实现 ModelPort
  storage: new MemoryStorage(),      // 生产换 JsonlStorage(dir) 或自实现 StoragePort
  approvals: new AutoApproval(),     // 生产换 RuleApproval；不传落 DenyApproval（fail-closed）
  sandbox: new PassthroughSandbox(), // 生产不传：内核探测 OS 隔离，探测不到落 PolicySandbox 并告警
  receipts: { persist: true },       // 回执链落盘（<workspace>/.omniharness/receipts）
});

try {
  const result = await kernel.runTask('用一句话介绍自己');
  console.log(result.finalText, kernel.capabilities().receipts?.count ?? 0); // 文本 + 已入链回执数
} finally {
  await kernel.close(); // 幂等：取消在跑回合 → 有界 drain → 关 MCP/工作台 → 落完回执
}
```

`examples/embed.mjs` 与上例同形，另带 `maxSteps: 4`。`create` 还负责工作台 / MCP / 遥测 / 执行证书的装配
（各自有显式开关，未开启即零开销），并代理 `runTask` / `resume` / `fork` / `cancel`。

### 1.2 手动接线：`ConfigFactory` + `Runtime` + `Agent`

```js
import { mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import {
  Agent, AutoApproval, ConfigFactory, MemoryStorage, MockModel, PassthroughSandbox,
  Runtime, SilentEventPort,
} from '@omniharness/kernel';

const config = ConfigFactory.build({
  workspaceRoot: await mkdtemp(join(tmpdir(), 'omni-kernel-example-')),
  maxSteps: 4,
  model: new MockModel(),
  storage: new MemoryStorage(),
  events: new SilentEventPort(),
  approvals: new AutoApproval(),
  sandbox: new PassthroughSandbox(),
});
const result = await new Agent(Runtime.createRuntime(config)).runTask('用一句话介绍自己');
console.log(result.finalText);
```

与 `create` 的差别：手动接线只有主循环；工作台、MCP、回执、遥测、执行证书需自行装配（§3）。

## 2. 语义子路径与顶层公开面

### 2.1 稳定语义入口

除顶层 60 符号外，应用优先使用 curated 子路径（每个都是纯再导出桶）；完整 16 条清单见 §3。

深路径闭包已移除：`exports` 只剩 18 条（2 根 + 16 curated）；应用 248 条导入已全部迁到
`contracts` / `adapters` / `runtime` / `protocols` 四个语义桶。`npm run consumer:check` 钉住
剩余 9 条导入（4 桶 + 5 curated），只降不升。

## 2.2 顶层公开面（60 符号）

清单来自 `node scripts/apiSurface.ts`，按职责分组，每符号一句话。

**组合根（11）**
- `OmniKernel` — 一次装配全部宿主侧能力的句柄类，`create(input)` 是唯一入口。
- `Runtime` — `createRuntime(config)` 把已解析配置装配成运行时端口集合。
- `ConfigFactory` — `build(partial)` 填默认端口 / 预算 / 模型，产出 `ResolvedConfig`（唯一配置解析点）。
- `ResolvedConfig` — 全部端口已填默认的已解析配置（`extends OmniHarnessConfig`）。
- `OmniHarnessConfig` — 用户可写配置面，`ConfigFactory.build` 的入参。
- `OmniHarnessRuntime` — 运行时端口集合（model / tools / storage / events / sandbox / approvals / gate …）。
- `OmniHome` — 用户级归属根解析：显式值 > `OMNI_HOME` > `~/.omniharness`。
- `BuiltinDefaults` — `defaults/*.json` 加载器；文件缺失即抛（安全默认档不可静默变空）。
- `RuntimeLimitsConfig` — `limits` 段：HTTP / 预览 / 工具族 / 维护的超时、并发与体积上限。
- `API_VERSION` — 当前 API 版本字符串常量。
- `ApiVersion` — 版本常量的字面量类型。

**主循环与错误（7）**
- `Agent` — 事件溯源回合执行器：runTask / resume / fork / eventsOf / cancelCurrentRun。
- `AgentPort` — 主循环端口契约（adapters 与协议桥只依赖它）。
- `AgentResult` — 单次结果：sessionId、steps、finalText、truncated / aborted、persisted。
- `OmniError` — 带稳定 `code` 的基类错误，所有可分类错误都继承它。
- `ErrorCode` — 稳定错误码目录（`CONFIG_ERROR` / `MODEL_CALL_ERROR` / `BUDGET_EXCEEDED` …）。
- `ModelCallError` — 模型调用失败（status、retryable、retryAfterMs、responseBody）。
- `BudgetExceededError` — 成本硬预算耗尽熔断（limitUsd、spentUsd、model）。

**端口（20）**
- `ModelPort` — 模型插口：`name` + `generate`（可选 `stream`）。
- `ModelRequest` — 一次模型请求（messages、tools、responseFormat、signal …）。
- `ModelMessage` — 对话消息（role + content + images / files / toolCalls / reasoning）。
- `ModelOutput` — 模型产出（reasoning、text、toolCalls、usage、finishReason）。
- `ModelUsage` — token 用量（prompt / completion / total，含缓存命中与写入字段）。
- `ToolPort` — 工具插口：list / execute（可选 unregister / listDirect / lastFailure）。
- `ToolDefinition` — 工具定义（name、description、parameters、deferred）。
- `ToolCall` — 模型发起的调用（id、name、arguments、parseError）。
- `ToolContext` — 执行上下文（sessionId、workspaceRoot、signal、delegation、ctxIsolation）。
- `ToolResult` — 执行结果（callId、ok、output / error、files、exitCode、errorCode）。
- `ToolInputSink` — 工具参数流式观察端口（UI 实时渲染，不进事实日志）。
- `StoragePort` — 会话事件持久化插口（save / load + 可选 append / listSessions / withSessionLock）。
- `KvPort` — 通用键值插口（get / set / delete / has / keys / list / close）。
- `ApprovalPort` — 审批插口：`decide(request)`。
- `ApprovalRequest` — 审批请求（sessionId、toolName、target、args、source）。
- `ApprovalDecision` — 裁决取值：`'allow' | 'deny'`。
- `SandboxPort` — 沙箱插口：check + 可选 wrapCommand / wrapArgv。
- `EventPort` — 事件出口：emit + 可选 flush。
- `SessionEvent` — 会话事件信封（append-only 事实日志的单位）。
- `EscalationPort` — 提权审批插口：沙箱拒绝后裁决 escalate / abort。

**默认适配器（15）**
- `MockModel` — 演示模型：首步返回 shell 工具调用，之后返回固定文本（零 API Key）。
- `OpenAiCompatibleModel` — OpenAI 兼容 chat/completions 客户端（DeepSeek / OpenAI / 自建网关）。
- `OpenAiCompatibleConfig` — 其配置（baseUrl、apiKey、model、requestTimeoutMs）。
- `AnthropicModel` — Anthropic Messages API 客户端（缓存断点 + thinking 块）。
- `AnthropicModelConfig` — 其配置（baseUrl、apiKey、model、maxTokens …）。
- `MemoryStorage` — 进程内会话存储（name `memory`，不落盘）。
- `JsonlStorage` — 每会话一个 `.jsonl` 文件的存储（name `jsonl`，可观测可回放）。
- `SilentEventPort` — 丢弃全部事件的出口（name `silent`）。
- `AutoApproval` — 全放行（name `auto`，仅演示 / 测试）。
- `DenyApproval` — 全拒绝（name `deny`，库级缺省）。
- `RuleApproval` — 规则集审批：deny 优先 → ask → allow → 默认决策（缺省 deny）。
- `RuleApprovalOptions` — 其选项（rules、defaultDecision、askHandler、glob）。
- `PassthroughSandbox` — 零隔离（name `passthrough`，仅演示）。
- `PolicySandbox` — 危险命令黑名单 + 工作区白名单（name `policy`；策略层，不是隔离）。
- `PolicySandboxOptions` — 其选项（workspaceRoot、extraPatterns）。

**回执与审计（7）**
- `ReceiptChain` — 单 issuer 线性回执链：append / length / export / tailHash / summary / signSummary。
- `ReceiptPayload` — 链式哈希的输入（receiptId、issuerId、seq、previousReceiptHash、action）。
- `ActionReceipt` — 回执信封 `{ payload, signature, anchors }`；未签名即 `signature: null`。
- `AuditPack` — 交换格式：`{ issuerId, exportedAt, receipts }`。
- `AuditPacks` — 离线复核器：`verify(pack, trustStore?, expected?, anchorTrust?)`。
- `AuditPackVerdict` — 复核结论（ok / compliant / signatureChecked / problems / verdicts）。
- `JoseReceiptSigner` — EdDSA 回执签名器：`create({ kid, privateKey? })`、`publicSpki()`。

## 3. 子路径入口（16 个 curated + 根）

| 子路径 | 用途 | 典型导入 |
| --- | --- | --- |
| `@omniharness/kernel` | 稳定面：主循环、组合根、默认适配器、回执核心 | `import { OmniKernel } from '@omniharness/kernel'` |
| `/contracts` | 常用端口与配置类型桶 | `import type { ResolvedConfig } from '@omniharness/kernel/contracts'` |
| `/adapters` | 可选适配器桶（模型/沙箱/存储/审批/事件/遥测） | `import { OpenAiCompatibleModel } from '@omniharness/kernel/adapters'` |
| `/runtime` | 内核运行时桶（core/context/config/plugin/evolution/autonomy/util） | `import { NativeKernel } from '@omniharness/kernel/runtime'` |
| `/protocols` | MCP / ACP / AG-UI 协议桶 | `import { McpServer } from '@omniharness/kernel/protocols'` |
| `/embed` | `create` 的完整选项 / 句柄**类型面** | `import type { OmniKernelInput } from '@omniharness/kernel/embed'` |
| `/tools` | 内置工具实现（真实系统注入自己的 ToolPort） | `import { ShellTool } from '@omniharness/kernel/tools'` |
| `/receipts` | 回执完整面：签发、锚定、JCS、执行证书 / 图 / 包 / 披露 | `import { AatExporter, Jcs } from '@omniharness/kernel/receipts'` |
| `/sandbox` | OS 级隔离后端（Landlock / bwrap / Seatbelt / Windows）与能力表 | `import { SandboxCapabilityTable } from '@omniharness/kernel/sandbox'` |
| `/governance` | 出处出证、策略快照、记忆治理、长期运行遥测 | `import { ProvenanceIssuer } from '@omniharness/kernel/governance'` |
| `/mcp` | MCP 服务端 HTTP/stdio 装配 + 客户端连接桥 | `import { McpHttpAssembly } from '@omniharness/kernel/mcp'` |
| `/agui` | AG-UI 事件映射与 HTTP/SSE 端点（runner 由宿主注入） | `import { AgUiHttpServer } from '@omniharness/kernel/agui'` |
| `/workbench` | 工作台服务器 + 事件/提问双端口 Hub（宿主进程，依赖 `node:http`） | `import { WorkbenchServer } from '@omniharness/kernel/workbench'` |
| `/workbench-view` | 纯投影（零 `node:`，浏览器可打包） | `import { SessionProjector } from '@omniharness/kernel/workbench-view'` |
| `/maintenance` | 会话保留 / 临时产物清扫 / serve 实例记录 / 巡检编排 | `import { MaintenanceRunner } from '@omniharness/kernel/maintenance'` |
| `/eval` | 模型能力探针、注入指标、可靠性报告、轨迹评分 | `import { ReliabilityReports } from '@omniharness/kernel/eval'` |
| `/omniError.js` | 错误目录兼容入口（实现与顶层 `OmniError` 同源） | `import { OmniError } from '@omniharness/kernel/omniError.js'` |

## 4. 配置

`OmniHarnessConfig` 是唯一用户可写配置面，且**只在组合根解析一次**：`ConfigFactory.build(partial)` →
`ResolvedConfig`（端口与默认值全部就位），此后各层只读已解析结果；`OmniKernel.create(input)` 先把顶层
旋钮（workspaceRoot / model / storage / approvals / sandbox / maxSteps）取走，再把 `input.config` 透传进同一解析器。

`OmniKernel.create()` 默认会话与未指定路径的长期记忆只保存在内存；需要重启恢复时
显式注入持久存储和记忆路径。`/adapters` 导出 `EncryptedStorage`，加密 payload 并保持
后端追加锁语义；解密迁移需显式允许旧明文。

**默认 fail-closed**（不配置也不放开）：
- 审批缺省 `DenyApproval`；提权缺省 `DenyEscalation`（不提权）。
- 沙箱缺省**探测** OS 级隔离；探测不到落 `PolicySandbox` 并 warn「策略层不是隔离」，不静默当成已隔离。
- 未知键 / 类型越界 → `CONFIG_ERROR` 启动即失败，不静默忽略。
- 一次接入另开三档审计默认：`auditRecords: true`、`effectJournal: true`、`ctaMode: 'shadow'`（可显式关）。

常用字段（35 个键；全量见 `src/contracts/ports/config/omniHarnessConfig.ts`）：

| 组 | 字段 |
| --- | --- |
| 模型 | `model`、`fallbackModel`、`reasoning`、`modelRouter`、`modelRetry`、`costBudgetUsd` |
| 存储 | `storage`、`spillAdapter`、`toolCache` |
| 审批 | `approvals`、`escalation`、`elevatedSandbox`、`approvalCache`、`rbac` |
| 沙箱 | `sandbox`、`promptInjectionGuard`、`capflow` |
| 上下文 | `maxSteps`、`toolCallTimeoutMs`、`compactionMaxTokens`、`compactionKeepRecent`、`deferredTools` |
| 记忆 | `longTermMemory`、`memoryConsolidate`、`semanticRecall` |
| 协议 | `mcpServers`、`agentIdentity`、`delegation` |
| 回执 | `auditRecords`、`auditPrincipal`、`effectJournal`、`ctaMode` |
| 遥测 | `runtimeTelemetry` |
| 插件 | `plugin`、`capability` |

## 5. 端口契约速查

签名照 `src/contracts/ports/` 原文；可选方法用 `?` 标注。

```ts
interface ModelPort {
  readonly name: string; generate(request: ModelRequest): Promise<ModelOutput>;
  stream?(request: ModelRequest, callbacks: StreamCallbacks): Promise<ModelOutput>;
}
interface ToolPort {
  readonly name: string;
  list(): readonly ToolDefinition[];
  execute(call: ToolCall, context: ToolContext): Promise<ToolResult>;
  unregister?(name: string): boolean; listDirect?(): readonly ToolDefinition[];
  lastFailure?(sessionId: string): string | undefined;
}
interface StoragePort {
  readonly name: string; readonly location?: string;
  save(sessionId: string, events: readonly SessionEvent[]): Promise<void>;
  load(sessionId: string): Promise<readonly SessionEvent[]>;
  append?(sessionId: string, events: readonly SessionEvent[], fromCount: number): Promise<void>;
  writeSummary?(sessionId: string, events: readonly SessionEvent[]): Promise<void>;
  listSessions?(): Promise<readonly string[]>;
}
interface SandboxPort {
  readonly name: string; check(action: SandboxAction): Promise<SandboxDecision>;
  wrapCommand?(command: string, cwd: string): string;
  wrapArgv?(argv: readonly string[], cwd: string): { readonly bin: string; readonly args: string[] };
}
interface ApprovalPort { readonly name: string; decide(request: ApprovalRequest): Promise<ApprovalDecision>; }
interface EscalationPort { readonly name: string; decide(request: EscalationRequest): Promise<EscalationDecision>; }
interface EventPort { readonly name: string; emit(event: SessionEvent): void; flush?(): Promise<void>; }
interface UserResponder { // @beta
  readonly name: string; cancelPending?(sessionId: string): boolean;
  ask(questions: readonly AskQuestion[], context?: AskContext): Promise<readonly AskAnswer[]>;
}
interface RetrievalPort { // @beta
  readonly name: string; remove?(ids: readonly string[]): number;
  index(doc: RetrievalDoc): void; retainSession?(sessionId: string): void; releaseSession?(sessionId: string): void;
  search(query: string, limit: number, sessionId?: string): readonly RetrievalHit[];
}
```

`UserResponder` 类型经 `@omniharness/kernel/contracts` 取；`RetrievalPort`
未开 deep export，只能按结构化对象注入 `config.retrieval`（`{ name, index, search }`）。配套类型
（`SandboxAction` / `SandboxDecision`）在 `@omniharness/kernel/contracts`。

## 6. 错误与取消

```ts
class OmniError extends Error { readonly code: ErrorCodeValue; }        // 基类：稳定码 + 消息
const ErrorCode = { CONFIG_ERROR, MODEL_CALL_ERROR, BUDGET_EXCEEDED, CIRCUIT_OPEN, PERMISSION_DENIED,
  WORKFLOW_CYCLE, WORKFLOW_SPEC, NATIVE_KERNEL_UNAVAILABLE, EGRESS_BLOCKED, MEDIA_FORMAT_ERROR, UNKNOWN } as const;
class ModelCallError extends OmniError { status?; retryable; retryAfterMs?; responseBody? }
class BudgetExceededError extends OmniError { limitUsd; spentUsd; model }
```

- `OmniError` / `ErrorCode` / 两个子类都在顶层，可 `instanceof` 与按 `code` 分支；新增错误码只追加不改值。
- `CancelledError`（`reason` = `'user' | 'timeout' | 'loop-guard' | 'shutdown' | 'parent' | { custom }`）由主循环
  在步边界与在飞请求中断时抛出；它**不在公开面**，catch 侧按形状识别（`instanceof` 或
  `error.name === 'CancelledError'`，跨包 / 跨 realm 后者才可靠；`AgentResult.aborted` 是同一事实的机读出口）。
- 取消语义：`kernel.cancel(reason = 'user', sessionId?)` 代理 `agent.cancelCurrentRun(reason, sessionId?)`；不传
  `sessionId` 即**取消全部在跑会话**（服务端 / 协议桥必须显式传，否则并发回合误伤）。已产生事件仍会落盘，
  回合以 `aborted: true` 收尾而非抛给宿主。
- `BudgetExceededError` 之后同一预算下的模型调用继续 fail-closed 阻断，直到预算口径改变；`close()` 先
  `cancelCurrentRun('shutdown')` 再有界 drain（缺省 10s，`drainTimeoutMs` 可调）。

## 7. 回执 / 审计公开 API

```ts
class ReceiptChain {
  static readonly GENESIS: string;                      // 全零创世哈希
  static hashOf(payload: ReceiptPayload): string;        // SHA256(utf8(JCS(payload)))
  constructor(options: { issuerId: string; signer?: ReceiptSigner; anchor?: AnchorPort; now?: () => string;
    retentionDays?: number; previous?: readonly ActionReceipt[]; previousPath?: string;
    persistPath?: string; hotWindow?: number });
  append(request: ReceiptAppendRequest): Promise<ActionReceipt>;
  length(): number; cachedCount(): number; export(): readonly ActionReceipt[];
  tailHash(): string; summary(): ReceiptChainSummary; signSummary(): Promise<SignedReceiptSummary>;
}
class AuditPacks {
  static verify(pack: AuditPack, trustStore?: TrustStore, expected?: AuditPackExpectation | SignedReceiptSummary,
    anchorTrust?: Rfc3161TrustInput): AuditPackVerdict;
  static verifyFile(path: string, issuerId: string, trustStore?: TrustStore,
    expected?: AuditPackExpectation | SignedReceiptSummary, anchorTrust?: Rfc3161TrustInput): AuditArchiveVerdict;
}
class JoseReceiptSigner {
  readonly kid: string; readonly alg: 'EdDSA';
  static create(options: { kid: string; privateKey?: KeyObject | Uint8Array }): Promise<JoseReceiptSigner>;
  publicSpki(): string;                                 // SPKI PEM，登记进信任根
  sign(payloadBytes: Uint8Array): Promise<Uint8Array>;
}
```

复核读法：`ok` = 结构 / 链 / 验签全过（空包恒 false）；`compliant` 再叠加「全部锚定已验签」；不给
`trustStore` 时 `signatureChecked: false`（「没查」不说成「查过」）。线性链只能检出中间篡改：要检出尾条
改写 / 尾截断，必须把 `{ receiptCount, tailHash }` 从带外可信通道作为 `expected` 传入。

`kernel.receipts`（`receipts: false` 时为 `undefined`）：

```js
const handle = kernel.receipts;              // receipts: false 时为 undefined
await handle.flush();                        // 等在途回执入链（导出前必做）
const pack = handle.pack();                  // { issuerId, exportedAt, receipts }
const files = await handle.exportBundle();   // pack.json + trust.json (+ summary.json)
console.log(files.directory, AuditPacks.verify(pack, handle.trustStore()).ok);
```

`OmniKernel` 的三个导出方法（**落盘并返回文件路径**，缺省目录在 `<workspace>/.omniharness/`）：

```ts
exportAuditBundle(sessionIds: readonly string[], directory?: string,
  delivery?: AuditDeliveryOptions,             // 交付编码：gzip / 口令加密 / 分片（manifest + parts）
  reliability?: ReliabilityReport,             // 可选：摘要写入包级 reliability
  options?: { timeline?: boolean }): Promise<OmniKernelAuditBundle>;
exportAat(sessionId: string, directory?: string,
  reliability?: ReliabilityReport): Promise<OmniKernelAatBundle>;  // 先自检 AAT，结论不过即抛
exportDisclosurePack(selections: readonly { sessionId: string; indices: readonly number[] }[],
  directory?: string): Promise<OmniKernelDisclosurePack>;          // 只交选中事件 + 包含证明
```

`exportAuditBundle` / `exportDisclosurePack` 需要回执签名器（`receipts` 未开或 `sign: false` 时抛出可行动
错误）；`exportAat` 只需会话事件。证据类型面在 `/receipts`（`AuditBundles`、`DisclosurePacks`、`AatExporter`）。

## 8. 兼容性

- **顶层 60 符号不变**：新增 / 删除 / 改名都要显式 `node scripts/apiSurface.ts --update-golden` 并记
  CHANGELOG；`npm run api:check` 比对 golden 快照，超限或漂移即红。
- **子路径**：根入口是唯一兼容承诺面；16 条 curated 子路径是公开语义入口（不承诺内部实现兼容），
  深路径闭包为 0。应用只能经 `src/host/kernel/` 对接面导入，`cross:check` 核对钉定形态、安装一致与导入闭包。
- `exports` 子路径条数被 `npm run drift:check` 的 `pkg.subpaths` 指标计量，预算只降不升；端口只增可选方法（`?`）以保持既有实现可用，新增**必选**方法属于破坏性变更。

### HTTP 操作授权与硬预算

AG-UI 的 `authorize(request, operation)` 按线程判定；MCP 同名回调在批量分派前逐项判定。
返回 false 或抛错会拒绝，非回环监听必须同时配置令牌和该回调。请求头只提供身份输入，
宿主负责验证身份并核对会话归属。

硬预算请求必须提供正的有限 `maxOutputTokens`；输入估算取现有估算与消息 UTF-8 字节数
的较大值，再计工具 schema。供应商真实计费、隐藏 token、图片和实时价格仍须由宿主核对；
该估算不能替代供应商账单。
