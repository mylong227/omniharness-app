# 安全模型（SECURITY）

> 范围：本文件描述 `src/` 中**实际存在**的安全机制与失效方向，不描述路线图。
> 原则：先证明“发生了什么”，再谈“是否安全”；证明不了的能力一律不宣称。

## 1. 安全目标与非目标
**目标**（内核能承担的部分）：

- **可拦截**：每个模型工具调用在副作用之前经过同一条确定性门禁链；任一道拒绝即失败，
  不存在“先执行、后告警”。
- **可验证**：决策、审批、委托、回执、证书、审计包均有可重算的字节口径
  （JCS + SHA-256）；验证器对“没查”与“查过且通过”分开报告。
- **可审计**：门禁决策与执行结果落到追加式记录；拒绝原因可机读、可归因到具体门禁。
- **失败方向固定**：门禁缺失、端口异常、探测失败、配置未知值默认都拒绝
  （`fail-closed`），不退回宽松档。

**非目标**（内核明确不承诺的部分）：

- 不承诺模型生成的代码、命令、计划或结论**正确**；只承诺它们可被拦截、记录、离线复核。
- 不承诺提示注入检测“全覆盖”：它是基于规则的启发式，存在漏报与误报；
  `enforce` 只代表“命中即隔离”，不代表“未命中即可信”。
- 不承诺策略档（`policy` / `restricted`）提供 OS 级隔离，也不承诺审计包“法律合规”；
  合规判断、保留期与披露义务由使用方承担。
- 不承诺防住拥有签发私钥、宿主 root 权限或可整体重写存储的攻击者；没有外部 witness
  时，单签发方可以重写一份自洽的新历史。
- 不承诺外部系统“恰好一次”执行；效果日志只做保守对账。

## 2. 工具执行门禁链
模型工具调用的唯一入口是 `StepToolExecutor`：`authorizeCall()` 完成全部执行前
判定后才进入 `executeCall()`。`ToolGate.gate()` 的顺序是固定的：

```text
监督否决 → 意图策略 → 角色 → 计划 → 审批 → 沙箱 → 提权复核
```

| # | 门禁 | 拒绝条件 | 缺省与配置开关 | 实现 |
| --- | --- | --- | --- | --- |
| 1 | 监督否决 | `supervisor.intercept(name)` 返回理由 | 组合根缺省构造 `SupervisorKernel({ hazardousTools: MUTATING_TOOLS })`；`nominal` / `degraded` 不拦，`safe` 拦危险工具，`locked` 全拦。可用 `supervisor` 端口替换；手工构造且不注入则跳过 | `src/kernel/core/toolGate.ts`、`src/kernel/supervisor/supervisorKernel.ts` |
| 2 | 意图策略 | `intent.allow === false` | 缺省 `shadow`：只记录高风险，不改变行为；`OMNI_INTENT_POLICY=enforce` 才拒绝高风险意图；未知取值回落 `shadow`，不回落 `enforce` | `src/kernel/security/toolIntentPolicy.ts` |
| 3 | 角色 | 未知角色、未登记工具、显式 deny、写类被禁、不在 allowlist | 缺省不启用（`rolePolicy` 与 `role` 任一缺失即跳过）；`rbac.enabled` 时注入 `RbacPolicy`。角色门禁在审批之前，拒绝时审批端口零调用 | `src/kernel/security/rbacPolicy.ts` |
| 4 | 计划 | `planMode && MUTATING_TOOLS.has(name)` 且计划端口缺失、无计划、状态非 `approved` | 缺省 `planMode=false`；配置 `planMode` / `plan`。**计划模式但未接计划端口时写类工具一律拒绝** | `src/kernel/core/toolGate.ts` |
| 5 | 审批 | 审批端口返回 `deny` | 缺省 `DenyApproval`（全拒），必须在组合根显式注入其他端口；策略拒绝**不升级** | `src/kernel/config/configBuilder.ts`、`src/kernel/adapters/approval/*` |
| 6 | 沙箱 | 任一目标动作的 `sandbox.check()` 返回不允许 | 缺省由 `probeDefaultSandbox()` 探测，显式档用 `--sandbox <profile>`；探测失败回落 `PolicySandbox` 并告警，`OMNI_SANDBOX_STRICT=1` 时改为启动失败 | `src/kernel/config/corePortsAssembler.ts`、`src/kernel/adapters/sandbox/*` |
| 7 | 提权复核 | 升级裁决不为 `escalate`，或提权沙箱仍拒绝 | 缺省 `DenyEscalation` + `FAIL_CLOSED_ELEVATED_SANDBOX`（恒拒）；只在**沙箱拒绝**后咨询，审批拒绝不进入本步；提权沙箱必须显式注入 | `src/kernel/adapters/escalation/denyEscalation.ts`、`src/kernel/core/toolGate.ts` |

补充语义：

- **多目标补丁逐目标检查**：`apply_patch` / `patch_candidates` 的每个目标各生成一条
  `file_write` 沙箱动作；任意一条拒绝即整条补丁拒绝。
- **门禁异常也是拒绝**：`StepToolExecutor` 把门禁异常收敛为 `policy-denial` 失败结果并
  补配对 `tool_result`，不把“没查成”记成“查过并通过”；取消（`CancelledError`）原样上抛。
- **审批观测按会话隔离**：审批请求/回答只投递给发起该调用的会话，避免并发会话把彼此的
  工具名、路径、命令写进对方审计链。
- **意图的 `requireApproval` 不参与本链**：`ToolGate` 只消费 `allow`；是否弹审批由
  `ApprovalPort` 决定，不要把它当审批开关。

## 3. 审批端口
`ApprovalPort.decide()` 只返回 `allow` / `deny`；**fail-closed 由调用方保证**。
`ToolGate` 只把 `deny` 当作拒绝，其余值必须由具体端口保证不产生“隐含放行”。

| 端口 | 语义 | 适用面 |
| --- | --- | --- |
| `DenyApproval` | 恒 `deny` | 未显式配置审批时的缺省；fail-closed 基线 |
| `AutoApproval` | 恒 `allow` | 只用于演示/测试/明确自担风险的场景；生产不应作为缺省 |
| `RuleApproval` | 有序规则求值；聚合优先级 `deny > ask > allow`；未命中走 `defaultDecision`（缺省 `deny`） | 需要稳定、可复核的命令/工具策略时。规则可按工具名、命令前缀、命令 glob 匹配；`ask` 无回调时按 `deny` |
| `AskApproval` | 本地只读工具自动放行，其余请求交给 `askHandler`；无回调即 `deny` | 交互式“请求批准”档。白名单来自计划模式只读集合并去掉联网工具，因此 `web_search` / `web_fetch` 一律询问 |
| `PlanApproval` | 只放行 `PLAN_ALLOWED_TOOLS`（可加 `extraAllowedTools`），其余 `deny` | 计划模式的审批层白名单。它比 `ToolGate` 的计划门禁更严：连未列出的只读工具也会被拒；但 `extraAllowedTools` **不能**绕过 `ToolGate` 对写类工具的拦截 |
| `GuardianApproval` | 预检 deny 子串/正则命中即拒，预 allow 正则命中即放；否则送 LLM 审查 | 无人值守但要 LLM 预审的场景。提示用每请求随机 nonce 把目标与入参包成不可信数据；解析器拒绝语义优先，只有出现独立 `allow` 且无拒绝词才放行；模型异常/空输出一律 `deny` |

- `CachedApproval` 是可选装饰层，不是上述语义的替代：缓存键含工具名、目标、cwd 与
  “审批名|沙箱名”策略指纹，**不持久化、无 TTL**；`source: 'capflow-confirm'` 的
  逐次确认请求**旁路缓存**。策略切换后宿主必须使其失效。

## 4. 沙箱
`SandboxPort` 的契约是：`name`、`check(action)`，以及可选的 `wrapCommand()` /
`wrapArgv()`。`allowed:false` 必须同时给出 `reason` 与 `category`。
**没有 `wrapCommand` 只表示“能裁决、不能包装执行”**；调用方必须 fail-closed，
不能把“选了某个 profile”当成“已经隔离”。

### 4.1 策略层与 OS 级后端

| Profile / 后端 | 实际施加的边界 | 失败方向与诚实边界 |
| --- | --- | --- |
| `policy` / `PolicySandbox` | 进程内危险命令黑名单 + 工作区路径白名单 | **不是隔离**；绕过黑名单的命令仍可在宿主执行 |
| `restricted` / `RestrictedSandbox` | 在 `policy` 上增加网络外联、提权、持久化、权限篡改、资源破坏规则 | 仍是策略层；命中规则才拒绝 |
| `passthrough` | 全部允许 | 只用于演示/测试；生产禁用 |
| `landlock` / `LinuxLandlockSandbox` | Linux 内核 LSM 路径 ACL，经 `OMNI_LANDLOCK_HELPER` 指向的外部 helper 施加；`check` 对写路径限工作区 | 探测四条件缺一即整后端拒绝：Linux、内核 ≥ 5.13（ABI 推导）、`/sys/kernel/security/landlock` 可读、helper 可执行。该后端不做命令黑名单；其包装只声明路径写限制，网络约束不由它承诺 |
| `seatbelt` / `MacOsSeatbeltSandbox` | macOS `sandbox-exec` + 每命令唯一 SBPL profile：`deny default`、读全盘、读写限工作区、禁出站（仅本地回环放行） | 非 macOS 或 `sandbox-exec` 不可用即拒绝；profile 写在 OS 临时目录（0600），不写工作区 |
| `bwrap` / `LinuxBwrapSandbox` | bubblewrap：根只读 bind、工作区可写 bind、`--unshare-net`、`--die-with-parent` | 探测不到 `bwrap` 即拒绝；不静默回退策略档 |
| `windows-native` / `WindowsNativeSandbox` | 裁决面同 `restricted`；执行面经 `omni-cli sandbox run --workspace`，以 `WRITE_RESTRICTED` + 工作区 SID 限制写边界 | **只限制写**；读、网络、进程可见性不受限。缺 `omni-cli` 或非 Windows 时包装抛错（fail-closed），但 `check()` 本身不探测二进制 |
| `container` / `ContainerSandbox` | Docker/Podman：`--network none`、只读根、`--cap-drop ALL`、`no-new-privileges`、workspace rw 挂载、memory/pids 上限、`--rm` | 共享宿主内核，**不是 microVM**；workspace 是 rw，容器内仍可删改工作区；命令不做黑名单；运行时/守护进程不可用即由 `check` 拒绝，镜像缺失则容器启动失败，均不回退宿主 |

`unshare` / `wsl-bwrap` 同属 OS 级 profile，经同一 `SandboxManager` 注册；语义与
`bwrap` 一样是命名空间隔离，探测不到即拒绝，不冒充其他后端。未知 profile 返回
`UnsupportedSandbox`（一律拒绝），**绝不回退 `PassthroughSandbox`**。

### 4.2 `OMNI_SANDBOX_STRICT` 与缺省探测
`probeDefaultSandbox()` 的探测顺序是：Linux Landlock → Windows 原生写隔离 →
macOS seatbelt。全部不可用时：

- 未设 `OMNI_SANDBOX_STRICT=1`：使用 `PolicySandbox` 检查路径，禁用宿主命令并告警；
- 设了 `OMNI_SANDBOX_STRICT=1`：抛 `ConfigError`，宁可不起跑，不静默降级。

该变量只作用于**缺省探测**。显式选择 `--sandbox policy` 是使用者的自主决定；
显式 OS profile 仍由各后端自己的探测与 `check()` fail-closed。

### 4.3 `SandboxCapabilityTable`：探测与降级
`SandboxCapabilityTable.describe()` 只做文件系统/环境判定，**不 spawn 任何进程**：

- `passthrough` / `policy` / `restricted` 恒 `real:true`（纯 TS 可达）；
- `windows-native` 看平台与 `OmniCliLocator` 能否定位二进制；
- `landlock` 复用后端 `probe()` 的四条件报告；
- `seatbelt` / `bwrap` / `unshare` / `wsl-bwrap` 看平台 + PATH 上的命令；
- `container` 只看 PATH 上是否有 `docker` / `podman`，**不证明守护进程可连**；
  运行期 `ContainerSandbox.available()` 才做 `docker version` 探测。

因此：

- **探测不到 ≠ 已隔离**：探测失败意味着不可宣称隔离，后端必须拒绝；
- **探测到 ≠ 已隔离**：能力表只证明“本机具备该路径的入口/证据”，不证明运行时
  一定能施加限制；真正执行仍以 `check()` / 包装成功为准。
- `SandboxManager.EXECUTION_UNWIRED` 为空集只表示“执行包装已接线”，不表示
  “本机可用”。宿主启动检查与 `omniharness doctor` 应把能力表原样展示给用户。

## 5. 副作用单出口与旁路收口
**模型可见的副作用入口只有一个：`StepToolExecutor`（Executor）。** shell、文件读写/补丁、
checkpoint/rollback（git 状态操作通常经 `shell`，检查点/回滚是治理工具）以及以
工具形式暴露的验证命令，都先过 `authorizeCall()`（意图/角色/计划/审批/沙箱/委托/
授权/CTA），再进 `executeCall()`。native 后端与 JS 后端共享同一门禁；任何环节抛错
都**不回退重跑**，避免双写或命令双跑。

需要单独说明的三个执行面：

- **自动验证**：写后、回合末和长时程验证共用受控命令执行器。命令经审批、沙箱检查和
  `wrapCommand` 后才启动，子进程只收到基础运行变量。长时程命令取宿主配置，
  工作区状态只记录进度。回合自验证需显式开启。
- **workflow 隔离提交**：`WorkflowIsolatedRun` 在独立 worktree 中跑；只有结果成功且
  `guard` 对 `changedPaths()` 的**每个路径**调用
  `sandbox.check({ kind: 'file_write', target: join(workspaceRoot, path) })` 全部放行后，
  才 `commit()` 回主工作区；任一拒绝即抛错，`finally` 丢弃 worktree，主工作区零改动。
  隔离运行不支持 `persist:true`（构造期 fail-closed）。
- **`plan_present` 可取消**：经 `ResponderCancellation.ask()` 与 `context.signal` 竞速；
  用户停止时调用 `responder.cancelPending(sessionId)` 并抛 `CancelledError`，不会把
  “等不到回答”误判为“用户驳回”，也不会永久占住会话。

## 6. 审计与回执
### 6.1 追加式记录与哈希链
- **审计记录**：`AuditRecorder.append()` 把 `AuditRecord` 追加为 `audit` 事件，维护
  `hash = SHA-256(JCS({ prevHash, record }))` 的线性链；`fromSink()` 重放既有事件并
  逐条复算，缺字段/断链即抛 `AuditChainError`，不静默续链。`checkpoint rollback` 的
  合法截断由 `resyncIfDrifted()` 探测并重放重同步；只对合法截断自愈，不放松篡改检测。
- **回执链**：单 issuer 线性链，`payloadHash = SHA-256(UTF8(JCS(payload)))`，
  `previousReceiptHash` 指向前驱，创世为 64 个 `0`。并发 append 经互斥队列序列化。
  无 signer 则 `signature:null`，无 anchor 则 `anchors:[]`，**不编造**。启动接管
  `adopt` 时校验同 issuer、seq 连续、前驱相接、receiptId 唯一，任一不满足即失败。
- 事件存档正常路径是追加；整文件 `save` 是原子替换的兜底，`rollback` 是唯一合法截断
  路径。事件存档本身不是密码学不可变日志，不可把它等同于回执链。

### 6.2 Merkle 根、锚定与交付物
- **执行证书**：`eventRoot = Merkle(JCS-normalized events)`；叶子
  `SHA256(0x00 ‖ JCS(event))`，内部节点 `SHA256(0x01 ‖ left ‖ right)`，奇数上提、不复制
  末项；绑定 `sessionId`、`eventCount`、可选回执链尾 `{issuerId, receiptCount,
  tailHash, merkleRoot?}` 与工具面摘要，并对 `JCS(certificate)` 签名。它证明完整性/顺序/归属，
  **不证明内容为真**。
- **RFC 3161 锚定**：`Rfc3161Verifier` 解析 `TimeStampResp` / `TSTInfo` / CMS，重算
  payload 摘要并与 `messageImprint` 逐字节比对，再在调用方**带外**提供的 TSA 信任输入
  下验 CMS 签名。没有信任输入 ⇒ `ANCHOR_UNTRUSTED`、`anchored:false`；畸形/摘要不符/
  签名不符/算法不支持各有独立问题码。`kind:'chain'` 另做 TSA 证书链、有效期、
  EKU/keyUsage 检查；RFC 5280 策略/名称约束/CRL 分发点/OCSP nonce 未实现。
- **审计包与选择性披露**：审计包＝事件流 + 执行证书 + 回执链（+ 可选执行图）可整包签名，
  离线复核 `AuditBundles.verify()`；选择性披露包只出选中事件，每条附 `EventMerkle`
  包含证明锚回证书根，复核 `DisclosurePacks.verify()`。混合会话回执使用独立域叶子
  `SHA256(0x02 ‖ JCS(receipt))` 与证书签名绑定的 `merkleRoot`；仅披露所选会话正文和
  兄弟节点哈希。哈希、链位置和总数仍会暴露，不提供流量隐私。旧证书无回执根时
  不可补造该证明；同会话前缀保留线性链验证。

### 6.3 `AuditPacks.verify` 的判定口径

实现入口是 `AuditPacks.verify(pack, trustStore?, expected?, anchorTrust?)`。两个结论**不是同义词**：

- `ok` = 无结构类问题 **且** 每条回执的 `chainOk` 为真。结构类包括 seq 连续、
  前驱链接、JCS 规范形态/哈希重算、签发方标签、带外期望摘要、以及**已提供信任根时**
  的验签失败。空包恒 `ok:false`；包形状非法恒 `ok:false`。
- `compliant` = 无阻塞问题 **且** `chainOkAll` **且** `anchoredAll` **且** `signedAll`。
  即：每条回执的签名都**被检查且有效**，每个锚都**被验证**（imprint 匹配 + CMS
  签名通过），链完整。缺签名信任根 ⇒ `signatureChecked:false`，不阻塞 `ok`，但阻塞
  `compliant`；没有可验证锚 ⇒ 锚定问题只压 `compliant`，不翻 `ok`。

因此“`ok:true` 的包”只说明结构与链自洽，可能**没有检查过任何签名，也没有任何
可验证锚**；需要来源与时间证明时必须同时要求 `compliant`，并自带 trust store 与
TSA 信任输入。

## 7. 上下文与数据流安全
- **提示注入护栏**：`PromptInjectionGuard` 是确定性规则扫描（无 ML/外部服务）。强规则
  （指令覆盖、角色伪造、数据外泄）命中即拦；弱规则与指令式启发式按来源阈值累计：
  `external` / `unknown` / `memory` 为 1，`file` 为 2，`local` 为 3。`off` 不跑；
  `shadow` 只记录“本该拦截”；`enforce` 才替换为隔离标记。库级未配置为 `off`，CLI 生产
  入口默认 `shadow`。扫描器异常时 `enforce` 保守隔离、`shadow` 原样放行。
- **CTA 污点隔离**：`ContextTaint` 从事件流派生，按工具输出来源抬高污点级，级别
  **单调不降**（回到 `TRUSTED_ONLY` 需显式开新 epoch）。非 `READ_ONLY` 效果类在非可信
  污点下需要 step-up 回执；回执必须绑定 `requestDigest`、未过期、scope 覆盖工具（空
  scope = 仅本次请求）。`off` / `shadow` / `enforce` 三档；`enforce` 无有效回执即拒。
  它不对模型内部推理做数据流分析，只记录“本 epoch 摄入过不可信来源”。
- **CapFlow 能力数据流**：`CapabilityLedger` 按成功工具输出的信任级授予会话能力
  （`untrusted-external` / `untrusted-content` / `injected-untrusted` /
  `inherited-untrusted`），委托边保留继承标记。`CapFlowPolicy` 按声明式
  “source → sink → deny/require-approval”表评估；`enforce` 的 `deny` 直接拒，
  `require-approval` 走 `ApprovalPort` 逐次确认（端口异常按拒绝），`shadow` 只留证；
  策略文件加载不合 Shape 即启动失败。sink 按工具名逐字匹配（`mcp_` 前缀通配），部署应
  核对默认策略的 sink 名与本机注册工具名是否一致，不能假定默认表覆盖所有执行工具。
- **SSRF 守卫**：`SsrfGuard` 拦截云元数据地址（默认永远拒绝，含 IPv6 内嵌 IPv4）、
  非法字面量与内网域名；`SsrfGuard.defaultOptions()` 默认放行私网（本地 A2A/Ollama 场景），
  `OMNI_SSRF_STRICT=1` 时拦私网；`web_fetch` 的 `EgressPolicy` 默认拒绝私网，需
  `OMNI_EGRESS_ALLOW_PRIVATE=1` 才放行。DNS 二次判定默认开启：解析失败按拦截、
  解析到危险 IP 也拦截；重定向逐跳复检（最多 3 跳），防公网 302 进内网。
- **路径边界**：`PathBoundary.contains()` 委托 `WorkspaceGuard.isInside()`，同时做词法
  越界、`realpath` 逃逸与 Windows 大小写折叠；不是裸 `startsWith`，所以
  `/work/proj-secret` 不会被当成 `/work/proj` 的子路径，symlink/junction 指向外部也会
  被识别。
- **秘密打码**：`ToolResultPipeline` 在任何落盘/入事件流之前，用 `SecretRedactor` 对
  `output` / `error` 做自由文本打码（PEM、厂商 Key 形态、键值赋值、Bearer），结构化
  配置按键名与容器（`providerKeys` / `env` / `headers` / `auth`）打码。它是**输出层
  打码，不是加密**，也不做权限校验；无法识别任意高熵随机密钥。

## 8. 委托与信任
- **令牌**：`DelegationToken` 含 `authority.scopes`、可选 `maxCalls`、`expiresAt`、
  `depth` / `maxDepth`、`principal`、`parentTokenHash`，签名覆盖 `JCS(unsigned)`。scope
  支持 `*` 与尾部通配（如 `read_*`）；子 scope 必须 ⊆ 父，子过期不得晚于父，子
  `maxCalls` 不得大于父，`principal` 整链不变，逐跳 `parentTokenHash` 绑定。
- **执行期与信任根**：`StepDelegationGate` 在每次工具调用前做验签/有效期、scope 覆盖与
  `maxCalls` 扣减（提供 `DelegationUsage` 时）；有 trust store 时按 `kid` 解析验签身份并检查吊销（`REVOKED`），查不到
  即 `UNTRUSTED_ISSUER`；父子可共享 `DelegationUsage`，预算合计受限。
  `DelegationTrustRegistry` 只提供进程内注册/吊销与 JSON 快照 `save/load`；**谁把信任根
  快照分发到哪台机器、如何认证分发通道，是宿主职责**。内核不自带授权服务器，也未实现
  完整 OAuth/WIMSE 的 `par_hash`、DPoP。

## 9. 记忆与持久化
- `OmniKernel.create()` 默认使用进程内会话存储；长期记忆未显式指定路径时也不落盘。
  需要持久化时由宿主注入存储。`EncryptedStorage` + `AesGcmTextCodec` 加密事件 payload，
  解密时核对 ID、会话、类型、时间和序号的认证绑定。外层元数据仍是明文；附件、快照、回执、spill 与备份须另行保护。
  显式配置 `longTermMemoryPath` 时默认加密；`longTermMemoryEncryption:false` 显式选择明文。
  旧明文迁移需 `migratePlaintext:true`，存在损坏行时拒绝覆盖。密钥应和数据分开备份。
- **AES-GCM vault**：`CryptoVault` 以 AES-256-GCM 加密凭据，载荷 `iv:cipher:tag`，每次
  写入随机 12 字节 IV；`AesGcmSealer` 用 scrypt 派生密钥（旧 SHA-256 派生仅用于解密历史
  密文）。密钥来源：`OMNIHARNESS_VAULT_KEY` → 密钥文件（0600）→ 无文件时进程内临时密钥
  并**告警**（重启后不可解）。`AesGcmTextCodec` 对长期记忆逐行独立加密，密钥来源为
  `OMNIHARNESS_MEMORY_KEY` 或密钥文件；**无持久密钥源时直接抛错**，不静默丢记忆。
- **记忆治理与保留**：`MemoryGovernance` 写入时补 provenance（内容 SHA-256、来源事件、
  信任档），准入拒绝空文本、非法重要度、重复内容与注入片段；默认开启（可用
  `governance:false` / `OMNI_MEMORY_GOVERNANCE=0` 关闭）。墓碑只让 `recall` 不再命中，
  事实本体仍保留供审计，**不是物理擦除**；`maxFacts` 超限按重要度/新旧淘汰，`expiresAt`
  与时间衰减控制召回。会话存档另由 `SessionGc` 按 `keepNewest`、年龄、总量上限与孤儿
  附件回收，删除失败逐组跳过。
- **会话存档完整性**：`JsonlStorage.save()` 用唯一临时文件 + `rename` 原子替换；
  `append()` 在进程间锁内校验条数和链尾再追加。SQLite 在同一写事务内复核前缀。
  冲突报告落盘失败并保留已提交历史。JSONL/SQLite 读取拒绝坏行、重复 ID 和不连续序号，
  非 ENOENT 读取失败上抛。回滚先持久化前后镜像，再替换文件/事件；中断后从日志恢复，
  补偿失败保留日志并报告错误。加密存储的恢复日志使用同一编解码器保护会话和文件镜像，
  超过读取上限的日志在写入前拒绝。内置存储用可重入会话锁覆盖整个操作，自定义存储须实现
  `withSessionLock` 才能保证并发读写隔离。
  回执链和遥测等追加式账本另用 `DurableJsonlAppender`：尾字节
  非换行即截断残行并写 tombstone、写必 fsync、非 ENOENT 读错误上抛，消费方须跳过
  tombstone。

## 10. 残余风险与宿主职责
以下事项**内核不做**，或只提供接口不提供保证；部署方必须自行补齐：

- **模型端点信任**：模型输出可能错误、被污染或由恶意端点生成；TLS、供应商、代理与模型选择属宿主；`GuardianApproval` 的 LLM 审查同样依赖该端点。
- **交互式 OAuth 回环**：浏览器回调监听、授权码兑换与凭据保管属部署形状；内核启动时
  不自动开回调。
- **信任根、摘要与锁的分发**：TSA 信任材料、委托信任根快照、审计摘要的公告/交换渠道
  都由使用方带外提供；单 `issuerId` 是单写者语义，跨进程写同一回执链会分叉，宿主须
  串行化或改用不同 `issuerId`。
- **密钥与签名者**：私钥文件、vault 密钥、签名服务的保管与轮换属宿主（Windows 上 0600 是
  no-op，ACL 由宿主）；私钥泄露者可伪造回执/证书。没有 HSM/witness 时，签发方仍可整体重写历史。
- **注入与出站**：规则检测有漏报/误报；CapFlow 是会话级能力粗粒度，不是解释器级逐值
  污点；`shadow` 只记录规则命中。内置网页抓取与出站 fetch 包装使用通过校验的地址建连。
  自定义网页传输必须显式设置 `trustedTransport:true`；该回调可执行宿主代码，须由宿主
  实施 DNS、跳转和网络策略。浏览器也需在网络层施加策略。
- **OS 隔离与包装**：策略档不是隔离；Windows 原生只限制写；容器共享宿主内核且
  workspace 可写；Landlock 依赖外部 helper；探测不到即拒绝，探测到也不等于已隔离。
  自动测试使用能提供 `wrapCommand` 的沙箱。宿主按任务选择足够的读、写和网络限制。
- **演示档位与会话存档**：`AutoApproval` + `PassthroughSandbox` 只用于演示/测试，生产
  必须换成 fail-closed 审批与真隔离沙箱。损坏存档先备份，再人工修复；需要不可
  篡改历史时应依赖回执链/证书。保留期、备份与异地副本由使用方负责。
- **记忆与凭据**：输出打码不是加密；无持久密钥时 vault 的临时密钥会导致重启不可解；
  固定应用级 KDF 盐不防针对本应用的预计算。记忆召回正确性与中毒治理不等于事实核验。
