# 路线图（唯一规划源）

> **性质**：现行规划，不是提案。本文件回答三个问题：**做到哪了、下一件是什么、凭什么说做完了**。
> **机检**：`npm run plan:check`（已并入 `npm run verify`）。状态账与代码事实不一致即红。
> **边界事实**见 [BOUNDARY.md](BOUNDARY.md)；**变更历史**见 [../CHANGELOG.md](../CHANGELOG.md)；**每日动作**见 git log。

---

## 1. 规划怎么闭环

```text
目标 → 判据 → 工作项 → 证据 → 状态回写 → plan:check 对账 → （下一轮）
```

四条纪律，每条都可执行、可复核：

1. **状态只有两种**：`✅ done` / `⏳ open`。「做到一半」一律记 `open`，不发明第三种状态。
2. **双向对账**（`scripts/planCheck.mjs`）：
   - 标 `done` ⇒ 该里程碑判据**全部**通过（禁止提前记账）；
   - 标 `open` ⇒ 判据**至少一条不通过**（禁止做完不记账）。
3. **判据分两类**：`auto` 由脚本读仓库事实（文件 / 数字 / 边界机检）；`manual` 必须在
   [§6 人工复核记录](#6-人工复核记录)留下 `日期 + 判据 id + 证据` 行，否则视为未通过。
4. **一项工作 = 一个判据 + 一条证据**：没有证据的改动不进状态账；判据不通过就不许翻 ✅。

> 为什么这样设计：这个项目最容易犯的两个错，是「文档说做完了但代码没跟上」和「代码做完了但文档停在旧状态」。
> 单向门禁只能防前者；双向对账把后者也变成红灯。

---

## 2. 北极星（D90 / D180）

以 2026-11-03 为起点（`10 h/周`预算，与切分方案一致）：

| 时点 | 判据 | 当前 |
| ---- | ---- | ---- |
| **D90（2027-02-01）** | 至少 1 个**外部**安装或使用反馈（npm 下载 / issue / 下游仓库钉版本） | ⏳ 0（尚未发布到 npm） |
| **D90** | OmniHarness 钉内核版本并跑通全量回归 | ✅ vendored tgz 钉版 alpha.6 + 全量回归绿（2026-11-05，§6 m2-consumer） |
| **D180（2027-05-02）** | 公开面仍 ≤60；按行为分面的契约测试 ≥30 例；`npm run verify` 全绿不靠人肉 | ✅ 60 / 60；契约 124 例（单元总 564） |
| **D180** | 适配器归属裁决执行完（`laya` 移出、`@beta` 组复核） | ✅ laya 已迁出；`@beta` 三组 9 文件 |

北极星不达标时的**默认动作是收缩，不是加功能**：不拆仓、不加公开面、不写第二套 CLI。

---

## 3. 状态账

> `plan:check` 直接解析下表。改状态 = 改这一行；判据 id 必须在 §5 有实现。

| 里程碑 | 状态 | 预算 | 判据 |
| ------ | ---- | ---- | ---- |
| M0 切分收口 | ✅ done | 68 h（已完成） | m0-boundary, m0-no-compat, m0-public-cap, m0-tests, m0-headless-imports |
| M1 发布就绪（alpha.1） | ✅ done | 10 h | m1-publishable, m1-files, m1-changelog, m1-readme, m1-ci, m1-dist |
| M2 第一个外部消费（D90） | ✅ done | 20 h | m2-consumer |
| M3 beta 硬化（alpha.2） | ✅ done | 30 h | m3-laya-migrated, m3-adapters-beta-marked, m3-support-surface, m3-contract-coverage |
| M5 立信（回执链） | ✅ done | 40 h | m5-jcs-conformance, m5-receipts-contract-suite, m6-provenance-public |
| M6 通电与沙箱收口 | ✅ done | 30 h | m6-mcp-server-wired, m6-mcp-capability-honest, m6-sandbox-failclosed, m6-examples-public, m6-workbench-bridge |
| M4 切片收口（盘点并账） | ✅ done | 20 h | m4-metaphor-zero, m4-zero-inbound, m4-source-lines, m4-unreachable-lines, m4-gate-bypass, m4-maturity-evidence, m4-public-45 |
| M8 效率与内存收口（调研底稿 [RESEARCH-2026-11.md](RESEARCH-2026-11.md)） | ✅ done | 16 h | m8-bench-harness, m8-research-doc, m8-memory-multipliers, m8-serialization-shortcircuit, m8-eventlog-snapshot |
| M9 硬化收口（接线审计 [WIRING.md](WIRING.md) + 毛边 + 压力） | ✅ done | 14 h | m9-wiring-audit, m9-polish, m9-stress |
| M10 缺口补完（取消 / 尾摘要 / mcpServers） | ✅ done | 8 h | m10-cancel-propagation, m10-signed-summary, m10-mcp-servers-wired |
| M11 一次接入收口（`./embed`） | ✅ done | 10 h | m11-embed-entry, m11-embed-evidence, m11-embed-minimal, m11-embed-receipts-persist, m11-embed-execution-certificate, m11-embed-audit-bundle, m11-embed-full-audit-bundle |
| M12 架构图谱与数学不变量 | ✅ done | 10 h | m12-arch-graph, m12-math-invariants |
| M13 数学覆盖二期（调度/估算/覆盖率/回执并发） | ✅ done | 6 h | m13-math-expansion |
| M14 执行证书（运行级可复核） | ✅ done | 12 h | m14-execution-certificate |
| M15 执行图谱系（多智能体可验证） | ✅ done | 8 h | m15-execution-graph |
| M16 审计包（单文件离线交付） | ✅ done | 6 h | m16-audit-bundle |
| M17 审计包运行时闭环（`kernel.exportAuditBundle`） | ✅ done | 6 h | m17-runtime-audit-bundle |
| M18 选择性披露（最小披露仍可验） | ✅ done | 8 h | m18-selective-disclosure |
| M19 核心循环韧性（任务解决能力一大步） | ✅ done | 10 h | m19-loop-resilience |
| M20 审计交付编码（压缩 / 口令加密 / 分片） | ✅ done | 8 h | m20-audit-delivery |
| M21 迁移桥显式化（通配 → 承诺闭包，底稿 RESEARCH-2026-11C 已归档） | ✅ done | 12 h | m21-explicit-exports, m21-generator-source |
| M22 认知域重入（plugin / eval / media 迁回，裁决见 ARCHITECTURE §7.4） | ✅ done | 20 h | m22-eval, m22-media, m22-plugin |
| M23 断线清偿（盘点 6 缺失 + 5 畸形，审计记录入 CHANGELOG 历史） | ✅ done | 12 h | m23-ssrf-wired, m23-plugin-capabilities, m23-toolface-consistency |
| M24 评测闭环与收尾（fixture 重建 / 漂移清偿 / 文档账实） | ✅ done | 10 h | m24-fixtures-rebuilt, m24-drift-cleaned, m24-docs-truth |
| M26 应用侧终盘收编（kernel-compat 通用件 + 影子清偿，盘点 2026-11-07） | ✅ done | 14 h | m26-shadow-clearing, m26-adapters, m26-vault, m26-trace, m26-util-completion, m26-skill-asset, m26-steering-cache |
| M27 兼容层清零（kernel-compat 退役 + SDK/打码终批收编 + alpha.12） | ✅ done | 12 h | m27-sdk-client, m27-secret-redactor, m27-alpha12, m27-compat-zero |
| M28 插话词表配置化（defaults/interjection.json + omniharness.json interjection 段，2026-11-07） | ✅ done | 3 h | m28-interjection-config |
| M29 审计 canonical 单一真源（auditCanonical → 内核 Jcs，M26 遗留闭环项） | ✅ done | 6 h | m29-jcs-audit |
| M32 AAT 决策级审计（执行前决策 / 策略快照 / 导出复核） | ✅ done | 34 h（已完成） | m32-aat-records, m32-aat-export, m32-aat-wiring |
| M33 CTA 上下文污点隔离（污点格 / 数据面 Merkle / step-up 执行前拦截） | ✅ done | 18 h（已完成） | m33-cta-core, m33-cta-wiring |
| M34 效果日志（崩溃一致性 / resume 对账） | ✅ done | 12 h（已完成） | m34-effect-journal, m34-effect-wiring |
| M35 Agent Skills 规范字段（license / compatibility / metadata / allowed-tools） | ✅ done | 6 h（已完成） | m35-skills-spec |
| M36 AAT 单次授权（issue / consume / 复用拒绝） | ✅ done | 10 h（已完成） | m36-authorization, m36-authorization-wiring |
| M37 可衰减委托链（签发 / 衰减 / 整链复核） | ✅ done | 12 h（已完成） | m37-delegation-chain |
| M38 MCP Skills 扩展（skills/list / skills/get / 能力声明） | ✅ done | 10 h（已完成） | m38-mcp-skills |
| M39 MCP Tasks 扩展（task handle / get / update / cancel） | ✅ done | 14 h（已完成） | m39-mcp-tasks |
| M40 记忆治理与可靠性回执（provenance / 准入 / 墓碑 / 签名报告） | ✅ done | 16 h（已完成） | m40-memory-governance |
| M41 CTA 的 MCP 服务端互操作（`_meta.ctxIsolation` + McpCtaPort） | ✅ done | 8 h（已完成） | m41-mcp-cta |
| M42 委托链工具层接线（ToolContext / config / subagent） | ✅ done | 10 h（已完成） | m42-delegation-wiring |
| M43 边界收口（CTA 客户端发送 / 委托自动签发+预算 / 记忆自动治理+报告入 AAT/审计包） | ✅ done | 16 h（已完成） | m43-cta-client, m43-delegation-auto, m43-memory-auto |
| M44 边界二轮（跨 issuer/吊销/共享预算 / CTA HTTP 头 / approval+heartbeat 生产者 / 记忆默认治理） | ✅ done | 12 h（已完成） | m44-delegation-trust, m44-cta-http, m44-aat-producers, m44-memory-default |
| M45 校准自主性（共形风险控制放权层） | ✅ done | 10 h（已完成） | m45-calibrated-autonomy |
| M46 GK01 全量分位数草图（严格 ε·n 秩误差界） | ✅ done | 6 h（已完成） | m46-gk-quantile |
| M47 AAT 共形决策自证（放行证据 + 离线重算） | ✅ done | 8 h（已完成） | m47-conformal-aat |
| M48 账本可靠性基建（DurableJsonlAppender + PathLock） | ✅ done | 12 h | m48-durable-appender |
| M49 取消语义完整性（CancellationClassifier） | ✅ done | 8 h | m49-cancellation |
| M50 协议边界加固（形状守卫前置） | ✅ done | 10 h | m50-protocol-boundary |
| M51 模型适配器收敛（ToolCallIdAllocator） | ✅ done | 8 h | m51-tool-call-ids |
| M52 安全边界二轮（SSRF / 注入 / 诚实标记） | ✅ done | 10 h | m52-security-hardening |
| M53 核心正确性收敛（单一真源清偿） | ✅ done | 10 h | m53-core-convergence |
| M54 深度测试装置（压力/极限/边界三线） | ✅ done | 8 h | m54-deep-tests |
| M55 内核哨兵（kernel.diagnostics() 运行时健康报告） | ✅ done | 6 h | m55-kernel-sentinel |
| M56 确定性读缓存（workspace generation + CachedToolPort） | ✅ done | 8 h | m56-deterministic-cache |
| M57 回合成本信封（turnCostEnvelopeUsd） | ✅ done | 6 h | m57-turn-envelope |
| M58 审计时间线（timeline.html 自包含交付） | ✅ done | 6 h | m58-audit-timeline |
| M59 能力数据流防火墙（CapFlow，CaMeL 式结构化来源追踪） | ✅ done | 10 h | m59-capflow |
| M60 检索供给编排（推入式会话历史检索，RetrievalContextPort） | ✅ done | 16 h | m60-retrieval-context |
| M61 语义召回扶正（semanticRecall 配置段 + 降档链 + 哨兵 context 分区） | ✅ done | 10 h | m61-semantic-recall-config |
| M62 检索质量与性能基准（bench 探针 + LongMemEval 注入模式 + 冷索引停顿补测） | ✅ done | 8 h | m62-retrieval-bench |
| M63 上下文工程策略面（contextPolicy 降档阶梯声明式化） | ✅ done | 12 h | m63-context-policy |
| M64 prompt cache 一等公民（内核级读数台账 + 哨兵 context 分区呈现） | ✅ done | 6 h | m64-prompt-cache-evidence |
| M65 缓存守卫观测闭环（命中率门限联动 + 机制修正后不做节流器） | ✅ done | 5 h | m65-cache-aware-tail |
| M66 查询改写（ModelPort 语义级可插拔，规则版裁撤） | ✅ done | 8 h | m66-query-rewriting |
| M67 检索精排（ModelPort 序数判定可插拔，降档跳过联动） | ✅ done | 12 h | m67-cross-encoder-rerank |
| M68 注入面 CapFlow enforce（injected-untrusted 能力维度 + M60 标记升级） | ✅ done | 10 h | m68-capflow-injection-enforce |
| M71 干净检出编译机检（worktree tsc 双配置，P0-1 制度化修复） | ✅ done | 3 h | m71-clean-checkout-tsc |
| M69 检索质量对照自动化（eval:inject 跑批） | ✅ done | 6 h | m69-eval-automation |
| M70 多会话检索供给压力（隔离 + 有界延迟） | ✅ done | 8 h | m70-supply-stress |
| M72 VectorStorePort 可选适配器对齐面（广度） | ✅ done | 12 h | m72-vector-port |
| M73 检索对照真实回填（eval:inject 真实模型档 + §7 落账） | ✅ done | 4 h | m73-eval-real-backfill |
| M74 SSE/Web 对接面（宿主侧最小 UI + 起任务入口 + 无头冒烟） | ✅ done | 6 h | m74-web-sse-surface |
| M75 多模型路由质量对照（七策略 × 质量/延迟/成本） | ✅ done | 5 h | m75-route-quality-compare |
| M76 残余工作台账与过期表述收尾（R8 收尾） | ✅ done | 3 h | m76-residual-ledger |

> M8 复盘（2026-11-06）：调研先行两次修正了直觉——内存「4-6 份转录副本」被加固后的
> 仪器证伪大半（真值 2.04×，首版 5.1× 是首跑混入语料索引的仪器污染）；效率大头不在每步
> 管线（热稳态本就 ~1 ms）而在冷索引（3.1s 一次性）与稳态重复序列化（指纹 14.2×、
> schema 137×）。P3 五项按「实测过关才做」全部不做，理由记录在调研底稿 §4。

### M9 硬化收口 ✅

**目标**：把「文档说已通电」与「代码里真的接上」之间的差距变成可执行的红灯。

| 工作项 | 结果 |
| ------ | ---- |
| 接线审计 | 可达性根从单入口修正为 8 个公开入口（旧口径 19,858 → 正确口径 8,303 行不可达）；`npm run wiring:check` 机检入口完整 / 预算 / 零入边落账 / 文档不悬空；处置表见 [WIRING.md](WIRING.md) |
| 声明未接线修复 | 遥测链 + 晋升台账（README「可审计」的两条声明）接进 `governance`；隔离阶梯 + 内置 wasm 执行器接进 `sandbox`；MRTR 三个 handler 接进 `mcp` 并给 `McpHttpAssemblyOptions.inputRequired` 注入口（缺省关闭，显式接线） |
| 毛边打磨 | 16 条回归判据：回执链异步 signer 分叉、工作台非法 request-target 崩进程、配置端口被忽略、SSE 回放重复投递与无背压、错位回答、500→400、close 幂等、MemoryStorage 空桶 append、JCS 孤立代理项、MCP 预检/显式 CORS、fallback 门禁丢失、装配器绕过 runtime.gate、深嵌套参数打崩回合、sessionId 冲突/超长、尾篡改带外绑定 |
| 压力测试 | `tests/stress` 三文件 9 用例（20k 事件 / 40 会话 / 350 回执 / 20 并发 SSE / 100 投影 / 1 MiB 边界 / 200 步会话 / 10 MiB 载荷），`npm run stress` 并入 `verify` |
| 盘点清账 | 12 个零引用、零判据、注释指向已删模块的文件删除（见 WIRING §3「M9 删除」）；`m4-zero-inbound` 改用全部入口口径 |

> M9 复盘：旧审计工具本身是最大的「声明未接线」——只从 `src/index.ts` 起算，7 个公开
> 子路径入口整棵被判成死代码，于是数字长期显示「MCP/沙箱/工作台不可达」，与事实相反。
> 修正测量口径后，真正的缺口只剩 5 个宿主侧/通配模块（全部在 WIRING 落账）。压力测试
> 另外证明了「同步路径 100 并发零分叉」是**假绿**：注入异步 signer 后 8 个并发 append
> 全部拿到同一 seq——现有判据恰好只测了同步路径。

### M10 缺口补完 ✅

**目标**：把 M9 明确记录、未在本轮修的三项缺口补成可执行判据。

| 工作项 | 结果 |
| ------ | ---- |
| 取消传播 | `StepToolExecutor` 与工具执行竞速（取消即抛 `CancelledError`，不再等 60s 工具跑完）；`ToolScheduler` 不再把取消吞成 failed ToolResult；`ask_user` 等待期取消会清理 `WorkbenchHub` 挂起提问并释放会话锁；取消原因 `timeout/custom` 原样透传 |
| 尾条可信摘要签发 | `ReceiptChain.summary()` 产出 `{issuerId, receiptCount, tailHash}`，`signSummary()` 用回执同一 signer 对 `JCS(summary)` 签名；`AuditPacks.verify(pack, trustStore, signedSummary)` 验签并比对条数/尾哈希——尾条被改/被删由 `EXPECTED_MISMATCH` 检出，改摘要由 `SIGNATURE_INVALID` 检出；无 signer 时拒绝签发 |
| `config.mcpServers` 装配 | 字段进入 `OmniHarnessConfig`/`ResolvedConfig` 并由 `ConfigFactory` 透传；新增 `startMcpServers(runtime)`（`mcp` 子路径）用 `SdkMcpConnector`（stdio/远端 + auth）逐台连接，经 `McpGateway` 把远端工具注册进工具面，`close()` 反注册；`auth` 的 bearer/oauth 令牌由 `McpAuthProvider` 真正变成 `Authorization` 头 |

> M10 复盘：三项缺口的共同形态都是「信号/配置到了，消费者没到」——取消信号已下传却没人竞速、
> 摘要参数已支持却没人签发、`mcpServers` 已校验却没人读取。补完后，WIRING §6 的三条已分类：
> H1（交互式 OAuth）/ H4（摘要分发渠道）/ H7（行数口径），见 [RESIDUAL.md](RESIDUAL.md)。

### M11 一次接入收口 ✅

**目标**：把「宿主为了用上内核全部能力而必须自己写的那一层」收进内核，宿主只剩一次调用。

| 工作项 | 结果 |
| ------ | ---- |
| 一次接入入口 | 顶层新增 `OmniKernel.create()`（腾出 `AgentFactory` 的第 60 位；后者下沉为内部件），并保留 `@omniharness/kernel/embed` 作为完整选项/句柄类型面：主循环 + 内置工具/记忆/技能 + 工作台 HTTP/SSE（含历史会话发现）+ MCP 客户端 + MCP 服务端（可选）+ 遥测（可选）+ 回执链一次装配；`examples/embed.mjs` 只留 6 行核心；公开面仍 60/60 |
| 能力可核对 | `kernel.capabilities()` 实时列出工具数 / 工作台地址 / 回执条数 / MCP 工具 / 审批 / 沙箱 / embedding / evolution / native / telemetry；「全部能力」不再靠读代码猜 |
| 生命周期与安全默认 | `close()` 幂等（取消回合 → 关 MCP → 落回执 → 冲刷事件 → 关工作台）；模型缺省 `MockModel` 且不读本机凭据，审批/沙箱保持 fail-closed，工作台回环绑定，MCP 未配置零连接 |
| 审计闭环 | `receipts.persist` 落 append-only JSONL + 0600 私钥；重启 `ReceiptChain.adopt` 逐条校验后续写，启动即复核既有链；坏链/丢钥/降级签名一律 fail-closed（[RECEIPTS.md](RECEIPTS.md) §1.1） |
| 运行级证书接入 | `receipts.certificates` 每次回合自动签发执行证书（M14 资产）并落盘；显式 `kernel.certificate(sessionId)` 同实现；篡改/链尾不符由 `ExecutionCertificates.verify` 检出（[API.md §1.8](API.md)） |
| 审计分发 | `receipts.exportBundle(dir?)` 一次导出 `pack.json` + `trust.json` + `summary.json`，第三方可零出网复核；尾条改/删由 `summary` 检出（[API.md §1.9](API.md)） |
| 单文件运行证明 | `kernel.exportAuditBundle([sessionId])` 交付 `bundle.json`（事件 + 证书 + 回执 + 整包签名）+ trust + digest；`AuditBundles.verify` 一次复核全部层（[API.md §1.10](API.md)） |
| 判据 | `tests/contract/embedOneCall.test.ts`（12 例）：工具回合 + 工作台投影 + 审计包真实验签 + MCP 客户端/服务端 + 事件扇出 + 未签名语义 + config 透传 + fail-closed + 回执续链/篡改/丢钥；`m11-embed-minimal` 机检示例 ≤60 行且只经顶层；文档 [API.md §1](API.md) / README 快速开始 / [WIRING.md](WIRING.md) 声明对照 |

> M11 复盘：M9 接线审计把「声明未接线」变成了红灯，但**宿主侧的重复接线**不在它的口径里——
> 应用仓库仍要用 17 个生成域文件把内核内部路径收敛起来。`OmniKernel.create()` 的取舍是：**把组合根
> 之上的组合根留在内核**（顶层一个符号 + 一份测试），而不是继续让每个消费者各写一层；顶层稳定面
> 以「移出 `AgentFactory`」腾位，`api:check` 仍 60/60，`wiring:check` 入口数 8 → 9。

### M12 架构图谱与数学不变量 ✅

**目标**：让「架构」和「数学」也从口头承诺变成可执行判据。

| 工作项 | 结果 |
| ------ | ---- |
| 架构机检 | 新增 `npm run arch:check`（`scripts/archCheck.mjs`）：运行时依赖图 Tarjan SCC 无环、跨层边规则（contracts 叶子 / protocols 单一支撑面 / kernel→protocols 仅声明例外）、[ARCHITECTURE.md](ARCHITECTURE.md) 依赖快照与代码一致；`arch:update` 重新生成快照 |
| 契约层收口 | `OmniError`/`ErrorCode` 与 `API_VERSION` 从根实现迁到 `contracts/`（根文件保留兼容再导出），消除 `contracts → 根入口` 回指；kernel→根入口的同类边归零（只余版本兼容路径） |
| 数学覆盖 | 新增确定性属性测试骨架 `tests/property/harness.ts`（mulberry32 + 固定 seed + seed/trial 失败定位）；5 文件 / 20 属性覆盖 JCS、0/1 背包、UCB1、BM25、哈希链、事件日志；[MATH.md](MATH.md) 记录覆盖矩阵、诚实边界（属性测试 ≠ 证明）与未覆盖项 |
| 判据 | `m12-arch-graph`（archCheck 全绿 + 快照一致 + 并入 verify）、`m12-math-invariants`（≥4 文件 / ≥12 属性 + 覆盖矩阵在位） |

> M12 复盘：运行时依赖图此前**没有任何机检**——`boundary:check` 只看文本 import 规则，
> 类型依赖与真实回指混在一起。加入「只算运行时边」的图分析后发现：运行时环为 0，
> 但 `contracts → 根入口` 有 4 条回指（错误目录/版本常量住在根实现里）——已迁到契约层。
> 数学侧的最大收获不是多测了几个函数，而是**把「哪些只是工程近似」写进了文档**：
> 背包有精确最优对拍，UCB1 只钉骨架不声称 regret 界，公平调度不声称偏差界。

### M13 数学覆盖二期 ✅

**目标**：把属性测试从「算法样例」扩到**并发/调度/计量/估算**四类容易被直觉骗过的面。

| 工作项 | 结果 |
| ------ | ---- |
| 新增属性套件 | `fairScheduler`（等权服务量差额 ≤2、并发 ≤ limit、排队取消）、`tokenEstimator`（单调/可加/开销/缓存不变性）、`rewardCoverage`（计数自洽/差分可加/异常归口）、`receiptsConcurrency`（异步 signer 任意 N 并发线性 + 摘要=链尾） |
| 规模 | 属性测试 5 → **9 文件 / 20 → 32 属性**，全部固定 seed、失败可复现 |
| 文档 | [MATH.md](MATH.md) 覆盖矩阵新增 4 行；SFQ 从「示例级判据」升级为属性判据；诚实边界不变（仍不声称 regret/偏差界证明） |
| 判据 | `m13-math-expansion`（≥8 文件 / ≥28 属性 + 4 个新套件均在矩阵中） |

> M13 复盘：这四类算法的共同点是「单点用例很容易全绿，但性质在边界上会破」——
> 调度器在 40 个任务下是否真的不让某会话饿死、Token 估算在混合中英文时是否单调、
> 覆盖率在 0 样本时是否除零、回执链在异步签名下是否还线性。属性测试把它们变成
> 「任意 N + 固定 seed」的断言，同时不引入第三方向量库。

### M14 执行证书（运行级可复核）✅

**研究目标**：把「可审计」从动作级回执推进到**运行级离线证明**，形成难替代的护城河。

| 工作项 | 结果 |
| ------ | ---- |
| 事件 Merkle | `eventMerkle.ts`：叶子/内部域分离、奇数上提（不做末项复制）、JCS 规范化；空流固定根；包含证明 |
| 执行证书 | `executionCertificate.ts`：`{sessionId, eventCount, eventRoot, receipt?, toolSurfaceDigest?, issuedAt}`；签名/复核；单事件包含证明 |
| 安全边界 | 证明完整性/顺序/条数 + 与回执链尾互相咬合；**不**证明内容为真、无外部 witness 时不能防整体重写（如实记录） |
| 实测 | 10k 事件建树/证书约 0.8–0.9 s（一次性、宿主显式导出时付），单条验证 ~0.5 ms；篡改矩阵 5/5 + 回执尾绑定检出；底稿 [RESEARCH-2026-11B.md](RESEARCH-2026-11B.md) |
| 判据 | `m14-execution-certificate`：契约/属性判据 + receipts 子路径导出 + 研究底稿与 MATH 矩阵 |

> M14 复盘：回执链解决「动作是否被签发」，但回答不了「事件流是否完整、顺序是否签发时、
> 某事件是否属于这次运行」。Merkle 化把这三个问题变成可复核的密码学承诺；把回执链尾
> 绑进证书，使攻击者不能只伪造一边。最大的取舍是**不做** witness 网络/公共透明日志：
> 那需要外部运维与信任根，超出内核边界，已列为后续研究问题。

### M15 执行图谱系（多智能体可验证）✅

**目标**：单次运行可复核之后，让「哪次运行由谁委派」也可离线验证——子代理/工作流历史
不能被悄悄挪到别的父会话名下，也不能凭空多出一个子运行。

| 工作项 | 结果 |
| ------ | ---- |
| 结构 | `ExecutionGraph = nodes(执行证书) + edges(parent, child, delegationEventHash?)`；整图签名 |
| 锚定 | 边可锚定到父事件流里的真实委派事件（叶子哈希 + 子会话 id 出现）；否则只能靠图签名保证完整性（如实记录） |
| 结构判据 | 单根（恰一个）、无环（Kahn）、每个子节点恰一个父；多父/环/多根分别报可读问题码 |
| 判据 | `m15-execution-graph`：契约 4 例 + 属性 1 条（随机树、删边、加环、改事件） |

> M15 复盘：多智能体系统的审计难点不是「有没有日志」，而是「日志之间的因果关系是否可信」。
> 把委派边锚定到父事件哈希后，攻击者要伪造谱系必须同时改父事件、子证书与图签名；这比
> 只给每个会话一份独立证书强一个量级。仍未解决：跨图引用（图与图之间的因果链）与
> 外部 witness。

### M16 审计包（单文件离线交付）✅

**目标**：把 M14/M15 的零件变成收证方真正能消费的**单文件交付物**。

| 工作项 | 结果 |
| ------ | ---- |
| 打包 | `AuditBundles.build({runs, graph?, exportedAt})`：逐会话生成/复用执行证书，回执链自动绑定链尾 |
| 复核 | `AuditBundles.verify`：事件证书 → 回执链（含绑定比对/验签）→ 执行图 → 整包签名，一次报告全部问题码 |
| 交付 | 可选整包签名；`AuditBundles.digest` 供公告/锚定；`scripts/verifyBundle.mjs bundle.json trust.json` 零出网复核 |
| 判据 | `m16-audit-bundle`：契约 4 例（roundtrip/事件篡改/回执篡改/图缺失/签名伪造） |

> M16 复盘：证书/图再强，收证方不会拼装就没有价值。审计包把「先验哪一层、缺哪份事件流」
> 这类装配知识收进内核；交付边界也写清了——大包适合归档取证，不适合每步传输，
> 压缩/加密/分片留作后续。

### M17 审计包运行时闭环（`kernel.exportAuditBundle`）✅

**目标**：宿主不再手工拼 events/certificates/receipts——一次 `exportAuditBundle([sessionId])`
产出 `bundle.json + trust.json + digest.txt`，第三方用一条 CLI 离线复核。

| 工作项 | 结果 |
| ------ | ---- |
| 运行时导出 | `kernel.exportAuditBundle(sessionIds, directory?)`：逐会话取事件 + 签执行证书（绑定全局回执链当前尾）+ 打包 + 整包签名 + 落盘 |
| 链作用域修正 | 回执链是 **issuer 单链跨会话共享**：证书绑定的是「签发时链尾前缀」；复核按 count 在全局链里比对尾哈希，**不再按会话过滤回执**（过滤会破坏 `previousReceiptHash` 连续性） |
| 产物 | `bundle.json`（已签名审计包）、`trust.json`（kid → SPKI）、`digest.txt`（JCS SHA-256） |
| 判据 | `m17-runtime-audit-bundle`：embed 契约（单会话 + 多会话同 issuer 链）+ `AuditBundles.verify` 复核 + CLI |

> M17 复盘：M16 的包级 `receipts` 设计在这里救了一次——最初按会话过滤回执会让
> `previousReceiptHash` 断裂、证书链尾对不上；改成包级全局链 + 前缀校验后，
> 多会话共享一个 issuer 的语义才自洽。验证也补了「多会话同链」用例，防止回归。

### M18 选择性披露（最小披露仍可验）✅

**目标**：审计包交付全量事件流——收证方拿到全部内容，披露方失去最小化披露能力。
把 M14 的 Merkle 包含证明从证书内部升格为**交付语义**：只交子集事件（每条附证明）
仍可离线复核，未选事件不出包。

| 工作项 | 结果 |
| ------ | ---- |
| 披露包契约 | `DisclosurePack`：会话 = 证书 + `disclosed[]`（事件 + 包含证明）；包级回执链**必需前缀**（第 1 条到最大绑定条数）；`kind: 'disclosure-pack'` 供 CLI 判别 |
| 构建 | `DisclosurePacks.build({runs, receipts})`：全量流只做证明源不出包；下标升序去重；回执按绑定裁剪（绑定超出链长即抛）；无绑定时回执整项省略 |
| 复核 | `DisclosurePacks.verify`：形状 → 证书自洽 → 逐条包含证明（叶子重算 + 根/条数比对）→ 前缀链 → 绑定比对 → 整包签名；绑定存在而前缀缺失即红（悬空承诺） |
| 内核导出 | `kernel.exportDisclosurePack([{sessionId, indices}], directory?)` 产出 `disclosure.json + trust.json + digest.txt`；CLI `verifyBundle.mjs` 按 `kind` 自动识别审计包/披露包 |
| 判据 | `m18-selective-disclosure`：契约 6 例（roundtrip/最小化/篡改矩阵 7 项/回执前缀/签名/叶子不变式）+ embed 内核级 1 例 + 属性 2 条 |

> 诚实边界：包含证明不证明「未披露事件存在/不存在」——收证方只知道证书承诺了
> `eventCount` 条、可验其中 K 条；回执链前缀含未披露会话的动作回执（单链固有泄露面）。
> 复核器比审计包更严一处：证书绑定回执而包内无前缀 ⇒ `RECEIPT_BINDING_MISMATCH`
> （审计包对该状态沉默，披露包把它当篡改检出）。

### M19 核心循环韧性（任务解决能力一大步）✅

**研究目标**：主循环是任务解决能力的本体。调研（agentLoopAudit + 全量代码走读）发现六处
「安全关键逻辑零专属测试 / 文档-行为矛盾 / 死代码」——本里程碑把它们逐个变成可执行判据。

| 工作项 | 结果 |
| ------ | ---- |
| 重试/熔断默认开（M19-a） | `modelRetry`/`modelCircuitBreaker` 判定 `===true` → `!==false`——修「注释/文档宣称默认开、代码 opt-in」矛盾：此前裸 429/超时直接杀死整个 runTask，与宣称的韧性相反；配置文档同步「默认开，显式 false 关」 |
| 步级可重试恢复（M19-b） | `stepOnce` 接住 `ModelCallError.retryable`（模型层退避已耗尽）——回合内限额重试 2 次（重建上下文重新调用），转录留【模型瞬时错误】；超限仍走【回合失败】fail-closed 不变 |
| 过载降级装配（M19-c） | `fallbackModel` 此前被声明（stepTypes）、被消费（stepRunner LR-04）、唯独无人赋值——纯死代码。现 config 字段 → ConfigFactory 透传 → buildTurnRunner 注入，529/503 即切备用模型并留痕 |
| 毒工具反馈（M19-d） | supervisor 早就统计失败率但循环从不消费。现 StepToolExecutor 记每工具连败（成功清零；门禁拒绝/解析失败不计——那是策略/参数问题非工具故障），达阈值 3 在下一步上下文动态尾段注入【工具异常】点名提示 + 错误摘要 + 改道建议（与 repo-map 合并同一条 system，不多断前缀缓存） |
| 工具看门狗（M19-e） | 挂死且无视取消信号的工具此前冻结整回合（LoopGuard 只在步间采样）。现单次 JS 工具执行与墙钟竞速（缺省 600s，`toolCallTimeoutMs` 可调/0 关），超时补可读失败结果（中文文案避开只读重试的英文瞬态判据）；取消竞速保持内层即时穿透 |
| 测试债收口（M19-f） | 新增 `tests/unit/loopResilience.test.ts`（9 例）：LoopGuard 四检测器（先劝后熔/健康复位/失败不参与冗余/软硬两段）、ToolScheduler（读批真并发 + model-order + 写屏障）、RetryingModel（退避成功/不可重试即抛/耗尽上抛/退避期取消穿透/分类表）；agentLoopAudit 扩 G/G2/H/I/J 五例 |
| 判据 | `m19-loop-resilience`：六项事实（默认开判定、步级重试常量与留痕、降级三点接线、毒工具阈值与注入、看门狗竞速、回归网在位）全部机检 |

> M19 复盘：六个缺陷的共同形态是「韧性能力被**宣称**了但没有**接通**」——文档说默认开
> 代码却 opt-in、字段被声明被消费却无人赋值、supervisor 有统计循环却不读。修法全部是
> 接线而非新造：每项 ≤60 行实现 + 对应判据。最有价值的一课是 M19-f：安全关键件
> （失控检测/调度屏障/重试分类）此前零定向断言，「被别的用例路过」不等于「被钉住」。

### M20 审计交付编码（压缩 / 口令加密 / 分片）✅

**目标**：把 M16 复盘明确留作后续的交付三件套收掉——审计包/披露包是单文件 JSON，
大运行动辄数十 MB 且可能含敏感载荷；交付物要经得起不可信信道与归档场景。

| 工作项 | 结果 |
| ------ | ---- |
| 编码层 | `AuditDeliveries.encode/decode`（receipts 子路径，不占顶层 60 位）：JCS → gzip（缺省开，重复性事件流实测 >50% 收缩）→ 口令加密（scrypt N=2^15/r=8/p=1 + AES-256-GCM 认证加密，参数随 manifest 记录）→ 分片（每片独立 sha256）→ `manifest.json(kind=audit-delivery) + part-*.bin` |
| 分层口径 | **编码不复核**：decode 只做传输完整性（分片摘要/字节数/内容摘要/GCM 认证，问题码 `AUDIT_DELIVERY_*`），语义复核仍走 `AuditBundles/DisclosurePacks.verify` 同一路径；两个摘要口径分开写（`digest.txt` 对外锚定不受编码影响；manifest `contentDigest` 是含签名信封的传输级完整性锚） |
| 运行时接通 | `kernel.exportAuditBundle(sessionIds, dir?, delivery?)` 交付模式直出 manifest+分片（不再写裸 bundle.json），trust/digest 照常；embed 契约钉住落盘形态 |
| CLI 接通 | `verifyBundle.mjs` 新增 manifest（`--passphrase`）与 gzip 魔数两条路径，退出码语义不变；口令经带外交付 |
| 判据 | `m20-audit-delivery`：编码三要素 + 问题码 + barrel/kernel/CLI 接线 + 契约 6 例（roundtrip 摘要不变 / 分片篡改 / 口令错误与缺失 / 压缩真实收益 / 裸包语义 / CLI 两形态）+ embed 1 例，全部机检 |

> M20 复盘：诚实边界与 M14 同风格——加密护**机密性**，完整性与来源仍由签名 + 信任根
> 承担；口令强度是宿主责任。踩坑一则：Node scrypt 缺省 maxmem 恰好等于 128·N·r（32 MiB），
> 内部开销一加即溢出（`memory limit exceeded`）——两侧显式 `maxmem: 64 MiB` 解决，
> 已写进实现注释。迁移桥收窄（M2 工作项 4）按决策另行立项：先做域生成器解析源设计
> （顶层 60 位已满是硬约束），不在本里程碑。

### M21 迁移桥显式化（通配 → 承诺闭包）✅

**目标**：兑现 BOUNDARY 的「删 `"./*"` 通配」承诺——内部路径不再自动公开，承诺面
收窄为显式清单。设计定稿：RESEARCH-2026-11C（底稿已归档）。

| 工作项 | 状态 |
| ------ | ---- |
| Phase 2a 通配 → 显式闭包 | ✅（2026-11-07）：`exportsClosure.mjs` 从应用源码生成 **251 条显式深路径 + 10 条 curated**，通配删除（alpha.9）；首跑曾扫到应用 `.tmp` 迁移暂存树（706 条 / 180 缺失）被 `m21-explicit-exports` fail-closed 拦截，扫描规则修正为跳过全部点目录——判据按设计接住了带病清单 |
| Phase 2b 应用侧机检 | ✅（2026-11-07）：app `kernel:check` 新增「实际导入 ⊆ 内核承诺清单」——309 处导入全部命中清单；内核删条目 / 应用新消费未列条目都在 install/CI 期红 |
| Phase 3 生成器解析源对齐 | ✅（2026-11-07，alpha.10）：app `kernelSurface.mjs` 解析源改为「内核承诺清单第一优先 + dist 回退黄标」——现有映射与索引候选都先过承诺过滤，stale 自续在生成期暴露；**黄标实战首秀即闭环**：B1 给 `Runtime` 的新家（`kernel/composition/runtime.js`）未入 alpha.9 清单 → 黄标 → kernel:check 红 → 倒逼内核扩承诺面（251 → 252，alpha.10）→ 应用复绿，全链按设计走完 |
| 判据 | `m21-explicit-exports` ✅ auto（无通配 + 252 条全部指向存在 dist 产物）；`m21-generator-source` ✅ manual（§6 记录：解析源对齐实现 + 黄标实战闭环 + 应用回归 748/748） |

> M21 复盘：三个教科书时刻——① 首跑 `.tmp` 污染被 fail-closed 拦截（扫描规则修正）；
> ② 解析源切换首版把「已承诺的根导入」误判为未承诺（承诺集合的根 spec 存成了带尾
> 斜杠形态），TrustTier 连带解析失败——双侧口径对齐（全 spec 剥前缀 ↔ 清单去前缀）
> 后幂等恢复；③ 黄标机制的第一次真实触发就完整走完「生成器警告 → 门禁红灯 → 承诺面
> 扩张 → 复绿」，证明「解析源 = 承诺面」的闭环不是纸面设计。runtime.ts 遗留一根导入
> （B4 时代），整桶加载的性能 wart 如实在案，随逐域 barrel 化评估处理。

### M22 认知域重入（plugin / eval / media 迁回）✅

**目标**：按 ARCHITECTURE §7.4 重裁，把 M4 孤儿归档（tag `attic/2026-11-03`）中的三个
「完整能力集」域迁回内核——定位已变（中枢 = 完整能力集，§7.1），当年「内核内部零消费」
的孤儿判据不再成立。迁移以**逻辑保真 + 形态适配**为界：attic 源码已类化达标，适配限于
shapeGuard API 对齐、路径口径（`tools/eval` → `scripts/eval`）、装配缝重建。
spark / genesis 维持不迁（experimentalPaths 在案：常量探针伪造涌现 / resonantField 折负 /
qec.repair 损坏数据）。20 个长任务合成 fixture 未随档幸存，如实记为待重建，不 mock 冒充。

| 工作项 | 状态 |
| ------ | ---- |
| eval 域：口径库四模块（AbMetrics / LongMemEval / LongTaskCatalog / TracePatchPlanner）+ `scripts/eval/longTasks.mjs` 执行入口 + 判据 | ✅（65deb24）：attic 逻辑保真迁回，类化已达标零改动；路径口径 tools/eval → scripts/eval；判据 10 例 |
| media 域：契约 16 件 + 解码栈 19 件 + 适配器 12 件 + `view_media`/`view_image` 工具 + config 三件 + toolNames + 装配 + 判据 | ✅（690d5b3）：MediaStack 随 SubagentPortSeed 下行（恢复种子注释「含媒体抽帧栈」原设计）；栈恒装配（GIF 零外部依赖）；RuntimeLimits 声明式补 media 段（processConcurrency=4，attic 原值）；configError 接入 mediaConfigValidator；判据 5 例 |
| plugin 域：契约 8 件 + 实现 31 件（含 worker 进程隔离）+ config 装配缝 + 判据 | ✅：attic 31+8 文件迁回（tsc 仅 1 错——SafeFs 已退役，broker 内联 readCapped 保留双重越界校验语义）；新缝 `PluginStackAssembler`（`plugin.enabled!==true` ⇒ undefined，fail-closed；权限白名单缺省 denyAll；`defaultTools` 返回值增加裸注册表供注册-只读视图挂载）；判据 9 例 |
| 收口：§7.2/§7.4 状态回写 + CHANGELOG + 里程碑翻账 | ✅（本 commit） |

> M22 复盘：①「迁移源不是 app master 而是本仓 attic tag」是本项目最重要的省力决策——attic
> 形态已类化达标（宪法 B 阶段前的代码已符合「纯静态类」），全部适配收缩为路径口径/旧家
> import/被删依赖三小类；②fixture 遗漏如实记账：20 个长任务合成任务未随档，`longTaskCatalog`
> 的自检/沙箱/验证逻辑照常可判据（自检不依赖 fixture 数据），数据重建显式列为待办（已由 M24 重建清零）；③4 件
> `@maturity L1` 因原判据文件未随档降级 `L0-unverified` + 恢复路径在案（maturity:check 把关）；
> ④plan:check 双向对账再次收口「做完不记账」——三 gate 全绿当场逼翻账。

### M23 断线清偿（盘点 6 缺失 + 5 畸形）✅

**目标**：清偿 M22 后全仓真码盘点（三面交叉审计在案）发现的「声明未接线」存量——
机检体系拦得住回归、拦不住「三层齐全但上游无人喂」的断线，本轮把它们逐个变成判据。

| 工作项 | 状态 |
| ------ | ---- |
| ssrfPolicy 接线（安全级）：seed 携带 resolved policy → `web_fetch` 两处 check 传 `{ ssrf: { policy } }` → 判据 | ✅（b80f2bf）：`SsrfOptions.policy` 注入面早已预留（注释明写「由组合根注入」）只是没人注入——组合根 `resolveSsrfPolicy` 解析一次随 seed 下发；未注入行为逐字不变；判据 4 例 |
| plugin 端到端：`createOmniKernel` 装载触发（loadInstalled + onError 告警）+ `capabilities()` 补 mediaStack/pluginStack/capabilityStack + plugin/capability 入 passthroughSections → 判据 | ✅（39b9e52）：enabled ⇒ 启动即装载（逐件告警不断链）；判据 3 例走仓库内 fixture（vitest 会拦项目外动态 import，生产 node 无此限，dist 冒烟验证全链） |
| 工具面一致性：补 `tests/unit/toolNames.test.ts`（源文件承诺的三断言）+ loopGuard 写类口径收敛 MUTATING_TOOLS/TOOL_NAMES + 消费侧字面量漂移清理 + 注释账实差 | ✅（ac0f0b5）：三断言判据落盘（A 已注册⊆表 / B 表自洽 / C 漂移哨兵）；loopGuard 第二套字面量收敛；spillMaxRings 死字段删除；默认工具数注释 31/36→37/45；a2a 幽灵字样；toolNames 注释错位修位 |
| 存量处置：spillMaxRings 死字段删除 + eval dry-run 目录缺失指引 + observability metrics 决断（接线或记账） | ✅（ac0f0b5）：runner 裸抛错改可行动指引；**metrics 项为审计误判纠正**——`TraceExporterAssembly.wrap` 已实现 metrics 腿（`METRICS_ENDPOINT_ENV` 门控）、`cacheHitRateCollector` 被 repoMap 消费，全域在线无需改码 |

> M23 复盘：①审计代理的三处误判照实入账——metrics「零引用」实为 wrap() 已实现（审计只扫了
> 自域引用）；`EgressPolicy.check` 的 `options.ssrf` 一直存在（断点是上游无人喂，不是接口缺失）；
> `pluginProfile` 与 locale/chatMode 同属应用层字段，内核零消费是正常形态非缺口。②「三层齐全
> 但上游无人喂」是机检体系的盲区：boundary/arch/plan 全绿挡不住 ssrfPolicy 这种断线——M23 的
> 三条 gate 把「链上每一跳的引用事实」钉进 plan:check，同类回归自此红灯。③教训回收：本仓
> 自己的「声明未接线」病在 M9/M19 各清过一轮后仍有存量，根因是新能力接线时只看「消费点编译过」
> 不问「用户配置到没到」——ssrfPolicy 判据按「用户配置 → 出站拦截」整链写，是这类判据的模板。

### M24 评测闭环与收尾（fixture 重建 / 漂移清偿 / 文档账实）✅

**目标**：清偿 M22 的最大遗留（长任务 fixture 未随档幸存）+ M23 审计的剩余漂移与文档账实，
让 eval 口径库从「代码通、数据缺」变成**端到端可跑**。

| 工作项 | 状态 |
| ------ | ---- |
| fixture 重建：规格驱动生成器 `scripts/eval/materialize-fixtures.mjs` + 23 个合成任务（tasks/fixtures/verifiers/solutions 四件套，超原 20 计划） | ✅（本 commit）：四族覆盖（结构化进度×5 / 库实现×5 / 修 bug×5 / 跨文件状态×8）；fixture 自带 `package.json {"type":"commonjs"}`（防沙箱被宿主 "type":"module" 波及）；**self-check 23/23 全绿**（参考解全部过机械验收）；dry-run 可用 |
| 消费侧字面量漂移清偿 | ✅：toolResultSpiller（DEFAULT_EXEMPT/COMPRESSED_TOOLS）、provenanceTracker（UNTRUSTED_TOOLS）、subagentTypes（SUBAGENT_TOOL_NAME）、acpQuestionUplink（ask_user 上行）全部收敛 TOOL_NAMES——gate `m24-drift-cleaned` 永久把守 |
| 文档账实 | ✅：README「createOmniKernel 符号不存在」核实为**审计误报**（M21 后 README 已用真名），gate `m24-docs-truth` 锁定 README↔代码符号一致 |

> M24 复盘：①fixture 生成的三连坑全部由 self-check 判据当场抓获（沙箱被宿主 "type":"module"
> 波及成 ESM → fixture 自带 package.json 钉死 CJS；三个解漏 import node:path；Kahn 同层排序
> 期望序写错）——「参考解必须过机械验收」的自检设计把生成器的每个 bug 变成红灯，这正是
> 该判据存在的意义。②评测闭环至此端到端：23 任务可 dry-run / self-check / 跑分（跑分自动化
> 仍待应用仓 CLI，诚实边界在 runner 头注）。③应用侧 kernel-compat 退役为跨仓动作（需内核
> 发版 + 应用升级回归），不在本里程碑——内核侧已备齐（plugin/media/eval 能力面 + 承诺闭包
> 扩展按 M21 流程随应用消费添加）。

### M26 应用侧终盘收编（kernel-compat 通用件 + 影子清偿）✅

**目标**：应用侧两轮独立盘点（kernel-compat 全量 100 文件 + src/apps 通用能力扫描，2026-11-07
交叉确认）发现三类残留，本轮统一收编进内核并对外提供能力：①**影子副本**——rpc/transport
四件套与内核同名同体（逐字节 diff），内核早已有实现只是未承诺导出，应用被迫留副本服役；
②**契约-实现分裂**——`KvPort` / `AssetPackPort` / `ApprovalRule` / `EventPort` /
`EscalationPort` 契约全在内核，实现却留在应用 kernel-compat（内核 `sessionArchiveLayout`
头注释甚至点名应用侧 `sessionEventReader` 为必须回落归档目录的消费方）；③**通用件漂移**——
retry / quantileSketch / mimeType 等零应用形状纯工具留在应用侧，内核 util 族存在自然缺口。
迁移沿用 M22 纪律：逻辑保真 + 形态适配，端口不动、实现归位、承诺闭包前置（M21 流程预测形态）。

| 工作项 | 状态 |
| ------ | ---- |
| 影子清偿前置：exports 承诺闭包 += kernel/rpc/jsonRpc + kernel/transport 三件（应用消费点改写随后续发版） | ✅（a25c9a1） |
| 适配器补全族迁回：approval（ask/plan/guardian+prompt/builtinRules）+ escalation（ask/auto）+ event（composite 扇出）+ kv 三件套（KvPort 契约早有承诺、实现缺口）+ 判据 | ✅（a25c9a1） |
| vault 族迁回：VaultPort 契约 + CryptoVault（AES-256-GCM）/EnvVault 实现 + credentialResolver + 判据 | ✅（41c4276） |
| trace 自省族迁回：只读自省契约（Entry/Filter/Port/ReadRequest/ReadResult）+ ReadonlyTraceReader/SessionEventReader（回落归档目录语义与 sessionArchiveLayout 头注对齐）+ 判据 | ✅（5d227a5） |
| util/config 补全族迁回：retry（concurrency 族自然缺口）/jsonObjectFile/localDay/mimeType/portablePath/quantileSketch/configRebase + 判据 | ✅（9075aae） |
| skill 签名 + asset 收编：skillManifestSigner（Ed25519 分发签名，内核已有 ed25519 工具）+ assetPackCodec/assetPackInstaller（AssetPackPort 契约早有承诺，ADR-0011）+ 判据 | ✅（003ce7f） |
| 核心循环/观测补全收编：interjectionClassifier（插话分流，纯文本启发式，归 `core/steering`）+ cacheHitRateWatch/cacheMissAttributionAnalyst（缓存坍塌告警 + 未命中分因；内核 `cacheHitRateCollector` 头注释早已引用前者）+ 判据 | ✅（003ce7f） |
| 收口：BOUNDARY 迁移桥计数翻新 + CHANGELOG + 翻账 | ✅（本 commit） |

> M26 复盘：①判据当场抓获两处迁移期问题——`MemoryKv.close()` 语义是清空存储
> （vault 判据中途 close 把密文清掉了，改用「换实例换密钥」测轮换）、内核 `EventType`
> 是 snake_case 严格联合（应用侧事件夹具逐一对齐）；②**诚实边界修正一处**：应用侧
> quantileSketch 头注声称「确定性秩误差 ≤ εn」，迁移时按正确秩度量实测（n=2000、ε=0.05）
> 最坏秩误差 ≈0.07n（单调流）/0.18n（随机流）——声称与行为不符，头注改为实测误差带 +
> 恢复路径（论文 band 压缩全量实现），MATH.md 诚实边界同款处置；③承诺闭包 252 → 315
> 条深路径（M21 预置形态），应用侧 kernel-compat 对应件可在下次 vendored 发版升级时
> 退役（跨仓动作，判定清单在案）；④公开面 60/60 不变（全部新增走子路径，契约不进桶）。

### M27 兼容层清零（kernel-compat 退役 + SDK/打码终批收编）✅

**目标**：兑现「中枢 = 完整能力集」的终态——**应用侧不存在名为 kernel-compat 的目录**。
该目录是 vendored 切换期的收容所（README 自述），M22/M25/M26 已清偿其内核形状部分；
M27 做完三件事后整体除名：①内核终批收编（SDK 客户端族重审迁入 + 凭据打码单一事实源）；
②alpha.12 发版（M26+M27+M28 内容）；③应用 vendored 升级 → 41 件影子退役 + 死代码清偿 +
目录更名 extensions（跨仓人工判据）。此后应用对接只有一条路：`src/host/kernel/<域>.ts`
对接面 → 内核公开面；不再有第二份实现可逃逸。

| 工作项 | 状态 |
| ------ | ---- |
| SDK 客户端族重审迁入：SdkSocket 契约 + SdkClient（rpc 客户端半边，与服务端 jsonRpc 配对）+ WebSocketSdkSocket + 判据 | ✅（187fa15，判据 6 例） |
| 凭据打码单一事实源：SecretRedactor（递归打码 + maskKey 收敛三处分裂）+ 判据 | ✅（187fa15） |
| alpha.12 发版：version/CHANGELOG/打包验证（M26+M27+M28 入版，tag v0.1.0-alpha.12 = 187fa15） | ✅ |
| 应用 vendored 升级：删 41 件影子 + 47 消费文件改写（codemod 静态+动态 import 双形态）+ 18 域文件再生 + 死代码清偿 3 处 + 目录更名 extensions + 全量回归 | ✅（跨仓，§6 人工判据证据） |

> M27 复盘：①判据当场抓获真 bug 一枚——`SdkClient.bindSocket` 对 onClose 分两次注册，
> 而 `WebSocketSdkSocket.onClose` 是「最后一次注册生效」语义，第二次注册覆盖第一次，
> S14 的「就绪前 close 必须兑现 opened」在应用原实现中静默失效（判据首跑挂起 30s 暴露）；
> 内核侧修为单一 onClose 注册，应用随 alpha.12 升级同步受益。②「兼容层」的正名收尾：
> 该目录从未进过内核——它是应用侧的切换期收容所，M22 起按「中枢=完整能力集」教义清偿四轮
> （M22/M25/M26/M27），本里程碑以目录除名收官；同日并行会话的 M28（插话词表配置化）与
> 本里程碑在同一工作树交汇，共享账面文件按用户裁决先行提交、src 实现各自提交，未踩踏。
> ③应用侧对接面终态实测：360 处包导入全部命中内核承诺闭包（329 条承诺，黄标 0），
> `kernel:check` + 全量回归（web 748 + desktop 30 + smoke 原生实载）全绿。

**裁决不迁**（决策日志在案）：laya 九件（M3 厂商绑定裁决）、cronerSchedule（第三方依赖准入在应用）、
webLiveView / sdkSocket / webSocketSdkSocket / doctorReport / injectionSelfCheck 三件 / worker 三件 /
mcpRegistryClient / mcpServerCommand / modelCapabilityProbe / graphStore / agentPersonas /
maintenanceRunner / serveInstance / tmpSweep / sessionGc / daemon 端口族 + RoutineScheduler（应用
产品形状，且同仓另有第二套 automation 定时器需产品决策先合并）、sdkClient / codeGenerator
（维持 2026-11-03「应用形状清零」裁决）；仓内重复孤儿 kernel-compat/util/safeFs（零消费方）由
应用侧在升级时删除。audit 域通用半边（auditCanonical→Jcs 合并 / auditSink / auditExporter）与
凭据打码统一列为后续独立裁决（需 golden 逐字节对齐口径，见 M24 复盘③同款跨仓约束）。

### M28 插话词表配置化（defaults 数据 + omniharness 覆盖段）✅

**目标**：M26 收编的 `interjectionClassifier` 把打断词 / 关联词 / 确认句正则 / 停用词 /
三个判定旋钮（12 / 2000 / 0.15）写死在类常量里——调一条词、换一个阈值都要改代码重发
（违反「无硬编码：默认值走 defaults/*.json」）。本轮按 ssrfPolicy 同款链路配置化：
出厂词表进 `defaults/interjection.json`（改数据不改代码），用户侧 `omniharness.json` 的
`interjection` 段逐键**替换**覆盖，加载期 `interjectionConfigValidator` 与运行时
`InterjectionLexicon.resolve` 同源校验，configFactory 透传进 ResolvedConfig。

| 工作项 | 状态 |
| ------ | ---- |
| 词表配置化全链：defaults/interjection.json（七键逐字迁移）+ InterjectionLexicon 解析器（fail-closed 校验 + 逐键替换 + 出厂单例）+ 判定器改词表注入（既有调用面零改动）+ interjectionConfigValidator + configError/configFactory 接线 + 判据 | ✅（本 commit） |

> M28 复盘：①判据①的「历史逐字钉住」当场证明七键迁移零漂移（27 打断词 / 30 关联词 /
> 34 停用词 / 正则源串 / 三旋钮逐项相等）；②覆盖语义选定**逐键替换**而非合并（与 ssrfPolicy
> 同口径），显式空数组=清空（显式且危险，README 记录）；③`ackPattern` 存正则源串、编译
> 旗标 `i` 固定在代码侧（旗标进数据会诱导写出 `g` 这类带状态旗标，`test()` 语义漂移）；
> ④分类器尚无生产消费方，配置段先完成「校验 + 透传」两段，判定器接线（消费点读
> ResolvedConfig）留给核心循环接线里程碑。

### M29 审计 canonical 单一真源（auditCanonical → 内核 Jcs）✅

**目标**：清偿 M26 遗留的最后一项跨仓裁决——审计哈希链的序列化口径收敛为**内核 Jcs 一个实现**。
逐字节对齐结论（`tests/unit/jcsAuditAlignment.test.ts` 钉死）：**JSON 合法值域内，应用侧历史
AuditCanonical 与内核 Jcs 输出恒同**（键序同为 UTF-16 码元 sort、转义同为 JSON.stringify 语义、
数字同为 Number::toString 含 `-0→"0"`）；差异只在 JSON 非法值——历史实现**宽松改写**
（NaN→null、Date→{}、数组 undefined→null，哈希静默盖住被改写的值），Jcs **fail-closed 抛错**。
对审计信任面，fail-closed 严格更优：迁移即加固，行为变更如实入账（JSON 非法输入从「静默改写后
哈希」变为「显式拒绝」；JSON 合法输入的历史审计报告逐字节可验，链头哈希不变）。

| 工作项 | 状态 |
| ------ | ---- |
| Jcs 深度护栏补齐：`MAX_DEPTH = 64`（口径取自历史实现；回执载荷扁平、零行为变更；外部输入防环/防炸栈）+ 判据 | ✅（本 commit） |
| exports 承诺闭包 += `kernel/receipts/jcs.js`（应用审计域消费前置）+ 逐字 golden / fail-closed / 链头稳定性判据 4 例 | ✅（本 commit） |
| alpha.13 发版 + 应用侧切换（auditChain/auditReportBuilder/auditReportVerifier 改指 Jcs，auditCanonical 退役，HTML 复核脚本 golden 对齐） | ✅（跨仓，见 §6） |
| 裁决留应用：auditSink（链原语已共享内核 HashChain；轮转/落盘布局属部署形状）、auditExporter（维持 2026-11-03「审计导出格式属 server 层」裁决） | ✅（决策日志在案） |

### M32 AAT 决策级审计（执行前决策 / 策略快照 / 导出复核）✅

**目标**：把「可审计」从动作级回执推进到**执行前授权证据**——回答「这个动作在执行前是否被允许、
依据哪版规则、谁授权」。实现 IETF AAT 的可实现子集，不新增顶层符号。

| 工作项 | 结果 |
| --- | --- |
| 审计链 | 新增 `audit` 事件类型 + `AuditRecorder`（`prevHash → hash` 线性链，坏链构造期 fail-closed）；`audit` 不投影进模型上下文、不进检索索引 |
| 策略快照 | `PolicySnapshotBuilder`：审批 / 沙箱 / RBAC / 注入护栏 / 来源污点 / 意图策略 / 记忆信任档 / 计划模式 / 工具面 → `snapshotHash`；`RunManifest.policySnapshotHash` 同源 |
| 执行前决策 | `StepToolExecutor` 在门禁裁决后、执行前写 `decision`（allow/deny/unavailable + requestDigest + policySnapshotHash + principal）；`OmniKernel.create()` 缺省开启，`Agent` 直构默认关 |
| 导出/复核 | `AatExporter.build/verify` + `kernel.exportAat(sessionId)` 产出 `aat.json + digest.txt`；复核失败拒绝落盘（不导出坏证据） |
| 可核对 | `capabilities().securityPosture` 如实报告审批 / 沙箱 / 注入 / 污点 / 意图 / RBAC / 自验证 / 回执签名状态 |
| 判据 | `tests/unit/auditAat.test.ts`（链/导出/改内容/断链/重复 ID/缺 principal）+ `tests/contract/auditWiring.test.ts`（一次接入执行前 decision + `exportAat` + posture）；`m32-aat-records` / `m32-aat-export` / `m32-aat-wiring` 入 `plan:check`；文档 [AAT.md](AAT.md) / [STANDARDS.md](STANDARDS.md) |

> **诚实边界**：本里程碑覆盖 AAT 的 record phase / decision / principal / 链式哈希 / session hash；
> **未覆盖** tombstone 内容擦除、后量子签名、硬件证明、闭源模型决策可复现（AAT -09 §13）。
> AAT 草案是个人稿、未获 IETF 背书；导出物是「可复核证据格式」，不是合规认证。

### M33 CTA 上下文污点隔离（污点格 / 数据面 Merkle / step-up 执行前拦截）✅

**目标**：把提示注入防护从「字符串片段匹配、默认关闭」升级为「可记录、可签名、执行前可拦截」的
上下文污点判定，对齐 IETF WIMSE CTA 草案的可执行子集。

| 工作项 | 结果 |
| --- | --- |
| 污点状态 | `ContextTaint`：从事件流派生数据面块；`TRUSTED_ONLY → MIXED_TAINT → UNTRUSTED_INGESTED` 单调不降；数据面 Merkle（JCS + 域分离叶子）与系统提示摘要 |
| 效果类 | `ContextTaint.effectClassOf`：读 → `READ_ONLY`；写/状态 → `STATE_MUTATING`；exec/network/delete/high-risk → `PRIVILEGED_ACTUATE`；`needsStepUp` 只对非只读 + 非可信上下文生效 |
| CTA 信封 | `TaintAttestationBuilder`：`invocationId` / `parentTraceRef` / 数据面 Merkle / 污点级 / 效果类 / `iat/exp` / 可选 Ed25519 签名；`verify` 检出过期/篡改/未签名 |
| 执行前拦截 | `StepToolExecutor.enforceCta`：门禁通过后、执行前判定；`shadow` 只记、`enforce` 无匹配 step-up 回执即 `policy-denial`，并补配对结果；`ctaStepUp` 端口由宿主注入 |
| 可核对 | `securityPosture.ctaMode` 如实报告 off/shadow/enforce；`OmniKernel.create()` 缺省 `shadow`，库级 `Agent` 缺省 off |
| 判据 | `tests/unit/contextTaint.test.ts`（污点/Merkle/效果类/签名/篡改/过期）+ `tests/contract/auditWiring.test.ts` 的 `cta-enforce`（读文件后 shell 无回执即拒 + `context_taint` 记录）；`m33-cta-core` / `m33-cta-wiring` 入 `plan:check`；文档 [CTA.md](CTA.md) |

> **诚实边界**：污点级是来源分类，不是「模型一定被注入」；step-up 回执的审批者身份由宿主端口负责；
> 当前只在内核执行前判定 + 审计记录，**未**覆盖 MCP HTTP 头全链互操作。默认 shadow 先攒误报，
> 再按动作类升 enforce；不把它宣传成「零误报注入防火墙」。

### M34 效果日志（崩溃一致性 / resume 对账）✅

**目标**：把「`tool_call` 已落盘、`tool_result` 未落盘」的崩溃窗口变成可对账的状态，
避免 resume 对有副作用的调用盲目重跑。

| 工作项 | 结果 |
| --- | --- |
| 日志 | `EffectJournal`：append-only JSONL（0600），每行 intent/result；构造期逐行复核，坏行/重复条目 fail-closed |
| 分类 | `pure` / `idempotent`（带 `SHA-256(JCS(args))` 幂等键）/ `at_most_once` / `compensable`；未知工具保守按 `at_most_once` |
| 对账 | `reconcile(toolCallId)`：completed / retry_safe / unknown / none；`explain()` 给 resume 用的机器可读码 |
| 接线 | `StepToolExecutor` pre 钩子后、执行前 begin；结果/异常后 finish；取消不 finish（留 intent）；`Agent.resume/fork` 的悬空调用补录带 `[effect: …]` |
| 默认 | `OmniKernel.create()` 缺省开（`effectJournal:false` 关）；`Agent` 直构默认关 |
| 判据 | `tests/unit/effectJournal.test.ts`（跨重启/幂等/未知/重复/坏行）+ `tests/contract/auditWiring.test.ts`（真实回合落 intent+result）；`m34-effect-journal` / `m34-effect-wiring` 入 `plan:check`；文档 [EFFECTS.md](EFFECTS.md) |

> **诚实边界**：不承诺外部系统「恰好一次」；日志可被有写权限者篡改（审计证据仍走 AAT/回执链）；
> 不自动重放/自动补偿；`compensable` 仅占位。

### M35 Agent Skills 规范字段（license / compatibility / metadata / allowed-tools）✅

**目标**：让 `SKILL.md` 能直接消费 [Agent Skills 规范](https://agentskills.io/specification) 的
frontmatter，而不是只认本仓的 `name/description/tags/resources/exclusive`。

| 工作项 | 结果 |
| --- | --- |
| 字段 | `Skill` / `SkillEntry` 增可选 `license` / `compatibility` / `metadata`（字符串映射）/ `allowedTools`；全部向后兼容 |
| 解析 | `SkillMdCodec` YAML 路径与无 YAML fallback 路径都解析；`metadata` 只收字符串值；`allowed-tools` 走数组/逗号解析 |
| 序列化 | `serialize` 输出上述字段；JSON 流式映射是合法 YAML，往返一致 |
| 安全边界 | `allowed-tools` 只是**建议**，不自动授权；仍须 ToolGate/审批；`.agents/skills` 已由 `OMNI_AGENTS_SKILLS=1` 门控（默认关，避免 coding-style 误注入） |
| 判据 | `tests/unit/skillMdCodec.test.ts`（6 例，含规范字段往返）；`m35-skills-spec` 入 `plan:check`；[STANDARDS.md](STANDARDS.md) 状态更新 |
| 边界 | `scripts/` / `references/` / `assets/` 的渐进披露不做（MCP/Agent Skills 子集承诺，见 [RESIDUAL.md](RESIDUAL.md) N9） |

### M36 AAT 单次授权（issue / consume / 复用拒绝）✅

**目标**：把「审批一次」从运行时内存决策变成**执行前标记、重启后仍拒绝复用**的持久授权。

| 工作项 | 结果 |
| --- | --- |
| 台账 | `AuthorizationLedger`：append-only JSONL（0600）；构造期重放并校验（坏行/重复 issue/悬空 consume 都 fail-closed） |
| 签发 | allow 时 `issue(auth:dec:<callId>, requestDigest, snapshotHash, validUntil)`；令牌写入 decision 记录 `authorizationId` / `validUntil` |
| 消费 | 执行前 `consume`；失败码 `UNKNOWN/REUSED/EXPIRED/NOT_YET_VALID/REQUEST_MISMATCH/SNAPSHOT_MISMATCH` → `policy-denial` + 配对结果 |
| 导出 | `decision.action_detail.authorization_id`；同一授权出现在两条决策 ⇒ `AUTHORIZATION_REUSED` |
| 接线 | `StepAuthorizationGate`（issue/consume）；`Agent` 在 auditRecords 开启时按会话建台账；`StepToolExecutor` 执行前调用 |
| 判据 | `tests/unit/authorizationLedger.test.ts`（跨重启/复用/过期/摘要/快照/坏行）+ `auditWiring` 台账落盘与 decision 字段 + `auditAat` 复用检出；`m36-authorization` / `m36-authorization-wiring` 入 `plan:check`；文档 [AAT.md](AAT.md) §5 |

> **诚实边界**：防「同一授权被重放/重复执行」；不防签发方整体重写台账（需外部 witness/锚定）；
> 台账文件可被有写权限者篡改，审计证据仍以回执链/证书为准。

### M37 可衰减委托链（签发 / 衰减 / 整链复核）✅

**目标**：父 Agent 把工具 scope 委托给子 Agent 时，子权限必须 ⊆ 父权限、主体不变、
过期不晚于父、深度不超限；整条链可离线验签。

| 工作项 | 结果 |
| --- | --- |
| 令牌 | `DelegationToken`：principal / agent / parentTokenHash / depth / maxDepth / authority / 过期 / Ed25519 签名（JCS unsigned） |
| 签发/衰减 | `issueRoot` + `attenuate`：父验签、scope ⊆ 父、过期 ≤ 父、深度 +1 ≤ maxDepth、调用预算 ≤ 父；越权 fail-closed |
| 复核 | `verify`（单令牌）+ `verifyChain`（逐跳父哈希/主体/scope/过期/深度/预算）；10 类问题码 |
| 边界 | 已接入 `SubagentRunner` / `ToolContext` / `StepToolExecutor`（M42/M43）；自动签发要求同一 `delegationSigner` |
| 判据 | `tests/unit/delegationChain.test.ts`（3 例：根→子→孙、scope/过期/深度拒绝、换主体/改父哈希/换签名者/过期检出）+ `delegationWiring.test.ts`；`m37-delegation-chain` 入 `plan:check`；文档 [DELEGATION.md](DELEGATION.md) |

> **诚实边界**：不是完整 OAuth/WIMSE（无 `par_hash`/DPoP/授权服务器）；自动签发要求父子同一
> `delegationSigner`（跨 issuer 信任根未建模）。

### M38 MCP Skills 扩展（skills/list / skills/get / 能力声明）✅

**目标**：让外部 MCP 客户端能发现/读取本仓技能，而不是只把工具暴露出去。

| 工作项 | 结果 |
| --- | --- |
| 后端 | `McpServerOptions.skills?: SkillRegistryPort`；未注入时**不注册** skills/* 且**不声明**扩展（能力诚实） |
| 方法 | `skills/list`（只元数据：name/description/tags/license/compatibility/metadata/allowedTools）+ `skills/get`（含 instructions） |
| 能力 | `server/discover` 的 `capabilities.extensions['io.modelcontextprotocol/skills']` 仅在注入时出现 |
| 接线 | `McpHttpAssembly` 从 `runtime.config.skillRegistry` 注入（`OmniKernel.mcpServe` 自动获得）；stdio `McpServeRunner` 支持 `skills` 选项 |
| 边界 | `scripts/` / `references/` / `assets/` 的渐进披露不做（MCP/Agent Skills 子集承诺，见 [RESIDUAL.md](RESIDUAL.md) N9） |
| 判据 | `tests/unit/mcpSkills.test.ts`（2 例：list/get + 能力声明/未注入不声明）；`m38-mcp-skills` 入 `plan:check`；[STANDARDS.md](STANDARDS.md) 状态更新 |

> **诚实边界**：本里程碑只覆盖 Skills 扩展的发现/读取；`scripts/references/assets` 渐进披露明确不做（见 [RESIDUAL.md](RESIDUAL.md) N9）。

### M39 MCP Tasks 扩展（task handle / get / update / cancel）✅

**目标**：长任务不再阻塞 `tools/call`；服务端返回 durable task handle，客户端轮询/回填/取消。

| 工作项 | 结果 |
| --- | --- |
| 端口 | `McpTaskPort`（accepts/create/get/update/cancel）+ `McpTaskRecord`（status/TTL/poll/result/error/inputRequests） |
| 协议 | 异步工具 `tools/call` 先过门禁 → `create()` → `{resultType:"task", taskId, status, …}`；`tasks/get` / `tasks/update` / `tasks/cancel` |
| 能力 | `server/discover` 仅注入时声明 `io.modelcontextprotocol/tasks`；未注入 `tasks/*` 不存在、`tools/call` 保持同步 |
| 接线 | `McpHttpAssemblyOptions.tasks` + `OmniHarnessConfig.mcpTasks`（`OmniKernel.mcpServe` 自动注入）+ `McpServeOptions.tasks`（stdio fallback） |
| 判据 | `tests/unit/mcpTasks.test.ts`（2 例：异步 task/get/update/cancel/能力；未注入同步 + 404）；`m39-mcp-tasks` 入 `plan:check`；文档 [MCP-TASKS.md](MCP-TASKS.md) |
| 边界 | task 持久化/恢复/幂等由宿主端口负责；`run_goal`/`run_workflow` 自动映射未立项（见 [RESIDUAL.md](RESIDUAL.md) H2/H8） |

> **诚实边界**：内核只做协议形状与门禁前置；task 的持久化/恢复/幂等由宿主实现；取消是协作式，
> 不承诺强杀后台工作。

### M40 记忆治理与可靠性回执（provenance / 准入 / 墓碑 / 签名报告）✅

**目标**：让长期记忆**可追溯、可准入、可墓碑**，并让运行可靠性成为**可签名/离线复核**的交付物。

| 工作项 | 结果 |
| --- | --- |
| 来源证据 | `MemoryFact.provenance`（sourceEventIds / contentHash / sourceTrust）；`MemoryGovernance.provenanceOf` 生成；旧事实可选零迁移 |
| 写入准入 | `MemoryGovernance.admit`：空文本/非法重要度/重复内容/注入片段四类拒绝；`governance`/`OMNI_MEMORY_GOVERNANCE=1` 时自动接入 `remember()`（`OmniKernel` 默认开，`longTermMemoryGovernance:false` 关） |
| 墓碑 | `FileLongTermMemory.tombstone`：recall 跳过、all/get 保留、跨重启持久；物理删除仍走 `delete` |
| 可靠性回执 | `ReliabilityReports.build/sign/verify`：pass@1 / pass^k / passAllK / tokensPerSolved + 注入/记忆/失败分类；`EnvelopeSignature` 签名与 TrustStore 复核；`exportAat`/`exportAuditBundle` 可带报告摘要 |
| 判据 | `tests/unit/memoryGovernance.test.ts`（3 例）+ `tests/unit/reliabilityReport.test.ts`（2 例）+ `auditWiring`/`auditBundle` 报告断言；`m40-memory-governance` 入 `plan:check`；文档 [MEMORY-GOVERNANCE.md](MEMORY-GOVERNANCE.md) |
| 边界 | 不设 LongMemEval CI 门禁：mock case 池对 BM25 饱和、无区分度；真实门禁需数据集/凭据（见 [RESIDUAL.md](RESIDUAL.md) R1/N10） |

> **诚实边界**：准入是保守下限（不做语义事实校验）；报告只汇总传入 run，样本小就写小；
> 签名只证明报告未被改，不证明 run 本身没有作弊。

### M41 CTA 的 MCP 服务端互操作（`_meta.ctxIsolation` + McpCtaPort）✅

**目标**：外部 MCP 客户端可携带 CTA 信封，服务端在执行前校验；缺失/无效即拒。

| 工作项 | 结果 |
| --- | --- |
| 端口 | `McpCtaPort.verify({attestation, toolName, arguments}) -> {ok, code?}`；`McpServerOptions.cta` 可选 |
| 协议 | `tools/call` 读 `_meta['io.modelcontextprotocol/ctxIsolation']`；`ok:false` → `-32602`，不执行工具；未注入端口不检查 |
| 接线 | `McpHttpAssemblyOptions.cta` + `OmniHarnessConfig.mcpCta`（`OmniKernel.mcpServe` 自动注入）+ `McpServeOptions.cta`（stdio fallback） |
| 边界 | `scripts/`/`references/` 渐进披露不做（N9）；跨 issuer 委托信任根已由 M44 补齐 |
| 判据 | `tests/unit/mcpCta.test.ts`（2 例：缺失/污染拒绝 + 可信放行；未注入零行为）+ `mcpStatelessClient` 客户端 `_meta` 用例；`m41-mcp-cta` / `m43-cta-client` 入 `plan:check`；[CTA.md](CTA.md) §5 |

> **诚实边界**：服务端接收/校验与客户端主动发送均已接线；主机端口负责签名/污点策略本身。

### M42 委托链工具层接线（ToolContext / config / subagent）✅

**目标**：令牌链不再只是库级能力；宿主/子代理把 token 带进运行时后，工具层真实收窄。

| 工作项 | 结果 |
| --- | --- |
| 入口 | `OmniHarnessConfig.delegation` → `ResolvedConfig.delegation` → `ToolContext.delegation` |
| 子代理 | `SubagentRequest.delegation` → `SubagentPortsShape.delegation` → 子代 `ResolvedConfig` → 子代 `ToolContext` |
| 执行前 | `StepToolExecutor` 在门禁前校验**验签/有效期 + `call.name ⊆ authority.scopes` + `maxCalls`**；不通过 → `invalid/denied/exhausted` + `tool_result` |
| 判据 | `tests/contract/delegationWiring.test.ts`（scope 拒绝 + maxCalls 扣减 + delegation 审计）；`m42-delegation-wiring` / `m43-delegation-auto` 入 `plan:check`；[DELEGATION.md](DELEGATION.md) §5 |
| 后续 | 跨 issuer 信任根/吊销列表与共享预算已由 M44 补齐（`DelegationTrustRegistry` / `DelegationRevocationPort` / `DelegationUsage`）；本里程碑当时只做同 issuer |

> **诚实边界**：`SubagentRunner` 已能自动签发/衰减；自动签发要求父子同一 `delegationSigner`。

### M43 边界收口（CTA 客户端发送 / 委托自动签发+预算 / 记忆自动治理+报告入 AAT/审计包）✅

| 工作项 | 结果 |
| --- | --- |
| CTA 客户端 | `StepToolExecutor` 把 CTA 信封放入 `ToolContext.ctxIsolation`；`McpGateway` 透传；`McpStatelessClient` / `McpClient` 写 `_meta.ctxIsolation` |
| 委托自动签发 | `SubagentRunner` 无显式 token 且配置 `delegationSigner` 时：有父令牌 `attenuate`（scope 裁到父交集）、无父令牌 `issueRoot`（scope = 子代工具视图） |
| 委托执行期 | `StepDelegationGate` 验签/有效期 + scope + `maxCalls` 扣减；`Agent` 维护 `DelegationUsage` |
| 记忆自动治理 | `FileLongTermMemory` 的 `governance`/`OMNI_MEMORY_GOVERNANCE=1`：自动 provenance + 准入（重复/注入 `MEMORY_REJECTED`） |
| 报告入证据 | `ReliabilityReports.summaryForAat` + `exportAat(..., report)` 追加 `reliability_report` lifecycle 记录；`exportAuditBundle(..., report)` 写入包级 `reliability` |
| 判据 | `mcpStatelessClient`（`_meta.ctxIsolation`）、`delegationWiring`（scope + maxCalls）、`memoryGovernance`（自动治理）、`auditWiring`（AAT 报告）、`auditBundle`（包级报告）；`m43-*` 入 `plan:check` |

> **保留边界**：直接构造 `FileLongTermMemory` 时自动准入默认关闭（显式开启）。

### M45 校准自主性（共形风险控制放权层）✅

**目标**：把「审批自动化」从静态策略推进到**带统计保证的自适应放权**——共形风险控制
（Conformal Risk Control，可交换性下分布无关）：给定用户风险预算 α，自动放行阈值满足
`E[新调用不利 ∧ 被自动放行] ≤ α`。设计底稿 RESEARCH-2026-11E（已归档）。

| 工作项 | 结果 |
| ------ | ---- |
| 数学核心 | `ConformalRiskCalibrator`（CRC 镜像公式：最大可满足网格点）；属性判据钉公式对拍 / α 单调 / MC 有效性 / fail-closed |
| 放权点唯一 | `CalibratedApprovalPort`（ApprovalPort 装饰器）：校准充分且分数低于阈值直接放行并留结构化证据，其余逐字节透传内层；沙箱/计划/污点/委托/规则 deny 绝对面在 ToolGate 其他层永不放松 |
| 特征与配置 | `ToolRiskScorer`（确定性分数，权重走 `defaults/kernel/riskScorer.json`）；`calibratedAutonomy` 段（缺省 off，出厂 α 在 `defaults/kernel/calibratedAutonomy.json`）+ 严格校验器 + KNOWN_KEYS 注册 |
| 观测口径 | 审批拒绝与执行结果入校准集（结构性路径不入）；`CalibrationFeed` 契约 + `ResolvedConfig.calibratedApproval` 下发；`securityPosture.calibratedAutonomy` 如实报告 |
| 判据 | `tests/property/conformalRisk.property.test.ts`（4 属性）+ `tests/unit/calibratedAutonomy.test.ts`（5 例）+ `m45-calibrated-autonomy` 机检 |

> **诚实边界**：边际联合率保证（非逐调用正确）；分布漂移削弱可交换性前提（不做漂移检测）；
> 「用户 deny 一定是正确判卷」不被证明；AAT decision 字段级扩展已由 M47 补齐（见下）。

### M46 GK01 全量分位数草图（严格 ε·n 秩误差界）✅

**目标**：清偿 `quantileSketch.ts` 自述的文档化欠账——从「工程变体（实测最坏秩误差
0.18n 且不声称界）」升级为 Greenwald–Khanna 论文全量实现：**任意流任意查询秩误差 ≤ ⌊εn⌋**。

| 工作项 | 结果 |
| ------ | ---- |
| 严格实现 | 摆动余量插入（`Δ = g_后继 + Δ_后继 − 1`，`max(g+Δ) ≤ max(1,⌊2εn⌋)` 恒成立）+ 摊销压缩（右向左最大区间合并）+ 严格查询（最小 j 使 `r_max(v_j) > r+⌊εn⌋` 返回 `v_{j−1}`） |
| 判据 | `tests/property/gkQuantile.property.test.ts`（6 族流逐秩对拍 / 确定性 / 2 万样本空间量级护栏）；MATH.md 矩阵 +1 行 |
| merge 证伪 | 元组拉链与按 g 加权重插均被属性判据证伪（g 是秩空间记账非样本数，containment 必破）——按诚实纪律不进能力面，证伪记录入 MATH §4 + 实现头注「合并」节 |

> **诚实边界**：ε·n 是秩误差界非数值误差界；merge 恢复路径 = 原始流重放或形式化并集算法。

### M47 AAT 共形决策自证（放行证据 + 离线重算）✅

**目标**：把 M45 的统计放行证据从「结构化日志」升级为 **AAT 包内可离线复算的证据**：
收证方不运行内核，只用 `aat.json` 就能回答「这条 allow 是策略放行还是统计放行、
当时用的哪组校准单元、阈值算得对不对」。设计见 M47-CONFORMAL-AAT（底稿已归档）。

| 工作项 | 结果 |
| ------ | ---- |
| 决策证据 | `AuditDecisionRecord.conformal`：α / 阈值 / 风险分 / 效果类 / 全类摘要 / 单类摘要 / 快照 id / 单元数 / 风险特征向量 / 风险模型摘要 |
| 单元 sidecar | 单元不进审计链：`calibration_units` 事件首个快照 `full`（三类全量），后续 `delta`（按类追加）；链上只留小快照元数据，每回合链重算成本与单元数解耦 |
| 快照元数据 | `snapshotId/effectClass/alpha/minCalibration/unitCount/digest/globalDigest/threshold`；快照 id = `SHA-256(JCS({effectClass, alpha, minCalibration, units, globalDigest}))` |
| 风险分重算 | `ToolRiskScorer.featuresOf/scoreOf/modelDigest`：AAT 保存 toolName/argKeys/intentKind/intentRisk/mutating + 权重摘要，复核器用同一公式重算 riskScore |
| 全类摘要重算 | sidecar 带三类单元；复核器按固定类序重算 `globalDigest`，不再是不可复算元数据 |
| 离线复核 | `ConformalAatVerifier`：还原 full/delta 单元 → 单类/全类摘要 + τ̂ + riskScore 重算；10 个机读问题码 |
| 导出闭环 | `exportAat` 同时跑 `AatExporter.verify`（结构）与 `ConformalAatVerifier`（语义），任一失败即拒绝落盘 |
| 判据 | `tests/unit/conformalAat.test.ts`（7 例）+ `tests/property/conformalAat.property.test.ts`（2 属性）+ `tests/contract/conformalAatWiring.test.ts`（一次接入导出重算）+ `m47-conformal-aat` 机检 |

> **诚实边界**：保证仍是可交换性下的边际联合率；原始 args 不进 AAT，记录的是风险分实际
> 使用的特征向量（`requestDigest` 仍绑定 args）；权重变更后旧证据报
> `CONFORMAL_RISK_MODEL_MISMATCH`（fail-closed）；sidecar 体积随观测数线性增长，单包有上限。
> Review 处置记录入 CHANGELOG 历史（审计底稿已归档）。

### M48 账本可靠性基建（DurableJsonlAppender + PathLock） ✅

**目标**：追加式账本获得崩溃一致性、读失败分类、进程内串行化与跨进程协调四项基建能力，
并迁移全部账本写入方（回执链/授权台账/遥测/奖励账本族/便签）；撕裂尾行从「砖死」变为「有界恢复」。
审查依据与完整设计：PLAN-2026-11-R2 §3-M48（发现：AUDIT-2026-11-12 分区四/六/八；两底稿已归档）。

| 工作项 | 内容 |
| ------ | ---- |
| DurableJsonlAppender | 尾行修复+tombstone / `flush:true` fsync / 进程内队列 + `mutate()` 串行读改写 / read 三分类（ENOENT=空，其它=上抛）/ `maxEntries` fail-closed 校验 |
| 迁移-回执链 | `receiptChain.ts`、`authorizationLedger.ts` 走 Appender；adopt 撕裂尾行报 `LEDGER_TORN_TAIL` 并提供 tombstone 恢复 |
| 迁移-遥测/账本族 | `jsonlRuntimeTelemetry` 尾行修复；`processRewardStore`/`workflowMemoryStore`/`failureReflectionStore`/`fileScratchpad` 改走 `mutate()` |
| PathLock | 抽 `WorkflowRunLock` 模式为共享类；晋升台账 `emit()` 与 `applyPromotion` 持锁；`workflowRunner.resume()` 锁内重读 replay |
| 记忆族 | `fileLongTermMemory` 载入形状守卫；`memoryExtractor` 单条隔离 + 游标必然推进 |
| 判据 | `tests/unit/durableJsonlAppender.test.ts` + `tests/unit/ledgerTornTail.test.ts` + `tests/stress/ledger.stress.ts`；`m48-durable-appender` 机检 |

### M49 取消语义完整性（CancellationClassifier） ✅

**目标**：取消从「工具路径碰巧能用」变成全路径一等语义；取消不再被伪装成 policy-denial 或 RUN_ERROR。

| 工作项 | 内容 |
| ------ | ---- |
| 回合接线 | `agent.ts` continueSession 传 signal 进 `TurnRunner.run`（激活回合级 assertNotAborted） |
| 门禁透传 | `stepToolExecutor.gateWithPairing` 对取消 rethrow（不再伪造审计决策） |
| VRR 修复 | `TurnFailureLedger` 成功后清除签名（非连续失败不再误停） |
| 协议出口 | `aguiEventStream` catch 先查 aborted ⇒ `CANCELLED`；ACP truncated 补 `max_tokens` 语义 |
| 媒体/工具 | `spawnMediaProcessRunner` 取消路径 SIGTERM→SIGKILL→强制结算三段式；`patchCandidatesTool`/`gifFrameExtractor` 透传 signal |
| 共享类 | `CancellationClassifier`（isCancellation 单一真源） |
| 判据 | `tests/unit/turnCancellation.test.ts` + `tests/unit/cancellationClassifier.test.ts`；`m49-cancellation` 机检 |

### M50 协议边界加固（形状守卫前置） ✅

**目标**：协议载荷进决策前一律过白名单/形状守卫；行式传输生命周期（EOF/EPIPE/背压）统一。

| 工作项 | 内容 |
| ------ | ---- |
| jsonRpc 严格化 | `parse` 要求 `jsonrpc==='2.0'` + string method + 合法 id |
| ACP 决策白名单 | `decisionOf` 严格匹配已提供 optionId 集合；`askOne` 与 `askMulti` 同规则过滤 |
| ACP 鉴权补全 | `closeSession`/`cancelSession` 补 `auth.require()` |
| 生命周期统一 | `LineTransport` 补 EOF→onClose；`AcpStdioTransport` 补 EPIPE 守卫 + 坏帧 stderr + 出站背压上限 |
| MCP 恢复 | 旧式握手后发 `notifications/initialized`；gateway 错误分类（JSON-RPC 错误/超时返回 ok:false 不杀进程）；`sdkMcpClientAdapter` 接 `onToolsChanged` |
| 杂项 | AG-UI threadId 非空校验；ACP 会话数上限；requestPermission 对已关闭会话即时 deny |
| 判据 | `tests/unit/protocolBoundary.test.ts` + `tests/unit/mcpInitialized.test.ts` + `tests/unit/mcpGatewayErrors.test.ts`；`m50-protocol-boundary` 机检 |

### M51 模型适配器收敛（ToolCallIdAllocator） ✅

**目标**：五条模型通路的工具调用 id、参数收窄、帧解析收敛到单一实现。

| 工作项 | 内容 |
| ------ | ---- |
| ToolCallIdAllocator | 实例级单调序号共享类；五适配器（OpenAI 兼容流/非流、Anthropic、Ollama、Gemini、Responses）统一合成交 |
| llamaCpp 修正 | `done:true` 终止外层循环并 cancel body；Ollama arguments/name 走共享收窄 |
| 帧解析收口 | `geminiModel` 裸 JSON.parse → `SseFrames.parse` |
| 路由健康回退 | `modelRouter` 非重试错误与已取消 signal 停止遍历 |
| 判据 | `tests/unit/toolCallIdAllocator.test.ts` + `tests/unit/adapterToolIds.test.ts`（两步同工具 + 台账开启全适配器矩阵）；`m51-tool-call-ids` 机检 |

### M52 安全边界二轮（SSRF / 注入 / 诚实标记） ✅

**目标**：审查点名的 9 个安全面收口；「没查」一律如实报告。

| 工作项 | 内容 |
| ------ | ---- |
| SSRF | `expandTrailingIpv4` 前导零拒绝；Playwright `screenshot` 补导航守卫；screenshot 回退走真 CDP 工厂 |
| shell 策略 | `isCommandWord` 匹配命令替换尾；单 `&` 作分隔符；`NETWORK_PROGRAMS` 补全；`\s*\|\s*` 归一化 |
| 沙箱/子进程 | `processTreeKiller` 非零退出回退；`codeInterpreter` 并发上限 + terminate 后守卫 |
| 路径/原型 | 附件 containment 断言；`sketchWriteTool` `Object.hasOwn`；manifest.name 过 safeName；快照 restore 遏制；ledger sep 边界 |
| 诚实标记 | TaintAttestation 无验证器报问题码；disclosurePack 补 `signatureChecked`；EnvelopeSignature 校验 alg；TSA nonce 闭环 + 响应上限 + OCSP unknown 如实 |
| 其它 | delegationTrustRegistry 坏条目 fail-closed；guardianApproval 去 g 旗标；secretRedactor 短键全遮 |
| 判据 | `tests/unit/ipAddress.v6tail.test.ts` + `tests/unit/shellPolicyBypass.test.ts` + `tests/unit/verifierHonesty.test.ts`；`m52-security-hardening` 机检 |

### M53 核心正确性收敛（单一真源清偿） ✅

**目标**：并行实现漂移清单清偿；组合点（合并后配置）复验。

| 工作项 | 内容 |
| ------ | ---- |
| 语料缓存 | 同步 revalidate 从构建期产物派生签名；`fileK` 单一真源；invalidate 文档改如实 |
| 配置 | `mergeConfigs`/`loadWithChain` 合并后复验；显式 `--config` 缺失抛错；softRatio (0,1] fail-closed；skill 字段 trim |
| 账本补偿 | `evolutionKernel` append 失败 ⇒ verdict 改 promoted:false + degraded；`assetPackInstaller.record` 失败 ⇒ 补偿回滚 |
| 媒体 | `gifDecoder` 场景采样内存预算；`imageStreamSplitter` 切片从对齐签名起 |
| 基元校验 | `retry` 入参 RangeError；`toolRoundSanitizer` 邻接构造；`circuitBreaker` 半开迟成功忽略；`jsonlBoundedLog` maxEntries；`arrayAt` 按 length 判界 |
| 收编 | 四处手写 containment → WorkspaceGuard；diff 游走抽共享；两份 `loadDatabaseSync` → 共享加载器；manifest 读取器统一 |
| 杂项 | `sessionRecorder.indexer` 隔离；`agent.replay` 逐事件隔离；模型链复用；`configRebase` 补 lsp/identity；`pluginWorkerSupervisor` exitPromise 重建；playwright 启动泄漏；longHorizon catch 加日志 |
| 判据 | `tests/unit/retryInput.test.ts` + `tests/unit/mergedConfigRevalidate.test.ts` + `tests/property/toolRoundSanitizer.property.test.ts`；`m53-core-convergence` 机检 |

### M54 深度测试装置（压力/极限/边界三线） ✅

**目标**：行为零覆盖模块与错误码零断言族补齐；压力/极限/边界三线装置纳入 verify。

| 工作项 | 内容 |
| ------ | ---- |
| 边界线 | 委托链四升级码负测试；`UNAUTHORIZED_CAPABILITY`/`MALFORMED_GRAPH` 负测试；`sandboxManager` 档案映射 + 后端 dryRun 结构 |
| 行为线 | `workflowRunner`（周期检测/guard/锁）；`stepAuthorizationGate`；`eventPersister` 崩溃持久化 |
| 压力线 | `instances.stress.ts`（多 Runtime 共享 workspace）；`lifecycle.stress.ts`（重启循环无 fd 泄漏）；签名器中途抛错 |
| 极限线 | 64 MiB 大载荷走 spill/compaction；GIF 帧数极限内存断言；hub churn soak |
| 判据 | 对应 test 文件；`m54-deep-tests` 机检 |

### M55 内核哨兵（kernel.diagnostics() 运行时健康报告） ✅

**目标**：嵌入者一次调用拿到机读健康报告；每分区探测失败 ⇒ degraded + 问题码（fail-soft，不静默不崩诊断）。设计：PLAN-2026-11-R3 §3-M55（底稿已归档）。

| 工作项 | 内容 |
| ------ | ---- |
| contracts | `KernelHealthReport`（六分区 status/problems，absent ≠ degraded） |
| sentinel | `KernelSentinel`：receipts 尾哈希/条数、telemetry verify、budget snapshot、sessions、plugins、sandbox |
| 接线 | `OmniKernel.diagnostics()`（方法，不加导出符号） |
| 判据 | `tests/unit/kernelSentinel.test.ts` + `m55-kernel-sentinel` 机检 |

### M56 确定性读缓存（workspace generation + CachedToolPort） ✅

**目标**：`toolCache` 开启后白名单纯读工具按 (tool, argsDigest, generation) 记忆；写提交 bump generation 全量失效。

| 工作项 | 内容 |
| ------ | ---- |
| 协调器 | `WorkspaceFileCoordinator.generation`（withWrite/withWriteMany 成功 +1，抛错不 bump） |
| 装饰器 | `CachedToolPort`：白名单默认 read 族、仅 ok:true、LRU、命中统计 |
| 接线 | config `toolCache` + 装配处包裹（审批语义不变——缓存层在审批门之后） |
| 判据 | `tests/unit/cachedToolPort.test.ts` + `m56-deterministic-cache` 机检 |

### M57 回合成本信封（turnCostEnvelopeUsd） ✅

**目标**：回合以 BudgetedModel.spentUsd 基线差分，超信封 ⇒ 该回合停止（事件如实留痕），全局预算不受影响。

| 工作项 | 内容 |
| ------ | ---- |
| config | `turnCostEnvelopeUsd`（>0 校验，非法启动即拒） |
| core | `TurnCostEnvelope` 基线差分 + TurnRunner.postStep 检查 + `turn.envelope_exceeded` 事件 |
| 联动 | M55 budget 分区报信封余量 |
| 判据 | `tests/unit/turnCostEnvelope.test.ts` + `m57-turn-envelope` 机检 |

### M58 审计时间线（timeline.html 自包含交付） ✅

**目标**：exportAuditBundle 可选产出自包含 HTML 时间线（内联样式、零脚本、全转义），与机器 JSON 同源。

| 工作项 | 内容 |
| ------ | ---- |
| 生成器 | `AuditTimelineHtml.generate(bundle)`：会话分段/事件行/回执绑定标记/全转义 |
| 选项 | exportAuditBundle 第 5 参 `{ timeline?: boolean }` ⇒ 结果附 timelineHtml |
| 判据 | `tests/unit/auditTimelineHtml.test.ts`（含转义防注入用例）+ `m58-audit-timeline` 机检 |

### M59 能力数据流防火墙（CapFlow，CaMeL 式结构化来源追踪）✅

**目标**：把 SEC-03 `ProvenanceTracker` 的「字符串片段匹配下限」（自述会漏会误报、默认关）
升级为**调用级结构化能力数据流**：工具结果按来源信任级授能力（会话级累积），声明式策略
对「来源 → sink」组合裁决（deny/shadow）；模型对内容的任何改写/编码无法绕过来源标记。
前沿依据与诚实边界：[PLAN-2026-11-R4.md](PLAN-2026-11-R4.md)。

| 工作项 | 内容 |
| ------ | ---- |
| contracts | `SourceCapability` / `CapFlowRule` / `CapFlowDecision` / 端口 |
| ledger | `CapabilityLedger`：`ToolOutputTrust.fromToolName` → external/unknown ⇒ `untrusted-external`，file/memory ⇒ `untrusted-content`，local 不授 |
| policy | 默认 `defaults/capflow-policy.json`（external→mutating→deny）；`policyPath` 可覆盖；Shape 校验 fail-closed |
| 集成 | `runToolCall` 执行前 assess（enforce 拒 `CAPFLOW_DENIED` / shadow 留证）+ 执行成功后 observe |
| 配置 | `capflow: { mode }`（off 缺省 / shadow / enforce；resolver 未知值抛错） |
| 判据 | `tests/unit/capflow.test.ts` + `tests/unit/capflowWiring.test.ts` + `m59-capflow` 机检 |

### M60 检索供给编排（推入式会话历史检索，RetrievalContextPort）✅

**目标**：把会话历史检索从「模型主动拉取」升级为「内核按预算推入」——每步上下文组装时
派生查询（与 repo-map/工具暴露同一口径）→ BM25 检索 → 注入守卫扫描（fail-closed 丢弃）→
token 预算裁剪 → 并入**唯一 system 尾消息**（前缀缓存不变量）；片段一律标 `untrusted-content`
（M59 CapFlow 语义），审计留证落事件日志但不进模型上下文。调研依据：[RESEARCH-2026-11F.md](RESEARCH-2026-11F.md)。

| 工作项 | 内容 |
| ------ | ---- |
| contracts | `RetrievalSnippet` / `RetrievalContextPolicy` / `RetrievalContextPort` / `OMNI_RETRIEVAL_V1` 标记 + `RetrievalContextConfig` 配置段 |
| 实现 | `RetrievalContextSupply`（查询派生委托共享 `TaskQueryDeriver`；守卫扫描；预算裁剪不截半文；降档减半；审计编码） |
| 接线 | `StepContextBuilder` 尾消息合并（off 档字节级不变）+ `Agent` 装配（off/未配置 = undefined）+ 投影剔除审计标记 |
| 配置 | `retrievalContext: { mode, maxSnippets, maxTokens }`（缺省 off）+ KNOWN_KEYS + 严格校验器 + `defaults/kernel/retrieval-context.json` |
| 判据 | `tests/unit/retrievalContextSupply.test.ts` + `tests/unit/repoMapInjectorQuery.test.ts` + `tests/unit/stepContextBuilderRetrieval.test.ts` + `m60-retrieval-context` 机检 |

### M61 语义召回扶正（semanticRecall 配置段 + 降档链 + 哨兵 context 分区）✅

**目标**：把语义召回从 `OMNI_SEMANTIC_RECALL=1` env 门升级为配置能力：`semanticRecall.mode`
（缺省 off 零行为变更，env 保留为段缺省时的兼容别名，显式 `mode` 恒优先）；开启后嵌入适配器
构造失败 ⇒ BM25-only 降档 + `SEMANTIC_RECALL_DEGRADED` 入哨兵 context 分区（absent ≠ degraded，
不静默假装语义在位）。单一真源：`SemanticRecallConfigValidator.requested`（装配与诊断同源）。

| 工作项 | 内容 |
| ------ | ---- |
| 配置 | `semanticRecall: { mode }` + KNOWN_KEYS + 严格校验器 + `defaults/kernel/semantic-recall.json` + workspaceTrust SAFE_KEYS（只读语义键） |
| 装配 | `ConfigFactory.buildEmbeddingPort(config)`：读配置段（env 为别名）；构造失败 fail-closed 降档（BM25-only + 告警，不再让装配崩） |
| 诊断 | 哨兵新增 context 分区：`ContextHealthDetail.semanticRecall { requested, active }`；requested && !active ⇒ degraded + `SEMANTIC_RECALL_DEGRADED`；`capabilities().semanticRecall` 诚实标记同步 |
| 判据 | `tests/unit/semanticRecallConfig.test.ts`（非法值拒绝 / env 等价 / off 零构造 / 降档三态）+ `m61-semantic-recall-config` 机检 |

### M62 检索质量与性能基准（bench 探针 + LongMemEval 注入模式 + 冷索引停顿补测）✅

**目标**：检索供给落地前后**数字说话**（先测量纪律）：bench 新增 `retrievalSupply` 探针
（冷索引 + 供给编排端到端）；LongMemEval 增**注入模式**（事实索进独立检索后端 → 按 M60
预算供给 → 断言答案可及，recall@k / MRR）；`coldIndexStall.mjs` 隔离冷索引 TTL 停顿形态
（M8-P3 遗留补测，数据裁决回填 [RESEARCH-2026-11.md](RESEARCH-2026-11.md) §5）。
顺带清偿：bench 探针 1/2 的陈旧 API（`appendUser` / `headFingerprint` 已迁移）修复——
bench 自 M8 后无人重跑，已带伤两轮。

| 工作项 | 内容 |
| ------ | ---- |
| bench | 探针 6 `retrievalSupply`（600 篇 BM25 冷索引 13.7ms；供给端到端 **0.1845 ms/次**，注入 4 条）；探针 1/2 陈旧 API 修复 |
| 评测 | `LongMemEval.scoreInjection`（独立索引杜绝 case 串扰 + 预算档位随报告返回）；拉取式 `score` 口径不动 |
| 裁决 | 冷索引 TTL 停顿：400 文件 36ms / 1200 文件 88ms（摊销 ~1–3ms/s）——**维持 M8-P3「不做」**，首次有数字背书 |
| 判据 | `tests/unit/longMemEvalInjection.test.ts`（recall 计算 / 预算裁剪 / case 隔离）+ `m62-retrieval-bench` 机检 |

### M63 上下文工程策略面（contextPolicy 降档阶梯声明式化）✅

**目标**：把「软预算越档时逐级收紧」的组合编排从各消费点的隐式代码路径升格为**声明式
策略**（本仓「声明式优先」宪法）。压缩/外溢/裁剪/检索注入/记忆蒸馏各轴的既有配置键不重复；
本段只补缺失的**降档阶梯**：第 1 级恒开（M60 供给减半 + repo-map degrade，既有行为），
第 2 级 `shapersAggressive`（激进裁剪随降档）、第 3 级 `compactionForce`（强制压缩随降档）
缺省全关——**缺省 = 当前行为的显式快照**，等价判据钉住（字节级一致）。

| 工作项 | 内容 |
| ------ | ---- |
| 数据 | `ContextPolicyConfig.degradeLadder { shapersAggressive, compactionForce }` + 严格校验器（段/阶梯两层）+ `defaults/kernel/context-policy.json`（全 false 快照）+ KNOWN_KEYS + workspaceTrust SAFE_KEYS |
| 消费 | `StepContextBuilder`：`aggressive = forceCompaction ∨ (降档 ∧ 第2级)`、`compactForce = forceCompaction ∨ (降档 ∧ 第3级)`；LR-03 逃生口（prompt-too-long 强制压缩）语义不变 |
| 装配 | `Agent.buildTurnRunner` 经 `ContextPolicyConfigValidator.resolve` 注入（校验与解析同源） |
| 判据 | `contextPolicyConfig.test(3)` / `contextPolicyEquivalence.test(3)`（缺省等价 + 显式快照字节级一致 + forceCompaction 直通）/ `contextPolicyDegrade.test(3)`（阶梯两/三级启用、独立启用、降档未置位不自发）+ `m63-context-policy` 机检 |

### M64 prompt cache 一等公民（内核级读数台账 + 哨兵 context 分区呈现）✅

**目标**：把 prompt cache 命中率从被动测量升为**有反馈回路的一等观测面**——事件流面
（usage 事件已带 `cachedPromptTokens` + `ModelContextSnapshot.prefixReuseRatio`，M8 起即一等）
之上补**内核级最近读数**：`Agent` 回合收尾记录 → `ContextCacheReadoutLedger` 单槽台账 →
哨兵 context 分区 `cache` 字段呈现（absent ≠ degraded）。按读数裁决的优化项另立候选
（本轮不预设行为变更）。**诚实边界**：AAT 决策记录不加 cache 字段——缓存读数是回合级
遥测，塞进逐调用决策记录会污染决策语义（单一真源：事件流面已可复算命中率）。

| 工作项 | 内容 |
| ------ | ---- |
| 契约 | `ContextCacheReadout` / `ContextCacheReadoutStore`（composition）+ `ContextHealthDetail.cache` 可选字段 |
| 实现 | `ContextCacheReadoutLedger`（单槽覆盖式、浅拷贝入账）+ `TurnRunner.contextReadoutOf`（缺字段不臆造）+ `Agent` 收尾记录（runtime 未注入台账时零开销跳过） |
| 哨兵 | `KernelSentinelInput.cacheReadout` 注入缝 + context 分区 `cache` 呈现 + `OmniKernel.diagnostics()` 桥接 |
| 判据 | `tests/unit/contextCacheReadout.test.ts`（台账覆盖/浅拷贝 + 哨兵两态）+ `m64-prompt-cache-evidence` 机检 |

### M65 缓存守卫观测闭环（命中率门限联动）✅

**目标**：M64 读数的**联动闭环**——命中率跌破门限时经 `CacheHitRateWatch` 既有纪律
（只告警不阻断、样本不足自静默）活告警。**实施前机制修正（诚实边界）**：原拟「尾段
指纹节流延长 provider 缓存」不成立——尾消息恒在新增历史之后，尾字节稳定不延长可缓存
前缀（内核 54%→81% 收益来自「动态内容后置」位置学且已实现）；裁撤节流器与 tailChanged
计数（与 `ContextPrefixMeter` 重复）。依据：[RESEARCH-2026-11G.md](RESEARCH-2026-11G.md) §2.3。

| 工作项 | 内容 |
| ------ | ---- |
| 契约 | `contextPolicy.cacheGuard { hitRateFloor }`（0,1 开区间，缺省 undefined = off）+ `ContextCacheReadoutTotals` 累计面（Σ/Σ 口径与容量统计服务一致） |
| 实现 | 台账累计（只累计带 token 读数）+ `Agent` 构造期按门限建 `CacheHitRateWatch`（×100 换算）+ 回合收尾**新读数到达才判定**（不重复告警同一累计值） |
| 判据 | `tests/unit/contextCacheReadout.test.ts`（累计口径 + 组合判定两态）+ `contextPolicyConfig.test.ts`（门限校验/resolve 透传）+ `m65-cache-aware-tail` 机检 |

### M66 查询改写（ModelPort 语义级可插拔）✅

**目标**：多轮会话「接着改」「刚才那个文件」类查询经模型重写为**自足检索查询**。
**实施前修正（诚实边界）**：规则版裁撤——`TaskQueryDeriver` 已拼接最近 ≤3 条 user 消息，
指代回填与既有派生冗余；价值在语义级模型改写（off 缺省），对照结论留真实模型部署时
经 `scoreInjection` 的 rewriter 参数回填。依据：[RESEARCH-2026-11G.md](RESEARCH-2026-11G.md) §3。

| 工作项 | 内容 |
| ------ | ---- |
| 契约 | `QueryRewriterPort`（fail-closed 契约：异常/空结果回退原查询）+ `retrievalContext.rewriter: 'off' \| 'model'` 配置 |
| 实现 | `ModelQueryRewriter`（ModelPort 精简 prompt，上文口径与检索派生同源）；`RetrievalContextSupply` 可选改写 + 审计报告 `rewritten` 标记 |
| 判据 | `tests/unit/queryRewrite.test.ts`（三态 fail-closed / 配置校验 / 供给集成含无改写器基线对照 / 评测面）+ `m66-query-rewriting` 机检 |

### M67 检索精排（ModelPort 序数判定可插拔）✅

**目标**：守卫后候选经**语义精排**再进预算裁剪——`ModelReranker` 用生成式模型做
**LLM-as-judge 序数判定**（零新增依赖的 cross-encoder 替代；真打分模型可另实现
`RerankPort` 插拔）。契约：**保序保集**（返回原对象、可重排可裁剪、不新增文档）+
fail-closed（不可解析/覆盖不全/异常回退原序）。降档时跳过（M63 阶梯联动——降档语义
是收敛预算，一次精排调用与降档方向相反）。缺省 off；质量对照经 `scoreInjection` 的
reranker 参数回填。

| 工作项 | 内容 |
| ------ | ---- |
| 契约 | `RerankPort`（保序保集 + fail-closed）+ `retrievalContext.rerank: 'off' \| 'model'` 配置 |
| 实现 | `ModelReranker`（编号候选 prompt → 序数解析容错「3, 1, 2」/「1. 3」→ 覆盖不全/越界回退）+ `RetrievalContextSupply` 降档跳过 + 审计 `reranked` 标记 |
| 判据 | `tests/unit/queryRerank.test.ts`（重排生效 / 三态回退 / 供给集成 + 单候选直通 / 降档跳过）+ `m67-cross-encoder-rerank` 机检 |

### M68 注入面 CapFlow enforce（injected-untrusted 能力维度）✅

**目标**：M59/M60 留证面的**enforce 兑现**——检索供给（M60）注入上下文的片段获得独立的
`injected-untrusted` 来源能力（片段在本轮工具执行前就进入注意力，独立于工具来源授能力）；
`CapFlowPort` 增可选 `observeInjection()`（@beta 加法，第三方实现可省略）；策略 Shape 与
默认策略文件增注入面维度（injected-untrusted → mutating sinks → deny，enforce 档生效，
shadow 留证，off 零行为）。

| 工作项 | 内容 |
| ------ | ---- |
| 契约 | `SourceCapability` +`injected-untrusted` + `CapFlowPort.observeInjection?()` 可选方法 |
| 实现 | `CapabilityLedger.observeInjection()`（幂等集合语义）+ `CapFlowPolicy.observeInjection` 委托 + 策略 Shape/默认规则 + M60 片段标记升级（untrusted-content → injected-untrusted）+ Agent 审计回调回授（有片段注入才授，丢弃/跳过不算） |
| 判据 | `tests/unit/capflow.test.ts`（授能力/三态矩阵/幂等）+ `m68-capflow-injection-enforce` 机检 |

### M71 干净检出编译机检（worktree tsc 双配置）✅

**目标**：P0-1（三个 commit 干净检出 16 个 tsc 错而脏树 verify 全绿）的制度化修复——
`npm run clean:tsc` 在临时 worktree（HEAD 干净检出）+ junction/symlink node_modules 上跑
`tsc --noEmit`（主配置 + 测试配置各一次），fail-closed：任何非零退出即门禁红。接入 verify 链第 3 道。
依据：[RESEARCH-2026-11H.md](RESEARCH-2026-11H.md) §3（机检盲区增补）。

| 工作项 | 内容 |
| ------ | ---- |
| 实现 | `scripts/cleanCheckoutTsc.mjs`：worktree add --detach + junction/symlink node_modules + 双 tsc + finally 清理（链接先删、worktree remove --force）；gitBin 解析（Win32 Git Bash 会话的 POSIX PATH 继承会损坏 CreateProcess 环境 block ⇒ 连绝对路径 spawn 都报 ENOENT——探测常见安装位取原生路径） |
| 配置 | `package.json.clean:tsc` + verify 链插入（typecheck:tests 后） |
| 判据 | `m71-clean-checkout-tsc` 机检（脚本事实 + script/verify 接线） |

### M69 检索质量对照自动化（eval:inject 跑批）✅

**目标**：LongMemEval 注入模式的**一键对照面**——同一确定性 case 池，改写/精排 on/off
四组跑批（baseline / +rewriter / +reranker / +both）→ recall@k / MRR 对比表 + JSON --out 落盘。
真实模型部署时的**回填机制**——把 mock 适配器换成真实模型后跑本脚本，数字回填
[RESEARCH-2026-11G.md](RESEARCH-2026-11G.md) §7。

| 工作项 | 内容 |
| ------ | ---- |
| 脚本 | `scripts/evalInject.mjs`：确定性 case 池（20 case × BM25）× 四组对照 + `package.json.eval:inject` |
| 判据 | `m69-eval-automation` 机检（脚本事实 + script 接线） |

### M70 多会话检索供给压力（隔离 + 有界延迟）✅

**目标**：8 会话并发 × 检索供给 on × BM25 索引——会话隔离（snippet 不跨会话漏召回）、
有界延迟（p95 < 50ms）、总墙钟护栏（< 10s）。

| 工作项 | 内容 |
| ------ | ---- |
| 压力 | `tests/stress/supply.stress.ts`：8 会话并发 × 25 步 × 50 文档独立索引；供给端口隔离语义 = 独立后端（snippet docId 前缀断言） |
| 判据 | `m70-supply-stress` 机检（隔离断言 + p95 护栏） |

### M72 VectorStorePort 可选适配器对齐面（广度）✅

**目标**：外部向量库经端口接入内核的**对齐面**——内核只认端口，不内置任何向量库实现
（R5/R6 裁决延续）。契约 `upsert/search/remove?`（同 `RetrievalPort` 形态——幂等写入 +
降序命中 + 可选删除）；嵌入编码归 `EmbeddingPort`，两步管线由调用方编排。

| 工作项 | 内容 |
| ------ | ---- |
| 契约 | `contracts/ports/context/vectorStorePort.ts`：`VectorRecord` / `VectorSearchHit` / `VectorStorePort` |
| 判据 | `tests/unit/vectorStorePort.test.ts`（mock 语义判据：幂等写入/降序/删除）+ `m72-vector-port` 机检 |

### M73 检索对照真实回填（eval:inject 真实模型档 + §7 落账）✅

**目标**：把 M69 的「回填机制」升级为**可执行的真实模型档**，并把实测数字写进
[RESEARCH-2026-11G.md](RESEARCH-2026-11G.md) §7。两条诚实边界：① mock 数字只证机制闭环
（case 池对 BM25 饱和），质量结论必须来自真实模型；② 缺凭据/端点不可达一律 fail-closed，
绝不静默回退 mock 冒充真实数字。

| 工作项 | 内容 |
| ------ | ---- |
| 脚本 | `scripts/evalInject.mjs`：`--provider deepseek\|openai\|anthropic\|ollama`（端点/默认模型/凭据 env 名来自数据文件）+ `--model/--base-url/--api-key-env` 覆盖 + `--out` 回执（schema `omni-eval-inject/v1`，含 `runMode` / `modelCalls` / git SHA） |
| 共享件 | `scripts/lib/modelPortFactory.mjs`：provider 配置声明式形状校验 + 动态构造 `OpenAiCompatibleModel` / `AnthropicModel`（M75 复用） |
| fail-closed | 缺凭据 → `MODEL_API_KEY_MISSING`；端点不可达先探活 → `MODEL_UNREACHABLE`（否则改写/精排静默回退 baseline，数字失去对照意义） |
| 回填 | [RESEARCH-2026-11G.md](RESEARCH-2026-11G.md) §7：mock 实测基线 + 真实档槽位 + 一条命令回填程序 |
| 判据 | `tests/contract/evalInjectCli.test.ts`（四组落盘 + modelCalls + 本地假端点真跑通 + 两条 fail-closed）+ `m73-eval-real-backfill` 机检 |

### M74 SSE/Web 对接面（宿主侧最小 UI + 起任务入口 + 无头冒烟）✅

**目标**：把内核已有数据面（`WorkbenchServer` 的 SSE / state / answers）端到浏览器——
**宿主侧**补齐内核刻意不做的两件事：静态 UI 与「启动任务」入口（§8：内核不做体验层）。
本里程碑不进 `src/`、不新增导出面，只提供可运行示例与端到端冒烟。

| 工作项 | 内容 |
| ------ | ---- |
| 宿主 | `examples/web/hostServer.mjs`：静态 UI + `GET /api/config` + `POST /api/tasks`（串行 409）+ 内嵌 workbench（回环、随机令牌、CORS loopback）+ 幂等 `close()` |
| UI | `examples/web/public/`：`index.html` / `app.js`（EventSource 命名事件 + state 投影 + pendingAsk 选项）/ `styles.css` |
| 入口 | `examples/web/server.mjs`（`npm run web:sse`）+ `examples/web/README.md`（数据流与诚实边界） |
| 冒烟 | `scripts/webSseSmoke.mjs`（`npm run web:sse:smoke`）：静态 UI → config → 起任务 → SSE 回放/直播 → pendingAsk → answers → 最终 state；含并发 409 断言 |
| 判据 | `tests/contract/webSseHost.test.ts` + `m74-web-sse-surface` 机检 |

### M75 多模型路由质量对照（七策略 × 质量/延迟/成本）✅

**目标**：把 `ModelRouter` 从「单测证明选了谁」升级为**跨策略质量-成本对照面**：
同一任务集 × 同一组候选模型 × 七种策略（round-robin / least-cost / by-task /
by-context / by-role / ucb1 / health-fallback），输出质量、延迟、成本、失败、调用分布。
mock 档用于验证「策略确实按声明的权衡工作」；真实档留给多模型部署回填。

| 工作项 | 内容 |
| ------ | ---- |
| 脚本 | `scripts/modelRouteCompare.mjs`：12 任务（code/reason/general 各 4）+ 三档 mock（质量/延迟/单价/失败节律显式）+ 七策略跑批 + `--out` 回执（schema `omni-route-compare/v1`） |
| 真实档 | `--real-config <json>`：`{entries:[{provider, model?, baseUrl?, apiKeyEnv?, pricing?, maxContextTokens?}]}` 每条可覆盖端点/凭据环境变量名/窗口，经 `ModelPortFactory` 构造并逐个探活；缺凭据/坏配置/不可达 fail-closed；示例 `scripts/eval/route-models.example.json` |
| 计量 | `MeteredModel` 装饰器按 entry 单价 × 实际 usage 记成本；`health-fallback` 回退追加调用单独计数 |
| 接线 | `package.json.route:compare` |
| 判据 | `tests/contract/modelRouteCompareCli.test.ts`（七策略/成本/回退失败/真实档 fail-closed）+ `m75-route-quality-compare` 机检 |

### M76 残余工作台账与过期表述收尾（R8 收尾）✅

**目标**：把散落在里程碑/调研/API/WIRING/RECEIPTS 的「未做 / 尚未 / 待 / 缺口」收敛为
**一份可核对总账** [RESIDUAL.md](RESIDUAL.md)，并清除「已经做完却还写未做」的过期表述。
剩余项只允许三类：外部阻塞（凭据/外部主体）、宿主职责（内核刻意不做）、明确不做（有触发条件）。

| 工作项 | 内容 |
| ------ | ---- |
| 总账 | [RESIDUAL.md](RESIDUAL.md)：R1–R4 外部阻塞 / H1–H8 宿主职责 / N1–N12 明确不做 / §4 本轮关闭项 |
| 过期表述 | `DELEGATION`（已接入 SubagentRunner）、`RESEARCH-H §1/§3/§4`（M71 已落地、R8 已裁决）、`RESEARCH-G §1`（M65–M68 已闭合）、`ROADMAP M39/M40/M42`（宿主边界/M44 已补齐）、`WIRING §6`（三条待办分类）、`API §1.7` / `RECEIPTS §3` / `STANDARDS`（指向总账） |
| 代码侧收尾 | `route:compare` 真实档支持 per-entry `baseUrl` / `apiKeyEnv` / `maxContextTokens` 覆盖，并用本地假端点端到端跑通七策略 |
| 判据 | `tests/contract/modelRouteCompareCli.test.ts`（真实档 per-entry 覆盖）+ `m76-residual-ledger` 机检（总账分节 + 过期表述已消） |

### M44 边界二轮（跨 issuer/吊销/共享预算 / CTA HTTP 头 / approval+heartbeat 生产者 / 记忆默认治理）✅

| 工作项 | 结果 |
| --- | --- |
| 跨 issuer | `DelegationTrustStore` + `DelegationRevocationPort`；`verifyWithTrust` / `verifyChainWithTrust`；`delegationTrust` / `delegationRevocations` 进 config/ToolContext/subagent |
| 共享预算 | `DelegationUsage` 经 `config.delegationUsage` / `SubagentRequest.delegationUsage` / `subagent` 工具透传，父子复用同一计数器 |
| CTA HTTP | `mcp-ctx-isolation` 头（JSON/base64url）由 `McpHttpServer` 合并进 `_meta`（body 优先，坏头 400） |
| AAT 生产者 | `ToolGate.setApprovalObserver` → `StepApprovalAuditor` 写 approval 请求/回答；每个工具批次写 heartbeat |
| 记忆默认 | `OmniKernel` 的 `longTermMemoryGovernance` 默认开（`false` 关）；直接构造 `FileLongTermMemory` 仍默认关 |
| 判据 | `delegationChain`（跨 issuer/吊销/共享预算）、`mcpMrtrWiring`（HTTP 头）、`auditWiring`（approval/heartbeat）、`memoryGovernance`；`m44-*` 入 `plan:check` |

> **保留边界**：信任根快照的文件分发渠道由宿主决定（内核提供 save/load）。

---

## 4. 里程碑
### M0 切分收口 ✅

从 OmniHarness 切出独立内核并证明「删掉应用它还能跑」。判据与复现命令见
[BOUNDARY.md §当前状态](BOUNDARY.md#当前状态可复现判据)，这里只留结论：边界五条规则全绿、
`src/compat` 清零、公开面 59/60、切分时 25 文件 140 用例（M3 扩容后 29 文件 170 用例）、
headless 示例只经公开入口。

### M1 发布就绪（alpha.1）✅

**目标**：让「发一个 alpha」成为一个可重复的动作，而不是一次手工事故。

| 工作项 | 产出 |
| ------ | ---- |
| 规划闭环 | 本文件 + `scripts/planCheck.mjs` + `npm run plan:check` 并入 `verify` |
| 发布元数据 | `private: false`、`publishConfig.access: public`、`files[]` 覆盖路线图 |
| 版本纪律 | 版本 `0.1.0-alpha.1`；CHANGELOG 顶条与 `package.json` 同版本 |
| 使用者入口 | README 首屏即可跑通；四不变量 + 快速开始 + 指向本路线图 |
| CI | `.github/workflows/verify.yml`：`npm ci` → `npm run verify` → headless 冒烟 |

**退出条件**：§3 的六条 `m1-*` 判据全过；`npm pack` 后空目录安装可跑（见 §7 发布记录）。
**不在 M1**：真正执行 `npm publish`（需要凭据，记在 §7）。

> `m1-ci` 只证明**工作流存在且调用同一条命令**，不伪装成「CI 已经绿」。双平台首跑结论在
> 首次推送后回填 §6，作为人工复核而不是 auto 判据——执行器的结果不是本地可复现事实。

### M2 第一个外部消费（D90）✅

**目标**：证明内核不是只有作者能用的库。

> **收口（2026-11-05，证据在 §6）**：npm registry 无凭据，改走 **vendored tgz 钉版**路径——
> 应用钉 `file:vendor/omniharness-kernel-0.1.0-alpha.6.tgz`（tag `v0.1.0-alpha.6` = f362434），
> 应用 verify 全链绿（typecheck×3 + kernel:check 6/6 + web:test + build + smoke + desktop 25/25）。
> 下方「现状」是 11-03 分支迁移路径（`migration/kernel-package`）的历史记录，该分支未合并，
> 已被 vendored 路径取代；工作项 4（迁移桥删除）仍 open——应用仍有
> `@omniharness/kernel/kernel/*` 等深路径导入，删除条件未满足（[BOUNDARY 迁移桥](BOUNDARY.md)）。

**现状（2026-11-03 深夜，实测；历史记录）**：

- 内核侧已就绪：`npm pack` 3.09 MB / 3474 文件，空目录安装 + headless 跑通；
- **阻塞 1（发布）**：本机未登录 npm（`npm whoami` → `ENEEDAUTH`，无 `NPM_TOKEN` / `~/.npmrc`）。
  已尝试 `npm login --auth-type=web`，流程需要浏览器确认，无头会话无法完成 ⇒ 只能停在
  「发布就绪 + 本地 tag / tarball」；
- **应用接入已推进到分支**：OmniHarness 的 `migration/kernel-package` 分支完成 6,529 处导入重写、
  删除 1,914 个文件 / **143,883 行**内嵌副本；`tsc`（含 web）、`build`、`arch:gate` 全绿。
  **未合并**：75 个测试文件 / 93 例失败待分流（内核源码级不变量测试回迁内核、CLI 子进程测试按新布局
  调整、`check.mjs` 导入铁律放行包路径）。顺序与判据见 M2_APP_MIGRATION 测绘底稿（已归档）。

工作项（按顺序，不并行）：

1. 发布 alpha 到 registry（需要凭据）后，应用改为**钉版本依赖**（替换 `file:../omniharness-kernel`）；
2. 完成分支上的 75 个测试文件分流，`check.mjs` 放行包路径，再合并应用 main 并跑全量回归；
3. 收集第一批反馈：装不上 / 类型不对 / 文档看不懂，各记一条 issue 模板；
4. 合并后删除内核的**迁移桥**子路径导出（BOUNDARY「迁移桥」），把应用剩余导入收敛到顶层。

**退出条件**：`m2-consumer`（人工判据）——应用钉版本 + 全量回归绿 + 日期与证据写入 §6。

### M3 beta 硬化（alpha.2）✅

**目标**：把「能跑」变成「敢用」。四件事全部落地（2026-11-03）：

| 工作项 | 结果 | 证据 |
| ------ | ---- | ---- |
| 归属裁决执行 | `adapters/laya`（9 文件 + Python 资产）与 `decisionEngineResolver` 移出内核；应用仓库保留实现 | `m3-laya-migrated`；内核只留 `decisionEnginePort` 注入缝，`mode` 非 off 却未注入即**构建期报错** |
| @beta 组复核 | 三组 9 文件全部带 `@beta 归属裁决`，符号仍不进公开面 | `m3-adapters-beta-marked` |
| 支撑面收窄 | `protocolsSupport` 22 符号（16 值 + 6 类型；2026-11-08 +`ErrorMessage`） | `m3-support-surface` |
| 契约覆盖面 | `tests/contract` 6 文件 **32 例**：事件顺序 / 回放 / 压缩 / 审批语义 / 沙箱语义 / 门禁接线，只经公开入口 | `m3-contract-coverage`；`npm test` 29 文件 170 例 |

**行为变更（alpha 破坏性，已记 CHANGELOG）**：配置 `decisionEngine.mode` 非 `off` 时必须注入
`decisionEnginePort`；此前由内核直接 new 出 `LayaDecisionEngine`，现在内核不再持有厂商绑定实现。

---

## 5. 判据实现映射

| 判据 id | 类别 | 判什么 | 实现在哪 |
| ------- | ---- | ------ | -------- |
| `m0-boundary` | auto | 五条分层规则 | `scripts/boundaryCheck.mjs` |
| `m0-no-compat` | auto | `src/compat` 不存在 | `scripts/planCheck.mjs` |
| `m0-public-cap` | auto | 公开面 ≤60 | `scripts/publicSurface.mjs` |
| `m0-tests` | auto | ≥20 测试文件 / ≥100 用例 | `scripts/planCheck.mjs` |
| `m0-headless-imports` | auto | 示例只 import 公开入口 | `scripts/planCheck.mjs` |
| `m1-publishable` | auto | 非 private + public access + engines | `scripts/planCheck.mjs` |
| `m1-files` | auto | `files[]` 每项存在 | `scripts/planCheck.mjs` |
| `m1-changelog` | auto | CHANGELOG 顶条 = 包版本 | `scripts/planCheck.mjs` |
| `m1-readme` | auto | 四不变量 + 快速开始 + 指向本文件 | `scripts/planCheck.mjs` |
| `m1-ci` | auto | 工作流跑 `npm run verify` | `scripts/planCheck.mjs` |
| `m1-dist` | auto | `dist` 入口与声明可加载 | `scripts/planCheck.mjs` |
| `m2-consumer` | manual | 应用钉版本 + 全量回归 | 本文件 §6 |
| `m3-laya-migrated` | auto | `adapters/laya` 已移出 | `scripts/planCheck.mjs` |
| `m3-adapters-beta-marked` | auto | 三组 9 文件带裁决标记 | `scripts/planCheck.mjs` |
| `m3-support-surface` | auto | 支撑面 ≤22 符号 | `scripts/planCheck.mjs` |
| `m3-contract-coverage` | auto | `tests/contract` 用例 ≥30 | `scripts/planCheck.mjs` |
| `m8-bench-harness` | auto | bench 脚本在位且 `npm run bench` 带 `--expose-gc` | `scripts/planCheck.mjs` |
| `m8-research-doc` | auto | 调研底稿在位（基线数字 + retention 口径 + 前后对照表） | `scripts/planCheck.mjs` |
| `m8-memory-multipliers` | auto | TokenEstimator 单例共享（压缩器 ↔ 容量分解器） | `scripts/planCheck.mjs` |
| `m8-serialization-shortcircuit` | auto | 游标/指纹/schema 三处每步序列化短路（行为测试同行） | `scripts/planCheck.mjs` |
| `m8-eventlog-snapshot` | auto | 事件日志读路径走失效即重建快照 | `scripts/planCheck.mjs` |
| `m9-wiring-audit` | auto | 8 个公开入口为根、可达预算、零入边逐条落账（[WIRING.md](WIRING.md)） | `scripts/wiringCheck.mjs` |
| `m9-polish` | auto | 毛边判据 ≥12 条，每条有回归用例 | `tests/contract/hardeningPolish.test.ts` |
| `m9-stress` | auto | 压力套件在位（≥3 文件 / ≥8 用例）且 `npm run stress` 并入 verify | `tests/stress/` + `vitest.stress.config.ts` |
| `m10-cancel-propagation` | auto | 工具执行/ask_user 等待与取消竞速，Hub 清理挂起提问 | `StepToolExecutor` / `WorkbenchHub` + `tests/contract/cancellationPropagation.test.ts` |
| `m10-signed-summary` | auto | 链尾摘要签发 + 复核器验签/比对（尾篡改可检出） | `ReceiptChain.signSummary` + `tests/contract/receiptSummary.test.ts` |
| `m10-mcp-servers-wired` | auto | `config.mcpServers` 透传并真正连接/注册（auth 生效） | `mcpServersBridge` + `tests/contract/mcpServersWiring.test.ts` |
| `m11-embed-entry` | auto | 顶层 `OmniKernel.create()` + `./embed` 类型面 + 示例/README 使用 + 公开面仍 ≤60 | `scripts/planCheck.mjs` |
| `m11-embed-evidence` | auto | 一次接入的证据：工具回合 / 工作台投影 / 审计包验签 / MCP 双向 / 事件扇出 / 未签名语义 / config 透传由同一契约测试钉住 | `tests/contract/embedOneCall.test.ts` |
| `m11-embed-minimal` | auto | 最小接入可机检：示例只经顶层、非注释代码 ≤60 行、只调一次 `OmniKernel.create()` | `scripts/planCheck.mjs` |
| `m11-embed-receipts-persist` | auto | 回执闭环：持久化跨重启续链 / 密钥复用 / 存档篡改与丢钥 fail-closed（两条判据同行） | `tests/contract/embedOneCall.test.ts` |
| `m11-embed-execution-certificate` | auto | 运行级执行证书接入：自动落盘 / 显式签发 / 离线复核 / 事件篡改检出（判据同行） | `tests/contract/embedOneCall.test.ts` |
| `m11-embed-audit-bundle` | auto | 审计分发：pack + trust + summary 三件套导出并离线复核（尾条改/删可检出） | `tests/contract/embedOneCall.test.ts` |
| `m11-embed-full-audit-bundle` | auto | 单文件审计包：事件 + 证书 + 回执 + 整包签名，`AuditBundles.verify` 复核/篡改检出 | `tests/contract/embedOneCall.test.ts` |
| `m12-arch-graph` | auto | 运行时依赖无环 + 跨层边合法 + [ARCHITECTURE.md](ARCHITECTURE.md) 快照一致 | `scripts/archCheck.mjs` |
| `m12-math-invariants` | auto | 属性测试 ≥4 文件 / ≥12 属性 + 覆盖矩阵与诚实边界在案 | `tests/property/` + [MATH.md](MATH.md) |
| `m13-math-expansion` | auto | 属性测试 ≥8 文件 / ≥28 属性，调度/估算/覆盖率/回执并发四套件在矩阵中 | `tests/property/` + [MATH.md](MATH.md) |
| `m14-execution-certificate` | auto | 执行证书：Merkle 完整性/包含证明/回执绑定/签名复核 + 研究底稿 | `src/kernel/receipts/executionCertificate.ts` + `tests/contract/executionCertificate.test.ts` |
| `m15-execution-graph` | auto | 执行图谱系：节点证书/委派锚定/单根无环/图签名 | `src/kernel/receipts/executionGraph.ts` + `tests/contract/executionGraph.test.ts` |
| `m16-audit-bundle` | auto | 审计包：事件证书/回执链/执行图/整包签名一次复核 + CLI | `src/kernel/receipts/auditBundle.ts` + `tests/contract/auditBundle.test.ts` |
| `m17-runtime-audit-bundle` | auto | 运行时闭环：`kernel.exportAuditBundle` 产出 bundle/trust/digest，第三方 CLI 可复核 | `src/kernel/bootstrap/createOmniKernel.ts` + `tests/contract/embedOneCall.test.ts` |
| `m18-selective-disclosure` | auto | 选择性披露：子集事件 + 包含证明 + 必需前缀可离线复核，未选事件不出包 | `src/kernel/receipts/disclosurePack.ts` + `tests/contract/disclosurePack.test.ts` |
| `m19-loop-resilience` | auto | 核心循环韧性：重试/熔断默认开 + 步级恢复 + 过载降级装配 + 毒工具反馈 + 工具看门狗 + LoopGuard/Scheduler/RetryingModel 回归网 | `src/kernel/core/turnRunner.ts` + `src/kernel/core/stepToolExecutor.ts` + `tests/unit/agentLoopAudit.test.ts` + `tests/unit/loopResilience.test.ts` |
| `m20-audit-delivery` | auto | 审计交付编码：gzip / scrypt+AES-256-GCM 口令加密 / 分片 manifest + 运行时与 CLI 接通 + 传输级篡改与口令错误 fail-closed | `src/kernel/receipts/auditDelivery.ts` + `tests/contract/auditDelivery.test.ts` + `scripts/verifyBundle.mjs` |
| `m21-explicit-exports` | auto | 迁移桥显式化：`exports` 无 `"./*"` 通配、每条深路径导出指向存在的 dist 文件 | `package.json` + `scripts/planCheck.mjs` |
| `m21-generator-source` | manual | 域生成器（app 侧）解析源对齐内核承诺清单：exports 清单第一优先 + 回退黄标 + 17 域文件再生成一致 | 本文件 §6 |
| `m26-shadow-clearing` | auto | rpc/transport 四件套入承诺闭包且 dist 产物存在 | `package.json#exports` + `scripts/planCheck.mjs` |
| `m26-adapters` | auto | 适配器补全族十锚点在位 + `tests/unit/adapterCompletions.test.ts` 覆盖 | `src/kernel/adapters/{approval,escalation,event,kv}/` + `scripts/planCheck.mjs` |
| `m26-vault` | auto | VaultPort 契约 + CryptoVault/EnvVault + credentialResolver 在位 + 判据 | `src/contracts/ports/memory/vault.ts` + `src/kernel/adapters/vault/` + `scripts/planCheck.mjs` |
| `m26-trace` | auto | 只读自省契约 + trace/会话事件读取器在位 + 判据 | `src/contracts/ports/telemetry/` + `src/kernel/adapters/telemetry/` + `scripts/planCheck.mjs` |
| `m26-util-completion` | auto | util/config 补全七锚点在位 + 判据 | `src/kernel/util/` + `src/kernel/config/configRebase.ts` + `scripts/planCheck.mjs` |
| `m26-skill-asset` | auto | skillManifestSigner + assetPackCodec/assetPackInstaller 在位 + 判据 | `src/kernel/skill/skillManifestSigner.ts` + `src/kernel/asset/` + `scripts/planCheck.mjs` |
| `m26-steering-cache` | auto | 插话分类器 + 缓存观测双件在位 + 判据 | `src/kernel/core/steering/interjectionClassifier.ts` + `src/kernel/observability/` + `scripts/planCheck.mjs` |
| `m28-interjection-config` | auto | 插话词表配置化四锚点在位（数据 / 解析器 / 校验器 / 契约）+ 逐字钉住 / fail-closed / 覆盖语义 / 透传接线 / 反硬编码判据 | `defaults/interjection.json` + `src/kernel/core/steering/interjectionLexicon.ts` + `src/kernel/config/interjectionConfigValidator.ts` + `src/contracts/ports/config/interjectionConfig.ts` + `tests/unit/interjectionConfig.test.ts` + `scripts/planCheck.mjs` |
| `m29-jcs-audit` | auto | Jcs 深度护栏（MAX_DEPTH=64）+ 审计语义逐字 golden + fail-closed 矩阵 + exports 承诺在位 | `src/kernel/receipts/jcs.ts` + `tests/unit/jcsAuditAlignment.test.ts` + `scripts/planCheck.mjs` |
| `m32-aat-records` | auto | `audit` 事件 + `AuditRecorder` 链 + `PolicySnapshot` + 执行前 `decision` 均在位 | `eventType.ts` + `auditRecorder.ts` + `policySnapshotBuilder.ts` + `stepToolExecutor.ts` + `agent.ts` |
| `m32-aat-export` | auto | `AatExporter.build/verify` + `kernel.exportAat` + 篡改矩阵判据 | `aatExporter.ts` + `omniKernel.ts` + `docs/AAT.md` + `tests/{unit,contract}/audit*.test.ts` |
| `m32-aat-wiring` | auto | 一次接入缺省 `auditRecords` + config 透传 + `securityPosture` 如实报告 | `omniKernelAssembler.ts` + `configFactory.ts` + `omniKernel.ts` + `auditWiring.test.ts` |
| `m33-cta-core` | auto | 污点格（单调）+ 数据面 Merkle + 效果类 + CTA 信封签名/复核均在位 | `contextTaint.ts` + `taintAttestationBuilder.ts` + `contextTaint.test.ts` |
| `m33-cta-wiring` | auto | `StepToolExecutor` 执行前 CTA + `ctaMode` 透传 + 缺省 shadow + enforce 判据 | `stepToolExecutor.ts` + `stepCtaEnforcer.ts` + `omniKernelAssembler.ts` + `auditWiring.test.ts` + `docs/CTA.md` |
| `m34-effect-journal` | auto | 效果日志 append-only / 分类 / 对账 / 坏行 fail-closed | `effectJournal.ts` + `effectJournal.test.ts` + `docs/EFFECTS.md` |
| `m34-effect-wiring` | auto | `StepToolExecutor` begin/finish + `Agent` resume 解释 + 缺省开 + 真实回合落盘判据 | `stepEffectRecorder.ts` + `agent.ts` + `omniKernelAssembler.ts` + `auditWiring.test.ts` |
| `m35-skills-spec` | auto | Agent Skills 规范字段（license/compatibility/metadata/allowed-tools）解析/序列化/往返 | `skill.ts` + `skillEntry.ts` + `skillMdCodec.ts` + `skillMdCodec.test.ts` |
| `m36-authorization` | auto | 单次授权台账 issue/consume/复用/过期/坏行 fail-closed | `authorizationLedger.ts` + `authorizationLedger.test.ts` + `docs/AAT.md` |
| `m36-authorization-wiring` | auto | allow 时签发、执行前消费、AAT 导出 authorization_id、复用检出 | `stepAuthorizationGate.ts` + `stepToolExecutor.ts` + `agent.ts` + `auditWiring.test.ts` + `auditAat.test.ts` |
| `m37-delegation-chain` | auto | 委托令牌签发/衰减/整链复核（scope/主体/过期/深度/签名） | `delegation.ts` + `delegationChain.ts` + `delegationChain.test.ts` + `docs/DELEGATION.md` |
| `m38-mcp-skills` | auto | MCP skills/list + skills/get + 能力声明（未注入不声明） | `mcpServerOptions.ts` + `mcpMethodService.ts` + `mcpSkills.test.ts` |
| `m39-mcp-tasks` | auto | MCP task handle + tasks/get/update/cancel + 能力声明 | `mcpTaskPort.ts` + `mcpMethodService.ts` + `mcpTasks.test.ts` + `docs/MCP-TASKS.md` |
| `m40-memory-governance` | auto | 记忆 provenance/准入/墓碑 + 可靠性报告签名/复核 | `memoryGovernance.ts` + `reliabilityReport.ts` + 两个 unit test + `docs/MEMORY-GOVERNANCE.md` |
| `m41-mcp-cta` | auto | MCP 服务端 `_meta.ctxIsolation` 校验 + 未注入零行为 | `mcpCtaPort.ts` + `mcpMethodService.ts` + `mcpCta.test.ts` + `docs/CTA.md` |
| `m42-delegation-wiring` | auto | config/子代理 token 进 ToolContext + 工具层 scope 收窄 | `toolContext.ts` + `stepToolExecutor.ts` + `subagentRuntimeFactory.ts` + `delegationWiring.test.ts` |
| `m43-cta-client` | auto | CTA 信封从执行器 → gateway → MCP 客户端 `_meta` | `toolContext.ts` + `mcpGateway.ts` + `mcpStatelessClient.ts` + `mcpStatelessClient.test.ts` |
| `m43-delegation-auto` | auto | 自动签发/衰减 + 执行期验签 + maxCalls 扣减 | `subagentRunner.ts` + `stepDelegationGate.ts` + `agent.ts` + `delegationWiring.test.ts` |
| `m43-memory-auto` | auto | 自动 provenance/准入 + 可靠性报告进 AAT | `fileLongTermMemory.ts` + `reliabilityReport.ts` + `omniKernel.ts` + `memoryGovernance.test.ts` + `auditWiring.test.ts` |
| `m44-delegation-trust` | auto | 跨 issuer 信任根/吊销 + 父子共享 `DelegationUsage` | `delegation.ts` + `delegationChain.ts` + `stepDelegationGate.ts` + `delegationChain.test.ts` |
| `m44-cta-http` | auto | CTA `mcp-ctx-isolation` HTTP 头合并/坏头拒绝 | `mcpHttpServer.ts` + `mcpMrtrWiring.test.ts` |
| `m44-aat-producers` | auto | approval 请求/回答 + heartbeat 自动写入 | `toolGatePort.ts` + `toolGate.ts` + `stepApprovalAuditor.ts` + `auditWiring.test.ts` |
| `m44-memory-default` | auto | `OmniKernel` 记忆治理默认开 | `memoryStackAssembler.ts` + `memoryGovernance.test.ts` |
| `m47-conformal-aat` | auto | 共形快照/决策字段在位 + 离线重算 + 篡改问题码 + 一次接入导出复核 | `auditRecord.ts` + `aatExporter.ts` + `conformalAatVerifier.ts` + `conformalAat.test.ts` + `conformalAat.property.test.ts` + `conformalAatWiring.test.ts` |
| `m48-durable-appender` | auto | DurableJsonlAppender（tombstone/fsync/mutate/read 分类）+ 回执链/授权台账/遥测迁移 + PathLock + resume 锁内重读 + 记忆形状守卫 | `src/kernel/util/durableJsonlAppender.ts` + `src/kernel/util/pathLock.ts` + `receiptChain.ts` + `authorizationLedger.ts` + `jsonlRuntimeTelemetry.ts` + `workflowRunner.ts` + `fileLongTermMemory.ts` + 三判据文件 |
| `m49-cancellation` | auto | 回合 signal 接线 + 门禁取消透传 + VRR 签名清除 + AG-UI CANCELLED + 媒体取消三段式 + CancellationClassifier | `agent.ts` + `turnRunner.ts` + `stepToolExecutor.ts` + `turnFailureLedger.ts` + `aguiEventStream.ts` + `spawnMediaProcessRunner.ts` + `cancellationClassifier.ts` + 两判据文件 |
| `m50-protocol-boundary` | auto | jsonRpc 严格形状 + ACP optionId 白名单/鉴权补全 + LineTransport EOF + MCP initialized/gateway 错误分类/onToolsChanged | `jsonRpc.ts` + `acpValidation.ts` + `acpSessionLifecycle.ts` + `lineTransport.ts` + `acpStdioTransport.ts` + `mcpClient.ts` + `mcpGateway.ts` + `sdkMcpClientAdapter.ts` + 三判据文件 |
| `m51-tool-call-ids` | auto | ToolCallIdAllocator 单一真源 + 五适配器合成交 + llamaCpp done 终止 + Gemini SseFrames 收口 + 路由非重试停止 | `src/kernel/adapters/model/toolCallIdAllocator.ts` + `openAiCompatibleModel.ts` + `anthropicModel.ts` + `llamaCppModel.ts` + `geminiWire.ts` + `responsesModel.ts` + `modelRouter.ts` + 两判据文件 |
| `m52-security-hardening` | auto | IPv6 前导零拒绝 + screenshot 导航守卫/真 CDP 回退 + shell 替换/单 & 收口 + 验证器诚实标记矩阵 + TSA nonce 闭环 | `ipAddress.ts` + `playwrightBrowserSession.ts` + `browserScreenshotTool.ts` + `dangerousCommands.ts` + `shellCommandParser.ts` + `taintAttestationBuilder.ts` + `disclosurePack.ts` + `envelopeSignature.ts` + `rfc3161Anchor.ts` + 三判据文件 |
| `m53-core-convergence` | auto | 语料签名构建期派生 + 合并后配置复验 + retry/circuitBreaker 入参校验 + 账本补偿 + WorkspaceGuard 收编 | `corpusIndexCache.ts` + `configFile.ts` + `configError.ts` + `retry.ts` + `circuitBreaker.ts` + `evolutionKernel.ts` + `assetPackInstaller.ts` + `workspaceGuard.ts` + 三判据文件 |
| `m55-kernel-sentinel` | auto | KernelSentinel 六分区 fail-soft + diagnostics() 接线 + 判据 | `src/kernel/bootstrap/kernelSentinel.ts` + `omniKernel.ts` + `src/contracts/ports/composition/kernelHealth.ts` + `tests/unit/kernelSentinel.test.ts` |
| `m56-deterministic-cache` | auto | generation 计数 + CachedToolPort 白名单/LRU/失效 + config 透传 + 判据 | `workspaceFileCoordinator.ts` + `src/kernel/adapters/tool/cachedToolPort.ts` + `configFieldSpecs.ts` + `tests/unit/cachedToolPort.test.ts` |
| `m57-turn-envelope` | auto | 回合基线差分 + postStep 超限停 + 事件留痕 + 判据 | `src/kernel/core/loop/turnCostEnvelope.ts` + `turnRunner.ts` + `configError.ts` + `tests/unit/turnCostEnvelope.test.ts` |
| `m59-capflow` | auto | 能力 ledger（tier 授能力矩阵）+ 声明式策略（fail-closed 加载 + external→mutating 默认 deny）+ 执行前 assess（enforce/shadow）+ 装配接线 + 判据 | `src/contracts/ports/security/capflow.ts` + `src/kernel/security/capabilityLedger.ts` + `src/kernel/security/capflowPolicy.ts` + `defaults/capflow-policy.json` + `stepToolExecutor.ts` + `tests/unit/capflow.test.ts` + `tests/unit/capflowWiring.test.ts` |
| `m60-retrieval-context` | auto | 推入式检索供给：端口/编排（守卫扫描 + 预算裁剪 + 降档 + 审计编码）+ StepContextBuilder 唯一尾消息接线（off 字节级不变）+ 配置段/出厂缺省 + 判据 | `src/contracts/ports/context/retrievalContextPort.ts` + `src/kernel/context/retrievalContextSupply.ts` + `src/kernel/context/taskQueryDeriver.ts` + `src/kernel/config/retrievalContextConfigValidator.ts` + `defaults/kernel/retrieval-context.json` + `stepContextBuilder.ts` + `tests/unit/retrievalContextSupply.test.ts` + `tests/unit/stepContextBuilderRetrieval.test.ts` |
| `m61-semantic-recall-config` | auto | 语义召回配置段（单一真源 requested：显式 mode 恒优先 + env 别名）+ 构造失败降档 + 哨兵 context 分区（SEMANTIC_RECALL_DEGRADED，absent≠degraded）+ 判据 | `src/contracts/ports/config/semanticRecallConfig.ts` + `src/kernel/config/semanticRecallConfigValidator.ts` + `src/kernel/config/configFactory.ts` + `src/kernel/bootstrap/kernelSentinel.ts` + `src/contracts/ports/composition/kernelHealth.ts` + `defaults/kernel/semantic-recall.json` + `tests/unit/semanticRecallConfig.test.ts` |
| `m62-retrieval-bench` | auto | bench 检索探针 + 冷索引 TTL 停顿隔离（数据裁决回填 RESEARCH §5）+ LongMemEval 注入模式 + 判据 | `scripts/bench/run.mjs` + `scripts/bench/coldIndexStall.mjs` + `src/kernel/eval/longMemEval.ts` + `tests/unit/longMemEvalInjection.test.ts` + `docs/RESEARCH-2026-11.md` |
| `m63-context-policy` | auto | 降档阶梯契约（两级）+ 严格校验器 + 出厂缺省（全 false 快照）+ StepContextBuilder 阶梯消费 + Agent 装配 + 等价/降档判据 | `src/contracts/ports/config/contextPolicyConfig.ts` + `src/kernel/config/contextPolicyConfigValidator.ts` + `defaults/kernel/context-policy.json` + `src/kernel/core/stepContextBuilder.ts` + `src/kernel/core/agent.ts` + `tests/unit/contextPolicyConfig.test.ts` + `tests/unit/contextPolicyEquivalence.test.ts` + `tests/unit/contextPolicyDegrade.test.ts` |
| `m64-prompt-cache-evidence` | auto | 内核级缓存读数契约 + 单槽台账 + Runtime 装配 + TurnRunner 读数组装 + Agent 收尾记录 + 哨兵 context 分区呈现 + 判据 | `src/contracts/ports/composition/contextCacheReadout.ts` + `src/kernel/observability/contextCacheReadoutLedger.ts` + `src/kernel/composition/runtime.ts` + `src/kernel/core/turnRunner.ts` + `src/kernel/core/agent.ts` + `src/kernel/bootstrap/kernelSentinel.ts` + `src/kernel/bootstrap/omniKernel.ts` + `tests/unit/contextCacheReadout.test.ts` |
| `m65-cache-aware-tail` | auto | 台账累计面（Σ/Σ）+ cacheGuard 门限契约（0,1 开区间）+ Agent 收尾活判定（CacheHitRateWatch 只告警不阻断）+ 判据 | `src/contracts/ports/composition/contextCacheReadout.ts` + `src/kernel/observability/contextCacheReadoutLedger.ts` + `src/contracts/ports/config/contextPolicyConfig.ts` + `src/kernel/config/contextPolicyConfigValidator.ts` + `src/kernel/core/agent.ts` + `tests/unit/contextCacheReadout.test.ts` + `tests/unit/contextPolicyConfig.test.ts` |
| `m66-query-rewriting` | auto | 改写端口（fail-closed 契约）+ 模型适配器 + rewriter 枚举配置（缺省 off）+ 供给集成与审计标记 + 评测面 + 判据 | `src/contracts/ports/context/queryRewriterPort.ts` + `src/kernel/context/modelQueryRewriter.ts` + `src/kernel/context/retrievalContextSupply.ts` + `src/contracts/ports/config/retrievalContextConfig.ts` + `src/kernel/config/retrievalContextConfigValidator.ts` + `src/kernel/core/agent.ts` + `defaults/kernel/retrieval-context.json` + `tests/unit/queryRewrite.test.ts` |
| `m67-cross-encoder-rerank` | auto | 精排端口（保序保集 + fail-closed）+ 序数解析适配器 + rerank 枚举配置（缺省 off）+ 供给集成（降档跳过 = M63 联动）+ 审计 reranked 标记 + 判据 | `src/contracts/ports/context/rerankPort.ts` + `src/kernel/context/modelReranker.ts` + `src/kernel/context/retrievalContextSupply.ts` + `src/contracts/ports/config/retrievalContextConfig.ts` + `src/kernel/config/retrievalContextConfigValidator.ts` + `src/kernel/core/agent.ts` + `defaults/kernel/retrieval-context.json` + `tests/unit/queryRerank.test.ts` |
| `m68-capflow-injection-enforce` | auto | 能力枚举 +injected-untrusted + 台账注入面回授 + 策略维度/默认规则 + M60 片段标记升级 + Agent 回授 + 判据 | `src/contracts/ports/security/capflow.ts` + `src/kernel/security/capabilityLedger.ts` + `src/kernel/security/capflowPolicy.ts` + `src/kernel/context/retrievalContextSupply.ts` + `defaults/capflow-policy.json` + `src/kernel/core/agent.ts` + `tests/unit/capflow.test.ts` |
| `m71-clean-checkout-tsc` | auto | worktree 干净检出 + junction node_modules + tsc 双配置 + verify 接线 | `scripts/cleanCheckoutTsc.mjs` + `package.json` |
| `m69-eval-automation` | auto | scoreInjection 四组对照（off/rewriter/reranker/both）+ package script 接线 | `scripts/evalInject.mjs` + `package.json` |
| `m70-supply-stress` | auto | 8 会话并发供给 × BM25 + 隔离断言 + p95 延迟护栏 | `tests/stress/supply.stress.ts` |
| `m72-vector-port` | auto | 端口契约（upsert/search/remove?）+ mock 语义判据 | `src/contracts/ports/context/vectorStorePort.ts` + `tests/unit/vectorStorePort.test.ts` |
| `m73-eval-real-backfill` | auto | 真实模型档（provider 数据文件 + 凭据 env 解析 + 探活 fail-closed）+ 回执 schema + §7 实测落账 + CLI 判据 | `scripts/evalInject.mjs` + `scripts/lib/modelPortFactory.mjs` + `scripts/eval/models.json` + `tests/contract/evalInjectCli.test.ts` + `docs/RESEARCH-2026-11G.md` |
| `m74-web-sse-surface` | auto | 宿主侧静态 UI + 起任务入口 + 内嵌 workbench（SSE/state/answers）+ 无头冒烟（含并发 409） | `examples/web/hostServer.mjs` + `examples/web/public/` + `scripts/webSseSmoke.mjs` + `tests/contract/webSseHost.test.ts` |
| `m75-route-quality-compare` | auto | 七策略 × 12 任务质量/延迟/成本对照 + 三档 mock（可用性节律）+ 真实档探活/fail-closed + `MeteredModel` 成本计量 | `scripts/modelRouteCompare.mjs` + `scripts/eval/route-models.example.json` + `tests/contract/modelRouteCompareCli.test.ts` |
| `m76-residual-ledger` | auto | 残余总账四类分节（外部阻塞/宿主职责/明确不做/本轮关闭）+ 过期表述已消（DELEGATION/H §3/M42/WIRING §6） | `docs/RESIDUAL.md` + `docs/DELEGATION.md` + `docs/RESEARCH-2026-11H.md` + `docs/WIRING.md` |
| `m58-audit-timeline` | auto | 自包含 HTML（零脚本全转义）+ export 选项 + 判据 | `src/kernel/receipts/auditTimelineHtml.ts` + `omniKernel.ts` + `tests/unit/auditTimelineHtml.test.ts` |
| `m54-deep-tests` | auto | 委托四升级码负测试 + 多实例并发账本压力 + 重启循环 + 撕裂恢复压力装置 | `tests/unit/delegationEscalation.test.ts` + `tests/stress/instances.stress.ts` + `tests/stress/lifecycle.stress.ts` + `tests/stress/ledger.stress.ts` |
| `m27-sdk-client` | auto | SdkSocket 契约 + SdkClient + WebSocketSdkSocket 在位 + 判据 | `src/kernel/rpc/sdkClient.ts` + `src/kernel/transport/webSocketSdkSocket.ts` + `scripts/planCheck.mjs` |
| `m27-secret-redactor` | auto | SecretRedactor（递归打码 + maskKey）在位 + 判据 | `src/kernel/util/secretRedactor.ts` + `scripts/planCheck.mjs` |
| `m27-alpha12` | auto | package.json 版本 = CHANGELOG 顶条（alpha.12） | `package.json` + `CHANGELOG.md` + `scripts/planCheck.mjs` |
| `m27-compat-zero` | manual | 应用 kernel-compat 目录删除 + 影子退役 + 全量回归绿 | 本文件 §6 |

---

## 6. 人工复核记录

> `manual` 判据**只认这张表**：没有行 = 未通过。一行 = 一次复核，写日期、判据 id、可复核的证据（链接 / 命令输出摘要）。

| 日期 | 判据 | 证据 |
| ---- | ---- | ---- |
| 2026-11-15 | m2-consumer | alpha.20 vendored 升级：OmniHarness-app（`feat/kernel-package` bf65d4c）钉 `vendor/omniharness-kernel-0.1.0-alpha.20.tgz`（内核 tag `v0.1.0-alpha.20`，5.4 MB / 3,675 文件，含 native）；app `kernel:check` 284 源文件 / 288 导入全命中 + typecheck + web 201 文件 / 926 用例通过（app 仓 54 个桌面/设置 WIP 未纳入本次提交）；内核 `cross:check`：钉定 = 内核 = 0.1.0-alpha.20 / 1185 承诺导出名 |
| 2026-11-14 | m2-consumer | alpha.19 vendored 升级：OmniHarness-app（`feat/kernel-package` f183573）钉 `vendor/omniharness-kernel-0.1.0-alpha.19.tgz`（内核 tag `v0.1.0-alpha.19`，5.4 MB / 3657 文件，含 native）；app `kernel:check` 九条复绿（282 源文件 / 288 导入 / 19 域零变化）+ typecheck×3 + web 198 文件 / 905 用例 + build/build:web + smoke 8 条 + desktop 38 条；内核 `cross:check`：app 钉 0.1.0-alpha.19 / 1185 承诺导出名一致 |
| 2026-11-14 | m59-capflow | 提交（本 commit）：CapabilityLedger（tier 授能力矩阵）+ CapFlowPolicy（声明式 fail-closed 加载 + external→mutating 默认 deny + mcp_ 前缀通配）+ runToolCall 执行前 assess（enforce 拒 CAPFLOW_DENIED / shadow 留证）+ observe 回授 + config capflow.mode；判据 capflow.test(5)/capflowWiring.test(3)——含 enforce 端到端拒绝与 shadow/off 零行为 |
| 2026-11-14 | m60-retrieval-context | 提交（本 commit）：RetrievalContextPort/RetrievalSnippet（contracts）+ RetrievalContextSupply（守卫扫描 memory 档 / 预算裁剪不截半文 / 降档减半 / 审计编码）+ TaskQueryDeriver 共享查询真源（RepoMapInjector 委托）+ StepContextBuilder 唯一尾消息合并（off 字节级不变）+ Agent 装配（off=undefined）+ 投影剔除 OMNI_RETRIEVAL_V1 + config retrievalContext 段 + defaults/kernel/retrieval-context.json；判据 retrievalContextSupply.test(6)/repoMapInjectorQuery.test(2)/stepContextBuilderRetrieval.test(3)——含 off 字节级不变与审计不进模型两态 |
| 2026-11-14 | m61-semantic-recall-config | 提交（本 commit）：SemanticRecallConfig（mode off/on）+ 严格校验器 + 单一真源 requested（显式 mode 恒优先，env 为段缺省别名）+ buildEmbeddingPort 读配置段（构造失败 fail-closed 降档 + 告警）+ 哨兵 context 分区（requested/active 两态 + SEMANTIC_RECALL_DEGRADED）+ capabilities 诚实标记 + workspaceTrust SAFE_KEYS；判据 semanticRecallConfig.test(4)——含降档三态与 env 等价；kernelSentinel.test 六分区→七分区同步 |
| 2026-11-14 | m62-retrieval-bench | 提交（本 commit）：bench 探针 6 retrievalSupply（0.1845 ms/次 @600 文档）+ 探针 1/2 陈旧 API 修复（appendUser→eventFactory.append / headFingerprint→CompactionStateCodec——bench 自 M8 后带伤两轮的休眠债）+ coldIndexStall.mjs（400 文件 36ms / 1200 文件 88ms ⇒ 维持 P3 不做裁决，回填 RESEARCH §5）+ LongMemEval.scoreInjection（独立索引 + 预算档位）；判据 longMemEvalInjection.test(3)——recall 计算/预算裁剪/case 隔离 |
| 2026-11-14 | m63-context-policy | 提交（本 commit）：ContextPolicyConfig.degradeLadder（两级）+ 严格校验器（段/阶梯两层）+ defaults/kernel/context-policy.json（全 false = 当前行为显式快照）+ StepContextBuilder 阶梯消费（aggressive/compactForce = forceCompaction ∨ 降档∧级）+ Agent 装配（resolve 同源）+ KNOWN_KEYS + workspaceTrust SAFE_KEYS；判据 contextPolicyConfig.test(3)/contextPolicyEquivalence.test(3)/contextPolicyDegrade.test(3)——缺省字节级等价、LR-03 逃生口直通、两级独立启用 |
| 2026-11-14 | m64-prompt-cache-evidence | 提交（本 commit）：ContextCacheReadout/Store 契约 + ContextCacheReadoutLedger（单槽覆盖式）+ Runtime 装配 + TurnRunner.contextReadoutOf（缺字段不臆造）+ Agent 收尾记录（零开销跳过）+ 哨兵 context 分区 cache 呈现（absent≠degraded）+ diagnostics 桥接；AAT 决策记录不加 cache 字段（回合级遥测不进逐调用决策——诚实边界）；判据 contextCacheReadout.test(2)——台账覆盖/浅拷贝 + 哨兵两态 |
| 2026-11-14 | review-r5 自查 | 二手审查（b953b9f..659331c 全量 diff）结论可合入、无 P0；本 commit 清偿 P1-1（workbench 投影剔除 OMNI_RETRIEVAL_V1——契约自述的双层剔除账实对齐）+ P2-2/3/4/9/10（审计回调移出 try fail-soft / 查询回声与审计行排除 / 阈值覆盖透传同源 / longMemEval 走 eventFactory / resolve 白名单复核）+ P2-5/6（单尾消息 repo-map 在位变体 + off→装配 undefined 判据）+ P2-8（3 处 env-only 陈旧注释）；**择机收敛**：P2-7（段校验器家族 4+ 份，收敛为 Shape/共享段组合子——同类逻辑第二份信号已现，另立工作项）→ **已清偿**（2026-11-14 ConfigSectionGuard 组合子，R5 三校验器迁移为规格数据；calibratedAutonomy 随 R6 附带减法收官）。测试 +5 用例（回声排除/阈值透传/审计 fail-soft/resolve 白名单/单尾消息 repo-map 变体），投影测试补 M60 审计行剔除断言 |
| 2026-11-14 | m65-cache-aware-tail | 提交（本 commit）：ContextCacheReadoutTotals 累计面（Σ/Σ 与容量统计服务同源）+ contextPolicy.cacheGuard 门限（0,1 开区间）+ Agent 构造期按门限建 CacheHitRateWatch + 回合收尾新读数才判定；**机制修正**：裁撤原拟「尾段指纹节流」（尾字节稳定不延长 provider 可缓存前缀——RESEARCH-G §2.3 诚实边界），预算 10h→5h；判据 contextCacheReadout.test 累计口径/组合判定 + contextPolicyConfig.test 门限校验/resolve 透传 |
| 2026-11-14 | m66-query-rewriting | 提交（本 commit）：QueryRewriterPort（fail-closed 回退契约）+ ModelQueryRewriter（ModelPort 精简 prompt，上文口径与派生器同源）+ retrievalContext.rewriter 枚举（缺省 off）+ 供给集成（审计报告 rewritten 标记）+ scoreInjection 改写器参数（对照面）；**实施前修正**：规则版裁撤（派生器消息拼接冗余——RESEARCH-G §3）；判据 queryRewrite.test(4)——三态 fail-closed/配置校验/供给集成含基线对照/评测面 |
| 2026-11-14 | m67-cross-encoder-rerank | 提交（本 commit）：RerankPort（保序保集 + fail-closed）+ ModelReranker（LLM-as-judge 序数判定——编号候选 prompt → 容错解析「3, 1, 2」/覆盖不全回退）+ retrievalContext.rerank 枚举（缺省 off）+ 供给集成（降档跳过 = M63 阶梯联动 + 审计 reranked 标记）+ scoreInjection reranker 参数；判据 queryRerank.test(4)——重排生效/三态回退/供给集成含单候选直通/降档跳过 |
| 2026-11-14 | m68-capflow-injection-enforce | 提交（本 commit）：SourceCapability +injected-untrusted（注入面独立授能力——片段本轮工具执行前进入注意力）+ CapabilityLedger.observeInjection（幂等）+ CapFlowPolicy 观测委托 + 策略 Shape/默认规则（注入面 → mutating → deny，shadow 留证）+ M60 片段标记升级 + Agent 审计回调回授（有注入才授）；判据 capflow.test 注入面矩阵（授能力/三态/幂等）|
| 2026-11-14 | m69-eval-automation | 提交（本 commit）：evalInject.mjs 四组对照（off/rewriter/reranker/both）× 20 case BM25 → recall@k/MRR 对比表 + JSON --out；mock 适配器（数字只证机制闭环——真实模型回填留 adapter 切换）；判据 evalInject 脚本事实 + script 接线 |
| 2026-11-14 | m70-supply-stress | 提交（本 commit）：supply.stress.ts 8 会话并发 × 25 步 × 50 文档独立索引——跨会话漏召回断言 + p95 < 50ms + 墙钟 < 10s；判据 supply.stress 事实（隔离断言 + p95 护栏）|
| 2026-11-14 | m72-vector-port | 提交（本 commit）：VectorStorePort 契约（upsert/search/remove? 对齐面——内核不内置向量库）+ mock 语义判据（幂等写入/降序/删除/可选 remove 缺省路径）；判据 vectorStorePort.test(2) |
| 2026-11-14 | m73-eval-real-backfill | 提交（本 commit）：evalInject 真实模型档（provider 数据文件 + 凭据 env 解析 + 探活 fail-closed + `--out` 回执 schema omni-eval-inject/v1）+ modelCalls 机制证据 + RESEARCH-G §7 mock 实测基线/真实槽位；判据 evalInjectCli.test(4)——四组落盘/本地假端点真跑通/缺凭据/端点不可达 |
| 2026-11-14 | m74-web-sse-surface | 提交（本 commit）：宿主侧 SSE/Web 面（examples/web：静态 UI + `POST /api/tasks` + 内嵌 WorkbenchServer 回环/令牌/CORS loopback + 串行 409 + 幂等 close）+ EventSource 命名事件/state 投影/pendingAsk 回答 + 无头冒烟 webSseSmoke（SSE 6 帧：assistant/question/session_meta/tool_call/tool_result/user）；判据 webSseHost.test(1) |
| 2026-11-14 | m75-route-quality-compare | 提交（本 commit）：modelRouteCompare 七策略 × 12 任务（code/reason/general）+ 三档 mock（质量/延迟/单价/失败节律）+ MeteredModel 成本/调用分布 + health-fallback 回退计数 + 真实档 --real-config 探活 fail-closed；mock 实测：health-fallback 11/12@$0.000697 vs by-context 6/12@$0.0000176（质量-成本权衡可见）；判据 modelRouteCompareCli.test(2) |
| 2026-11-14 | m76-residual-ledger | 提交（本 commit）：RESIDUAL.md 总账（R1–R4 外部阻塞 / H1–H8 宿主职责 / N1–N12 明确不做 / §4 本轮关闭）+ 过期表述收尾（DELEGATION 已接线、H §3 M71 已落地、H §1/§4 R8 已裁决、G §1 M65–M68 已闭合、M42 由 M44 补齐、WIRING §6 分类、API/RECEIPTS/STANDARDS 指向总账）+ route:compare 真实档 per-entry 端点覆盖与端到端判据 |
| 2026-11-13 | m55-kernel-sentinel | 提交 e23e6a2：KernelSentinel 六分区 fail-soft（absent ≠ degraded）+ diagnostics() 接线；判据 kernelSentinel.test(3)——absent 形态/遥测在位/子探测抛错隔离 |
| 2026-11-13 | m56-deterministic-cache | 提交 b671d42：generation 计数 + CachedToolPort（白名单/LRU/callId 重写/失效统计）+ config toolCache；判据 cachedToolPort.test(6) |
| 2026-11-13 | m57-turn-envelope | 提交 53e920f：TurnCostEnvelope 基线差分（读数缺失 fail-open，全局预算兜底）+ postStep 超限停 + turn.envelope_exceeded 事件；判据 turnCostEnvelope.test(4) |
| 2026-11-13 | m58-audit-timeline | 提交 045e81b：AuditTimelineHtml（零脚本/全转义/无外链）+ exportAuditBundle timeline 选项；判据 auditTimelineHtml.test(4)——含注入转义用例 |
| 2026-11-12 | m48-durable-appender | 提交 8d20955：DurableJsonlAppender（tombstone 自愈 + flush fsync + read 三分类）+ PathLock + 全账本迁移；判据 durableJsonlAppender.test(7)/ledgerTornTail.test(3)/ledger.stress(3，8 实例交错 80 条 seq 连续 + 20 写者 100 样本零丢失) |
| 2026-11-12 | m49-cancellation | 提交 87ebdbd：signal 接线 + 门禁透传 + VRR 清除 + CancellationClassifier；判据 turnCancellation.test(2)/cancellationClassifier.test(4) |
| 2026-11-12 | m50-protocol-boundary | 提交 7f40efc：jsonRpc 严格形状 + ACP 白名单/鉴权 + EOF/EPIPE + MCP initialized/错误分类/onToolsChanged；判据 protocolBoundary.test(3)/mcpInitialized.test(2)/mcpGatewayErrors.test(3) |
| 2026-11-12 | m51-tool-call-ids | 提交 f170549：ToolCallIdAllocator 五通路统一 + done 终止 + 非重试停止；判据 toolCallIdAllocator.test(3)/adapterToolIds.test(2) |
| 2026-11-12 | m52-security-hardening | 提交 cbf1aa4：IPv6 八进制拒绝 + screenshot 导航守卫/真 CDP 回退 + shell 替换/单 & 收口 + 诚实标记（SIGNATURE_UNCHECKED/COMMITMENT_UNVERIFIED/alg/TSA nonce 闭环/OCSP unknown）+ 路径遏制；判据 ipAddress.v6tail(3)/shellPolicyBypass(6)/verifierHonesty(4) |
| 2026-11-13 | m53-core-convergence | 提交 598d153：语料签名单一真源 + 合并后配置复验 + 基元入参校验 + 账本补偿 + sanitizer 成组重建（属性判据当场抓出旧实现仍 400 的缺陷并修复）；判据 retryInput(3)/mergedConfigRevalidate(2)/toolRoundSanitizer.property(1) |
| 2026-11-13 | m54-deep-tests | 委托四升级码负测试 + 多实例并发账本压力 + 重启循环 + 撕裂恢复压力；判据 delegationEscalation(4)/instances.stress(2)/lifecycle.stress(2)/ledger.stress(3) 全绿入 stress 配置 |
| 2026-11-04 | m4-metaphor-zero | 3b9a977（隐喻栈+燧+Genesis 拆线）与 df80bed/1328fd2（孤儿清扫）；登记于 ExperimentalPaths |
| 2026-11-04 | m5-receipts-contract-suite | 869c647（JCS）+ 4ae8f1c（链/锚/复核器，变异判据四连全红自证）+ 6572c5d（RECEIPTS.md）|
| 2026-11-04 | m6-mcp-server-wired | cffe5e0（McpHttpAssembly 端到端 + capability 谎报修正 + provenance/governance 通电）+ 8684bbe（沙箱 fail-closed）|
| 2026-11-04 | m6-workbench-bridge | e8c1457（Hub+投影）+ 123da76（SSE/续传/审计端点）+ c09548f（端到端示例：提问桥真机闭环）|
| 2026-11-05 | m2-consumer | OmniHarness-app（D:deepseekomniharness-app，f3b36e1）钉 file:vendor/omniharness-kernel-0.1.0-alpha.6.tgz（内核 tag v0.1.0-alpha.6 = f362434）；app verify 全链绿（typecheck×3 + kernel:check 6/6 + web:test + build + smoke + desktop 25/25）；Runtime 收敛为内核薄扩展，被删能力 app 自有化（kernel-compat 122 文件）|
| 2026-11-07 | m2-consumer | alpha.7 首次升级回归：OmniHarness-app（feat/kernel-package，21f946c）钉 vendored alpha.7（tag v0.1.0-alpha.7 = e6cb909，vendorKernel.mjs 重建含 native）；M9 清账删除的 11 个模块（approval 适配器 ×5 / mcp ×3 / sdk socket ×2 / plugin 权限契约）随迁 app kernel-compat，业务消费点重接 + 17 域文件再生成；app verify 全链绿（kernel:check 360 文件 + typecheck×3 零错 + web 748 用例 + build + smoke 原生实载 + desktop 30/30）|
| 2026-11-07 | m2-consumer | alpha.9（M21 Phase 2 BREAKING）升级回归：OmniHarness-app 钉 vendored alpha.9（tag v0.1.0-alpha.9 = 1b94034，exports 通配删除 → 251 条显式闭包）；app kernel:check 新增「导入 ⊆ 承诺清单」机检——309 处导入全部命中；app verify 全链绿（kernel:check + typecheck×3 + web 748 用例 + build + smoke 原生实载 + desktop 30/30）|
| 2026-11-07 | m21-generator-source | M21 Phase 3（解析源 = 承诺面）落地并实战闭环：app `kernelSurface.mjs` 解析源改为「内核 exports 承诺清单第一优先 + dist 回退黄标」（应用 feat/kernel-package 同批提交）；黄标首秀即抓到 B1 的 `Runtime` 新家未入 alpha.9 清单 → kernel:check 红 → 内核扩承诺面 251→252（alpha.10 = 91a52b8）→ 应用复绿；修复过程含根 spec 尾斜杠口径缺陷（TrustTier 连带暴露）与幂等恢复；app verify 全链绿（kernel:check 360 文件 + web 748 用例 + smoke 原生实载 + desktop 30/30）|
| 2026-11-07 | m27-compat-zero | 兼容层清零收官：OmniHarness-app 钉 vendored alpha.12（tag v0.1.0-alpha.12 = 187fa15，tgz 4569 KiB / 3145 文件，M26+M27+M28 同版）；**`src/host/kernel-compat` 目录不复存在**（更名 `src/host/extensions`，只剩真应用形状件）——41 件影子退役（4e684f5）+ 死代码 3 处清偿（f0e8191）+ 29 引用文件随更名改写（b599fb7）；app verify 全链绿（kernel:check 269 文件 / 360 处包导入全部命中承诺闭包 329 条、黄标 0 + typecheck×3 + web 748 用例 + build + smoke 原生实载 + desktop 30/30）；同日内核 verify 全绿（117 文件 690 用例 + 27 里程碑 / 82 判据账实一致）|
| 2026-11-07 | m29-jcs-audit（人工复核补记） | 审计 canonical 单一真源闭环：alpha.13（tag v0.1.0-alpha.13 = 7bf2387）→ OmniHarness-app vendored 升级（96ea120）；auditChain/auditReportBuilder/auditReportVerifier 改指内核 Jcs，apps/audit/auditCanonical.ts（第二实现）退役；HTML 内嵌复核脚本 canon 与 Jcs 逐字节对齐（花括号配平提取独立求值）；应用侧 golden 4 例 + verify 全链绿（kernel:check 268 文件 / 361 导入全命中承诺闭包 330 条 + typecheck×3 + web 752 用例 + build + smoke + desktop 30/30）；内核 verify 全绿（117 文件 694 用例 + 28 里程碑 / 83 判据账实一致）|

---

## 7. 发布记录

| 版本 | 日期 | 动作 | 证据 |
| ---- | ---- | ---- | ---- |
| 0.1.0-alpha.20 | 2026-11-15 | 发布**就绪**（未 `npm publish`，无凭据）；alpha.19 后的收尾基线；app 已 vendored 升级（`bf65d4c`） | 14 个提交（f384ece..c1d50e9）；公开面仍 60/60；`god:report` 超预算 0；新增 `publish:check` + `docs/RELEASE.md`；app `kernel:check` 284/288 + typecheck + web 201/926；verify 全绿（343 文件 / 1533 用例 + 压力 23 + `plan:check` 73 里程碑 / 138 判据） |
| 0.1.0-alpha.19 | 2026-11-14 | 发布**就绪**（未 `npm publish`，无凭据）；app 已完成 vendored 升级 | 内核 `npm pack` 3.9 MB / 3,671 文件（M55–M76 入版，**不含 native**——native 由宿主 `vendorKernel` 构建注入）；app vendored tgz 5.4 MB / 3,657 文件（含 native/omni_napi.node）；app `kernel:check` 九条复绿 + typecheck×3 + web 198/905 + build/smoke/desktop 38；内核 `cross:check` 一致（app 钉 0.1.0-alpha.19 / 1185 承诺导出名）；app 提交 f183573 |
| 0.1.0-alpha.18 | 2026-11-13 | 发布**就绪**（未 `npm publish`，无凭据） | tag `v0.1.0-alpha.18` = ae09198；M48–M54 入版（账本可靠性 / 取消语义 / 协议边界 / 适配器收敛 / 安全二轮 / 核心正确性 / 深度测试装置）；CHANGELOG alpha.18 段；公共导出面不变 |
| 0.1.0-alpha.17 | 2026-11-11 | 发布**就绪**（未 `npm publish`，无凭据） | tag `v0.1.0-alpha.17` = e8b8420；二轮复核 27 条发现全闭环（台账底稿已随 2026-11-14 清理删除，摘要保留在 CHANGELOG alpha.17 段）；cross-repo 承诺面仍 1,185；端口签名变化要求应用侧重新 vendor |
| 0.1.0-alpha.16 | 2026-11-09 | 发布**就绪**（未 `npm publish`，无凭据） | tag `v0.1.0-alpha.16` = e6352d3；巡检闭环（AG-UI 公开 / 协议判据 / 账实收敛）+ M45–M47（校准自主性 / GK01 严格界 / 共形决策自证）同版 |
| 0.1.0-alpha.15 | 2026-11-08 | 发布**就绪**（未 `npm publish`，无凭据） | tag `v0.1.0-alpha.15` = 44218e6；**合并 alpha.14 内容**；P1 信任边界（交互式沙箱包装 / RFC3161 证书链 / 页面内请求拦截）+ 16 件 `L0-unverified` 清零 + MCP 客户端反向请求 + 覆盖率二次收紧 |
| 0.1.0-alpha.14 | 2026-11-08 | 发布**就绪**（未单独成版，内容并入 alpha.15） | tag `v0.1.0-alpha.14` = b4eb0a5；补提交被 `*.log` 忽略的评测夹具输入（CI 缺 `data/*.log` 导致 M24 红） |
| 0.1.0-alpha.13 | 2026-11-07 | 发布**就绪**（未 `npm publish`，无凭据） | tag `v0.1.0-alpha.13` = 78773b3；M29 审计 canonical 单一真源（auditCanonical → 内核 Jcs，golden 逐字节对齐）；应用 vendored 升级与回归见 §6 m29-jcs-audit |
| 0.1.0-alpha.12 | 2026-11-07 | 发布**就绪**（未 `npm publish`，无凭据） | tag `v0.1.0-alpha.12` = 5729be2；M26+M27+M28 入版；应用钉 vendored（4,569 KiB / 3,145 文件，kernel-compat 整目录退役），见 §6 m27-compat-zero |
| 0.1.0-alpha.11 | 2026-11-07 | 发布**就绪**（未 `npm publish`，无凭据） | tag `v0.1.0-alpha.11` = 311882f；M24 评测闭环与收尾（长任务 23 fixture 四件套 self-check 23/23）+ 消费侧字面量漂移清偿 |
| 0.1.0-alpha.10 | 2026-11-07 | 发布**就绪**（未 `npm publish`，无凭据） | tag `v0.1.0-alpha.10` = 91a52b8；M21 Phase 3 域生成器解析源对齐承诺清单（承诺面 251→252，`Runtime` 新家入列）；黄标实战闭环见 §6 m21-generator-source |
| 0.1.0-alpha.9 | 2026-11-07 | 发布**就绪**（未 `npm publish`，无凭据） | **BREAKING：exports 通配删除 → 251 条显式深路径闭包**（M21 Phase 2）；空目录安装 + headless 冒烟跑通；verify 全绿（108 文件 / 601 用例 + 压力 9 + 公开面 60/60 + `plan:check` 21 里程碑 / 61 判据，`m21-explicit-exports` 首次转绿） |
| 0.1.0-alpha.8 | 2026-11-07 | 发布**就绪**（未 `npm publish`，无凭据） | `npm pack` 2.74 MB / 2695 文件（M19 核心循环韧性 + M20 交付编码 + receipts OOP Phase A 首次入版）；空目录安装 + headless 冒烟跑通；verify 全绿（108 文件 / 601 用例 + 压力 9 + 公开面 60/60 + `plan:check` 20 里程碑 / 59 判据） |
| 0.1.0-alpha.7 | 2026-11-07 | 发布**就绪**（未 `npm publish`，无凭据） | `npm pack` 2.72 MB / 2692 文件（M8–M18 首次入版）；空目录安装 + headless 冒烟跑通；`verify` 全绿（106 文件 / 580 用例 + 压力 9 + 公开面 60/60 + `plan:check` 18 里程碑 / 57 判据） |
| 0.1.0-alpha.1 | 2026-11-03 | 发布**就绪**（未 `npm publish`，无凭据） | `npm pack` + 空目录安装 + `node examples/headless.mjs` 跑通 |
| 0.1.0-alpha.2 | 2026-11-03 | 发布**就绪**（未 `npm publish`：`npm whoami` → `ENEEDAUTH`，无 token） | `npm pack` 3.14 MB / 3529 文件（laya 已不在包内、tests 零泄漏）；空目录安装 + headless 跑通；`npm publish --dry-run` 通过 |
| 0.1.0-alpha.3 | 2026-11-03 | 发布**就绪**（同上，无凭据） | 应用形状清零（19 文件 / 2.5K 行）；`npm pack` 后空目录安装 + headless 跑通；`verify` 29 文件 170 例、59 / 60 |

> 纪律：发布记录只写**已经发生**的事。「就绪」与「已发布」分开写，避免把 `npm pack` 成功说成已上线。
> **待执行**（有凭据时，一条命令）：`npm publish --tag alpha`（`publishConfig` 已钉 `access: public` + `tag: alpha`，
> 不会误发到 `latest`）。

---

## 8. 不在计划内（以及什么条件下才考虑）

| 不做 | 触发条件 |
| ---- | -------- |
| 拆独立 git 仓库 / 上 npm workspaces | 出现真实外部消费者，且它要求独立版本节奏；否则只是把目录换成 `package.json` |
| 新增顶层导出 | 公开面先回到 ≤55 再谈；每个新增必须写「谁会用」 |
| 第二套 CLI / Web / TUI | 内核不做体验层；应用需要时在内核开 issue |
| 重写内核 | 债务在结构不在代码；重写只消除理解成本，不消除维护成本 |
| 自动发布流水线 | 先有 ≥2 次人工发布记录，且发布事故为 0 |

---

## 9. 风险

| 风险 | 症状 | 对策 |
| ---- | ---- | ---- |
| 账实再次漂移 | 文档写 ✅、`plan:check` 红 | 双向对账；翻状态必须同一 commit 带判据证据 |
| 公开面偷偷长回 | `api:check` 顶到 60 | 新符号先进子路径；`@beta` 组不得上顶层 |
| 判据变脆（重构即红） | 判据依赖具体文件名/措辞 | 判据只钉**事实**（文件存在、数字上限、命令退出码），不钉实现细节 |
| 单人 10 h/周 排期失真 | 里程碑连续两轮无进展 | 砍工作项而不是砍判据；必要时把里程碑拆小 |
| alpha 被当成稳定版 | 下游直接上生产 | README 与 CHANGELOG 首行同步标注「不承诺兼容」 |

---

## 10. 决策日志

| 日期 | 决策 | 理由 |
| ---- | ---- | ---- |
| 2026-11-14 | `m4-source-lines` 预算 162K → 164K（R7 上帝类拆分） | 三个超预算类（Agent 803→604 / ConfigFactory 727→668 / CorpusIndexCache 715→拆分中）拆出 `AgentTurnFinalizer` / `AgentStepAssembler` / `EmbeddingStackAssembly` /（CorpusIndexLoader）四个协作者——装配体逐字搬迁、行为不变；新增为文件头注/接口声明的结构性成本（实测拆分后 162,160，调账至 164K 余 ~1.8K）。交换条件：拆分不改任何行为（既有测试逐字过）、`god:report` 三个 [类>700] 标记消除；不以删功能换数字 |
| 2026-11-14 | `m4-source-lines` 预算账补记：155K → 162K（两次上调当时未入账，本条补记）+ R5 批次净增至 161,316 | M54 深度测试装置 158→160（压力/极限/边界三线测试代码，不改生产路径）；M59 CapFlow 160→162（能力 ledger/声明式策略/执行前 assess）；R5（M60–M64）检索供给/语义召回/评测/策略面/读数台账净 +2.6K（off 档零行为变更、等价判据钉住）。实测 161,316 / 上限 162,000，余量 684 行——**下一轮新增必须随 commit 记账**；交换条件：P2-7 段校验器组合子收敛目标净减行数，不以删功能换数字 |
| 2026-11-14 | `m4-source-lines` M66–M68 补记账：161,616 → 161,944（+328） | M66 改写（端口/适配器/配置）+ M67 精排（同型）+ M68 注入面（能力维度/策略规则）净 +328，**三 commit 均未随 commit 记账（P2-3，本条补记）**；余量 56 行告急。交换条件：R7 上帝类拆分为机械搬迁（净行数中性），后续新增随 commit 记账；不以删功能换数字 |
| 2026-11-11 | `m4-source-lines` 预算 155K → 158K | M47 三条边界闭环：`calibration_units` sidecar（全量/增量，审计链只留小元数据）+ 风险特征/权重摘要（riskScore 可重算）+ 三类单元（globalDigest 可重算），净 +0.8K；交换条件是每回合链重算与单元数解耦、AAT 包自足可复核，不以删证据换数字 |
| 2026-11-10 | `m4-source-lines` 预算 154K → 155K | 启动峰值收尾：回执 `previousPath` + `AuditPacks.verifyFile` 流式接管、晋升台账流式 list/verify/rollback、共享 `JsonlLines`，净 +0.3K；交换条件是启动与稳态内存均与链长无关，不以删功能换数字 |
| 2026-11-10 | `m4-source-lines` 预算 153K → 154K | 全量复核与内存审计：缺失的 `codeSandboxWorker` Worker 入口（209 行，P0 `run_code` 恒失败）＋读前上限/有界缓冲/对称清理的常量与注释，净 +0.5K；交换条件是全链路内存预算与生命周期闭环，不以删功能换数字 |
| 2026-11-10 | `m4-source-lines` 预算 147.5K → 153K | AAT/CTA/单次授权/委托链/记忆治理/边界二轮（M44 跨 issuer/吊销/共享预算/approval+heartbeat 生产者）落地，约 +6K；与历次「+1K 合法新增预算」同一处置，不以删功能换数字 |
| 2026-11-09 | `m4-source-lines` 预算 146.5K → 147.5K | 上帝类闭环：`ConfigError` 字段守卫 / `LongHorizonStateStore` / `Rfc3161TokenParser` / `Rfc3161TrustResolver` / `ResponsesStreamAccumulator` / `McpStateless*` / `Temporal*` / `SessionRetrievalIndex` 等协作类拆分（方法/职责下降，文件与 JSDoc 净 +0.4K）；不以删功能换数字 |
| 2026-11-08 | `m4-source-lines` 预算 145.5K → 146.5K | 固定文案配置化（`TextCatalog` + `tool-exposure` / `report-texts` / `tool-result-texts` 三目录与十个消费点，净 +0.7K）与同工作树 RFC3161 nonce/时间窗/吊销判据（+0.6K）；两者都是「契约面扩张、实现层收口」，不以删功能换数字 |
| 2026-11-07 | `m4-source-lines` 预算 134K → 138K | M26 终盘收编（36 件 src +4.6K）与 M27 SDK/打码终批（+0.9K）——契约-实现分裂清偿与 SDK 族重审；交换条件是应用仓退役 40 件影子 + kernel-compat 整目录（净迁移在应用侧兑现）。与 M11/M18 三次调整同一处置，不以删功能换数字 |
| 2026-11-07 | M27 重审：`sdkClient`/`sdkSocket`/`webSocketSdkSocket` **迁入内核**，推翻 2026-11-03 的清零裁决 | 当年理由「外部 SDK 客户端不是内核能力，且零引用」的零引用前提已失效（真实消费者在案）；且内核 rpc 域 M26 起有服务端半边，客户端是天然配对——按「中枢 = 完整能力集」（§7.1）重裁 |
| 2026-11-07 | M29 裁决：auditCanonical **退役**（auditChain/auditReportBuilder/auditReportVerifier 改指内核 Jcs， golden 逐字节对齐钉死；Jcs 补 MAX_DEPTH=64 深度护栏）；auditSink / auditExporter **留应用** | JSON 合法值域内两实现恒同，非法值上历史实现宽松改写会让哈希盖住被改的值——fail-closed 才是审计信任面正解；auditSink 链原语已共享内核 HashChain、轮转/布局属部署形状；auditExporter 维持 2026-11-03「导出格式属 server 层」裁决 |
| 2026-11-07 | M30 裁决（应用侧产品统一，收尾 M26/M27 遗留的最后一个未决项）：双定时器收为一套——server 自动化收敛 RoutineScheduler 调度核心（Routine 契约 +id/enabled/scope/createdAt 可选字段，scope 隔离驱动方），AutomationStore/AutomationScheduler 退役，automations.json 一次性迁移 | 调度语义重叠、执行语义不同；统一后 server 自动化免费获得 cron 能力，web RPC DTO 逐字不变（web 零改动）；共享 routines.json 由 scope 隔离 + 同分钟防重护栏兜底 |
| 2026-11-07 | M26 终盘裁决：收编 rpc/transport 影子四件 + approval/escalation/event/kv 适配器 + vault/trace 族 + util/config 补全七件 + skill 签名 + asset 编解码安装器；**不迁**清单见 M26 节 | 端口已在内核契约（KvPort/AssetPackPort/ApprovalRule/EventPort/EscalationPort）而实现留应用 = 契约-实现分裂；两轮独立盘点交叉确认；迁移沿用 M22「逻辑保真 + 形态适配」纪律 |
| 2026-11-07 | 迁移桥收窄（M2 工作项 4）**单独立项**，先做域生成器解析源设计 | 应用侧 311 处导入已全部收敛于 17 个生成域文件，删除条件接近满足；但域生成器靠 `dist` 深路径解析符号——删 `"./*"` 通配前必须先给生成器换解析源（顶层 60 位已满是硬约束）。设计先行，不在 M20 顺带做 |
| 2026-11-03 | 本文件是**唯一规划源**；BOUNDARY 只记边界事实 | 规划与事实分离，避免两份文档各说各话 |
| 2026-11-03 | `plan:check` 采用**双向对账** | 单向门禁只能防提前记账，防不了做完不记账 |
| 2026-11-03 | M1 只到「发布就绪」，不含 `npm publish` | 无发布凭据；把「就绪」和「已发布」分开写才诚实 |
| 2026-11-03 | `adapters/laya` 迁出，改 `decisionEnginePort` 注入 | 第三方 venv 绑定不进通用内核；注入缝让应用保留实现，内核不静默丢弃配置 |
| 2026-11-03 | 契约覆盖由人工判据改为机检（`tests/contract` ≥30 例） | 人工判据容易写成愿望；用例数可数、可回归 |
| 2026-11-03 | **应用形状清零**：TUI / license / server-audit / enterprise / SDK / codegen / CLI 帮助整棵删除 | 「切出来」只保证能跑，不保证只剩内核；零引用 + 编译与全量测试是唯一裁判 |
| 2026-11-03 | 应用迁移**先行**：先删重复副本、用子路径桥接，测试分流随后 | 公开面只有 59 符号，一次性收敛到顶层不可行；先拿到「单一源码」再逐步收窄，桥有删除条件 |
| 2026-11-06 | `m4-source-lines` 预算 114K → 115K | M11 `./embed` 组合根新增约 0.9K 行；交换条件是宿主侧不再各写一层接线，顶层公开面仍 60/60。与 M5/M6 时「+2K 合法新增预算」同一处置，不冻结后续工作 |
| 2026-11-06 | `m4-source-lines` 预算 115K → 117K | M11 回执持久化（append-only 存档 + 密钥管理 + 续链校验）与同期执行证书接线新增约 2K 行；两者都是「审计闭环」的必要实现，不以删功能换数字 |
| 2026-11-07 | `m4-source-lines` 预算 117K → 118K | M18 选择性披露（契约 + envelope 签名抽取 + 构建复核器）新增约 0.6K 行；「最小披露仍可验」是审计闭环的必要能力，处置与 M11 两次调整一致 |
| 2026-11-02 | 先同仓独立包，不拆双仓 | 10 h/周下双仓必然漂移（切分方案 §4） |

---

## 11. 迭代节奏

- **每轮开始（30 min）**：`npm run plan:check` 对账 → 只挑一个里程碑 → 只做它的一条工作项。
- **每轮结束（10 min）**：判据证据 + 翻状态 + CHANGELOG（若对外可见）+ 同一 commit。
- **每月**：复核 §2 北极星；连续两轮无进展就砍范围，不延期。
- **每个 alpha**：应用侧升一次依赖并跑全量回归，回归结果记入 §6。

