## 0.1.0-alpha.39 — 2026-11-22（架构收敛收口）

> 按 2026-11-22 架构评审结论做的一轮**减法**：清死代码、去伪门禁、文本内联、会话状态收口、
> 包结构按应用消费面剪枝，并给每类漂移加机检棘轮。本版为收敛收口版：`exports` 18 条、
> 应用 248 条深路径导入全部迁到语义桶、Session 聚合根与 EffectExecutor 落地。

### Added

- **漂移预算门禁** `npm run drift:check`：13 项结构指标（体量 / 公开面 / 配置面 / 回合复杂度 /
  源码文本测试 / 文档体积 / 门禁数量 / 不可达行），`--update` 只降不升。
- **行为基准** `npm run bench:behavior`：23 个 long-task fixture 的内容摘要 + 参考解自检基线；
  `bench/behavior-baseline.json` 由 CI 比对（不测模型质量，真实 pass@1 由 `eval:longtasks` 在凭据环境跑）。
- **应用导入棘轮** `npm run consumer:check`：应用仓 248 条深路径导入基线，只降不升。\n- **非工具副作用门面** `EffectExecutor`：长时程验证 / workflow 隔离提交统一走\n  “沙箱裁决 → 审计 → 执行”，拒绝抛 `EffectDeniedError`。
- **副作用出口白名单** `boundary:check` 规则 7：新增 `spawn`/`execFile` 调用点必须登记理由。

### Changed

- **文本**：2,444 处 `KernelTexts.get` 全部内联为模板字面量；删除 `defaults/kernel-texts.json`
  （2,393 键 / 228 KB）与 `KernelTexts` 类；错误信息回到调用点。
- **会话**：跨回合状态从静态 `SessionSlotRegistry`（WeakMap）迁到 Agent 持有的
  `SessionStateStore`；新增 `SessionScopedState`。
- **回合**：`TurnRunnerOptions` 19 项 → 6 项（`policy` / `services` / `completion` 分组）；
  新增 `TurnPolicy` 值对象。
- **配置**：env 读取收敛为 `KernelEnv` + `ENV` 单入口；`ConfigSections` 为 140 字段提供 7 个\n  冻结只读分区视图；`LimitEnv` 归并进 `RuntimeFlags.intEnv`；检索上下文 `ContextEnv` 改为固定默认值对象；
  删除 `OMNI_TOOL_PLAN_ORDER` 对照开关与 `OMNI_MCP_ALLOW` 别名。
- **包结构**：应用 248 条深路径导入全部迁到 `contracts` / `adapters` / `runtime` / `protocols`\n  四个语义桶；`exports` 346 → 18（2 根 + 16 curated，深路径 0）。
- **文档**：28 份 → 8 份活文档（−468 KB），调研/计划稿移入 `history/`。

### Breaking

- 删除 12 个检索环境变量（`OMNI_RRF_K` / `OMNI_SEM_WEIGHT` / `OMNI_BM25_FLOOR` /
  `OMNI_MERGE_SYMBOLS` / `OMNI_CHUNK_RECALL` / `OMNI_FULL_FILE_DOC` / `OMNI_DOC_MODE` /
  `OMNI_GRAPH_SIGNAL` / `OMNI_GRAPH_WEIGHT` / `OMNI_PAYLOAD` / `OMNI_RERANK` / `OMNI_RM3`）：
  对照实验改用 `RepoMapContextOptions` / `RecallKnobs` 显式参数。
- `OMNI_MCP_ALLOW` 别名删除，只认 `OMNI_MCP_ALLOWLIST`；`OMNI_TOOL_PLAN_ORDER` 删除。
- `exports` 删除的 89 条深路径若被仓外消费者使用将 404。
- `KernelTexts` 不再存在（原仅经 `kernel/protocolsSupport.ts` 暴露）。

### Fixed

- `plan_present` 等待审批现在与取消信号竞速（Stop 生效、挂起项清理）。
- 长时程验证命令先过 `SandboxPort`；workflow 隔离提交前逐路径过沙箱。

## 0.1.0-alpha.38 — 2026-11-22（R27：worker 域收编轮——CliWorker/ExternalCliWorker/WindowsShim 上内核；本地 tag 发布，npm publish 待 @omniharness scope 权限）

> R27 内容 = 应用侧 worker 三件收编进内核 worker 域 + 三条 worker 深路径承诺面（详见下方 R27 条目与 §6 R27 行）。
> 发版号随 R27 轮提升至 alpha.38。
>
> **发布口径（2026-11-22）**：外部 npm scope 权限仍阻塞 `npm publish`（R3 的外部阻塞项），本版只打**本地 tag**
> `v0.1.0-alpha.38`；应用侧以 `file:vendor/omniharness-kernel-0.1.0-alpha.38.tgz` 本地 vendor，不走 registry。
> 发版提交即最终 verify 提交（`cross:check` 当时唯一预期红：应用侧 worker 三件影子仍在；OmniHarness-app
> 接收提交 `cbe5a85` 已删除影子并复绿——与 R26 同一时序，见 §6 R27 行）。
> 发布态实测：verify **16/17 门**绿（`cross:check` 预期红如上）；390 文件 / 1,776 用例；src 168,580 / 169,000。

### Changed

- **R27 worker 域收编轮（2026-11-22）**：OmniHarness-app `extensions/kernel/worker` 三件逐字节行为等价收编进内核
  **worker 域**——`CliWorker`（212 行：任意 harness CLI 的 spawn worker；超时 / 会话取消 / 输出超限三条终止路径
  都终止整棵进程树，Windows 上把 npm `.cmd` 垫片解析为 `node <entry.js>` 以杜绝 `&` 注入面）、
  `ExternalCliWorker`（120 行：`NAME=COMMAND LINE` 纯分词解析 + worker 构造，不展开变量 / 不做 glob / 不调 shell）、
  `WindowsShim`（170 行：`.cmd`/`.bat` 垫片解析与 `isBatch` fail-closed 判据）。三件互相依赖全部改指内核内部实现：
  `ProcessTreeKiller` ← `src/kernel/adapters/tool/shell/processTreeKiller.ts`，`Worker`/`WorkerRequest`/`WorkerResult`
  ← `src/contracts/ports/worker/worker.ts`。用户可见文案 **9 条**外置 `defaults/kernel-texts.json`。
  跨仓交换：应用侧退役三件 **483 行**（OmniHarness-app 接收轮兑现，跨仓净迁移在应用侧记账）。
  src 净 +572（168,580 / 169,000）。
- **三条 worker 深路径承诺**：`package.json#exports` 追加 `./kernel/worker/cliWorker.js`、
  `./kernel/worker/externalCliWorker.js`、`./kernel/worker/windowsShim.js`（与既有 worker 条目同序）。
  应用侧 `cliBuildConfig.ts` / `cliFlagTable.ts` / `cliArgs.ts` 的 import 在接收轮改指这三条内核深路径，
  随后即可删除应用侧三件。

### Added

- **判据 23 用例**：`tests/unit/cliWorker.test.ts`（10）覆盖正常输出 / stderr 合并 / 非零退出 / 超时终止进程树 /
  运行中与预取消 / 输出超上限 / spawn ENOENT / 非法超时值回落 / Windows 垫片成功解析 / 不可解析批处理 fail-closed /
  原生 `.exe` 直连；`tests/unit/externalCliWorker.test.ts`（5）覆盖 parse 合法与非法形态、引号与反斜杠分词、create；
  `tests/unit/windowsShim.test.ts`（8）覆盖 resolve / isBatch / where 定位 / 缓存 / 认不出的垫片。

## 0.1.0-alpha.37 — 2026-11-21（R26：应用侧收编轮——ServeInstance/MaintenanceRunner/GraphStore 上内核 + compactionStateCodec 承诺；已 npm publish）

> R26 内容 = ServeInstance / MaintenanceRunner / GraphStore 三件应用侧能力收编进内核 + compactionStateCodec 承诺面扩张（详见下方 R26 条目与 §6 R26 行）。发版号随 R26 轮提升至 alpha.37。
>
> **发布回执（2026-11-21 22:57 +08）**：`npm publish --tag alpha` 成功——`npm view @omniharness/kernel dist-tags` 回读
> `latest = alpha = 0.1.0-alpha.37`；npm `gitHead = 85422e7`，tarball `kernel-0.1.0-alpha.37.tgz`
> （14,005,290 B）。tag `v0.1.0-alpha.37 = d8d9ce7` 与发布提交差异仅文档 + `vitest.config.ts`（`src` 零差异）。
> 发布态实测：verify **17 门**全绿（387 文件 / 1,742 用例声明 + 压力 9/24；plan 120 里程碑 / 193 判据）；
> 公开面 60/60；src 168,008 / 168,500。


> 本版并入 alpha.36 的三轮合并内容：**R22 文档清偿轮**（删 20 份无机检依赖历史稿，docs/ 46→28，零 fallout）+
> **R23 分类处理轮**（eval 七文件 2 迁 5 留 + M22 重裁 + 三份弱机检文档事实门）+
> **R24 语言统一评估轮**（.mjs 67 份版图评估 → checkJs 类型门落地为 verify 第 17 门）。
> 公共根导出面仍 **60/60**；全量 `verify` **17 门**全绿（384 文件 / 1,734 用例 + 压力 9/24，
> plan 120 里程碑 / 193 判据）；src 净 −91 行（167,220 / 167,500）。

### Changed

- **R26 应用侧收编轮（2026-11-21）**：OmniHarness-app extensions 三件收编进内核——
  `ServeInstance`（229 行，serve 实例记录：pid 判活 EPERM=存活 / fail-closed 脏记录 / 只删自己的 /
  sweepAll 全量自愈）与 `MaintenanceRunner`（~390 行，四件维护 best-effort 统一编排）上 **maintenance 域**
  （桶 ./maintenance 增至五能力），`GraphStore`（150 行，图定义持久化：保存期拓扑预检 + 4MB 有界读）
  上 **autonomy 域**（新深路径 ./kernel/autonomy/graphStore.js，GraphSummary 契约落 contracts/ports/autonomy/）；
  exports 承诺 **./kernel/context/compactionStateCodec.js**（OmniHarness-app 登记 41 天的
  CompactionMarkerReader 登记件由此获得清偿解）；判据 21 用例补齐（原三件零专属判据）+ 文案 13 条外置
  kernel-texts；evalPropagation 类型导入修正（dcd660c 遗留 clean:tsc 缺口）；startup 补 env/home 注入缝。
  跨仓交换：应用侧退役三件 790 行 + 登记件 192 行（OmniHarness-app 接收提交 `b477365` 已入库；cross:check 复绿）。
  src 净 +788（168,008 / 168,500，发布态实测）。
- **文档清偿（R22）**：删除 20 份无机检依赖历史稿（PLAN-R4/R5/R6/R10/R13-R21、
  RESEARCH-F/I/J/M/N/S、M60-M64-DESIGN——逐份引用图取证，git 历史可溯：
  `git show 2ab1215^:docs/<file>`）；悬空引用全链 anchor 化（保留文档 8 处 + src 注释 4 处）；
  `auditSymbols` 活文档缺失改 fail-closed（删文档不再静默缩对账范围）。
- **eval 域分类（R23，M22 重裁）**：`budgetPolicy` / `binomialBound` 外迁
  `scripts/eval/lib/*.mjs`（零 import 独立执行件，91 行出 src）；其余 5 文件 value-import
  内核运行时件留 src（裁定依据细化为「与内核运行时共享单一真源者留 src，零依赖执行件
  归 scripts」，决策日志在案）。`dist` 不再包含这两份深路径产物（零消费方已验证）。

### Added

- **三份弱机检文档事实门（R23）**：`doc:check` 增 `DOC_FACT_AUDIT`——RELEASE 引用的
  npm 脚本在 package.json 验真 / MCP-TASKS `McpTaskPort` / STANDARDS 四个实现锚在 src
  验真——28 份文档全部达到「专属事实门或门禁链等价」强度。
- **scripts 类型门（R24，verify 第 17 门）**：`tsconfig.scripts.json`（checkJs 镜像项目
  模块选项）+ `typecheck:scripts` 并入 verify——43 份脚本 / 15,104 行纳入与 src 同一的
  tsc 类型视图（checkJs 全绿）；沙箱夹具 24 份保持 .mjs（模拟用户代码语义）。

### Fixed

- **bench/certificate 休眠脚本复活（R24 真实 bug）**：该脚本引用 dist 已不存在的 7 个
  导出（M14 时代 API 更名后失修，import 即崩）——改用现行类 API（`EventMerkle` /
  `ExecutionCertificates`）并实跑验证（篡改矩阵 5 项检出 + 回执绑定失配检出全过）。
- **文档漂移七处清偿**（R22 审计）：BOUNDARY A2A 段终态注记 / README 幽灵符号 ×3 改
  真名 / WIRING 旧入口名 ×3 + 深路径数 + 零入边行数 / ROADMAP 幽灵问题码
  `LEDGER_TORN_TAIL` + m17 判据路径 / API.md `Jcs` 大小写。
- **review 收口**：R22（P0×0 / P1×3 / P2×3 / P3×3——src 注释悬空引用 ×4 审查补网、
  RESIDUAL 孤儿表修复、auditSymbols fail-closed）+ R24（67 处 checkJs 存量错误修复，
  含 hostServer JSDoc `import()` 类型、spawnSync encoding 宽化、篡改矩阵元组注解）。



> 内容 = M120–M123（RESEARCH-T 双线审计实测驱动：性能面 P0 线性劣化 + 遗留/文档面机检
> 盲区）+ 独立 review 收口（P0×0 / P1×0 / P2×1 / P3×8，逐项见 ROADMAP §6）；公共根导出
> 面仍 **60/60**（无新增顶层导出）；全量 `verify` 16 门禁全绿（384 文件 / 1,734 用例 +
> 压力 9 文件 / 24 用例）；src 净 +119 行（167,311 / 预算 167,500，余量 189——不动 cap）。

### Added

- **每工具步扫描有界化（M120，P0）**：三处「全史扫描」随回合长度线性劣化收口——
  ① `collectToolResults` 逆序直扫本步 callId（删 `ToolCallPairs.of(allEvents())` 全量
  索引）② CTA 污点会话级增量折叠（`ContextTaintAccumulator`——折叠语义单源，
  `fromEvents` 收敛为全量路径；事件流收缩全量重折保守方向）③ `recentOutputsOf`
  逆序早停。探针实测 @8k 事件：CTA 全史重建 3042µs/批 → 增量 **30µs/批**（100×）、
  `recentOutputsOf` **4µs/次**；600 步会话省 ≈4s 且消除劣化斜率。
  属性级等价测试钉住（随机流 × 随机批次 ⇒ level/merkle/digest 逐位一致）。
- **检索复核哨兵收敛（M121）**：`tryStatReuse` stat 复核命中写空哨兵（watcher 为脏源）——
  安静仓库每 TTL 白付全树 walk 收口（实测 1675 文件 163ms/次 → <5ms）；安全网 =
  10×TTL 周期硬核验（`hardVerifyState` 对账，watcher 丢事件检出回落内容哈希重建）。
- **hybrid 冷启动降档（M122）**：`getHybridRepoMapContext` / LSP 路语料取用切 BM25 同型
  stale-while-revalidate——首查不等冷建（本仓 1675 文件实测 6.06s → 降档即时），后台建完
  自动恢复。
- **活文档符号对账机检（M123）**：`doc:check` 扩展——15 份活文档反引号标识符逐一要求
  src 提及（完整 token 词边界，458 候选零误报口径）+ 退役名黑名单（`createOmniKernel`，
  豁免 `.ts` 文件名历史引用）+ WIRING 零入边行数 ±5 容差——「文档说 X 代码是 Y」从抽查
  变门禁。

### Fixed

- **文档漂移七处清偿**（R21 审计）：BOUNDARY A2A 段补「已整体删除」终态注记 /
  README 幽灵符号 ×3 改真名 / WIRING 旧入口名 ×3 + 深路径 324→341 + §2 头部口径 +
  零入边行数 ×3 / ROADMAP 幽灵问题码 `LEDGER_TORN_TAIL` 终态注记 + m17 判据路径 /
  API.md `Jcs` 大小写。
- **review 收口**（独立审查代理逐 commit 全文审 + 行为等价推演）：P0×0 / P1×0 /
  **P2×1 / P3×8**。P2：`changedPaths` 复用成功清 `hardVerifyState` 基线（watcher 合法
  变更后旧基线必失配 ⇒ 每 10×TTL 白付一次全量内容哈希的自伤型误报）。P3：LRU 驱逐
  清硬核验状态 / 累积器 payload 防御统一 / 门禁文案与注释如实 ×3。审查登记不修：
  ProvenanceTracker 第四处全史（缺省关，前向候选）/ RETIRED `.tsx` 理论绕过面 /
  ACTIVE_DOCS 手工清单缩 scope 风险。



> 内容 = M115–M119（RESEARCH-S 双线审计 22 条发现全取证：P0×1 / P1×5 / P2×7 / P3×9——
> 集成面 DX + 可配置面两条独立审查线；升级路线押「接入摩擦 = 外部采用的瓶颈」）+
> 独立 review 收口（P0×1 / P1×2 / P2×3 / P3×4，逐项见 ROADMAP §6）；公共根导出面仍
> **60/60**（无新增顶层导出；`OmniKernelCloseOptions` 走 embed 类型面）；全量 `verify`
> 16 门禁全绿（381 文件 / 1,726 用例 + 压力 9 文件 / 24 用例）；src 净 +412 行
> （167,192 / 预算 167,500——cap +500 随注册 commit 记账，决策日志在案）。

### Added

- **厂商一键接线（M115）**：`OmniKernel.create({ model: 'deepseek' })`——`model` 接受
  字符串快捷 `'厂商id'` / `'厂商id:模型名'`（按第一个冒号切分，兼容 ollama `qwen3:8b`
  形态）。解析链全部复用单一真源：`defaults/providers.json` 预设（`providerPresets`
  单例）→ env `<厂商id大写>_API_KEY`（缺钥 fail-closed 点名环境变量）→
  `modelAdapterRegistry` 一张表构造；`providerPresets` 覆盖与 `omniharness.json` 同语义
  （同 id 整条替换）。示例 `examples/model-shortcut.mjs`。
- **close 生命周期收口（M116）**：`closeOnce` 重排为 cancel → **drain（有界等待回合收尾）**
  → 关 MCP → 落回执 → 冲刷事件 → 关工作台——修复「cancel 后立即关出口，
  `await close(); process.exit()` 截断尾部持久化」。`close(options?: OmniKernelCloseOptions)`
  增 `drainTimeoutMs`（缺省 10s；超时落 warn 继续收口，挂死回合兜底仍是工具看门狗）；
  close 后 `runTask/resume/fork` 明确报错「内核已关闭」。
- **配置孤儿清偿（M117）**：interjection 全链死段闭合（M28 复盘④预留的核心循环接线）——
  `Agent.classifyInterjection` / `kernel.classifyInterjection`（词表来自
  `omniharness.json` interjection 段，宿主拿判定自决并入/新任务）；mcpServers 文件面
  补 `env`/`cwd`（连接器早已消费）+ 条目内未知键 fail-closed；workspaceTrust 幽灵键
  `contextWindow` 删除。
- **配置错误自愈（M118）**：未知键报错附编辑距离 ≤2 的最接近合法键建议（did-you-mean）；
  合法键出口改指机读 `ConfigError.knownConfigKeys()`（旧文案指向内核仓不存在的
  `omniharness.json.example`）；`ROUTER_STRATEGIES` 运行时清单入 contracts（与类型联合
  双向机械核对，configBuilder 内联第二份 Set 删除）；modelRouter 覆盖显式 model 时
  log.warn 指明实际生效者；`FileConfig` 补 `turnCostEnvelopeUsd`。

### Fixed

- **文档账实清偿（M119）**：API.md §1.1 坏 import 修复（`createOmniKernel` 照抄即编译
  失败的 P0）+ §1.4 capabilities/句柄形状补齐（semanticRecall/mediaStack/pluginStack/
  capabilityStack/calibratedAutonomy/diagnostics()/classifyInterjection/close 选项）+
  §1.5.1 配置文件诚实边界明示；旧入口名 `createOmniKernel` 全链退役（kernel-texts ×9 +
  三份活文档 ×12 + `createOmniKernel.ts` barrel 收编进 `omniKernel.ts`，m119 门禁扩面锁死）。
- **review 收口**（独立审查代理逐 commit 全文审 + 真实模块黑盒实测）：**P0×1 / P1×2 /
  P2×3 / P3×4**。P0：did-you-mean DP **删除分支丢 +1**（TS strictness 改写同型失误，
  `editDistanceOf('ab','a')` 实测 0、超距键照样建议）→ 两分支 +1 恢复 + 「真距 3 不建议」
  钉板。P1：旧入口名退役漏三份活文档（门禁扩面）；close 测试序钉板有固有竞态 → 改钉
  drain 语义不变量（close 解析时刻在飞表必空）。P2：drain 补 **reserve→open 加载窗口**
  双表轮询（hydrate 期回合此前会在 flush 后才落尾）/ mcpServers url 形态带 env/cwd
  fail-closed / m118 门禁串去噪。P3：modelRouter 覆盖告警移到装配器（区分显式/缺省
  model）/ close 幂等语义 JSDoc / drainTimeoutMs 负值钳 0 / m115 门禁措辞对齐。


> 内容 = M112–M114（RESEARCH-R 九项盘点总账裁决：两项 R19 候选闭合 + CRLF 债归一 +
> RESIDUAL 总收口；三项再列后维持触发登记 + 三项外部阻塞复测维持）+ 深度 review 收口
> （P0×0 / P1×1 / P2×3 / P3×9，逐项见 ROADMAP §6）；公共根导出面仍 **60/60**（无新增
> 导出）；全量 `verify` 16 门禁全绿（377 文件 / 1,705 用例 + 压力 9 文件 / 24 用例）；
> src 净 +38 行（166,780 / 预算 167,000，随 commit 记账）。

### Added

- **会话上下文贯穿（M112）**：`ToolContext` 增可选 `capflowSessionContext` 实时闭包
  （执行器注入——recorder 同源零滞后 + 继承指令信道 capflowInheritedTask）：
  RunWorkflowTool resume 预检优先消费——review-r18 P1-1（窗口滞后）+ P2-1（派生会话
  继承源）双收口；storage 快照降级为直连 API 回退（滞后边界移入 H9 登记）。
- **遗留台账总收口（M113）**：RESIDUAL.md 从「R8 收尾」时代全面刷新——外部阻塞复测
  （npm 401 / 三 key UNSET 实测）/ 宿主职责增 H9 / 明确不做增 N14–N16（OTEL Development /
  INFUSE / 解释器级 provenance，触发条件可判）/ §4 六条清偿记录（R15–R19 候选逐条）/
  §5 各轮「登记不修」逐项复核表（R13–R18，六行裁决有据）。
- **EOL 卫生收口（M114）**：`.gitattributes` 钉未来（ts/mjs/json/mts/cts/yml = LF）+
  149 代码文件 CRLF→LF 归一（review-r19 P2-1 更正：corpusIndexFactory 的「非行尾 CR」
  经 blob 取证为双 CR 行尾伪影一并归一）——src/scripts/tests **零 CRLF 残留**（m114 门
  全目录扫描生效）；docs 锚敏感历史区不动。

### Fixed

- review 收口（独立审查代理逐 commit 全文审 + blob 级字节取证）：**P0×0 / P1×1 / P2×3 /
  P3×9**。P1：M112「滞后归零」声明超出实际覆盖——真实边界是 pairing **暂存**（同步骤
  早批输出步末才 flush 进 recorder；派生型工具恒屏障串行，「竞速」登记失真）→ **批级
  产出缓冲真闭合**（同批强断言直接证明）+ 判据描述修正。P2：corpusIndexFactory 排除
  依据错误声明更正并归一 / resumeCfiCheckOf fail-soft 吞 requireSpecHash（read/hashSpec
  移出 fail-soft 区，绑定绝不静默失效）/ 2KiB 截断常量单源。P3 修 5 + 登记 3（详见
  ROADMAP §6）。

## 0.1.0-alpha.34 — 2026-11-20（R20：好用收口轮——厂商一键接线 + close 生命周期 + 配置孤儿清偿 + 错误自愈 + 文档账实，未 npm publish）

## 0.1.0-alpha.32 — 2026-11-19（R18：resume 盲区收口轮——续跑档 CFI 闭合 + workflow 边实测，未 npm publish）

> 内容 = M110–M111（RESEARCH-Q 裁决：收口 R17 review-r17 P2-1 登记的 resume 续跑档
> CFI 盲区）+ 深度 review 收口（P0×0 / P1×2 / P2×2 / P3×4，逐项见 ROADMAP §6）；公共
> 根导出面仍 **60/60**（无新增导出）；全量 `verify` 16 门禁全绿（376 文件 / 1,702 用例
> + 压力 9 文件 / 24 用例）；src 净 +93 行（166,742 / 预算 167,000，随 commit 记账）。

### Added

- **resume 续跑档 CFI 闭合（M110）**：RunWorkflowTool resume 分支预检（resumeCfiCheckOf）
  ——WorkflowRunLog 预读（不持锁）存档 step prompts 逐条 × 当前会话最近工具输出重查，
  enforce 命中先于任何子会话拒绝（CAPFLOW_CFI_DENIED resume 档专用文案）、shadow 留证
  放行（shadowRules 可断言）、off / 无 assessor 零行为；**预检 specHash 传 runner 锁内
  复验**（review-r18 P1-2：被查 prompts 与实际执行 spec 逐字节绑定）+ scheduleGuarded
  改调度锁内快照 spec（顺带修复 runner 自身 S1/S2 混态执行窗口——2026-11-12 P1 修复
  的 completions）。
- **workflow 边四档实测（M111）**：`eval:propagation` 十三档——workflow 边 verbatim/
  CFI success=false（spec prompt 入 CFI 执法实测生效）+ paraphrase/CFI 诚实负结果 +
  step-up 墙兜底；**三进程内派生边（subagent/goal/workflow）全部具备实测曲线收官**
  （run_plan 无逐调用文本设计内不入曲线）。

### Fixed

- review 收口（独立审查代理逐 commit 全文审 + 三读绑定推演）：**P0×0 / P1×2 / P2×2 /
  P3×4**。P1：①预检快照 ≠ 实际执行 spec → 锁内快照调度 + requireSpecHash 绑定（必修）；
  ②预检窗口为 storage write-behind 滞后快照 → 三处诚实登记（完整闭合 R19 候选）。
  P2：shadow 留证可断言化（修）+ 派生会话内 resume 链式洗白源不查（登记，R19 候选）。
  P3：WorkflowSpecError 分流上抛 / resume 档专用文案外置（反硬编码机检同行抓到）/
  eval JSDoc / 收官表述补 run_plan 排除依据。

## 0.1.0-alpha.31 — 2026-11-19（R17：派生边收口轮——全派生边执法扩面 + goal 边曲线，未 npm publish）

> 内容 = M108–M109（RESEARCH-P 裁决：收口 R16 review-r16 P1-1 登记的派生边覆盖缺口；
> FIDES / Agent-ZTA 印证「污点标签随委托链保持」方向）+ 深度 review 收口（P0×0 / P1×1 /
> P2×4 / P3×9，逐项见 ROADMAP §6）；公共根导出面仍 **60/60**（无新增导出）；全量
> `verify` 16 门禁全绿（375 文件 / 1,698 用例 + 压力 9 文件 / 24 用例）；src 净 +83 行
> （166,649 / 预算 167,000，随 commit 记账）。

### Added

- **全派生边执法扩面（M108）**：跨代理 provenance 保持覆盖全部进程内派生入口——
  `IN_PROCESS_DERIVED_TOOL_NAMES` 单一真源（subagent/run_workflow/run_goal/run_plan；
  delegate 外部 worker 出内核进程豁免）；CFI 扩面（指令信道文本按工具提取：task/goal/
  spec.steps[].prompt 逐条，**提取器强转镜像工具层**——review-r17 P1-1 收口）+ stamp
  扩面（四边统一打 `inherited-untrusted`）+ 继承源透传（runGoalTool 传 goal /
  workflowRunner 传 promptFor 合成文本——run_plan 经同路径自动覆盖）。
- **goal 边三档实测曲线（M109）**：`eval:propagation` 九档实测（subagent 臂 5 档基线
  维持 + goal 边 4 档）——verbatim/CFI **success=false（M108 扩面执法端到端实测生效）**/
  paraphrase/CFI 诚实负结果 / step-up 墙兜底 success=false——**attenuation 三形态成立**；
  探针装配 RunGoalTool 真装配 + listSessions 统一收集 + OMNI_TOOL_EXPOSURE 固定 off。

### Fixed

- review 收口（独立审查代理逐 commit 全文审 + 黑盒绕过实验）：**P0×0 / P1×1 / P2×4 /
  P3×9**。P1：derivedTextsOf 严格 typeof-string 与工具层强转不一致 ⇒ 非字符串实参整段
  绕过 CFI → 提取器强转镜像必修。P2 修 4（resume 续跑档 CFI 盲区三处登记 R18 候选 /
  goal 边继承源注入型判据补交付 / goalEdgeAttenuated 补 exposure 前置 / 契约注释四处
  同步）。P3 修 7 + 注记 2（详见 ROADMAP §6）。

## 0.1.0-alpha.30 — 2026-11-19（R16：跨代理 provenance 轮——委托边继承标记 + 链式洗白窗口 + paraphrase 三档曲线，未 npm publish）

> 内容 = M105–M107（RESEARCH-O 裁决：arXiv 2610.05640「Can CaMeLs Talk?」精读，boundary
> laundering 为逐代理防御的唯一成功攻击形态）+ 深度 review 收口（P0×0 / P1×1 / P2×3 /
> P3×8，逐项见 ROADMAP §6）；公共根导出面仍 **60/60**（无新增导出）；全量 `verify` 16
> 门禁全绿（374 文件 / 1,692 用例 + 压力 9 文件 / 24 用例）；src 净 +116 行（166,566 /
> 预算 167,000，随 commit 记账）。

### Added

- **委托边继承标记（M105）**：`inherited-untrusted` 第四能力维度——跨代理 provenance
  保持的内核确定性子集（信任标签随委托交接保持而非逐代理重置）：`CapFlowPort.observeInherited?`
  （与 CFI 各自独立可选）+ 台账/策略/执行器三层接线（信任判定封装在策略内：off / 无不可信
  能力零操作；subagent 派生在 CapFlow 层放行即打标，共享台账 ⇒ 整树感染）；声明式规则表
  第四来源——策略作者可写 `{source: 'inherited-untrusted', sinks: [...], action:
  'require-approval'}` 构造继承污点 step-up 墙；**默认策略不变**（零默认行为变更）。
- **子代 CFI 窗口扩展（M106）**：委托边显式携带父代 task（`ResolvedConfig.capflowInheritedTask`
  → Agent → 执行器 `inheritedSources`）——**仅当台账携带继承标记时并入洗白源**（信任方向
  钉死：顶层 user 是可信主 voices 永不入源，共享台账整树感染也不误伤根上合法转发）；链式
  懒转发（hop ≥ 2 处父代合成文本原样拷进孙代 task）被 verbatim 捕获。
- **paraphrase 三档实测曲线（M107）**：`eval:propagation` 五档实测（hops=2，零凭据）——
  载荷侧预分片（`（连）` 打断 16 字符连续 span）+ 对抗模型机械还原：verbatim CFI 对
  paraphrase **不衰减（诚实负结果，R15 诚实边界的实测证明）**；继承 step-up 墙
  （M105 规则 + 无应答审批端口）**结构性拦截**（success=false，不依赖检测命中）——
  attenuation 双形态成立；success 度量收紧为「outbound 带配对 `ok:true` 结果」
  （被确认门拒掉的出界记 exposure 不记 success）。

### Fixed

- review 收口（独立审查代理逐 commit 全文审 + 五档曲线独立复现）：**P0×0 / P1×1 / P2×3 /
  P3×8**。P1：run_workflow/run_goal/run_plan 派生边不经 CFI/不携带继承源 → 三处登记为
  已知局限 + R17 前向候选（机制范围维持 M103 subagent-only 口径）。P2 修 3（observeInherited
  独立可选判定 / m68 门放宽串注释 / 分片不变量 fail-fast 守卫）。P3 修 6 + 登记 2
  （inheritedSources 截 2KiB / 保守语义注释 / callId 前提 / 可用性收窄登记 / gate stub
  契约对齐 / hops 语义注释；登记不修：tmp 清理 / CRLF 混合既有债）。

## 0.1.0-alpha.29 — 2026-11-19（R15：遗留清偿轮——参考轨迹匹配 + Multi-CaMeL 双通道 + 金丝雀感染曲线，未 npm publish）

> 内容 = M102–M104（PLAN-R15 裁决：「遗留问题全部处理掉」）+ 深度 review 收口（P0×0 /
> P1×2 / P2×9 / P3×11，逐项见 ROADMAP §6）+ MCP 2026-07-28 伪候选清账（RESEARCH-N §3）；
> 公共根导出面仍 **60/60**（./eval 子路径新增 TraceMatch + 4 类型）；全量 `verify` 16
> 门禁全绿（372 文件 / 1,669 用例 + 压力 9 文件 / 24 用例）；src 净 +459 行（166,450 /
> 预算 167,000，随 commit 记账）。

### Added

- **参考轨迹匹配四档组合子（M102）**：`TraceMatch`——strict / unordered / subset /
  superset 四档（**带键多重集合**统一实现：`name#argsDigest` 键，参数维度在全部档位
  生效，对齐 agentevals `TrajectoryMatchEvaluator`；review-r15 P1-2 重写收口）+ 参数
  exact/ignore 独立比对档 + 按工具名 override；`eval:trace --expected <file>` 接线
  （match-mode/args-match 枚举校验 fail-closed）；`./eval` 子路径导出 TraceMatch + 类型。
- **Multi-CaMeL 双通道子代理契约（M103）**：variables **数据信道**（父传 → 子代
  `get_variable` 按键读取，读取即工具调用落事件流可审计；缺键如实报错不臆造）+
  **指令信道完整性**（capflow enforce 下 subagent 的 task 含会话内成功工具输出的 ≥16
  字符 verbatim 片段 ⇒ `CAPFLOW_CFI_DENIED` staged 拒绝——`ToolOutputLeak` task 侧
  逐位滑窗 + 输出侧 16-gram 预热线性化；窗口=全会话最近 10 条成功输出、各截 2KiB）；
  嵌套委托经 `VariableChannelCompose` 组合去重（listDirect 透传 + 基座 get_variable 去重）。
- **金丝雀感染曲线（M104）**：`npm run eval:propagation`——Bhuiyan「Attenuation, Not
  Amplification」协议内核级实现：父会话工具输出注入唯一金丝雀 → 脚本化对抗模型逐跳派生
  → outbound 度量**双指标**（exposure 暴露率 / success 危害达成率，Exposure Before
  Success 拆分口径）；CFI on/off 对照实测 **off success=true 穿透 / on success=false
  拦截，attenuation 成立**；attenuated 自证含 exposure 前置（注入失败不冒充拦截）；
  度量函数导出单源（判据测试 import 真实现，零凭据零模型调用）。

### Fixed

- review 收口（独立审查代理逐 commit 全文审）：**P0×0 / P1×2 / P2×9 / P3×11**。
  P1：①R15 feat commit 带 doc:check 红 → README/BOUNDARY 计数刷新；②TraceMatch
  unordered/subset 静默丢弃参数维度 → 带键多重集合统一重写。P2 修 8（compose 透传
  listDirect / get_variable Object.hasOwn / 嵌套去重 / leakOf 线性化 / ./eval 导出 /
  attenuated exposure 前置 / 度量单源化 / 窗口口径钉死）。P3 修 6 + 登记 2（match-mode
  枚举 fail-closed / m103 门双查 / UNTRUSTED_CAPS 单源；登记不修：探针 outbound 计数
  差异 attenuated 只消费布尔 / executor 放行路径纯函数已覆盖四档）。
- 测试基建：longTask 夹具 verify 预算 5s→30s、pluginDomain VM 编译测试 retry 2——全量
  并行负载下墙钟假红余量放宽（断言本体与超时判定分支不变，非语义放宽）。

## 0.1.0-alpha.28 — 2026-11-18（R14：CapFlow 确认门 + 污点跨委托传播 + 确定性轨迹评测，未 npm publish）

> 内容 = M99–M101（RESEARCH-M 裁决：外部前沿对照 24 检索/抓取）+ 深度 review 收口
> （P0×0 / P1×3 / P2×9 / P3×11 全处置）；公共根导出面仍 **60/60**（eval 子路径新增
> TraceFold/TrajectoryRules）；全量 `verify` 16 门禁全绿（369 文件 / 1,668 用例 + 压力
> 9 文件 / 24 用例）；src 净 +416 行（165,991 / 预算 167,000，随 commit 记账）。

### Added

- **CapFlow 确认门（M99）**：`require-approval` 动作从「枚举预留按 deny」落地为
  **真确认门**——三态裁决（deny 直拒 / require-approval 走 `ApprovalPort` 取人工/策略
  确认 / 放行），确认请求用与门禁同口径的**真实 target**（共享 `ToolTargets` 单一真源）
  + `source: 'capflow-confirm'` 标注（CachedApproval 组合下旁路缓存，per-call 确认不退化
  为 per-rule 一劳永逸放行）+ callId/请求摘要绑定入审计（GhostJacking TOCTOU 防御复用）；
  无审批人/端口异常一律 fail-closed 拒绝（CAPFLOW_APPROVAL_DENIED）。
- **污点跨委托传播（M100）**：CapFlow 执法面闭合进子代理树——装配点（configFactory）
  **单点构造**共享 assessor（含树级能力台账），同一实例经 seed → 工厂 → 子代 Agent：
  父能力集对子可见（injected-untrusted 跨边界传播，Multi-CaMeL boundary laundering 的
  执法面防御）、子 observe 感染整树（双向）；off/未配置全链 undefined 零行为变更。
- **确定性轨迹评测器（M101）**：`npm run eval:trace`——事件流 fold（`TraceFold`：
  有序调用投影 + 参数 JCS 摘要）+ 规则四件套（步数上界/工具白名单/**调用指纹循环
  检测**/错误率上界），`{key,score,comment}` schema（agentevals 同构）；零凭据零模型
  调用（规则型 100% 确定性层，LLM-judge 抽样留给宿主）；demo 探针指纹循环命中退出码 1，
  空轨迹评测无效退出码 2（fail-open 收口）。

### Changed

- **决策观测面（review-r14 P1-3）**：`CapFlowDecision` 增 `action` 字段（两档都带）——
  shadow 档可回答「若切 enforce 的确认/拦截量」，容量/疲劳度信号不丢失。
- **审批契约**：`ApprovalRequest` 增 `source` 标注（capflow-confirm 缓存旁路 + UI 区分
  两类弹框）；`ToolTargets` 共享类（第二份手写即收敛，目标口径单一真源）。
- 测试基建：三处长测试（webSseHost/longTaskAgentRunner/pluginDomain）并行负载余量放宽
  （墙钟预算问题，非语义放宽；死循环用例 200ms 不变）。

### Fixed

- review 收口（独立审查代理逐 commit 全文审）：**P0×0 / P1×3 / P2×9 / P3×11**。
  P1：①确认门 target 语义错位（策略句令 RuleApproval 失配 → 用户 allow 清单被静默
  否决）；②审批缓存把 per-call 确认退化为 per-rule 放行；③shadow 确认信号丢失 +
  三方口径矛盾（action 字段解决）。登记不修：确认门在委托门禁之前（M59 结构层先行的
  既定 doctrine）、双审批叠加（文档化为防御纵深语义）。

## 0.1.0-alpha.27 — 2026-11-18（R13：预算观测面 + tail 整形收口 + 指纹 JCS 化 + 区分性检索集 + RNG 收敛，未 npm publish）

> 内容 = M94–M98（RESEARCH-L 裁决：外部前沿对照 18 检索 + 5 一手抓取）+ 深度 review
> 收口（P0×0 / P1×2 / P2×7 / P3×8 全处置）；公共根导出面仍 **60/60**；全量 `verify`
> 16 门禁全绿（366 文件 / 1,654 用例 + 压力 9 文件 / 24 用例）；src 净 +536 行
> （165,575 / 预算 166,000，随 commit 记账）。

### Added

- **统一工具结果预算读数（M94）**：`ToolResultBudgetReadout` 契约（单槽最新 + Σ 累计，
  照 `ContextCacheReadout` 形状）+ 回合级 `ToolResultBudgetMeter` + 哨兵 context 分区
  `budget` 字段——spill（字节，落盘时）与 trim/snip（字符，构建时）三处分散决策首次
  有了统一账目；**不叠加口径**（同一内容不重复处理）由组装期语义复核背书
  （`SPILL_PREVIEW_BYTES_CEILING` = trim 阈值 24,000，超限 ConfigError fail-closed）。
- **tail 侧整形收口（M95）**：`compose.over_budget` 从「只记不治」到**预算内确定性整形**
  ——丢弃循环救不回时（tail 消息本身超预算，RESEARCH-K §6.2 根因），对超单条上限
  （min(预算×0.6, 预算−prefix 占用)）的消息做头尾整形（共享 `HeadTailTrimmer`，第二份
  手写即收敛）；整形后仍超才如实留痕（带 `shaped` 字段）。退化守卫：上限 < 80 字符
  跳过整形（不把内容清成纯占位符）。确定性：同输入逐字节一致、跨步形状稳定。
- **区分性检索对照池（M97 / A3）**：`--pool discriminating` 三级难度（easy 饱和确认 /
  medium 同模板噪声 / hard 交叉引用污染 + 别名释义）；**hard 档 baseline recall 0.8 <
  1.000**（缺省池四组恒 1.000 的饱和假象打破），mock 精排价值首次可测（MRR 0.3→0.8）；
  池纯度自检判据（答案不重复 / 非档案不提目标 id / 邻居不泄漏目标别名）+ 显式超限
  fail-closed。真实模型档仍 fail-closed 等凭据（R1）。

### Changed

- **MCP 工具指纹 JCS 化（M96）**：rug-pull 闸（`McpToolIntegrity`，2026-10-24）的指纹
  序列化从 `JSON.stringify`（键序敏感）改为 `Canonical.stableStringify`（key 字典序 +
  剔除 undefined，数组保序）——服务端重排同一 schema 键序不再误触 fail-closed 闸
  （假阳曾把正常工具掐到进程重启）；只有**语义内容**变化才算漂移。实施前机制修正：
  网关完整性闸已覆盖全部客户端实现，原设计的适配器级 pin 无直接消费者——裁撤。
- **属性套件双 RNG 收敛（M98）**：`tests/property/support/seededRandom.ts` 删除（H9
  清偿），唯一用户迁移 harness `rng()`（int 双端含）；500 例深度基线重录 3/3、
  属性套件 53/53；M87 判据同步全链。
- 文档计数随新增判据刷新（366 文件 / 1,654 用例；contracts 12.7K / kernel 139.9K）。

### Fixed

- review 收口（独立审查代理，逐 commit + 全文上下文）：**P0×0 / P1×2 / P2×7 / P3×8**。
  P1：①M94「不叠加·恒成立」缺校验背书 → 组装期语义复核 + 判据；②M97 池别名泄漏
  （idf 标定失真）→ 显式避让 + 自检。P2：池 id 撞车/自引用避让、整形退化守卫、
  构建次数口径写明、at 双端含意图声明、`--cases` 显式超限 fail-closed。P3：haystack
  数字勘误、嵌套键序测试、meter 幂等快照（结构防双消费者）、m97 门补行为断言、
  契约覆盖面清单、RESIDUAL R1/N10 随 M97 回改。登记不修：M96 `check()` 布尔旗标
  （2026-10-24 旧账）、M95 ceiling 跨步稳定边界（已如实注释）。

## 0.1.0-alpha.26 — 2026-11-17（R12 第二批：工具暴露稳定杠杆 monotonic + A/B 实测闭环，未 npm publish）

> 内容 = M93（RESEARCH-K §7.3 候选 1 落地）；公共根导出面仍 **60/60**；全量 `verify`
> 16 门禁全绿；src 净 +211 行（163,767 / 预算 165,000）。

### Added

- **工具暴露稳定杠杆（M93）**：`OMNI_TOOL_EXPOSURE=monotonic`（显式第三模式，缺省仍
  `plan`）——规划语义 + 稳定可见序**只增不减**（追加序；陈旧名剔除；schema 预算压力
  才整组重置对齐当前回合）。跨回合状态经 `SessionSlotRegistry`（M92 计量器注册表
  泛化为三级键：runtime 作用域 × sessionId × 槽位名）驻留。
- **探针 A/B 场景（窗口退出形状）**：唯一变量 = 暴露模式。实测 **monotonic tools 前缀
  复用率均值 1.0 vs plan 0.8197**；窗口退出时 plan 收缩集合（**0.001 灾难性重写**），
  monotonic 只增不收缩；每次新增的断裂为 **0.9999**（追加序，近似无损）。
- **两处实施前机制修正**（A/B 反直觉归因，探针第二轮）：① ≤3 条 user 窗口的并集效应
  已覆盖窗口混合期——乒乓形状下 plan 本就稳定，杠杆真实收益在窗口退出；② 追加序
  优于升序（升序中段插入断裂深 0.5874 vs 尾追加 0.9999）。

### Changed

- `SessionPrefixMeterRegistry` 泛化为 `SessionSlotRegistry`（三级键 + 槽位名常量），
  前缀计量器与稳定工具集同壳驻留；`RunManifest.exposureMode` 契约放宽第三值。
- 诚实边界：tools 复用率只测 tools 段——新增块之后的 provider 侧仍有一次 suffix 重算；
  杠杆消除删除性断裂与灾难性重写。缺省不翻（真实模型对照为前置判据，凭据阻塞）。

## 0.1.0-alpha.25 — 2026-11-17（R12 第一批：缓存命中率三层修复 + 内存上界收口 + 测量架构修正，未 npm publish）

> 内容 = M88–M92（全面 review 三路审查：缓存链路 / 内存边界 / 文档准确度的全部 P1 落地）；
> 公共根导出面仍 **60/60**；全量 `verify`：361 文件（unit+contract 1,573 用例）。
> src 净 +370 行（163,556 / 预算 165,000，随 commit 分笔记账）。

### Added

- **finalize 兜底保留工具前缀（M88-1）**：provider 序列化 prompt 中 tools 位于最前，
  旧实现兜底请求传 `tools: []` 会让整个会话（tools+system+全部历史）按全价重算。
  现在沿用主请求的同一数组（同字节 ⇒ 前缀逐字节连续）；模型仍试图调工具时按原口径
  无工具回退一次——兜底语义不变，两次用量如实入账。
- **tools 前缀复用测量（M88-2）**：`toolsPrefixReuseRatio` 进 `ModelContextSnapshot` /
  缓存读数 / debug 日志——tools 抖动（provider 前缀从第 0 字节断裂而消息复用率照样高）
  首次可归因。
- **缓存读数逐步入账（M88-3）**：旧口径只记每回合最后一步（20 步回合的前 19 个请求
  不入 Σ）且失败回合整体不入账。现在 `TurnRunner` 每步完成即捕获（`completedRequests`
  序号闸门防半途重复入账），`Agent` 收尾（含 catch 路径）批量冲账。探针实测旧口径
  低估 **1.99×**（2 步/回合，随步数线性放大）。
- **gapMs 分因面（M88-4）**：相邻请求完成间隔首次有了生产者——`ttl-expired` 归因
  此前恒不可达。
- **会话级前缀计量器（M92）**：探针实测暴露旧计量器为单回合寿命（每回合首请求恒无
  基准，跨回合复用率从未被测量）。`SessionPrefixMeterRegistry`（sessionId 键控，
  LRU 64）跨回合/resume 复用同一实例；`finish` 是每回合路径故 LRU 为唯一回收机制
  （探针第二轮证伪后裁决）。
- **前缀稳定性实测探针（M92）**：`node scripts/eval/prefixStabilityProbe.mjs --turns 4`
  （零凭据可复现）。基线：意图稳定 tools 复用率 **1** vs 类别切换 **0.8197**（最差步
  **0.001**——tools 串几乎从头重写）；台账低估 **1.99×**；**并集效应**新发现
 （`TaskQueryDeriver` ≤3 条 user 窗口把跨回合意图并集化——tools 稳定但逐回合裁剪
  被钝化）。前向候选入 RESEARCH-K §7。

### Fixed

- **内部缓存一致性三项（M89）**：嵌入内容缓存代际保留窗（跨 root 交替构建互不误扫
  ——原实现 A 的构建把 B 的全部文档向量扫掉，嵌入分钟级成本重付）；语义索引缓存
  命中续命（FIFO→LRU 口径对齐，热点 root 不再被逐出）；语料缓存硬清联动 `onEvict`
 （硬清后旧语义索引条目不再残留占位）。
- **内存上界三项（M90）**：磁盘嵌入镜像 256 MiB 字节预算（原实现随唯一文本数无界
  增长；超预算先落盘再淘旧半，最新向量仍命中）；watcher 变更路径 1024 峰值哨兵
 （一次 npm install 数万事件不再无界累积）；插件沙箱 race 落定即清定时器。
- **二轮 review 收口（P1×1 + P2×5，2026-11-17）**：
  计量器序列化剥离 images/files base64 负载（64 会话 × 多模态可达数百 MB 驻留——
  与 M90「缓存有上界」纪律对齐；文本面前缀复用口径注记）；计量器注册表改
  runtime 作用域两级键（WeakMap——同进程多 Runtime 实例读数隔离 + 自动回收）；
  finalize 兜底请求（含两段式回退）读数入账 Σ（跑满步数/空转止损/失控熔断回合
  不再偏样）+ 违规工具调用留痕；「请求完成但步后段抛错」的读数经闸门补捕获；
  嵌入缓存代际改 cycle 语义（失败构建不再左移保留窗/误删命中续用向量——abort
  只按本代写入键精确回收）；磁盘嵌入缓存重启加载即收预算窗（旧实现预算只在
  append 路径生效）；探针场景改独立 sessionId（数字校准 0.8422→0.8197）。
- **文档准确度九处（M91）**：RESEARCH-K §2.3 旧稿（落地值 4,000）、M86 判据例数、
  MEMORY-GOVERNANCE 与 RESIDUAL N10 冲突对齐、EFFECTS 工具名 `edit_file`→`edit`、
  北极星快照时点、alpha.23 口径作废指针、PLAN-L 回填标题、归档位置追溯、
  机检同步（arch:update / WIRING 增量 / m64 判据随 API 改名）。

## 0.1.0-alpha.24 — 2026-11-15（R11 深挖收口：预算策略 / 压缩长段落 / 回溯文件态 / 回滚原子性，未 npm publish）

> 内容 = alpha.23 + M84–M86 与 review 修正；公共根导出面仍 **60/60**；深路径导出名 **1,190**。
> 全量 `verify`：354 文件 / 1,595 用例。

### Added

- **预算策略（M84）**：`BudgetPolicy`（成功运行 p95 × 1.2、10K 取整、30K 下限）+
  `eval:longtasks --pilot`（只打印建议、样本排除预算截断）。k=2 实测：60K 4/4、62.7K
  tokens/solved、全越线；96K 4/4、81.3K、1/4 越线——按「效率优先 60K / 不越线优先 96K」选择。
- **压缩长段落（M85）**：正文扫描 4,000 字、全局按句长取 60 条、短首行不再占配额；
  新增 `long-multi` / `long-mid` 探针。实测 long / long-multi / long-mid 约束保留均
  **0–3 → 29/30**，mixed 58/120 不退化。
- **回溯文件态（M86）**：checkpoint 文件快照恢复判据（快照内逐字节恢复、快照外不恢复、
  无 snapshotter 不假装恢复）；D1 测试扩展为**同一次回滚里文件 + requestHash 双等价**。

### Fixed

- **回滚半恢复**：`CheckpointManager.rollback` 把文件恢复移到事件写回**之前**——restore 失败时
  事件流保持原样（判据：失败 snapshotter + 计数 storage，`saves === 0`）。
- 压缩探针口径：summary-only + 唯一 token（废弃 all-message/子串口径）；`--profile` 未知值
  fail-closed；目标段截断实验证伪后回滚（tail 受限是最近消息本身，不是摘要）。
- git 依赖测试 hermetic：`--version` skip、`GIT_CONFIG_NOSYSTEM` / `GIT_CONFIG_GLOBAL` 隔离、
  禁签名与 hooks。

## 0.1.0-alpha.23 — 2026-11-15（R9/R10 能力批次：端到端评测、压缩保真、请求哈希回溯、引用检查、拆分基准，未 npm publish）

> 内容 = alpha.22 + M77–M83 与 R10 review 修正；公共根导出面仍 **60/60**；深路径导出名
> **1,190**（新增 contracts 的 `FILE_WRITE_TOOL_NAMES`）。全量 `verify`：352 文件 / 1,585 用例。

### Added

- **长任务 agent 端到端跑分（M77）**：`LongTaskAgentRunner` + `npm run eval:longtasks`——
  物化隔离仓 → 注入 agent → 机械验收（`verifyCommand` + 产物）→ pass@1/pass@k + 失败拆解；
  回合 token 预算生效；纯代码任务允许空 `expectedFiles`（修复 11 个未声明 `out/selftest.json`
  的不可解任务）。
- **评测统计与预算画像（M78）**：任务级 `summary`、`--budget` 覆盖、`completedOverBudget`
  与真正失败分离；实测 30K 4/5 → 60K 5/5（4/5 仍越线）。
- **模型请求哈希与回滚等价（M82/D1）**：`ModelRequestHash`（messages+tools 规范串 sha256）+
  `model` 事件可选 `requestHash`（记录最后一次实际请求）；回滚重放逐字节等价判据含变异自证。
- **收尾结论引用检查（M83/A2）**：`CitationChecker` + `FILE_WRITE_TOOL_NAMES`（含
  `patch_candidates`）+ `turnDiff.changedCount` 第二触发（覆盖 shell 落盘）；文件写类成功而
  结论零引用 ⇒ `unverified`（不阻断）；兜底总结路径同样检查。
- **问题拆分质量基准（M81/B1）**：coverage/redundancy/order 纯函数 + 11 份夹具（含真实命名
  `aliases`）+ `npm run eval:decomposition` + `--plan` 外部输入。

### Changed

- **压缩保真（M79）**：摘要新增「用户指令摘录」（短行优先、去重、1,000 字预算、长段落按句切分），
  助手摘录 20×300 → 8×200；探针实测植入事实保留 **30→67/120（25%→56%）**，摘要仅 +36%。
  （口径注：该数字的 all-message 口径在 alpha.24 已作废，现行口径为 summary-only + 唯一 token，
  同一机制实测 6/120 → 58/120 且 mixed 58/120 不退化——见上方 alpha.24 段；本段数字按 tag 时点保留。）

### Fixed

- **工具参数修复安全（M80）**：尾逗号修复改为字符串感知（不再篡改字符串内容）；括号类型不匹配
  fail-closed；括号/截断补全保留。
- `WorkspaceTrust` 分类补齐 `capflow`（权威）/`toolCache`（安全）（alpha.22 已含，此版延续）。
- 引用检查的误判面收窄：`Node.js` / `example.com` / `R10.A2` 不再当引用；结果 id 只认
  `spill/job/call/checkpoint/ckpt/patch` 前缀或 ≥8 位十六进制。
- 写类工具名单收敛：`loopGuard` 复用 `FILE_WRITE_TOOL_NAMES`，`turnDiffHooks` 由其派生。

## 0.1.0-alpha.22 — 2026-11-15（alpha.21 信任闸修复，未 npm publish）

> 内容等同 alpha.21 + 一处信任闸分类修复；公共根导出面仍 60/60。alpha.21 的应用侧三项
> （toolCache/capflow 文件面、SubagentTree 注入、压缩证据持久化）全部包含。

### Fixed

- **WorkspaceTrust 分类补齐 alpha.21 新键**：`capflow` 归**权威键**（`mode=off` 会关闭执行前
  能力裁决，未信任工作区不得降档），`toolCache` 归**安全键**（只影响读路径命中/失效，不授予
  权限、不改变门禁）。此前两键未分类 ⇒ 项目级配置在未信任工作区被信任闸拒绝/降档。

## 0.1.0-alpha.21 — 2026-11-15（应用侧深度适配三项：配置文件面补齐 / 子代理父子树注入 / 压缩证据持久化，未 npm publish）

> 对应 alpha.20 后的适配提交。公共根导出面仍 **60/60**；新增能力走显式深路径
> （`kernel/subagent/subagentTree.js`、`contracts/ports/subagent/subagentTreePort.js`、
> `contracts/ports/config/{toolCache,capflow}Config.js`），未改顶层稳定面。

### Added

- **配置文件面补齐（M56/M59）**：`FileConfig` 新增 `toolCache`（enabled/maxEntries）与
  `capflow`（mode/policyPath）两段，`KNOWN_KEYS` 收编，校验走 `ConfigSectionGuard`
  （未知键 / 类型 / 枚举一律 fail-closed）。此前两段只有编程入口，配置文件与设置页写不进去。
- **子代理父子树注入（M77）**：新增 `SubagentTreePort` 与默认实现 `SubagentTree`；
  `OmniHarnessConfig.subagentTree` / `SubagentPortSeed.tree` 注入后，`SubagentOrchestrator`
  把「父 → 子 / 调用 → 子」写入宿主实例；`SubagentRequest` 增加可选 `callId`（由
  `SubagentTool` 传入）。宿主编队面无需等 `tool_result` 即可拿到运行中子会话 id。
- **压缩证据持久化（M78）**：`CompactionState` 增加可选 `audit` / `signals`；
  `CompactionStateCodec` 以 ` evidence=<base64url-json>` 附在 `OMNI_COMPACTION_V1` header，
  旧游标兼容，坏证据 fail-soft（保摘要）。`ContextCompactor` 在写回游标时挂上
  `stateAudit` 与 `triggerSignals`——shadow 语义不变，只留证不改压缩产物/时机。

### Tests

- `compactionEvidence`（4）：往返 / 旧格式 / 坏证据 / 形状不符；
- `subagentTree`（3）：父子与调用映射 / 单父上限 / 无 callId；
- `configEvidenceSections`（4）：两段合法/非法/缺省零行为。

## 0.1.0-alpha.20 — 2026-11-15（alpha.19 后的收尾基线：上帝类清零 + 文档账实 + 发布自检 + 评测可判分 + 回环端口修复，未 npm publish）

> 对应提交 f384ece..c1d50e9（14 个提交）。公共导出面仍 **60/60**，未新增/删除导出；
> 除回环端口选择修复外行为面无变化（上帝类拆分逐字搬迁），本版把 alpha.19 之后的收尾
> 固化为可发布基线；app 侧仍钉 alpha.19（功能等价），下次升级再 vendor 本版。

### Changed

- **上帝类收尾**：`StepToolExecutor` 拆出 `ToolCallAuditTrail` / `ToolCallPairing` /
  `ToolResultRecorder`，`AatExporter` 拆出 `AatHashing` / `AatVerifier`，`Agent.continueSession`
  拆出 `runSessionTurn`；`god:report` 超预算 0（类 ≤700 / 方法 ≤20 / 单方法 ≤150）。
- **发布自检**：新增 `npm run publish:check`（registry 验 token、`publishConfig` 与版本冲突；
  401 如实报 HTTP 状态）与 `docs/RELEASE.md` 发布手册。
- **路由对照可判分**：12 条任务改为确定性答案（R2 关闭），真实档质量列可用。
- **压力用例**：供给 p95 断言单轮超界重跑一次，区分机器瞬时负载与真实变慢。
- **回环端口**：新增 `SafePort`，工作台 / MCP HTTP / AG-UI / OAuth 回调在 `port: 0` 时
  避开 Fetch 规范坏端口（6000/5060/6665…）——修复「服务起来了但浏览器/Node fetch
  报 `bad port`」的偶发缺陷（含判据 `tests/unit/safePort.test.ts`）。

### Fixed

- **文档账实**：BOUNDARY 计数纳入 `doc:check`（测试数 + 三行层行数），11 处悬空链接清偿；
  alpha.19 工件口径修正（内核 `npm pack` 3.9 MB / 3,671 文件不含 native；native 由宿主
  `vendorKernel` 注入后 5.4 MB / 3,657 文件）。
- **测试稳定性**：workbench SSE 加固用例改原生 `http.request`，避开端口 0 的 Fetch 黑名单假红。

## 0.1.0-alpha.19 — 2026-11-14（M55–M76：观测/缓存/成本 + 检索供给与质量 + 上下文策略 + 安全纵深 + 评测与应用侧收尾，未 npm publish）

> 对应提交 8f6ffe7..225bcfc（50 个提交；M55–M76）。公共导出面仍 **60/60**（golden 不变），
> 本版是 app 侧 alpha.19 vendored 升级基线；新增契约均走显式深路径/curated 子路径，
> 顶层稳定面未变。
>
> 关键批次：M55 内核哨兵 / M56 确定性读缓存 / M57 回合成本信封 / M58 审计时间线 /
> M59 CapFlow / M60–M65 检索供给·语义召回·基准·上下文策略·缓存读数·命中率联动 /
> M66–M68 查询改写·精排·注入面 enforce / M69–M72 评测自动化·供给压力·干净检出 tsc·
> VectorStorePort / M73–M76 真实回填·SSE/Web 对接面·多模型路由对照·残余台账。

### Added

- **观测与成本**：`KernelSentinel` 七分区健康报告（M55）；确定性读缓存 `CachedToolPort`（M56）；
  回合成本信封（M57）；`timeline.html` 审计时间线（M58）。
- **安全纵深**：CapFlow 能力数据流防火墙（M59）与注入面 enforce（M68，`injected-untrusted`）。
- **检索与上下文**：推入式供给 `RetrievalContextPort`（M60）+ 语义召回配置（M61）+
  LongMemEval 注入模式（M62）+ 上下文工程策略面（M63）；prompt cache 读数台账（M64）与
  命中率门限告警联动（M65）；查询改写（M66）/ 模型精排（M67）。
- **广度与评测**：`VectorStorePort` 广度对齐面（M72）；`eval:inject` 四组对照（M69）与
  真实模型档（M73）；`route:compare` 七策略质量/成本对照（M75）；宿主侧 SSE/Web 示例（M74）。
- **工程**：干净检出 `tsc` 双配置进 verify（M71）；多会话供给压力（M70）；残余工作台账（M76）。

### Changed

- **R7 上帝类收口**：`Agent` / `ConfigFactory` / `CorpusIndexCache` 拆分协作者，装配体逐字搬迁、
  行为不变（`god:report` 三个 [类>700] 清零）。
- **2026-11-14 上帝类收尾**：`StepToolExecutor`（923 行）拆出 `ToolCallAuditTrail`（审计轨迹）/
  `ToolCallPairing`（暂存+配对）/ `ToolResultRecorder`（结果落地）；`AatExporter` 拆出
  `AatHashing` / `AatVerifier`（链哈希与结构复核单一真源）；`Agent.continueSession` 拆出
  `runSessionTurn`——`god:report` 超预算清零（类 ≤700 / 方法 ≤20 / 单方法 ≤150）。
- **R6/R7 审查闭环**：缓存台账累计口径、检索供给口径、配置段校验组合子、浅拷贝与审计注等修正。

### Fixed

- 干净检出不可编译（M66/M67 契约字段漏提交）、缓存命中率把「未上报 cached」按 0 混入、
  查询改写/精排降档联动口径等审查发现。

## 0.1.0-alpha.18 — 2026-11-13（M48–M53：账本可靠性 + 取消语义 + 协议边界 + 适配器收敛 + 安全二轮 + 核心正确性，未 npm publish）

> 对应提交 8d20955(m48) / 87ebdbd(m49) / 7f40efc(m50) / f170549(m51) / cbf1aa4(m52) / 598d153(m53)。
> 2026-11-13 二轮审查闭环（437d451）：撕裂窗口扩展（长行不再销毁整账）/ 晋升台账第二读者
> tombstone 口径 / SDK 超时重打机读标记 / M49 确定性判据 / 探测代次 / PathLock host 口径 /
> 单 & 重定向豁免；M54 深度测试装置（9b40916）一并入本版。公共导出面不变。
> 公共导出面不变；契约增量：锚新增 `nonce?`（M52 起新锚携带，复核时作为期望值回验，
> 请求/响应绑定闭环）+ 问题码新增 `ANCHOR_NONCE_MISMATCH`；DisclosurePackVerdict 新增 `signatureChecked`（诚实标记）。

### Added

- **M48 账本可靠性基建**：`DurableJsonlAppender`（崩溃半截行原子截断）+ `PathLock`
  （跨进程账本互斥）+ 全账本迁移到同一 durable 口径。

### Changed

- **M51 模型适配器收敛**：`ToolCallIdAllocator` 单一真源；帧解析/路由收口。
- **M52 安全边界二轮**：SSRF/注入收口；验证器诚实标记（「没查」不再报成「查过」）；
  路径遏制；TSA 锚携带 nonce 并在复核时回验（`ANCHOR_NONCE_MISMATCH`）。
- **M53 核心正确性收敛**：语料签名单一真源（`SIGNATURE_UNCHECKED` 诚实档）；
  合并后配置复验；基元入参校验；账本补偿。

### Fixed

- **M49 取消语义完整性**：回合 signal 接线 + 门禁透传；`CancellationClassifier` 单一真源；
  取消后不再启动工具、不再派发排队调用。
- **M50 协议边界加固**：形状守卫前置；决策白名单；生命周期统一。

## 0.1.0-alpha.17 — 2026-11-11（复核闭环补丁：27 条发现全闭环 + 判据缺口清零，未 npm publish）

> 详见 `docs/AUDIT-2026-11-11-R2.md`。本版不改变公共导出名
> （cross-repo 承诺面仍 1,185），只改行为正确性、端口签名与判据；应用侧需按
> `kernel:vendor` 重新 vendor（端口签名变化见下）。

### Changed（端口签名，应用侧需同步）

- `ToolGatePort.setApprovalObserver(sessionId, observer)`：按会话注册并返回反注册函数
  （共享门禁不再串会话审批审计）；
- `TurnDiffTrackerPort` 全部方法首参为 `sessionId`（runtime 级单实例按会话分区）；
- `RbacPolicyOptions.toolCatalog` 支持 `() => readonly string[]` 提供器；
- `ShellProcessRunner` 增加可选构造参数 `killTree`（缺省行为不变）；
- `CompactionStateAudit` 的分段标记改为 `CompactionReconstructor` 同一真源
  （删除已退役 8 段模板与对应 8 个文案键）。

### Fixed（全分区独立复核第二轮——剩余 14 条全部闭环）

> 台账见 `docs/AUDIT-2026-11-11-R2.md`。

- **P1 会话隔离三件套**：`ToolGatePort.setApprovalObserver` 改为按会话注册（共享门禁不再把 A 的
  审批证据写进 B 的审计链）；`TurnDiffTrackerPort` 全部方法带 `sessionId`（并发会话不再互相
  `reset` 基线/串 `turn_diff`）；`resume/fork` 占位期即持有取消令牌（加载存档时按 Stop 不再无效）。
- **P1 取消边界**：`StepCancellation.throwIfCancelled` 收敛为单一实现，回合起点/步边界/护栏每次
  尝试/门禁与 CTA 之后/scheduler 每次派发都会先验；取消后**不再启动工具、不再派发排队调用**，
  兜底摘要阶段的取消也上抛（不再被吞成「正常截断」）。
- **P2**：RBAC 工具目录支持提供器（MCP/插件晚注册工具立刻可用，不再永久 `tool-not-registered`）；
  profile 用户级查找跟随注入的 `userHomedir`；bundle 补丁别名键落规范键（不再静默丢弃）；
  空白数值 env 不再变 0 关掉 `maxSteps`（数值项只收十进制字面量，非法启动即报错）；
  SessionGc 跨目录不再提前 `break`（主目录超龄会话会真的删）+ 先删 sidecar（半删除不再留
  不可见残骸）；压缩结构审计改用重建器分段标记（影子信号不再每次误报）；子代理抛错仍保留
  真实 sessionId/轨迹并进父子树；`tool.errors` 不再把策略拒绝与非零退出计成工具失败。

### Fixed（全分区独立复核，P0 3/3 + 高价值 P1/P2 闭环）

- **P0 MCP HTTP 来源校验**：无令牌时 `guard.enabled && guard.verify(...)` 把 Host/Origin 两道防线一起
  短路（DNS rebinding / 任意网页可驱动本机 MCP）；改为恒调用 `verify`，令牌环节才看 `enabled`。
- **P0 工作区信任闸分类缺口**：`plugin` / `calibratedAutonomy` / `longTermMemoryGovernance` 未进
  `AUTHORITY_SUMMARIES` ⇒ 未信任仓库可开插件栈（加载工作区 JS）、开统计放权、关记忆准入；
  三键补齐 + `interjection` 显式归入只读语义键 + 别名键连原键一起删 + 恢复被引用却不存在的
  `tests/unit/workspaceTrust.test.ts`（已知键全覆盖判据）。
- **P0 回滚后审计链断裂**：`AuditRecorder` 在事件日志被 `checkpoint rollback` 截断后仍用旧链尾
  ⇒ 下一次 resume 必抛 `AUDIT_CHAIN_ERROR`（会话永久不可续）；记录器改为按事件总数探测漂移、
  合法截断后重放自愈（坏链照旧 fail-closed）。
- **P1 补丁应用器两处**：末尾终止换行被当成「空上下文行」⇒ 文件中间的 hunk 必然报上下文不匹配；
  新增行不继承目标文件行尾 ⇒ CRLF 文件被注入 LF 行、CRLF 补丁的 `+++` 头解析出带 `\r` 的路径。
- **P1 晋升台账 seq 不受保护**：`seq` 不在哈希正文且 verify 不比序号 ⇒ 改号后 `rollback(N)` 会还原
  更晚的快照；`checkEntry` 增加序号连续性校验（不改哈希域，旧台账不失效）。
- **P2**：Windows 大小写使 shell 改动失效逻辑恒不命中；崩溃半截行吞掉下一条记忆；shell 输出超限
  后每块都再树杀（taskkill 风暴）；共形证据增量保留态平方放大（离线复核 DoS）；畸形系谱证书抛
  TypeError；`signatureChecked` 把「没查」说成「查过」；warn 模式越预算后每次调用都回调；
  `style:check` 换 AST 口径并覆盖 tests/examples（修掉 3 处真实 `function` 声明）。

## 0.1.0-alpha.16 — 2026-11-08（巡检闭环：AG-UI 公开 / 协议判据 / 账实收敛，未 npm publish）

> 详见 `docs/AUDIT-2026-11-08-CLOSURE.md`。

### Added（2026-11-11：M45 校准自主性 / M46 GK 严格界 / M47 共形决策自证——能力升级，同版未发布）

- **M45 校准自主性（Conformal Risk Control 门禁层）**：`ConformalRiskCalibrator`（CRC 镜像公式，
  可交换性下分布无关保证 `E[不利 ∧ 自动放行] ≤ α`）、`ToolRiskScorer`（确定性共形分数，权重
  走 `defaults/kernel/riskScorer.json`）、`AutonomyCalibrator`（按效果类吸收校准单元 + 摘要
  记忆化）、`CalibratedApprovalPort`（**唯一统计放权点**：校准充分且分数低于阈值直接放行，
  其余逐字节透传内层——沙箱/计划/污点/委托/规则 deny 绝对面永不放松）。配置
  `calibratedAutonomy`（缺省 off，`defaults/kernel/calibratedAutonomy.json` 出厂 α 预算），
  `capabilities().securityPosture.calibratedAutonomy` 如实报告。判据
  `tests/property/conformalRisk.property.test.ts`（公式对拍 / α 单调 / MC 有效性 / fail-closed）
  + `tests/unit/calibratedAutonomy.test.ts`（5 例）；设计底稿 `docs/RESEARCH-2026-11E.md`。
- **M46 GK01 全量分位数草图**：`quantileSketch.ts` 从工程变体升级为严格实现——摆动余量插入
  维持 `max(g+Δ) ≤ 2εn` 不变式、摊销压缩、严格查询；**任意流任意查询秩误差 ≤ ⌊εn⌋**
  （此前实测最坏 0.18n 且不声称界）。merge 被属性判据证伪（g 是秩空间记账非样本数），
  按诚实纪律不进能力面、记录于 MATH §4。判据 `tests/property/gkQuantile.property.test.ts`
  （6 族流逐秩对拍 / 确定性 / 2 万样本空间量级）。
- **M47 AAT 共形决策自证**：M45 统计放行的证据从结构化日志升级为 AAT 包内可离线复算——
  `decision.conformal`（α / 阈值 / 风险分 / 效果类 / 单类与全类摘要 / 快照 id / 单元数 /
  风险特征 / 权重模型摘要）+ 校快照元数据 + `calibration_units` sidecar（首个全量、
  后续按类增量；单元不进审计链，每回合链重算与单元数解耦）。`ToolRiskScorer.featuresOf/
  scoreOf/modelDigest` 让 riskScore 用记录内特征重算；`ConformalAatVerifier` 还原 full/delta
  单元、重算单类/全类摘要、τ̂、riskScore（10 个机读问题码）；`exportAat` 结构 + 语义双复核
  （fail-closed）。判据 `tests/unit/conformalAat.test.ts`（7 例）+
  `tests/property/conformalAat.property.test.ts`（2 属性）+
  `tests/contract/conformalAatWiring.test.ts`（一次接入导出重算）；设计 `docs/M47-CONFORMAL-AAT.md`。
- **M45/M46 配套审计修复**：授权台账过期重签不再破坏重放（seenIds 单口径）；ProvenanceIssuer
  签名域改走 Jcs（JCS 化通道往返后验签不再必挂）；AuditPacks 逐条核对 issuer 标签
  （`ISSUER_MISMATCH`）；任务断言缺省 ±5 分钟新鲜度窗；ReceiptPolicy 透传 TSA 信任输入；
  scrypt/JCS 深嵌套类型化失败；主循环配对兜底圈收口（authorize/recordDecision 抛错不再
  让工具调用无声消失）+ 合成 tool call id 跨步唯一；KNOWN_KEYS 补齐 `rbac`/`plugin`
  （文件层白名单不再拒绝已声明配置段）；worktree copy 路径段匹配；snapshot 读前 stat。

### Added（2026-11-10：M32–M44 审计 / 污点 / 授权 / 委托 / 效果日志 / Skills / MCP / 记忆治理 / 边界二轮，同版未发布）

- **M32 AAT 决策级审计**：新增 `audit` 事件类型 + `AuditRecorder`（prevHash 链，坏链 fail-closed）、
  `PolicySnapshotBuilder`（策略快照哈希写入 `RunManifest.policySnapshotHash`）、`AatExporter.build/verify`、
  `kernel.exportAat(sessionId)`；`StepToolExecutor` 在门禁裁决后、执行前写 `decision`（含
  requestDigest / snapshotHash / principal）；`OmniKernel.create()` 缺省开启。判据 `tests/unit/auditAat.test.ts`
  （7 例）+ `tests/contract/auditWiring.test.ts`；文档 [docs/AAT.md](docs/AAT.md)。
- **M33 CTA 上下文污点隔离**：`ContextTaint`（污点格单调 / 数据面 Merkle / 系统提示摘要）、
  `TaintAttestationBuilder`（JCS + Ed25519 签名/复核）、`StepCtaEnforcer`（执行前 step-up 校验，
  `off/shadow/enforce`）；`OmniKernel.create()` 缺省 shadow，enforce 无匹配回执即拒。判据
  `tests/unit/contextTaint.test.ts`（3 例）+ `auditWiring.test.ts` 的 `cta-enforce`；文档 [docs/CTA.md](docs/CTA.md)。
- **M34 效果日志**：`EffectJournal`（intent/result append-only JSONL、跨重启对账、坏行 fail-closed）、
  `StepEffectRecorder`（执行前 begin / 结果 finish）、`InterruptedToolCalls` 接 effect 解释；
  `OmniKernel.create()` 缺省开启。判据 `tests/unit/effectJournal.test.ts`（3 例）+ 真实回合落盘断言；
  文档 [docs/EFFECTS.md](docs/EFFECTS.md)。
- **M35 Agent Skills 规范字段**：`Skill` / `SkillEntry` / `SkillMdCodec` 支持
  `license` / `compatibility` / `metadata` / `allowed-tools`（解析 + 序列化 + 往返）；`allowed-tools`
  仅作建议、不自动授权。判据 `tests/unit/skillMdCodec.test.ts`（6 例）。
- **M36 AAT 单次授权**：`AuthorizationLedger`（issue/consume/持久化 usedAt，坏行 fail-closed）、
  `StepAuthorizationGate`；allow 时签发、执行前消费，失败码 `REUSED/EXPIRED/REQUEST_MISMATCH/...`
  → `policy-denial`；AAT 导出 `authorization_id` 并检出 `AUTHORIZATION_REUSED`。判据
  `tests/unit/authorizationLedger.test.ts`（3 例）+ `auditWiring`/`auditAat` 断言；文档 [docs/AAT.md](docs/AAT.md) §5。
- **M37 可衰减委托链**：`DelegationChain.issueRoot/attenuate/verify/verifyChain`；scope ⊆ 父、主体不变、
  过期 ≤ 父、深度/预算不超限、Ed25519 逐跳验签。判据 `tests/unit/delegationChain.test.ts`（3 例）；
  文档 [docs/DELEGATION.md](docs/DELEGATION.md)（明确尚未接入子代理工具门禁）。
- **M38 MCP Skills 扩展**：`skills/list`（元数据）+ `skills/get`（含 instructions）；仅注入
  `SkillRegistryPort` 时声明 `io.modelcontextprotocol/skills`；`McpHttpAssembly` 从
  `runtime.config.skillRegistry` 自动注入。判据 `tests/unit/mcpSkills.test.ts`（2 例）。
- **M39 MCP Tasks 扩展**：`McpTaskPort` + `tasks/get` / `tasks/update` / `tasks/cancel`；
  `tools/call` 对异步工具先过门禁再返回 `resultType:"task"`；仅注入时声明
  `io.modelcontextprotocol/tasks`。判据 `tests/unit/mcpTasks.test.ts`（2 例）；文档 [docs/MCP-TASKS.md](docs/MCP-TASKS.md)。
- **M40 记忆治理与可靠性回执**：`MemoryGovernance`（provenance / 准入 / 墓碑补丁）；
  `FileLongTermMemory.tombstone`（recall 跳过、all/get 保留、跨重启）；`ReliabilityReports`
  （pass@1 / pass^k / passAllK / tokensPerSolved + 注入/记忆/失败分类，`EnvelopeSignature` 签名/复核）。
  判据 `memoryGovernance.test.ts` + `reliabilityReport.test.ts`（各 2 例）；文档 [docs/MEMORY-GOVERNANCE.md](docs/MEMORY-GOVERNANCE.md)。
- **M41 CTA 的 MCP 服务端互操作**：`McpCtaPort`；`tools/call` 读 `_meta.ctxIsolation`，
  缺失/无效 → `-32602`；未注入端口零行为；`OmniKernel.create({ config: { mcpCta } })` 自动注入。
  判据 `tests/unit/mcpCta.test.ts`（2 例）；文档 [docs/CTA.md](docs/CTA.md) §5。
- **M42 委托链工具层接线**：`config.delegation` / `SubagentRequest.delegation` →
  `ToolContext.delegation`；`StepToolExecutor` 执行前按 `authority.scopes` 收窄，
  不覆盖即 `tool.delegation.denied`（fail-closed）。判据 `tests/contract/delegationWiring.test.ts`；
  文档 [docs/DELEGATION.md](docs/DELEGATION.md) §5。
- **M43 边界收口**：
  - CTA 客户端：`StepToolExecutor` 把信封放入 `ToolContext.ctxIsolation`，`McpGateway` 透传，
    `McpStatelessClient`/`McpClient` 写 `_meta.ctxIsolation`；
  - 委托：`SubagentRunner` 自动 `attenuate`/`issueRoot`，`StepDelegationGate` 执行期验签 +
    `maxCalls` 扣减；
  - 记忆：`FileLongTermMemory` 的 `governance`/`OMNI_MEMORY_GOVERNANCE=1` 自动 provenance/准入；
    `exportAat(..., reliability)` 追加 `reliability_report` lifecycle 记录，
    `exportAuditBundle(..., reliability)` 写入包级 `reliability`。
  判据：`mcpStatelessClient` / `delegationWiring` / `memoryGovernance` / `auditWiring` / `auditBundle`。
- **M44 边界二轮**：委托跨 issuer 信任根/吊销（`verifyWithTrust` / `verifyChainWithTrust`）+
  父子共享 `DelegationUsage`；CTA `mcp-ctx-isolation` HTTP 头；`ToolGate` 审批观测器写
  approval 请求/回答 + 每工具批次 heartbeat；`OmniKernel` 记忆治理默认开。
  判据：`delegationChain` / `mcpMrtrWiring` / `auditWiring`；`m44-*` 入 `plan:check`。
- **能力清单**：`capabilities().securityPosture` 如实报告注入 / 污点 / 意图 / CTA / 审批 / 沙箱 /
  RBAC / 自验证 / 回执签名；`docs/STANDARDS.md` 记录 AAT/WIMSE/MCP/Skills 的对齐状态与诚实边界。
- **测试规模**：261 文件 / 1250 用例；`plan:check` 41 里程碑 / 106 判据。

### Added

- **AG-UI 提升为公开子路径** `@omniharness/kernel/agui`（`src/agui.ts`）：`AgUiHttpServer` /
  `AgUiEventStream` / `AgUiEventMapper` 与全部事件类型；AG-UI 从「全部入口不可达」变为可达
  （不可达从 14 文件 / 3,280 行降到 6 文件 / 1,618 行）。判据 `tests/contract/aguiServeWiring.test.ts`（5 例）。
- **ACP 服务端判据** `tests/unit/acpServer.test.ts`（4 例）：initialize 能力声明、new → prompt →
  cancel → close、重复 close 幂等、未声明的 `session/delete` 按 `-32601` 拒绝、requireAuth 拒绝。
- **MCP v2 客户端判据** `tests/unit/mcpStatelessClient.test.ts`（7 例）：`server/discover` + 每请求
  `_meta`、tools、MRTR 重试、无 inputHandler fail-closed、`subscriptions/listen`、关闭/错误/反向请求。
- **Windows 原生沙箱判据** `tests/unit/windowsNativeSandbox.test.ts`（4 例）：包装命令与命令文件落盘、
  非 Windows 拒绝、定位器缺失 fail-closed、裁决面与 restricted 同源；`WindowsNativeSandbox`
  增加平台/定位器注入缝。
- **`planCheck` 章节标题状态对账**：`### Mxx … ✅/⏳` 必须与状态账一致，变异用例见
  `gateMutation.test.ts` 绕过#5。

### Changed

- **MCP 默认连接器**：`McpServersBridge` 缺省从 `SdkMcpConnector` 改为 `SdkPreferredMcpConnector`
  （SDK 优先；stdio 失败回落手写 `mcpConnector`，后者支持 2026-07-28 无状态协商）。
- **覆盖率地板**：全局 58/58/73/71 → 60/60/73/72（新基线 60.91/73.66/72.85/60.91）。
- 测试规模：237 文件 / 1145 用例 → **248 文件 / 1200 用例**。
- **固定文案配置化（全量）**：新增 `TextCatalog`（加载 / 形状校验 / `{name}` 渲染一份实现）与
  `KernelTexts`，把 `src/**` 内 **3,235 处**中文文案（含工具结果、协议报错、校验诊断、
  `throw` 文案）外置到 `defaults/kernel-texts.json`（**2,260 键**，`模块.上下文.类别.序号`；
  模板变量 `{argN}`）；另有 `tool-exposure.json`（9 类别词表）、`report-texts.json`
  （沙箱能力表 / 信任清单 / 能力卡）、`tool-result-texts.json`（`plan_present` 交互）四个分域目录，
  并补齐 9 条工具参数说明。协议层经 `protocolsSupport.ts` 单一支撑面取用，不直插 `kernel/util`。
  配置加载器自举报错走 `defaults/bootstrap-texts.json` + `BootstrapTexts`；浏览器 bundle 的投影
  标签改由宿主注入 `ProjectSessionLabels`。判据：`kernelTexts.test.ts` 全仓扫描
  **1,122 文件 / 0 残留**（`src/**` 已无任何中文字符串字面量）；`reportTexts` /
  `toolExposureLexicon` / `toolResultTexts` 渲染逐字。复审口径见
  `docs/AUDIT-2026-11-08-TEXTS.md`。
- **上帝类重构（两轮，闭环到 0 超预算）**：`ContextCompactor`→`CompactionStateCodec`（825→704 行、
  21→16 方法）；`ConfigError`→`ConfigFieldGuard` + `configFieldSpecs`（23→12 方法）；
  `LongHorizonProtocol`→`LongHorizonStateStore`（25→16）；`Rfc3161Verifier`→`Rfc3161TokenParser` +
  `Rfc3161TrustResolver` + 三个阶段方法（973→671 行、23→13、最大方法 404→148）；
  `ResponsesModel`→`ResponsesStreamAccumulator`（25→17）；`McpStatelessClient`→
  `McpStatelessSubscriptions` / `McpMrtrAnswers` / `McpStatelessRequestMeta`（22→12）；
  `TemporalFactGraph`→四个协作类（23→12）；`OmniKernelAssembler.assemble` 189→116；
  `SessionRecorder`→`SessionRetrievalIndex`（23→19）；`FileLock`/`SessionProjector` 小步收敛。
  压缩标记收敛到 `contracts/ports/context/compactionMarker.ts` 单一来源；AST 去重
  `String(String(x))` 361 处 / 117 文件。`npm run god:report -- --check`：**744 类 0 超预算**
  （唯一白名单是纯文案 facade `HarnessTexts`），见
  `docs/AUDIT-2026-11-09-GOD-CLASSES.md`。

### Fixed

- **ROADMAP 账实漂移**：M22/M23 章节标题从 ⏳ 改回 ✅（状态账早已 done）。
- **WIRING 过期陈述**：ACP 显式深路径、AG-UI `./agui`、`sdkPreferredMcpConnector` 回归并默认注入、
  `config.mcpServers` auth 已接线、`./*` 通配已删除、omniError 走显式深路径。
- **README 沙箱措辞**：明确「非 strict 落 `PolicySandbox` + warn，`OMNI_SANDBOX_STRICT=1` 才启动失败」，
  不再让读者把缺省读成 OS 级隔离。

### Fixed（2026-11-10 全量复核与内存审计，详见 `docs/AUDIT-2026-11-10.md`）

- **P0 `run_code` 恒失败**：补齐缺失的 Worker 入口 `codeSandboxWorker`（call/log/console 协议 +
  双层日志/输出预算）；`tests/unit/codeInterpreter.test.ts` 真跑程序与工具桥。
- **审计证据内存有界（信息不丢）**：`ReceiptChain` 持久化模式只留 256 条热回执，`append`
  先写 JSONL 再推进链尾，`export()` 从存档重放全量并用「条数 + 链尾哈希」双校验拒绝残缺包；
  `AuthorizationLedger` 流式重放并清理过期令牌（文件历史完整）；`memory_search` 无 `session`
  时也逐会话扫描存档回退（索引淘汰不再漏召回）；回执**启动接管/复核**改为
  `previousPath` + `AuditPacks.verifyFile` 流式（峰值 O(1)）；`HashChainPromotionLedger`
  落盘模式只留 16 条热条目，`list/verify/rollback` 流式读档（旧快照仍可还原）。
- **其余内存预算（信息不丢）**：`Bm25MemoryIndex`（4096 条 / 8 MiB 双预算，活动会话保留 +
  指定会话存档回退 + resume 重放恢复）、`WorkbenchHub`（全局 20k 事件 + 256 会话 LRU，
  存档为事实源）、`WorkspaceFileCoordinator`（32 root LRU）、压缩摘要超 12K 字符时**全文外溢**
  （`spill_read` 可读回，不截断）、`EmbeddingContentCache`（8192 LRU + 失败代际清扫 + 构建串行化）、
  检查点每会话 50 label 上限、steering 64 条上限 + 回合收尾清理、OTLP 指标基数 2048、
  共享调度器 32、会话 GC 单文件 64 MiB；`EffectJournal` 改为分块流式重放（>8 MiB 不再拒绝
  resume，内存只留未完成 intent + 最近完成对）。
- **机检与生命周期收尾（2026-11-10）**：`ProjectInstructions` 默认读取器先 stat（超预算跳过）；
  `m4-gate-bypass` 按用例检查真实断言调用（空用例判红）；`docCountsCheck` 增加用例数上界
  （虚报 999999 判红）；`OmniHarnessRuntime.dispose()` 幂等释放 LSP（`OmniKernel.close()` 调用，
  直接 createRuntime 的嵌入方也能关）；`verifyBundle.mjs` 补 CLI 级回归（路径穿越/坏 JSON）；
  `BrowserProcessQuery` 抽出进程过滤器与 CIM 解析，浏览器收尾判据从 grep 升级为行为断言。
- **读前上限**：`view_image` 64 MiB、LSP didOpen/didChange 8 MiB、`patch_candidates` 8 MiB、
  watcher 增量路径按 `MAX_FILE_BYTES` 预检、PDF inflate 32 MiB、审计交付 gunzip 64 MiB。
- **生命周期对称清理**：`Agent` open/build 失败回滚在跑登记与检查点事件源；看门狗超时摘 abort 监听；
  Chrome exit 钩子可摘除；MCP 连接失败即 close；AG-UI 断开取消改挂 `res.close`；子代理 worktree
  cleanup 收进 finally 并 forget 协调器。
- **wire 边界**：Ollama 行缓冲 16 MiB、OpenAI `tool_calls.index` 上界 64、非流式响应体 32 MiB、
  AG-UI / MCP SSE 8 MiB 背压、workbench SSE 去重集仅回放期登记。
- **机检**：`sourceGraph` 支持无空白 `import{x}from"y"` 形态；`verifyBundle` 分片名防穿越。

---

## 0.1.0-alpha.15 — 2026-11-08（P1 信任边界收敛 + 成熟度清零，未 npm publish）


> 本版**合并** alpha.14（未 npm publish）的全部内容与 2026-11-08 夜的本轮收敛：P1 信任边界（交互式沙箱包装 / RFC3161 证书链 / 页面内请求拦截）、16 件 `L0-unverified` 清零、MCP 客户端反向请求、覆盖率二次收紧、跨仓消费契约层。
### Added（2026-11-08 深夜：成熟度清零 + MCP 反向请求 + 2 处缺陷修复）

- **`maturity:check` 报 0 件 `L0-unverified`**（原 16 件）：插件分发 4 件（静态扫描 / 分级 / 包读取 /
  私有技能源）、wasm 隔离 3 件（内存声明 / 资产类型 / 执行器，含**真实执行**手写 wasm）、
  自主调度 1 件、资产装配 1 件、repo-map 投送 1 件、进化闭环 6 件，全部补本仓判据后升 L1，
  不删徽章、不留空头支票。新增判据 15 个文件 / 95 例；判据规模 222 文件 / 1050 用例 →
  **237 文件 / 1145 用例**。
- **缺陷（写判据时实锤）**：`PrivateSkillSource.bundleFiles` 把「包数超限」的 throw 写在 try 里被
  自己的 catch 吞掉（超限时 `sync()` 报「0 安装 0 拒绝」——恰好是注释承诺不做的假象）；
  `EliteReentryDiscovery.enqueue` 超限用 `shift()` 丢掉**最老**重入候选，与「旧复核优先」相反。
  两处均已修复并由 `privateSkillSource.test.ts` / `evolutionCandidateFlow.test.ts` 钉死。\n- **MCP 客户端反向请求**（`McpClientOptions.serverRequests`）：此前服务端发起的 `sampling/createMessage`\n  / `roots/list` 一律回 `-32601`——客户端永远不被当成「支持 sampling 的宿主」，该能力面事实上不可用。\n  现由调用方按需注入处理器：`initialize` 只**如实声明**已注入的反向能力（`sampling` / `roots`），\n  请求按方法分派、同 id 回 result；未注入仍回 `-32601`（不让对端等到超时），处理器抛错回 `-32603`\n  且原因可读，关闭后不再写传输。判据 `tests/unit/mcpClient.test.ts`（8 例，此前 McpClient 零判据）。\n  `resources/subscribe` 保持**有意不实现**：2026-07-28 协议已由 `subscriptions/listen`（已实现+已判据）\n  取代，能力声明面也从未谎报 `subscribe`（`m6-mcp-capability-honest` 把守）。

### Added（2026-11-08 夜：剩余项收敛——沙箱执行包装补全 / RFC3161 证书链）

- **`shell_interactive` 补上 OS 沙箱命令包装**：此前只有 `shell` 经 `commandWrapper` 把命令包进
  选中后端，`shell_interactive` 只做策略裁决就直通终端——同一个 profile 两条执行路径两种隔离语义。
  现两条路径都在 `configToolRegistry` 单点注入同一 `commandWrapper`（先按原始命令裁决，再把通过的
  文本包进沙箱）；新增 `tests/unit/shellSandboxWrapping.test.ts`（4 例：包装生效 / 策略拒绝不包装 /
  交互式包装 / 未注入零变更）。顺带修正 `SandboxManager.EXECUTION_UNWIRED` 与 `src/sandbox.ts` 的
  过期注释（集合已为空 = 已接线；本机可用性另由能力表与各后端 `probe()` 如实描述）。
- **RFC3161 证书链校验**（`Rfc3161CertificateChain`，经 `./receipts` 导出）：`trust.kind:'chain'`
  提供叶子 + 中间链 + **显式固定信任根**，校验逐级签名、**genTime 时刻**有效期、叶子 EKU
  `id-kp-timeStamping`（必须 critical）、keyUsage（digitalSignature / nonRepudiation）、叶子非 CA、
  可选 TSA policy 名单；信任根为空即 fail-closed，令牌自带自签根不算数。untrusted 结论不降级为
  「只验签名」：`chainChecked/chainTrusted` 与 `signatureChecked/signatureVerified` 分层上报。
  判据 `tests/unit/rfc3161Chain.test.ts`（11 例，用 `tests/unit/rfc3161CertificateFixture.ts`
  手写 DER 生成真实证书链、node:crypto 真签名）；仍不验 CRL/OCSP 与完整 RFC 5280 策略链
  （离线复核器不出网，见 RECEIPTS §3）。
- **浏览器页面内请求拦截**（`BrowserRequestGuard`）：导航守卫此前只判 `goto` 目标 URL，页面脚本
  随后访问内网/云元数据完全绕过。现 CDP `Fetch`（Request 阶段逐条 `continueRequest` /
  `failRequest(BlockedByClient)`）与 Playwright `page.route` 两条引擎都过同一套 egress 判定；
  `data:`/`blob:`/`about:` 放行（不产生出站），`file:` 等本地协议拒绝；判定异常 fail-closed；
  同 URL 判定在单会话内缓存（上限 1024）。`Fetch` 域不可用时如实 warn 并返回 false（导航层
  守卫仍生效，不假装已拦截）。判据 `tests/unit/browserRequestGuard.test.ts`（6 例）。

- **覆盖率地板二次收紧**：全局 56/56/72/70 → **58/58/73/71**（基线 59.45 / 73.94 / 72.57），
  并新增 5 个域地板（evolution 85/88、capability 81/90、plugin 42/62、autonomy 29/34、
  maintenance 83/98）与 `protocols/mcp`（39/58）——本轮补齐判据的域从此纳入「只升不降」；
  目录地板共 16 个；另加 **8 个逐文件地板**（toolCallPairs / toolExposurePlanner / serverAuthGuard /\n  layeredCodeGraph / provenanceIssuer / packStaticScanner / privateSkillSource / evolutionKernel），\n  挡住「单文件整体塌掉但同目录其它文件补分」的退化。实测见 `vitest.config.ts` 头注。

### Added（2026-11-08 傍晚：跨仓消费契约 + APP 收敛，不涉及包内容）

- **跨仓门禁增加 TS 消费层**（`scripts/lib/appContractCheck.mjs`，`AppContractCheck`）：
  内核从自己的承诺面出发核对真实应用仓——①钉定必须是 `file:vendor/omniharness-kernel-<版本>.tgz`；
  ②已安装版本必须等于钉定；③应用 `src/**` 的 `@omniharness/kernel[/…]` 导入 ⊆ 内核 `exports`
  且只允许出现在 `src/host/kernel/` 对接面；④`src/host/extensions/**` 声明的符号名不得与内核
  承诺名重合。承诺面解析**穿透 curated 子路径的再导出桶**（`export { … } from` / `export *`）——
  只扫直接声明会让 `./sandbox` / `./mcp` / `./maintenance` 承诺的能力整类漏检。
  用例：`tests/unit/appContractCheck.test.ts`（6 例）+ `crossRepoCheck.test.ts` 消费层集成 2 例。
- **仓角色拆清**：旧 `crossRepoCheck` 把含 `crates/omni-core` 的仓称 `appRepo`（实为 Rust 消费仓），
  真实 TS 应用仓从未被核对；现拆为 `resolveRustRepo`（`OMNI_RUST_REPO` / `../omniharness`）与
  `resolveConsumerRepo`（`OMNI_APP_REPO` / `../omniharness-app`）。缺 TS 应用仓 SKIP，
  显式 `OMNI_APP_REPO` 或 `OMNI_APP_CONTRACT_REQUIRED=1` 时失败；版本钉定落后内核工作树只记 note。
- CI `cross-repo` job 改用 `OMNI_RUST_REPO`（语义与 `exportsClosure` 的 `OMNI_APP_ROOT` 对齐）。

### Docs（2026-11-08 傍晚）

- `docs/BOUNDARY.md` 增加「跨仓消费契约」两层表与 curated 子路径穿透口径；
- `docs/AUDIT-2026-11-08.md` §7 记录第三轮（应用侧 11 个影子名字清零 + 内核侧两层门禁）。

### Cross-repo（应用仓，同批）

- 应用侧影子扫描修复两处漏检（curated 键拼成目录、再导出名单未解析）后，`IsolationLadderFactory` /
  `SdkPreferredMcpConnector` / `SessionGc` / `SessionStorageLocation` / `TmpSweep` 连同 6 个类型
  共 11 个名字判红；应用删除 5 件影子（约 760 行），消费点改经 `src/host/kernel/` 对接面，
  生成器支持 curated 桶落点，域文件 18 → 19，`kernel:check` 复绿。

### Added（2026-11-08 巡检 §5 收尾：覆盖率 / RFC3161 真验签 / 沙箱 canary / 双内核同步）

- **覆盖率门禁**：引入 `@vitest/coverage-v8` 与 `vitest.config.ts` 阈值（statements/lines 56、branches 72、functions 70 作为「只升不降」地板；基线 57.63 / 73.17 / 71.75）；`npm run coverage`
  进入 `verify`（用覆盖率模式取代重复的 `npm test`，只跑一遍），`coverage/` 入 gitignore。
  `smoke` 同时执行 `examples/embed.mjs`（README 首条命令不再只被文本检查）。
- **RFC3161 真验签**：新增 `DerElement`（有界 DER 读取）/`Rfc3161Oids`/`Rfc3161Verifier`——
  解析 TimeStampResp → PKIStatusInfo → TSTInfo → messageImprint（按声明哈希 OID 重算并常量时间比较）
  → CMS SignerInfo 签名（signedAttrs 与 messageDigest 校验；SPKI/证书信任输入；1 MiB 上限；
  解析异常一律结构化返回）。`AuditPacks.verify` 增加第 4 个可选 `anchorTrust`，锚定结论给出
  `ANCHOR_VERIFIED` / `ANCHOR_MALFORMED` / `ANCHOR_IMPRINT_MISMATCH` / `ANCHOR_SIGNATURE_INVALID` /
  `ANCHOR_UNTRUSTED` / `ANCHOR_UNSUPPORTED_HASH`；`AuditBundles.verify` 透传；`Rfc3161Verifier`
  与类型经 `./receipts` 导出。独立复核 CLI 不再把「有令牌」当「已锚定」：`anchored` 恒 false、
  `compliant` 不可达，新增 `warnings[ANCHOR_UNVERIFIED]` 与 `anchorTokenContainsDigest` 形态字段。
- **Gemini 形状守卫**：非流式 2xx 走共享 `ModelResponseShape`；`promptFeedback.blockReason` ⇒
  结构化 `ModelCallError`（status 200 / retryable false，不返回空成功）；无 candidate 且无
  blockReason ⇒ malformed。
- **Seatbelt 每命令隔离**：profile 改为每次 `wrapCommand` 独立 `mkdtemp`（0600）、实例内记录并在
  `cleanup()`/退出清理，构造期清扫 1 小时以上的陈旧目录——消除并发命令共享一份可写 profile 的
  重写窗口（该层无 spawn 后钩子，无法逐条立即删除，已在类注释写明）。
- **真实沙箱 canary**：新增 `scripts/sandboxCanary.mjs`（`SandboxCanary`，结构自检 + `--real`
  真实 docker 两种模式；以宿主式执行还原 shell 工具路径，断言宿主 canary 标记不出现在 stdout/
  stderr 且宿主文件未创建）。CI 在 ubuntu 以 `OMNI_SANDBOX_CANARY_REQUIRED=1` 执行 `--real`；
  无 docker 的机器明确 SKIP（必需模式下 FAIL），不再只有构造级判据。新增 `npm run sandbox:canary`。
- **双内核同步**：`dangerous-commands.json` 增加声明式 `flagSets`（`rm` 的递归∧强制），TS
  `DangerousCommands` 改为从单一真源加载（删除硬编码表）；Rust `crates/omni-core` 的 `build.rs`
  修复真源解析（`OMNI_KERNEL_SRC` → 兄弟 checkout → 打包 dist，缺失即可行动 panic），并实现同语义
  结构判定与组件级路径包含（Windows 大小写折叠）。`cargo test -p omni-core` 83 通过。
- **覆盖率按目录收紧（2026-11-08 巡检 §6.1）**：`vitest.config.ts` 在全局地板之外增加目录地板
  （core 77/84、receipts 86/89、security 79/90、sandbox 69/79、model 60/74、context 65/70、
  util 75/80、contracts 87/98、protocols 28/51、kernel 59/70，均为 lines/functions），
  用 `**/*.ts` 形态覆盖嵌套文件；实测值向下取整 1–2 点作为「只升不降」地板。
- **跨仓漂移门禁（2026-11-08 巡检 §6.2）**：新增 `scripts/crossRepoCheck.mjs`（`CrossRepoCheck`）——
  三层核对：真源 `dangerous-commands.json` 形状（patterns/flagSets）、Rust 消费侧契约
  （`build.rs` 的 `OMNI_KERNEL_SRC` 与兄弟 checkout 候选、`sandbox.rs` 的 `DANGEROUS_FLAG_SETS`
  与 `path_contains`）、`cargo test -p omni-core` 可执行证据；无应用仓时明确 SKIP，
  `OMNI_CROSS_REPO_REQUIRED=1` 时 SKIP 即失败。`npm run cross:check` 进入 `verify`（有兄弟仓时真跑）；
  CI 新增 `cross-repo` job：同时 checkout 应用仓与 Rust 工具链后以 REQUIRED 模式执行。

### Fixed（2026-11-08 核心质量巡检闭环，最新）

- **信任边界**：审批缓存键改用无损 shell 词法（`cacheKeyOf`），`echo 'a && rm -rf ~'` 与未加引号
  形式不再同键（P0）；`permission.rules` 写入路径要求至少一个约束（无约束规则等于 allow-all）；
  escalation 缺省提升件改 fail-closed，并新增 `SANDBOX_STRENGTH` 校验拒绝弱于基准的提升档；审计包/审计束空证据不再 `ok`（`EMPTY_PACK`/`EMPTY_BUNDLE`），内嵌证书签名
  经 signed envelope 真验，新增可选 out-of-band `expected`（`COMMITMENT_MISMATCH`/`UNVERIFIED`），
  锚定改为诚实的 `anchorTokenContainsDigest` + `ANCHOR_UNVERIFIED`（containment 不再判 compliant）；
  `SecretRedactor` 覆盖 `providerKeys`/`*Key`；Guardian 提示加随机 nonce 数据封套并带 args；
  Seatbelt SBPL 转义 + profile 移出可写工作区；HMAC 空键告警。
- **模型层**：新增 `ModelResponseShape`——四个适配器 2xx 统一形状守卫（error 信封 / 必需数组），
  杜绝裸 `TypeError` 与静默空成功（P0）；`TokenCount` + `CostBudget` 归一，畸形 usage 不再把
  `spentUsd` 变 NaN（硬预算恢复阻断），快照与 `budget_status` 自报 `unmeasuredModels`（P0）；
  OpenAI 流式工具调用按 index/id 分桶（缺 index 的多调用不再互相覆盖），Anthropic 补合成 tool id，
  Responses 走 `ToolArgumentParser`（parseError）/data-only SSE/`onToolInput`（P0/P1）；
  `ModelHttpErrors` 统一 400 请求 dump 且始终带 `responseBody`（上下文溢出恢复对 OpenAI 生效）；
  SSE 增 16 MiB 帧上限、`data:` 精确剥一个空格；空文本不回传 `text`。
- **核心循环**：`resume` 同步占位单飞（消除 TOCTOU）；取消工具批 flush 已完成调用的事件；
  检索索引按 id 幂等（P0/P1）；LoopGuard 软时限不再早退、编辑振荡命中即清窗；TurnDiff 每回合重置；
  spill/flush fail-soft；workflow 传递 `verificationState` 并标注未验证；GoalRunner 按回合取证与
  真实迭代数；checkpoint 跨实例共享 live source，auto 快照改单键滚动。
- **上下文与存储**：6 处 tmp+rename 收敛到 `AtomicFileWriter`（唯一临时名 / 有界重试 /
  `writeBytes`/`writeSync`）；附件内容寻址写入校验摘要；JSONL BOM；SQLite 坏行容错；KV 前缀按
  字面匹配；压缩摘要跳过合成 user 消息（真实任务不再被 diff 顶掉）；RepoMap 排除控制流关键字；
  ToolIndex 参数名可检索；ContextImageBudget 只降级图片；DeterministicCompressor 加字节预算；
  LongHorizon 进度按字节安全裁剪；补齐 3 个只存在于注释的测试并发掘 corpusWalker 等价判据。
- **传输与协议**：WS upgrade `head` 透传 + `flush()`（首帧不再丢）；关闭帧绕过背压
  （1002/1007/1009 不再丢）；握手校验 `Upgrade`/`Sec-WebSocket-Version`（400/426）；
  LSP 头窗口 64 KiB 上限并与帧上限共用错误面。
- **重复实现收敛**：路径包含统一到 `WorkspaceGuard`（realpath，四个 OS 沙箱与容器同语义）；
  policy/restricted 合并为 `CommandPolicy`（两档现在真正执行 rm 旗标集规则）；工具调用配对四处
  合一为 `ToolCallPairs`；`CancelledError.is` 单源；corpus walker 同步/异步共用同一 gate；
  六个脚本目录遍历与两个 import 扫描器收敛到 `SourceGraph`。
- **校验装置**：`reachability.mjs` 变为可 import 的 `ReachabilityAudit`——`wiring:check` /
  `plan:check` 进程内调用，不再 spawn、不依赖 `.audit/reach.json`；计划门禁错误归因带
  code/signal/stderr；`api:check` golden 缺失 fail-closed 且上限检查先于 `--update-golden`；
  `prepack` 接入 `exportsClosure`、`build` 断言 dist 产物；`view:check` 认副作用/裸内建；
  新增 `style:check`（src 零 `function`/`console.log`）与 `doc:check`（README 计数）；
  `contractTestImports` 白名单改为 `package.json#exports` 派生；`verifyReceipts` 空包退出 1。
- **文档账实**：`README` / `BOUNDARY` / `MATH` / `WIRING` / 本文件按实测对齐——215 文件 / 1007 用例；
  src 143,405 行（contracts 10.5K / kernel 119K / protocols 11.5K）；可达性 19,581 / 显式入口口径
  3,280 行 / 335 个入口；`m4-source-lines` 预算按先例登记为 145,500（+6K 巡检）。
- **巡检报告**：`docs/AUDIT-2026-11-08.md` 更新为闭环清单（修复项、复核证据、诚实边界）。

### BREAKING

- **静态门面删除**：`ConfigBuilder.buildXxx` / `EigenSpectrum.xxx` / `UnifiedDiff.xxx` /
  `CommandCanonicalizer.xxx` 改为实例入口（`configBuilder` / `eigenSpectrum` / `unifiedDiff` /
  `commandCanonicalizer`，或自行 `new`）。迁移说明见 `docs/API.md` §8.1。
- **路由定价统一 per-1M**：新配置写 `inputPer1M/outputPer1M`；旧 per-1k 读取时自动 ×1000。
- **判别联合**：`SandboxDecision` 拒绝必须带 `reason`+`category`；`ImageContent` 必须给 `url` 或 `data`。
- **类型改名**：安全域 `TrustTier` → `ContentTrustTier`。

### Fixed（2026-11-07 全量审计：P0 15 / P1 57 / P2 / P3 分批闭环）

- **P0**：`sketch_write` 纳入写类工具；unshare 补网络命名空间；Guardian 否定语义 fail-closed；
  工作台/AG-UI/MCP 服务端补 Host 头防线（DNS rebinding）；审计包畸形载荷不再抛裸 `JcsError`；
  浏览器进程树按真实可执行名回收；新增 `BrowserNavigationGuard` 给 CDP/Playwright 导航接 egress；
  主循环门禁异常补配对事件、失败结果不再沉淀为成功模板、resume 回填检索索引；Anthropic
  `tool_use`/`tool_result` 配对与五通路流完整性。
- **P1**：AES-GCM scrypt 迁移 + 无密钥源 fail-closed；凭据全文本打码；发布者信任锚定；
  HMAC 台账；provenance 无签名不再判合格；四沙箱路径边界；egress DNS 逐 IP 复核；OAuth
  https/超时/响应上限；ReDoS 预筛与工具上限；`errorCode` 机读码；回执导出 flush；pending
  有界淘汰；close 回收插件 worker；语料缓存 stale-while-revalidate；MCP 工具归属表与反向
  请求回错；插件前缀/孤儿回收；GoalChecker 严格解析；`boundaryCheck`/`planCheck` 加固；
  出厂技能数据重写（删除不存在的脚本与文档）；README/BOUNDARY/defaults 账实对齐。
- **P2**：重复实现收敛——GENESIS、图片 token、裁决联合、有界 JSONL 三连、LCS 三份、验签三份、
  定价单位（`RoutePrice` per-1M，旧 per-1k 读取迁移）、推理七档、MCP `required` 元素校验、
  会话列举（Jsonl/Sqlite）、`DigestEquals` 常量时间摘要比较、四处静态门面别名 shim、
  错误信息提取（12 个带方法体 + 89 个内联文件收敛到 `ErrorMessage`）；语义/边界修复——
  JsonFileKv 原型污染与键序、CryptoVault 单飞、JSONL append TOCTOU、Zip/KDF 越界、sdkClient NaN id、Retry 监听器、
  连接上限、glob/grep 子树遍历、单飞 maxBytes、定价 NaN/负数、`SandboxDecision`/`ImageContent`
  判别联合、`TodoStatus`、`EventFactory.rollback`；删除「只写不读」的会话旁路摘要通道。
- **P3**：18 文件去 BOM；`console.warn` 归零；Ed25519 随机源改 `randomBytes`；worktree 目录
  唯一化；插件 HMAC 常量时间；0600 仅 POSIX 的账面；孤儿 JSDoc 清理。

### Docs

- 新增 `docs/AUDIT-CLOSURE-2026-11-07.md`：批次提交表、P0/P1 证据、P2/P3 收敛清单与**诚实边界**
  （不可回溯的哈希口径、protocolsSupport 21 符号上限、Sqlite 能力边界、unshare/浏览器/ReDoS
  的防护范围）。

### Changed（2026-11-08 核心解耦与应用侧通用件收编）

- **核心装配面收敛**：`ToolGate` 的 8 个位置参数改为 `ToolGateOptions`；`TurnRunner` 的 14 个
  位置参数改为 `TurnRunnerOptions`。深路径消费方需同步迁移（顶层公开面不变）。
- **工具执行职责拆分**：`StepToolExecutor` 抽出 `ToolCallStager`（批级事件按模型调用序提交）与
  `ToolResultPipeline`（打码 → 外溢 → 注入隔离 → 沙箱标注 → 附件外置 → 监督上报），执行器只保留
  门禁/钩子/执行编排；`ToolCallStager`/`ToolResultPipeline` 判据见 `tests/unit/toolCallStager.test.ts`。
- **重复实现收敛**：删除 `AppendOnlyEventLog` 的 5 个事件构造快捷方法（生产零消费，测试改用
  `eventFactory` + `append`）；`SessionRecorder` 的两个倒扫查询合并为 `lastTextOf`；`LoopGuard`
  两处 FNV-1a 实现合并；`ToolPort` 增加可选 `lastFailure` 读取面，移除三处重复的结构断言。
- **应用侧通用件收编（内核侧）**：新增 `kernel/maintenance` 与 `./maintenance` 子路径——
  `SessionStorageLocation`（会话目录单一事实源）/ `SessionGc`（keepNewest + 年龄 + 总量封顶 +
  孤儿附件）/ `TmpSweep`（本仓前缀临时产物清扫）。`SessionGc` 顺带修复「注入时钟只作用于会话组、
  附件回收仍用 `Date.now()`」的判据漂移。
- **装配工厂收编（内核侧）**：`IsolationLadderFactory.builtin()`（wasm 档可达；os 档缺省
  fail-closed）经 `./sandbox` 导出；`SdkPreferredMcpConnector`（SDK 优先、stdio 手写回退、url
  不回退且如实留痕）经 `./mcp` 导出。应用侧对应的 5 个影子实现可在升级时删除（本仓不代改应用仓）。

### Changed（2026-11-08 上帝类拆解与环境开关收敛）

- **`createOmniKernel` 1533 → 33 行 barrel**：句柄类 / 装配顺序 / 回执装配 / 事件端口 / 类型 /
  纯工具拆为 6 个文件；`src/index.ts` 与 `src/embed.ts` 的导入路径与公开面零改动。
- **`Agent` 764 → 585 行**：抽出 `AgentSessionRuntime`（在跑会话登记 / 取消 / write-behind /
  回卷 / 收尾），主循环只保留回合编排；回卷与登记的身份一致反注册语义逐字保留。
- **`TurnRunner` 846 → 606 行**：抽出 `TurnCompletionJudge`（证据下限 → 完成闸门 → reviewer →
  未完成待办），完成判定的有界性（闸门/reviewer 每回合至多一次）与 `unverified` 语义不变。
- **`StepContextBuilder` 611 → 386 行**：抽出 `RepoMapInjector`（查询推导 / 任务形状闸 /
  混合检索 / 降档）与 `ContextPrefixMeter`（相邻请求前缀复用率），两者各自可独立测试。
- **`StepToolExecutor` 941 → 592 行**：在 `ToolCallStager` / `ToolResultPipeline` 之外再抽出
  `ToolExecutionGuard`（只读瞬态重试 / 看门狗 / 取消竞速），执行器只保留门禁/钩子/编排。
- **核心环境开关收敛**：新增 `RuntimeFlags` 作为 `OMNI_*` 键名、默认值与关闭语义的唯一解析处；
  Agent / StepContextBuilder / StepToolExecutor / LoopGuard / AgentLimits / AgentCompactor /
  TaskComplexityClassifier / SessionInjector 不再各自解析 `process.env`。
- **判据**：`tests/unit/toolResultPipeline.test.ts` 3 例（打码先于外溢 / 注入隔离保留附件 /
  策略拒绝与命令非零退出不计健康失败）；全量 `npm test` 152 文件 / 778 用例全绿。

### Added（2026-11-08 固定文案外置：`defaults/harness-texts.json`）

- 新增 `HarnessTexts` 文案目录 + 声明式 `Shape` 校验（缺键/错型 fail-closed）：系统提示、
  平台方言段、失控纠偏、完成闸门回灌、待办纠偏、规划要求、续跑引导、收尾检查清单、
  回合失败留痕全部改为 JSON 数据。
- 移除 `defaultPromptFragments.ts` / `loopGuard.ts` / `turnCompletionJudge.ts` /
  `taskComplexityClassifier.ts` / `resumeGuidance.ts` / `preCompletionChecklist.ts` /
  `agent.ts` 中的对应硬编码长文案；改文案只改 `defaults/harness-texts.json`。
- 模板占位符统一为 `{name}`，渲染后残留占位符由 `tests/unit/harnessTexts.test.ts` 判据拦截。
- 新增 `defaults/tool-texts.json` + `defaults/tool-param-texts.json` + `ToolTexts`：
  52 个 `TOOL_NAMES` 的工具描述与 134 条参数 schema 字段说明全部外置；工具定义只保留
  `ToolTexts.description(TOOL_NAMES.x)` / `ToolTexts.parameter(TOOL_NAMES.x, 'path')`；
  缺条目时构造 fail-closed。判据 `tests/unit/toolTexts.test.ts` 逐值核对枚举与文案表一一对应。

### Added（M31 应用侧模型探针/注入度量收编 + 状态值表）

- **应用侧三件通用件迁入内核**：`ModelCapabilityProbe`（模型能力探针）、
  `InjectionSnapshotAggregator` + `InjectionMetric`（注入度量编排）共 702 行；
  新增 `./eval` 子路径一次性导出，应用侧升级 tgz 后可删除三份影子。
- **源码行预算明确放宽**：`m4-source-lines` 由 138,000 → 139,000，判据标题登记
  「+1K=M31（632 行；交换条件：应用侧退役两份影子）」。
- **工具参数 schema 文案外置**：`defaults/tool-param-texts.json` 收录 134 条
  `tool.path` 字段说明；工具定义统一 `ToolTexts.parameter(TOOL_NAMES.x, 'path')`。
- **状态值表化（枚举等价）**：全文 28 组字符串联合状态（待办 / 工作流 / 监督 / 验证 / 工具错误码 /
  图节点 / 隔离 / 信任 / 内容信任 / 工作区信任 / 决策 / 检索角色 / 审批 / 规则 / 计划 / 遥测 /
  沙箱动作与拒绝分类 / 审查 / 推理档位等）改为 `as const` 唯一值表，类型由值表推导；
  监督内核 `MODE_ORDER` 直接复用 `SAFE_MODES`，不再手写第二份状态数组。
- 判据：`tests/unit/evalDiagnostics.test.ts`（六探针全过 + TP/FN/FP/TN 可复算）、
  `tests/unit/statusEnums.test.ts`（8 组值表完整/去重）、`tests/unit/toolTexts.test.ts`
  （52 工具描述 + 参数路径读取）。

## 0.1.0-alpha.13 — 2026-11-07（vendored tgz 发布，未 npm publish）

### Added（M29 审计 canonical 单一真源：auditCanonical → 内核 Jcs，2026-11-07）

- **Jcs 深度护栏补齐**：`MAX_DEPTH = 64`（口径取自审计域历史实现；超限抛 `JcsError` fail-closed，防环/防炸栈——回执载荷是内核受控的扁平结构，对既有 receipts 消费方零行为变更）。

- **exports 承诺闭包 += `kernel/receipts/jcs.js`**：审计哈希链的序列化口径收敛为内核 Jcs 单一实现（M26 遗留闭环项）。逐字节对齐结论钉死于判据：JSON 合法值域内与历史 AuditCanonical 输出恒同；差异只在 JSON 非法值——历史实现宽松改写（NaN→null / Date→{} / 数组 undefined→null，哈希静默盖住被改写的值），Jcs fail-closed 拒绝。**迁移即加固**：JSON 合法输入的历史审计报告逐字节可验（链头哈希不变），JSON 非法输入从静默改写变为显式拒绝。

- 判据：`tests/unit/jcsAuditAlignment.test.ts` 4 例（逐字 golden / 深度护栏 / fail-closed 矩阵 / 链头稳定性）。

## 0.1.0-alpha.12 — 2026-11-07（vendored tgz 发布，未 npm publish）

### Added（M28 插话词表配置化：defaults/interjection.json + omniharness.json interjection 段，2026-11-07）

- **插话词表全链配置化**（ssrfPolicy 同款链路）：`InterjectionClassifier` 的打断词 / 关联词 /
  确认句正则 / 停用词 / 三个判定旋钮（上下文条数 / 单条截断 / 重合阈值）此前写死在类常量里，
  现迁入 `defaults/interjection.json`（改数据不改代码）+ `InterjectionLexicon`
  （fail-closed 校验 + 逐键**替换**覆盖 + 出厂单例）+ `omniharness.json` 的 `interjection` 段
  （`interjectionConfigValidator` 加载期与运行时同源校验，configFactory 透传 ResolvedConfig）。
  零配置行为与迁移前逐字一致（判据①逐字钉住 27/30/34 词 + 正则源串 + 三旋钮）。
- 判据：`tests/unit/interjectionConfig.test.ts` 5 例（历史逐字 / fail-closed 矩阵 / 覆盖语义 /
  消费点真读配置 + 透传 + 加载闸门 / 反硬编码守卫）；`m28-interjection-config` 判据入 plan:check。

### Added（M27 兼容层清零：SDK 客户端族重审迁入 + 凭据打码单一事实源，2026-11-07）

- **SDK 客户端族**（重审迁入，推翻 2026-11-03「零引用」清零裁决——前提已失效，且 rpc 域自此
  服务端/客户端两半齐备）：`SdkSocket` 契约（server 端口）+ `SdkClient`（JSON-RPC 请求-响应 +
  通知订阅，请求超时/挂起清理/就绪语义齐备）+ `WebSocketSdkSocket`（Node 22 全局 WebSocket /
  注入工厂双形态）。**判据当场抓获真 bug**：`bindSocket` 对 onClose 分两次注册被「最后一次
  注册生效」语义覆盖，S14「就绪前 close 兑现 opened」在应用原实现中静默失效——已修
  （单一 onClose 注册），应用升级后同步受益。
- **凭据打码单一事实源** `SecretRedactor`：递归打码（键名像凭据即遮 / env·headers 只遮凭据名 /
  auth 整遮）+ `maskKey`（前 3 后 4，短 Key 全遮）——收敛 CLI dump / 服务端回传 / Key 展示
  三处独立实现的口径分裂。
- 判据：`tests/unit/sdkAndSecrets.test.ts` 6 例（call roundtrip / RPC error / 超时 / 通知订阅 /
  close 打断挂起 / S14 形态 / 事件映射 / 全局缺失 fail-closed / 打码矩阵）。

### Added（M26 应用侧终盘收编：kernel-compat 通用件 + 影子清偿，2026-11-07）

- **影子清偿前置**：`exports` 承诺闭包 += `kernel/rpc/jsonRpc` + `kernel/transport` 三件——内核早有同名实现
  （compat 清零时下沉），应用侧逐字节影子副本可随下次发版退役；迁移桥 252 → 315 条深路径（M21 预置形态）。
- **适配器补全族**（端口全在内核契约，实现归位）：审批档 `AskApproval` / `PlanApproval` /
  `GuardianApproval`（LLM 审查 + 预检直判）/ `BUILTIN_APPROVAL_RULES`（rm/del 拦截单一真源）；
  升级 `AskEscalation` / `AutoEscalation`；事件扇出 `CompositeEventPort`（fail-soft）；
  KV 三件套 `MemoryKv` / `JsonFileKv`（原子写）/ `SqliteKv`（node:sqlite 惰性加载 + 失败路径注入缝）。
- **vault 族**：`VaultPort` 契约 + `CryptoVault`（AES-256-GCM，主密钥级联：环境变量 → 密钥文件 0600 →
  自动生成）+ `EnvVault` + `CredentialResolver`（环境变量优先、保险库回退，hydrateEnv 只填未设置项）。
- **trace 自省族**：只读自省契约（Entry/Filter/ReadRequest/ReadResult/Port）+ `ReadonlyTraceReader`
  （冻结快照、seq=源流下标）+ `SessionEventReader`（JSONL 存档读取、路径穿越拒绝、归档冷存储回落）。
- **util/config 补全族**：`Retry`（指数退避 + 全抖动 + 测试时钟注入）、`JsonObjectFile`、`LocalDay`
  （时区归属单点）、`MimeType`（fail-closed 唯一事实源）、`PortablePath`（~/$VAR/%VAR% 展开 compact 往返）、
  `QuantileSketch`（GK 风格流式分位）、`ConfigRebase`（跨工作区重基，工作区耦合端口显式剔除）。
- **skill 签名 + asset 收编**：`SkillManifestSigner`（声明式技能子集 Ed25519 签名/验签）+
  `AssetPackCodec`（.ohb 容器 + 非对称验签，ADR-0011）/ `AssetPackInstaller`（五步流水线：验签→全量预检→
  入册→入账→报告；整包原子 + 档位只收紧 + 无台账拒装 + 写入失败补偿撤销）。
- **核心循环/观测补全**：`InterjectionClassifier`（插话分流六步判定，零模型调用）+
  `CacheMissAttributionAnalyst`（未命中分因七分支，"假读数"≠"真未命中"）+ `CacheHitRateWatch`
  （命中率坍塌告警，内核 `cacheHitRateCollector` 头注引用闭合）。
- 判据：`tests/unit/adapterCompletions.test.ts` 43 例（白名单派生不变量 / fail-closed / KV 三后端行为对齐 /
  GCM 认证失败矩阵 / 归档回落实搬 / GK 实测误差带 / 五步流水线 / 档位只收紧 / 补偿撤销 / 插话六步 /
  分因优先级）；`m26-*` 七条 auto 判据入 plan:check。诚实边界修正：QuantileSketch 头注的
  「确定性秩误差 ≤ εn」与实测不符（最坏 ≈0.07n 单调流 / 0.18n 随机流），改为实测带 + 恢复路径。

## 0.1.0-alpha.11 — 2026-11-07（vendored tgz 发布，未 npm publish）

### Added（M24 评测闭环与收尾，2026-11-07）

- **长任务 fixture 重建**（M22 最大遗留）：规格驱动生成器 + 23 个合成任务四件套（tasks/fixtures/verifiers/solutions），四族覆盖（结构化进度/库实现/修 bug/跨文件状态）；fixture 自带 `package.json`（type=commonjs）防沙箱 ESM 污染；**self-check 23/23 全绿**（参考解全过机械验收），dry-run 可用，跑分自动化仍待应用仓 CLI。
- 消费侧字面量漂移清偿：四文件策略表（toolResultSpiller/provenanceTracker/subagentTypes/acpQuestionUplink）全部收敛 TOOL_NAMES 单一来源（gate 永久把守）。
- 文档账实：README↔代码符号一致性 gate 锁定（「createOmniKernel 不存在」核实为审计误报）。

### Fixed（M23 断线清偿：盘点 6 缺失 + 5 畸形，2026-11-07）

- **ssrfPolicy 接线（安全级）**：用户配置的出站策略表此前声明/校验/透传三层齐全但运行时
  只喂内置默认档（静默不生效）。现在组合根 `resolveSsrfPolicy` 解析一次随 seed 下发，
  `web_fetch` 两处 egress 校验（首查 + 每跳重定向）消费注入表；未配置行为逐字不变。
- **plugin 端到端通电**：开启 `plugin.enabled` 此前只装配句柄不装载——现在
  `createOmniKernel` 启动即 `loadInstalled()`（逐件告警不断链）；`capabilities()` 补
  mediaStack / pluginStack / capabilityStack 三栈真实汇报；plugin / capability 入
  passthroughSections（ResolvedConfig 副本此前恒 undefined）。
- **工具面一致性**：补 `tests/unit/toolNames.test.ts`（源文件头注承诺却从未落盘的
  「单一来源」判据：已注册⊆表 / 表自洽 / 漂移哨兵）；loopGuard 写类口径从第二套字面量
  收敛到 TOOL_NAMES（新写类工具的振荡守卫此前会静默失效）；`spillMaxRings` 死字段删除；
  默认工具数注释 31/36→37/45（实测口径）等四处注释账实差。
- **eval runner**：任务目录缺失从裸抛错改为可行动指引（fixture 重建待办在案）。
- 审计纠偏如实入账：observability metrics 并非悬空（`TraceExporterAssembly.wrap` 已实现
  metrics 腿）；`pluginProfile` 与 locale/chatMode 同属应用层字段，非内核缺口。

### Added（M22 认知域重入：plugin / eval / media 自 attic 迁回，2026-11-07）

- **plugin 体系**（31+8 文件）：manifest 校验 / 权限门禁（fail-closed）/ 注册表与安装 /
  node:vm 沙箱 / 技能包 A–C 分级 / Worker 进程隔离 / HMAC 打包。新装配缝
  `PluginStackAssembler`：`plugin.enabled !== true` 即 undefined（加载外部代码 opt-in），
  权限白名单缺省 denyAll、`plugin.permissions` 显式放行（值域机检）；`pluginStack` 切片入
  `ResolvedConfig`；`defaultTools` 返回值增加裸注册表（插件工具注册落点，注册-只读视图
  防 execute 绕过审批/沙箱——原 2026-10-21 安全模型原样保留）。
- **eval 评测口径库**（4 文件）：`abMetrics`（pass@k / pass^k / 配对 bootstrap 固定种子）、
  `longMemEval`（LongMemEval-S 本地检索命中，直连 LongTermMemoryPort）、`longTaskCatalog`
  （fail-closed 校验 / 隔离沙箱 / 验证执行 / 自检）、`tracePatchPlanner`（失败→四步补丁计划）；
  执行入口 `scripts/eval/longTasks.mjs`。诚实边界：20 个合成 fixture 未随档幸存，待重建。
- **media 多模态栈**（53 文件）：GIF 全链解码 / PNG 编码 / 媒体嗅探 / 帧采样（零第三方依赖）+
  ffmpeg/ffprobe 适配器 + `view_image`/`view_media` 工具。`MediaStack` 恒装配随种子下行
  （GIF 零外部依赖，视频路径如实降级）；`RuntimeLimits` 声明式补 `media` 段（并发=4）；
  `mediaConfigValidator` 入配置校验链。
- 定位依据见 ARCHITECTURE §7.4（M4 孤儿归档的重裁：中枢 = 完整能力集，孤儿判据不再成立）；
  spark / genesis 维持不迁（experimentalPaths 在案）。

## 0.1.0-alpha.10 — 2026-11-07

### Changed（M21 Phase 3：域生成器解析源对齐承诺清单 + 承诺面 +1，2026-11-07）

- **承诺清单 +1**：`kernel/composition/runtime.js` 入列（app 域生成器黄标实战——B1 给
  `Runtime` 的新家未入 alpha.9 清单，黄标 → `kernel:check` 红 → 按设计倒逼内核扩承诺面；
  251 → 252 条）。该路径本就经 B1 成为 `Runtime` 的唯一家，应用合法消费。
- 应用侧（OmniHarness-app）：域生成器解析源改为「内核承诺清单第一优先 + dist 回退黄标」
  ——现有映射与索引候选都先过承诺过滤；stale 自续（指向已从承诺面消失的路径）在生成期
  即暴露，硬门禁由 kernel:check 的「导入 ⊆ 清单」承担。M21 至此两层全部落地。

## 0.1.0-alpha.9 — 2026-11-07

### Changed（BREAKING：迁移桥显式化，M21 Phase 2，2026-11-07）

- **`package.json#exports` 删除 `"./*.js"` / `"./*"` 通配**——内部路径不再自动公开。
  替代：**251 条显式深路径闭包**（唯一已知消费者 OmniHarness-app 的全部实际导入，
  由 `scripts/exportsClosure.mjs` 从应用源码生成）+ 原有 curated 子路径保留。
- 双向机检防漂移：内核侧（plan:check `m21-explicit-exports`）每条导出必须指向存在的
  dist 产物；应用侧（kernel:check）实际导入必须 ⊆ 显式清单——内核删条目 / 应用新消费
  未列条目，都在 install/CI 期红。
- 兼容性：直接深路径消费本就不承诺兼容（alpha 纪律）；已知消费者仅本应用，已全量
  回归验证。设计见 `docs/RESEARCH-2026-11C.md`（Phase 3 生成器
  解析源对齐仍 open）。

## 0.1.0-alpha.8 — 2026-11-07

> 自 v0.1.0-alpha.7 tag 以来：M19 核心循环韧性 + M20 审计交付编码 + receipts OOP
> Phase A（审计链领域类化）。判据与复盘见 [ROADMAP.md](docs/ROADMAP.md)。

### Added（审计交付编码：压缩 / 口令加密 / 分片，M20，2026-11-07）

- **`AuditDeliveries.encode/decode`**（`@omniharness/kernel/receipts`）：JCS → gzip
  （缺省开，重复性事件流实测 >50% 收缩）→ 口令加密（scrypt N=2^15/r=8/p=1 +
  AES-256-GCM 认证加密）→ 分片（每片独立 sha256）→ `manifest.json +
  part-*.bin`——审计包/披露包从此可经不可信信道与归档场景交付。
- **分层口径**：编码不复核——解码只做传输完整性（分片摘要/字节数/内容摘要/GCM 认证，
  问题码 `AUDIT_DELIVERY_*`），语义复核仍走 `AuditBundles/DisclosurePacks.verify` 同一
  路径；`digest.txt` 对外锚定口径不受编码影响。
- **运行时/CLI 接通**：`kernel.exportAuditBundle(..., delivery?)` 直出交付编码；CLI
  `verifyBundle.mjs manifest.json trust.json --passphrase=…` 零出网复核（+gzip 魔数
  透明解压）；文档 API §1.12 / RECEIPTS §1.6。
- 诚实边界：加密护机密性，完整性与来源仍由签名 + 信任根承担，口令强度是宿主责任。
- 判据：`m20-audit-delivery`；契约 6 例 + embed 1 例；ROADMAP M20（含 scrypt maxmem
  踩坑记录）；迁移桥收窄单独立项决定入决策日志。

### Added（核心循环韧性：任务解决能力一大步，M19，2026-11-07）

- **模型重试与熔断默认开**：`modelRetry`/`modelCircuitBreaker` 修「文档宣称默认开、
  代码 opt-in」矛盾——裸 429/超时不再直接杀死整个 runTask；显式 `false` 才关闭。
- **步级可重试恢复**：可重试模型错误（模型层退避已耗尽）在回合内限额重试 2 次
  （重建上下文重新调用），转录留【模型瞬时错误】痕迹；超限仍走【回合失败】fail-closed。
- **过载降级装配**：`fallbackModel` 从死代码变成活能力——config 字段一键配置，主模型
  529/503 即切备用模型并留痕【模型过载】。
- **毒工具结构化反馈**：同一工具连续失败 3 次（成功清零；门禁拒绝/解析失败不计入），
  下一步上下文注入【工具异常】点名提示 + 错误摘要 + 改道建议——模型不再在坏工具上
  原样重试烧光步预算。
- **工具调用看门狗**：单次 JS 工具执行墙钟上限（缺省 600s，`toolCallTimeoutMs` 可调、
  0 关闭）——挂死且无视取消信号的工具不再冻结整回合，超时补可读失败结果供模型换道。
- **测试债收口**：新增 `tests/unit/loopResilience.test.ts`（9 例：LoopGuard 四检测器 /
  ToolScheduler 并行与屏障 / RetryingModel 分类与取消穿透）+ agentLoopAudit 扩 5 例
  （G/G2/H/I/J）。
- 判据：`m19-loop-resilience`（六项事实全部机检）；复盘见 [ROADMAP.md](docs/ROADMAP.md) M19。

## 0.1.0-alpha.7 — 2026-11-07

> 自 v0.1.0-alpha.6 tag（f362434）以来的全部工作：M8 效率收口 → M9 硬化 → M10 缺口补完 →
> M11 一次接入 → M12–M17 审计闭环 → M18 选择性披露。含 BREAKING：顶层 `AgentFactory`
> 符号位让给 `createOmniKernel`（M11）。判据与复盘见 [ROADMAP.md](docs/ROADMAP.md)。

### Fixed（测试仪器：tamper 判据去随机化，2026-11-07）

- `m11-embed-receipts-persist-tamper` 原以「改签名尾两字符为 AA」制造篡改，但 Ed25519 的
  S 分量已模 L ⇒ 签名末字节高 4 bit 恒为 0 ⇒ base64url 尾两字符以 ~1/16 概率恰为 'AA'，
  篡改退化为空转（存档原样通过复核，fail-closed 判据假警报、verify 间歇红）。改为改首
  字符（完整 6 bit，必然改变解码字节）；内核检出能力经探测实证无损（113/113 真篡改
  全部被拒）。

### Changed（形状守卫收敛为声明式 schema，2026-11-07）

- 新增内部件 `src/kernel/util/shapeGuard.ts`：极小组合子集（`objectOf` / `arrayOf` /
  `literal` / `matching` / `optional` / `nullable` / 叶子判定），校验策略表达为**数据**；
- 审计链五处手写形状守卫（auditPack 回执信封 / auditBundle / disclosurePack /
  executionCertificate / executionGraph）全部迁移为 schema 声明——检查语义全仓一个
  执行点，读 schema 如读类型；行为不变（判定语义由既有契约判据钉死），组合子直接
  用例见 `tests/unit/shapeGuard.test.ts`。

### Added（选择性披露：最小披露仍可验，M18，2026-11-07）

- **`buildDisclosurePack` / `signDisclosurePack` / `verifyDisclosurePack` /
  `disclosurePackDigest`**（`@omniharness/kernel/receipts`）：只交子集事件仍可离线
  复核的最小披露交付物——每条披露事件附 M14 包含证明锚回证书 Merkle 根，未选事件
  不出包，回执链裁剪到证书绑定的必需前缀（第 1 条到最大绑定条数）。
- **`kernel.exportDisclosurePack([{sessionId, indices}], directory?)`**：一次接入路径
  同步开放，落盘 `disclosure.json + trust.json + digest.txt`；CLI
  `scripts/verifyBundle.mjs` 按包内 `kind` 自动识别审计包/披露包。
- 判据：`tests/contract/disclosurePack.test.ts`（6 例：roundtrip / 最小化 / 篡改矩阵
  7 项 / 回执前缀 / 签名语义 / 叶子不变式）+ embed 内核级 1 例 +
  `tests/property/disclosurePack.property.test.ts`（2 条属性）；ROADMAP
  `m18-selective-disclosure`。

### Added（审计包运行时闭环，M17，2026-11-06）

- **`kernel.exportAuditBundle(sessionIds, directory?)`**：逐会话取事件、签发执行证书
  （绑定全局回执链当前尾）、打包、整包签名，落盘 `bundle.json + trust.json + digest.txt`；
  返回 `{directory,bundlePath,trustPath,digestPath,digest,signed}`。
- **链作用域修正**：回执链是 issuer 单链跨会话共享；证书绑定「签发时链尾前缀」，
  复核在全局链按 `receiptCount` 取第 count 条比对 `tailHash`，不再按会话过滤回执
  （过滤会破坏 `previousReceiptHash` 连续性）。
- 判据：embed 契约单会话 + 多会话同 issuer 链两例；`verifyAuditBundle` 复核通过；
  `m17-runtime-audit-bundle`。

### Added（审计包：单文件离线交付，M16，2026-11-06）

- **`buildAuditBundle` / `verifyAuditBundle` / `signAuditBundle` / `auditBundleDigest`**
  （`@omniharness/kernel/receipts`）：把「事件流 + 执行证书 + 回执链 + 执行图」打成一个
  可交付 JSON，一次复核四层——事件完整性/顺序/条数、回执链尾绑定（含验签）、执行图
  （节点/委派锚定/单根无环）、整包签名；逐层问题码可读。
- **离线 CLI**：`node scripts/verifyBundle.mjs bundle.json trust.json`（零出网；
  0=通过 / 1=复核失败 / 2=输入非法）。
- 判据：`tests/contract/auditBundle.test.ts`（4 例：roundtrip / 事件篡改 / 回执篡改+重复会话 /
  图缺失 / 签名伪造）；研究底稿 §9；ROADMAP `m16-audit-bundle`。

### Added（执行图谱系：多智能体可验证，M15，2026-11-06）

- **`ExecutionGraph`**（`@omniharness/kernel/receipts`）：节点 = 每次运行的执行证书，
  边 = 父会话在哪个事件里委派了子会话（可锚定 `delegationEventHash`）；整图签名。
- 离线复核 `verifyExecutionGraph`：逐节点重算证书、逐边锚定父事件（哈希 + 子会话 id）、
  结构单根/无环/单父（Kahn）、图签名（无信任根如实标 `UNPROVEN_ORIGIN`）。
  多父 / 环 / 多根 / 委派哈希错位分别返回可读问题码。
- 判据：`tests/contract/executionGraph.test.ts`（4 例）+ 属性
  `tests/property/executionGraph.property.test.ts`（随机树/删边/加环/改事件）；
  研究底稿 [RESEARCH-2026-11B.md](docs/RESEARCH-2026-11B.md) §8；ROADMAP `m15-execution-graph`。

### Added（执行证书：运行级可复核，M14，2026-11-06）

- **事件 Merkle 树**（`@omniharness/kernel/receipts`）：JCS 规范化叶子 + 域分离哈希 +
  奇数上提（不做末项复制，避免 `eventCount` 歧义）；`proveEventInclusion` /
  `verifyInclusion` 支持**单事件溯源**（无需交出整份日志）。
- **执行证书** `buildExecutionCertificate` / `signExecutionCertificate` /
  `verifyExecutionCertificate`：绑定 `{sessionId, eventCount, eventRoot}`，可选绑定
  回执链尾 `{issuerId, receiptCount, tailHash}` 与工具面摘要；签名对 `JCS(cert)`，
  收证方凭信任根离线验签。篡改/删改/换序/跨会话/换回执尾分别返回可读问题码。
- **研究底稿** [docs/RESEARCH-2026-11B.md](docs/RESEARCH-2026-11B.md)：问题、构造、
  安全论证、10k 事件实测（建树/证书约 0.8–0.9 s，单条验证 ~0.5 ms）、明确未做
  （witness 网络 / 公共透明日志 / 零知识选择性披露）。
- 判据：`tests/contract/executionCertificate.test.ts`（5 例）+ 属性
  `tests/property/merkleCertificate.property.test.ts`（5 属性）；ROADMAP `m14-execution-certificate`。

### Added（数学覆盖二期：调度 / 估算 / 覆盖率 / 回执并发，M13，2026-11-06）

- 属性测试从 5 文件 / 20 属性扩到 **9 文件 / 32 属性**（零第三方依赖、固定 seed、失败按
  `seed+trial` 复现）：
  - `fairScheduler`：等权会话服务量差额 ≤2、并发 ≤ limit、统计自洽、排队取消不占调度；
  - `tokenEstimator`：追加字符单调不减、消息列表 = 逐条之和、消息开销恒定、缓存不改变结果；
  - `rewardCoverage`：samples/verified/coverage 自洽、轮次差分可加、探针异常归不可验证；
  - `receiptsConcurrency`：异步 signer 下任意 N 并发 seq 连续/前驱成链，任意时刻摘要 = 链尾。
- [docs/MATH.md](docs/MATH.md) 覆盖矩阵同步（新增 4 行）；SFQ 从「示例级判据」升级为属性判据，
  仍不声称 regret/偏差界的证明。

### Added（架构图谱 + 数学不变量，M12，2026-11-06）

- **架构机检**：`npm run arch:check`（`scripts/archCheck.mjs`）——运行时依赖图 Tarjan SCC
  无环（`import type` 不计）、跨层边规则（contracts 叶子 / protocols 单一支撑面 /
  kernel→protocols 仅 `adapters/mcp` 与 `composition`）、[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)
  依赖快照与代码一致（`npm run arch:update` 重新生成）；已并入 `npm run verify`。
- **契约层收口**：`OmniError`/`ErrorCode` 与 `API_VERSION` 迁到 `contracts/`，根
  `src/omniError.ts` / `src/version.ts` 保留兼容再导出——消除 `contracts → 根入口`
  回指（运行时边），依赖图上的契约层成为真正叶子。
- **数学不变量**：新增零依赖确定性属性测试骨架 `tests/property/harness.ts`（mulberry32 +
  固定 seed + 失败定位到 seed/trial）；5 文件 / 20 属性覆盖 JCS（幂等/键序/良构/数字）、
  0/1 背包（与暴力枚举最优值对拍/可行性/确定性）、UCB1（冷启动/夹取/确定性/记账）、
  BM25（批量等价/词频单调/增量替换/排序）、哈希链与事件日志（确定性/前缀/水合/越界）。
- **诚实边界**：[docs/MATH.md](docs/MATH.md) 给出覆盖矩阵与三层口径（形式证明 / 属性测试 /
  示例判据），明确「属性测试不是证明」，并列出未覆盖项（形式化验证、regret 界、浮点误差界等）。
- 判据：ROADMAP `m12-arch-graph` / `m12-math-invariants`。

### Added（一次接入全部能力：顶层 `createOmniKernel`，2026-11-06）

- **`createOmniKernel(options)`**（顶层第 60 个符号；完整选项/句柄类型经
  `@omniharness/kernel/embed`）：把「宿主真正用起来」所需的胶水收进内核一次——主循环、内置
  工具/记忆/技能/计划/检索、工作台 HTTP/SSE、MCP 客户端（`config.mcpServers`）、MCP 服务端
  发布（`mcpServe`，缺省关）、长期运行遥测（`telemetry`，缺省关）、回执链（每次工具调用
  自动入链 + Ed25519 签名）一次装配；文件型存储还会自动扫描历史会话（工作台重启后侧边栏
  仍在）；宿主只留 6 行（`examples/embed.mjs`）。此前这些接线要每个宿主各写一遍
  （应用仓库的生成式对接面 + 122 文件 `kernel-compat` 的成因）。
- **BREAKING（顶层符号位交换）**：`AgentFactory` 移出顶层（下沉为内部件；`new Agent(runtime)`
  等价，且它从未被公开文档外的消费者使用），第 60 位让给 `createOmniKernel`；需要按运行时
  造 Agent 的调用方改用 `Agent` 构造器。`scripts/api-golden.json` 同批更新。
- **可核对的「全部能力」外形**：`kernel.capabilities()` 实时回答工具数 / 工作台地址 / 回执
  条数 / MCP 工具 / 审批 / 沙箱 / embedding / evolution / native / telemetry，不靠读代码猜。
- **安全默认不放宽**：模型缺省 `MockModel`（零凭据演示，且**不**读本机凭据）；审批缺省仍是
  `DenyApproval`、沙箱仍是 OS 隔离探测；工作台回环 `127.0.0.1:0`；MCP 未配置零连接。
- **生命周期收口**：`close()` 幂等，按「取消在跑回合 → 关 MCP → 落回执 → 冲刷事件 → 关工作台」
  顺序释放；`config` 透传任意 `OmniHarnessConfig` 字段，新增内核能力不需要同步改接入接口。
- **审计闭环（回执跨重启）**：`receipts.persist` 把回执链落到 `<workspace>/.omniharness/receipts/
  <issuerId>.jsonl`（append-only）并持久化 Ed25519 私钥（0600）；重启时 `ReceiptChain.adopt`
  逐条校验同 issuer / seq 连续 / 前驱相接后**续写不分叉**，启动即用 `verifyAuditPack` 复核既有链。
  坏行 / 断链 / 签名被改 / 有签名历史但密钥丢失 / 已签名链上 `sign:false` 一律 fail-closed。
  判据：`tests/contract/embedOneCall.test.ts` 的 `m11-embed-receipts-persist*`。
- **运行级执行证书接入**：`receipts.certificates` 在每个 `runTask/resume/fork` 结束后自动签发并
  落盘 `{certificate, signature}`（事件 Merkle 根 + 回执链尾 + 工具面摘要）；也可显式
  `kernel.certificate(sessionId)`。收证方用 `verifyExecutionCertificate(events, signed, {trustStore, receipt})`
  离线复核；改事件/删事件/换顺序/链尾不符均可检出。判据 `m11-embed-execution-certificate`。
- **审计三件套导出**：`kernel.receipts.exportBundle(dir?)` 一次写出 `pack.json` +
  `trust.json` +（有签名时）`summary.json`，第三方可直接用 `verifyAuditPack(pack, trust, summary)`
  或独立实现 `scripts/verifyReceipts.mjs` 离线复核；尾条被改/删由摘要的 `EXPECTED_MISMATCH` 检出。
  判据 `m11-embed-audit-bundle`。
- **单文件审计包接入（M16）**：`kernel.exportAuditBundle([sessionId])` 一次写出
  `bundle.json`（事件 + 执行证书 + 回执链，整包签名）+ `trust.json` + `digest.txt`；
  收证方用 `verifyAuditBundle(signed, {trustStore})` 或 `scripts/verifyBundle.mjs` 零出网复核；
  改事件/改回执/换证书/伪造签名全部 `ok:false`。判据 `m11-embed-full-audit-bundle`。
- 判据：`tests/contract/embedOneCall.test.ts`（工具回合 + 工作台投影 + 审计包真实验签 +
  MCP 客户端连接/反注册 + MCP 服务端健康与关端口 + 事件扇出 + 未签名语义 + config 透传 +
  非回环无令牌 fail-closed）；`m11-embed-minimal` 机检示例只经顶层、≤60 行、只调一次
  `createOmniKernel`；示例 `examples/embed.mjs`；文档 `docs/API.md` §1 / README 快速开始。

### Hardened（M10 缺口补完：取消传播 / 尾摘要签发 / mcpServers 装配，2026-11-06）

- **取消传播真正生效**：工具执行器与 `ToolContext.signal` 竞速（`StepToolExecutor.raceAbort`），
  用户停止不再等 60s 工具自然结束；`ToolScheduler` 穿透 `CancelledError`（不再吞成 failed
  ToolResult）；`ask_user` 等待期取消会清理 `WorkbenchHub` 挂起提问并释放会话锁；取消原因
  （`user`/`timeout`/`custom`）原样透传，不再折叠。
- **回执尾条可信摘要（签发侧）**：`ReceiptChain.summary()` 产出 `{issuerId, receiptCount, tailHash}`，
  `signSummary()` 用回执同一 signer 对 `JCS(summary)` 签名；`verifyAuditPack(pack, trustStore,
  signedSummary)` 验签并比对条数与尾哈希——尾条被改/被删由 `EXPECTED_MISMATCH` 检出，改摘要
  由 `SIGNATURE_INVALID` 检出；无 signer 时拒绝签发（不产出「看起来像承诺」的对象）。
- **`config.mcpServers` 真正装配**：字段进入 `OmniHarnessConfig`/`ResolvedConfig` 并由
  `ConfigFactory` 透传；新增 `startMcpServers(runtime)`（`@omniharness/kernel/mcp`），缺省用
  `SdkMcpConnector`（stdio / Streamable HTTP+SSE）逐台连接，经 `McpGateway` 把远端工具注册进
  工具面，`close()` 反注册；`auth` 的 bearer/oauth 令牌由 `McpAuthProvider` 真正变成
  `Authorization` 头（缺失即 fail-closed，不发匿名请求）。MCP 客户端栈因此从零入边转为可达。
- 判据：`tests/contract/cancellationPropagation.test.ts`、`receiptSummary.test.ts`、
  `mcpServersWiring.test.ts`、`tests/unit/mcpAuthProvider.test.ts`；ROADMAP M10 三条判据。

### Hardened（M9 硬化收口：接线审计 / 毛边 / 压力，2026-11-06）

- **接线审计有了机检**（`npm run wiring:check`，并入 verify 与 `plan:check`）：可达性图从
  「只从 `src/index.ts` 起算」改为**全部 8 个公开入口为根**——旧口径把 7 个子路径入口整棵判成
  死代码（127 文件 / 19,858 行），修正后为 42 文件 / 8,303 行；每个「src 内零入边且入口不可达」
  的模块必须在 [docs/WIRING.md](docs/WIRING.md) 逐条落账（接线/入口/内部保留/删除），
  文档引用的源码路径必须真实存在。
- **声明未接线修复**：README「哈希链化遥测 / 晋升台账可复核」的实现（`JsonlRuntimeTelemetry`、
  `PromotionHistoryService`、`HashChainPromotionLedger`）接进 `governance` 子路径；隔离阶梯
  `IsolationLadder` + 内置 wasm 执行器接进 `sandbox`；MRTR 三个 handler 接进 `mcp`，
  `McpHttpAssemblyOptions.inputRequired` 提供注入口（缺省关闭，显式接线才产生 `input_required`）。
- **毛边打磨（16 条回归判据）**：
  - 回执链 `append` 在异步 signer/anchor 下**并发分叉**（8 个并发全部拿到 seq 1）——队列队尾
    现在真正前移；此前 100 并发「零分叉」判据只测了同步路径，是假绿；
  - 工作台：非法 request-target 不再让进程因未处理拒绝退出（400）；`http.port` 真正生效
    （旧实现硬编码 `listen(0)`）；SSE 回放期重复投递去重 + **8 MiB 背压上限**（慢/挂起客户端
    不再无限占内存，超限断开由 EventSource 带 `Last-Event-ID` 续传）；`/answers` 校验回答 id
    与挂起问题精确匹配（错位/过期/重复 409，非法形状 400）；`decodeURIComponent`/null body/
    畸形审计包统一 400；`close()` 幂等；
  - `verifyAuditPack` 对畸形包 fail-closed（`MALFORMED_PACK`，不再抛裸 TypeError），并新增可选
    第三参 `{receiptCount, tailHash}`：线性链自身无法检出尾条被改/被删（没有后继绑定它），
    带外可信摘要给出时以 `EXPECTED_MISMATCH` 检出；
  - `MemoryStorage.append` 桶缺失时不再静默丢事件；`JCS` 孤立代理项按 `JSON.stringify` 转义
    （不再产出非法 UTF-8），非纯 JSON 对象（Date/Map/类实例）fail-closed；
  - MCP：CORS 预检免鉴权（浏览器 Bearer 客户端不再在预检阶段 401）、显式 `corsOrigin` 真正
    通过 Origin 防线；`McpServeRunner` 回退路径不再丢掉调用方的 `gate`（stdio 工具不再无审批）；
    `McpHttpAssembly` 使用 `runtime.gate`（计划态 / supervisor / RBAC 不再被外部调用绕过）；
  - 1,800+ 层嵌套工具参数不再让 `LoopGuard` 抛 RangeError 打崩整轮（深度上限 + 兜底）；
  - `sessionId` 空串与字面量 `_` 不再共用同一个存档文件，超长 id 报可行动错误。
- **压力/全面测试**：`tests/stress` 三文件 9 用例（20k 事件日志、40 会话 JSONL、350 回执链、
  20 并发 SSE、100 状态投影、1 MiB 请求体边界、200 步会话、8 并行工具、10 MiB 载荷），
  `npm run stress` 并入 `npm run verify`（独立 `vitest.stress.config.ts`，不拖慢 `npm test`）。
- **清账**：12 个零引用、零判据、注释指向已删模块（plugin / SDK / A2A / 应用层）的文件删除；
  `m4-zero-inbound` 改用「全部入口」口径。公开面不变（60/60）。

### Polished（M8 效率与内存收口：先测量后优化，2026-11-06）

- **仓内基准 harness**（`npm run bench`）：五探针 + 归因矩阵 + 冷热分离 + 内存滞留中位数采样，
  内核自身效率与内存从此可复现量化（此前历史性能结论全部引用仓外已删目录，不可复现）；
- **每步序列化短路三连**：前缀指纹 toolCalls 身份键缓存（**14.2×**）、工具 schema 序列化
  统一走 `schemaTextOf` 身份缓存（**137×**）、压缩游标引用相等短路（快路径零编码）——
  e2e 150 步会话热稳态 **1.08 → 0.74–0.86 ms/步（−20~−31%）**；
- **事件日志失效即重建快照**：`SessionRecorder.allEvents()`（每步 5+ 次全量读取扇出点）
  从每步 O(n) 浅拷贝改为 O(1) 引用返回（6000 事件稳态 **226×**）；快照冻结（fail-closed），
  `all()` 公开契约不变；
- **TokenEstimator 单例共享**：容量分解器与压缩器两套并行缓存栈合一，原生下沉单一事实源
  （内存收益≈噪声，如实记录；保留理由是消冗余与口径统一）；
- 调研底稿 [docs/RESEARCH-2026-11.md](docs/RESEARCH-2026-11.md)：静态分析与实测的偏差
  诚实记录——「4-6 份转录副本」被加固后的仪器证伪大半（真值 2.04×；首版 5.1× 是首跑
  混入语料索引的仪器污染）；冷索引 3.1s 一次性成本是全程最大单项，P3 五项按
  「实测过关才做」全部不做（理由逐条在案）。公开面不变（60/60），判据 `m8-*` 五条入账。

## 0.1.0-alpha.6 — 2026-11-04

> v0.1.0-alpha.6 tag（f362434）交付内容：M0–M6 + M4 + 对接参考文档。2026-11-05 起被应用
> vendored 钉版；2026-11-06 之后的增量（M8–M18）记入上方 alpha.7。

### Polished（工作台桥接层上线加固，同日第二遍打磨）

- `close()` 在有活跃 SSE 时**挂死**（node:http 的 close 等连接）→ 追踪并优雅结束全部活跃流；
- 跨端口浏览器 UI 需要 CORS → 回环回显默认（同 MCP 端口径）+ `corsOrigin` 收紧 + OPTIONS 预检免鉴权；
- EventSource 无法设头 → `?from=<seq>` 首连接续传 + `retry: 3000` 重连提示（`?token=` 鉴权口径写进 README）；
- 请求体无上限（DoS 面）→ 1 MiB 上限 413（drain 后回包，非 destroy）；坏 JSON 400 不落 500；路径命中方法不对 405；
- 长任务期间投影像卡死 → 进行中工具调用呈现 `pending: true`（结果到达自动消失，仍逐字节确定）；
- 历史会话侧边栏 → `discoverSessions` 钩子并入 `GET /api/sessions`（fail-soft 不 fail-silent）。

### Added（工作台桥接层，m6-workbench-bridge）

- **`@omniharness/kernel/workbench` 子路径**：把「UI 只做呈现」所需的全部内核侧设施一次备齐——
  - `WorkbenchHub`：`EventPort`（按会话扇出 + 全量直播缓冲 + 会话注册表）与 `UserResponder`
    （提问桥：`ask_user` 挂起 → HTTP 回答 → await resolve）双端口合一；
  - `WorkbenchServer`：SSE 事件直播（`Last-Event-ID`=seq 断线续传、15s 心跳）、`/state`
    一次投影快照、`/answers` 回答端点（409 防重放）、`/api/audit/verify` 审计复核；
    Bearer/`?token=`/cookie 鉴权，非回环绑定强制令牌（复用 `ServerAuthGuard`）；
  - `projectSession`：事件流 → 视图状态（消息流/reasoning 挂接/工具结果配对工具名/待办/计划/
    用量/回滚墓碑/挂起提问）的**确定性纯函数**，前端零事件语义知识。
- `examples/workbench.mjs`：端到端演示——3 行接线 → 脚本模型调 `ask_user` → 假浏览器经 SSE
  收帧、经 state 发现挂起提问并 POST 回答 → 模型拿到真答案完成回合 → 审计复核。
- 公开面不变（60/60，golden 一致）；判据 `m6-workbench-bridge` 入 M6 状态账。

### Docs（对接参考与浏览器投影收尾）

- **`docs/API.md` 全量对接文档**：包结构与子路径分工、最小 headless 接入、工作台 HTTP/SSE
  全量协议（鉴权/CORS/状态码/续传/心跳）、浏览器三种完整用例（会话 hook、提问弹窗、审计页）、
  `WorkbenchState`/`WorkbenchMessage`/`SessionEvent` 字段表、自定义 `ModelPort`/`ToolPort`、
  回执签发与离线复核；每条签名以源码为准（`runTask` 的第 4 参只给新会话命名，续跑用
  `agent.resume`——误把既有 id 交给 `runTask` 会用新事件流覆盖旧存档）。
- **`@omniharness/kernel/workbench-view` 子路径**：`projectSession` / `mergeEvents` 的浏览器
  安全出口（零 `node:`、零 I/O、可直接打包）；`workbenchViewPurity` 判据递归检查 re-export
  运行时图，`view:check` 在 build 后复核 `dist` 产物同一边界。

## 0.1.0-alpha.5 — 2026-11-04

> 执行 `docs/PLAN-2026-11.md`：M4 切片 → M5 立信 → M6 通电。
> 依据 `docs/AUDIT-2026-11.md` 的盘点事实。完整归档：git tag `attic/2026-11-03`。

### Added（M5 立信）

- **RFC 8785 JCS 规范化**（零依赖，7 条附录向量逐字节一致；NaN/Infinity fail-closed 抛错）。
- **动作级签名回执链**：`{payload, signature, anchors}` 三键信封、`SHA256(utf8(JCS(payload)))`
  链式哈希、单 issuer 单线性链、并发追加互斥序列化（100 并发零分叉）。
- **锚定**：jose Ed25519 签名（裸 payload 字节）+ RFC 3161 TSA 客户端（手写最小 DER TSQ，
  可注入 fetch）；无 TSA/无网如实 `anchors: []`，绝不为凑数伪造锚。
- **离线独立复核器**：`verifyAuditPack`（kernel）+ `scripts/verifyReceipts.mjs`（**独立实现**
  JCS/SHA-256，不 import 内核——第三方可离线复核的可行性证明）。零出网；`ok`（链结构）与
  `compliant`（合规档）分层；篡改四类（改 payload / 删首条 / 换锚 / 重排）全部可检出且失败码可读。
- `docs/RECEIPTS.md`：与 IETF draft-marques-asqav-compliance-receipts 逐字段映射 + 未实现项清单
  （保留期 / witness quorum / counterparty binding / CMS 完整验证）。

### Added（M6 通电）

- **provenanceIssuer 提公开面**（`@omniharness/kernel/governance`）：出证/复核经公开入口可用；
  `examples/audit-pack.mjs` 端到端演示（产出 → 复核 → 篡改检出 → 出处证书）。
- **MCP HTTP 服务端通电**（`@omniharness/kernel/mcp`）：`McpHttpAssembly` 经组合根装配
  2026-07-28 无状态服务端；外部 MCP 调用与本地同过审批/沙箱门禁；端到端用例真实起服断言。

### Changed（行为，均有负例测试）

- **缺省审批 = 缺省拒绝**：未注入 `approvals` 落 `DenyApproval`（旧缺省 `AutoApproval` 全放行）。
- **缺省沙箱 = 探测 OS 级隔离**：Landlock / Windows 原生写隔离可用即用之；探测不到落回
  `PolicySandbox` 并**显式告警**（黑名单不是隔离）；`OMNI_SANDBOX_STRICT=1` 时探测失败即拒绝启动。
- **并行工具事件按模型调用序落盘**（此前完成序——重放不可字节复现）。
- **压缩确定性重建**：LLM 摘要路径整体移除；产物 = 任务目标（user 原文摘录）+ 历史经过 +
  确定性工具台账 + 交接便签——同输入逐字节同输出、零模型调用、不可降级；user 请求不再可能被压丢。
- `rollback` 不再擦自己的历史：截断后落自包含 `rollback` 墓碑事件（旧实现留悬空 tool_result → 厂商 400）。
- **"无损收缩"名副其实**：`collapseBlankLines`（删行尾空白/压空行）从收缩管线移除——它会在模型
  看到之前改写补丁上下文；`compress()` 里降为显式 opt-in。
- MCP capability 诚实：删除指向从未实现的 `resources/subscribe` 处理器的声明（2026-07-28 订阅走
  `subscriptions/listen`）。

### Removed（M4 切片；完整归档 `attic/2026-11-03`）

- `protocols/a2a` 整树（贴 v1.0 标签的 v0.3 线格式）、隐喻算子栈（共振场/QEC/免疫/信念/退火/
  CRISPR/固化/刻蚀/元素/对称破缺/禁闭/涡环 + 燧编排 + Genesis 桥）、`kernel/plugin`、
  `kernel/media`、`kernel/asset`、`kernel/eval` 长任务目录、`context/rankVeto`、80+ 零引用孤儿。
- 依赖：`openid-client`（零 import）、`croner`（唯一消费者已删）；`sharp`/`unpdf`/`@huggingface/transformers`
  随媒体栈移除；`yaml` 升为直接依赖。
- 配置键：`resonantField`/`memoryAnnealing`/`qec`/`immuneMonitoring`/`belief`/`skillEditing`/
  `capabilityCrystallization`/`insightEtching`/`elementComposer`/`symmetryBreaking`/`confinement`/
  `vortexRing`/`genesis`/`sparkAutoRun`/`a2a`/`media`。

### Changed（门禁与证据层）

- 证据层修复：上游判据回迁 40 件（414→436 用例）；12 件降级 `L0-unverified`（注明恢复路径）；
  新门禁 `maturity:check`（L1+ 必带证据，机检）。
- 门禁加固（四个绕过各配**变异判据**）：双语引号 import、protocolsSupport 精确匹配、
  `export * as` 展开计数、人工复核记录限定 §6 且 id 必须存在；`contracts` 零 `node:` 内建（规则 6）。
- **API golden 快照**：公开符号增删/改名必须显式 `--update-golden`；顶层 60/60。
- 工具类导出下沉 `@omniharness/kernel/tools`；新增子路径 `receipts`/`sandbox`/`governance`/`mcp`。
- `tests/` 纳入 typecheck（`tsconfig.test.json`，修出 21 处潜伏类型错误）。

### BREAKING

- 公开面 60 符号重排（工具类/receipts 类型面移子路径）；顶层新增回执核心 6 符号。
- 上述配置键与子路径 `dist/protocols/a2a`/`dist/kernel/{spark,genesis,media,plugin,asset,eval}` 消失。
- 缺省审批/沙箱语义见上；依赖缺省放行或黑名单口径的调用方需显式注入。

## 0.1.0-alpha.4 — 2026-11-03

### Added

- **子路径导出（迁移桥）**：`exports` 增加 `"./*.js"` / `"./*"` → `dist/*`，让第一个消费者
  OmniHarness 在**公开面迁移期**按内部模块路径接入（应用仓库已删掉 143,883 行重复内核副本）。
  **不是兼容承诺**：顶层仍是唯一稳定面（59 / 60）；子路径随迁移完成即删除，见 BOUNDARY「迁移桥」。

### Changed

- 无公开面变化；版本 `0.1.0-alpha.4`。

## 0.1.0-alpha.3 — 2026-11-03

**应用形状清零**（第二遍收口：把「不属于内核」的残留整棵子树删掉）。公开 API 不变（59 / 60）。

### Removed

- `contracts/ports/tui/`、`contracts/ports/license/`、`contracts/ports/server/audit{Format,Query}.ts`、
  `contracts/ports/enterprise/`、`kernel/adapters/enterprise/`、`kernel/security/oidcClient.ts`、
  `kernel/sdk/sdkClient.ts`、`contracts/schema/codeGenerator.ts`、`defaults/cliHelp.json`。
  合计 **19 文件 / 约 2.5K 行**，逐项确认零引用（`tsc` + 29 文件 170 用例为裁判）。
- 以上均不在公开面，`api:check` 仍为 59 / 60。

### Changed

- `docs/BOUNDARY.md` 新增「应用形状清零」节；`compat/` 表里 `oidcClient` / `sdkClient`
  的去向从「下沉内核」改为「删除」（下沉只保证能跑，不保证只剩内核）。

### Known issues

- **未执行 `npm publish`**（无发布凭据）：`npm pack` + 空目录安装 + headless 已跑通；
  正式发布需先 `npm login` 或提供 `NPM_TOKEN`。

## 0.1.0-alpha.2 — 2026-11-03

**beta 硬化（M3）落地**。公开 API 面不变（59 / 60），但 `decisionEngine` 有 alpha 破坏性变更。

### Added

- **契约测试扩容**：新增 `tests/contract/` —— 审批语义 13 例、沙箱语义 8 例、门禁接线 6 例；
  原三份契约用例（事件顺序 / 回放 / 压缩）同目录归位。共 **6 文件 32 例，只经公开入口**。
- `tests/unit/decisionEngineInjection.test.ts`（3 例）：钉住「配置了引擎却没实现 ⇒ 构建报错」。

### Changed

- **`adapters/laya` 移出内核**（9 文件 + `decisionEngineResolver` + Python 资产）：第三方 venv
  绑定不属于通用内核面，实现回到应用仓库。内核保留 `DecisionEngineConfig` 并新增注入缝
  `decisionEnginePort`；`mode` 非 `off` 却未注入实现时 `ConfigFactory.build` **直接报错**
  （此前会静默 new 出 Laya 实现）。
- `@beta` 组从四组 18 文件收敛为**三组 9 文件**（`user` / `monitoring` / `live`），
  裁决标记与「不进公开面」纪律不变。
- **测试总数 25 文件 / 140 例 → 29 文件 / 170 例**；`plan:check` 的 `m3-contract-coverage`
  由人工判据改为机检（`tests/contract` ≥30 例），`m3-adapters-beta-marked` 口径 18 → 9。

### Known issues

- **未执行 `npm publish`**（无发布凭据）：`npm pack` + 空目录安装 + headless 已跑通；
  正式发布需先 `npm login` 或提供 `NPM_TOKEN`。

## 0.1.0-alpha.1 — 2026-11-03

**规划闭环 + 发布就绪**。公开 API 面不变（59 / 60）。

### Added

- **唯一规划源** `docs/ROADMAP.md`：里程碑 M0–M3、判据表（auto / manual）、人工复核记录、
  发布记录、决策日志；「下一版做什么」不再散落在 BOUNDARY 的一句话里。
- **规划对账门禁** `scripts/planCheck.mjs` + `npm run plan:check`（已并入 `npm run verify`）：
  状态账与代码事实**双向**对账——标 ✅ 必须判据全过，标 ⏳ 必须至少一条不过
  （既防提前记账，也防做完不记账）。
- **公开面计数单一实现** `scripts/publicSurface.mjs`：`apiSurface.mjs` 与 `planCheck.mjs` 共用，
  避免两处数字漂移。
- **CI** `.github/workflows/verify.yml`：`ubuntu-latest` + `windows-latest` 双平台跑
  `npm ci → npm run verify → node examples/headless.mjs`。
- **发布元数据**：`private: false`、`publishConfig.access: public`、`files[]` 收入
  `docs/ROADMAP.md`。

### Changed

- `docs/BOUNDARY.md` 的「下一步」移交 ROADMAP；本文件只保留**已经发生**的变更，
  发布记录只写「就绪」与「已发布」中真正发生的那一个。
- README 增加规划入口与 `npm run plan:check` 说明。

### Known issues

- **未执行 `npm publish`**（无发布凭据）：`0.1.0-alpha.1` 处于「发布就绪」，
  `npm pack` + 空目录安装 + headless 已跑通，见 ROADMAP §7。

## 0.1.0-alpha.0 — 2026-11-02

首次以「独立内核」形态收口。**不承诺兼容**（alpha）。

### Added

- **独立组合根** `kernel/composition/runtime.ts`：`Runtime.createRuntime(config)` 可在任意 Node
  进程里装配 `Agent`，不再依赖应用层 `apps/composition`。
- **公开入口** `src/index.ts`：58 / 60 个符号（`npm run api:check` 机检），
  覆盖组合根、主循环、端口与默认适配器。
- **契约测试** `tests/`：22 文件 / 135 用例，只依赖 `src/` 与 Node 内置；
  含一次「只经公开入口」的 headless 回合。
- **20 行 headless 示例** `examples/headless.mjs` 与 `npm run smoke`。
- **构建资产复制** `scripts/build.mjs`：`dangerous-commands.json`、worker mjs、laya py
  随 `dist` 发布（此前 `tsc` 不搬运，运行期 ENOENT）。
- **独立安装** `package-lock.json`；`node_modules` 不再是应用仓库的 junction。
- **`npm pack` 冒烟**：空目录安装 tarball 后可直接跑通 headless。

### Changed

- `src/compat/` 10 个「从应用借来的共享件」全部下沉：
  - `jsonRpc` → `kernel/rpc/`
  - 行传输 / WebSocket 编解码 → `kernel/transport/`
  - `serverAuthGuard`、`oidcClient` → `kernel/security/`
  - `safeFs`、`serveInstance` → `kernel/util/`
  - `serviceKeys` → `kernel/composition/`
- `contracts/sdk/sdkClient.ts` → `kernel/sdk/`（契约层不放实现）。
- `TuiRenderer` 删除：内核只保留 `ConsoleLiveView` 需要的两个纯 ANSI 片段。
- **契约反向依赖清零**（依赖规则 1 归零）：限制类型族（`RuntimeLimitsConfig` 等 10 个接口）
  与 `Spectrum` 下沉 `contracts/ports/`；A2A 协议数据（`a2aProtocol` + `TaskHandler`）移入
  `contracts/ports/a2a/`，新增 `A2aServerPort` / `A2aClientPort` 端口，
  `OmniHarnessRuntime.a2a` 只认端口（实现类在 protocols 侧 `implements`）。公开面 58 → 59。
- **协议穿透收口**：`protocols` → `kernel` 的 76 条散点 import 收敛为唯一支撑面
  `kernel/protocolsSupport.ts`（30 个文件改走该边，纯 re-export 零逻辑，只导出实际消费符号）；
  新增 `npm run boundary:check` 分层边界机检（fail-closed，四条规则），
  首跑即抓出 `kernel/adapters/mcp` → `protocols/mcp` 的 5 处存量穿透并声明为窄例外。
- **适配器归属裁决**（授权自主裁决）：`adapters/laya`（厂商绑定，待移出）、`adapters/user` /
  `adapters/monitoring` / `adapters/live`（端口默认实现，保留）四组共 18 文件标 `@beta`，
  处置理由与迁移路径记入 `docs/BOUNDARY.md`；组内符号不进公开面（api:check 把守）。
- **机检收口**：`boundary:check` 升至五条规则（新增规则 5「契约纯净」——contracts 只许相对
  路径导入，零 `node:` 内置、零第三方包）；新增 **`npm run verify`** 一键机检入口
  （typecheck + boundary:check + test + build + api:check）；README / BOUNDARY 同步终态
  （公开面 59/60、25 文件 140 用例、机检入口与裁决记录）。
- **契约测试扩容**（22 → 25 文件 / 135 → 140 用例）：
  - 事件顺序：`session_meta` 首条、`seq` 严格递增、`tool_result` 永不先于 `tool_call`、
    数量守恒、最终答案在最后结果之后、端口所见 = 存储落盘；
  - 会话落盘回放：JsonlStorage 跨实例（重启模拟）往返一致、`replay` 不改写历史、
    `resume` 历史严格前缀 + `seq` 延续；
  - 压缩不变量：确定性无损收缩只动空白且幂等、折叠后工具轮配对（无孤儿 tool / 无悬空
    toolCall）、前导 system 原样钉住。
- 清理最后一个再导出别名：`kernel/adapters/tool/toolHandler.ts` 删除，5 个引用方直连
  contracts（`ToolHandler` 单一引入路径）。
- **支撑面收窄**：`a2aTaskExecutor` 生产默认（子代理工厂 / Agent 主循环 / FilteredToolPort）
  挪到组合根 `kernel/composition/a2aBridge.ts`，经 `buildSubagent` / `runTask` / `filterTools`
  注入缝装配（**alpha 破坏性**：三项构造选项改必填，缺省即装配期报错）；
  fail-closed 工具收窄**策略**留在协议层、**机制**注入。`AgentPort` 扩展 `eventsOf` /
  `cancelCurrentRun` / 可选 `sessionId`（协议桥只认端口）；新增 contracts `ToolRegistryPort`
  （MCP 网关不再感知 `RegistryToolPort` 具体类）。支撑面 27 → 21 符号（全基础设施），
  协议层对 `core` / `subagent` 的感知归零。

### Removed

- `src/compat/` 目录整体删除；`src` 内零 `apps/` import。

### Known issues

- `npm publish` 未执行（无发布凭据）；包已可 `npm pack`（0.1.0-alpha.0，不承诺兼容）。
- `adapters/laya` 长期应迁回应用仓库（已标 `@beta`，迁移路径见 BOUNDARY 裁决表）。
