/**
 * 厂商一键接线（M115）：`model` 传字符串即可，不再手工 new 适配器。
 *
 * 格式：`'厂商id'`（预设缺省模型）或 `'厂商id:模型名'`（覆盖模型，模型名可含冒号）。
 * 解析链：`defaults/providers.json` 预设 → env `<厂商id大写>_API_KEY`（缺钥 fail-closed
 * 并点名环境变量）→ 内置适配器注册表构造。可用厂商见
 * `defaults/providers.json`（deepseek / moonshot / zhipu / dashscope / openai /
 * anthropic / ollama / gemini）。
 *
 * 运行（仓库内先 `npm run build`；安装后同样一条命令）：
 *   DEEPSEEK_API_KEY=sk-... node examples/model-shortcut.mjs
 *   （或 ollama：本地端点免 Key，`node examples/model-shortcut.mjs ollama`）
 */
import { OmniKernel } from '@omniharness/kernel';

// 命令行第 1 参可覆盖快捷串；缺省 ollama（本地免 Key，任何环境都能跑通）。
// 换真实厂商：`node examples/model-shortcut.mjs deepseek` 并设好 DEEPSEEK_API_KEY。
const shortcut = process.argv[2] ?? 'ollama';

const kernel = await OmniKernel.create({
  workspaceRoot: process.cwd(),
  model: shortcut, // ← 一键接线：'deepseek' / 'deepseek:deepseek-v4-flash' / 'ollama:qwen3:8b' …
});
console.log('适配器名：', kernel.model.name, '（能力一览：', kernel.capabilities(), '）');

const result = await kernel.runTask('用一句话介绍你自己，不要使用任何工具。');
console.log(result.finalText);

await kernel.close(); // 幂等：取消在跑回合 → drain → 关 MCP → 落回执 → 关工作台
