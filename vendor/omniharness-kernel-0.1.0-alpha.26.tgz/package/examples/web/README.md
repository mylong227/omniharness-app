# examples/web —— 宿主侧 SSE/Web 最小对接面（M74）

> **定位**：这不是内核的新能力，而是**宿主侧**把内核已有数据面端到 web 的最小实现
> （§8：内核不做体验层）。内核提供 `WorkbenchServer` 的 SSE / state / answers；
> 本目录提供「静态 UI + 启动任务入口」这层薄宿主。

## 运行

```bash
npm run web:sse
# 打开打印出的 UI 地址，输入：请先问我部署环境，然后汇报。
```

或拆开：

```bash
npm run build
node examples/web/server.mjs --port 0
node scripts/webSseSmoke.mjs   # 无浏览器冒烟（CI/无头环境）
```

## 数据流

```
浏览器 app.js
  ├─ GET  /api/config           ← 静态宿主：workbench 地址 + 令牌
  ├─ POST /api/tasks            ← 静态宿主：agent.runTask(prompt, sessionId)
  ├─ GET  /api/sessions/:id/state?token=       ← 内核 WorkbenchServer 投影
  └─ GET  /api/sessions/:id/events?token=      ← 内核 SSE（历史回放 → 实时）
       EventSource 命名事件 = SessionEvent.type
```

`ask_user` 的闭环：模型第 1 步调 `ask_user` → state 出现 `pendingAsk` → UI 点选项
→ `POST /answers` → 模型第 2 步拿到答案收尾。断线由 EventSource 自动重连（`Last-Event-ID`）。

## 诚实边界

- 演示模型 `ScriptedAskModel`、`AutoApproval`、`PassthroughSandbox` **只适合本机演示**；
  生产宿主必须注入真实 `ModelPort` 与 fail-closed 审批/沙箱。
- 同一宿主串行执行任务（第二次 `POST /api/tasks` 返回 409）；生产宿主应按会话隔离。
- 本目录不新增内核导出、不进 `src/` 行数预算、不被 `api:check` 计数。
