#!/usr/bin/env node
/**
 * 宿主侧 Web 演示入口（M74）：`node examples/web/server.mjs`
 *
 * 起两个回环服务：
 *  - 静态 UI + `POST /api/tasks`（本文件创建的宿主）；
 *  - 内核 `WorkbenchServer`（SSE / state / answers / audit）。
 *
 * 生产宿主应把脚本模型换成真实 `ModelPort`、把 `AutoApproval`/`PassthroughSandbox`
 * 换成 fail-closed 实现；本入口只证明「内核 SSE 面 → 浏览器」的对接形状。
 */
import { WebDemoHost } from './hostServer.mjs';

/** 解析 `--port N` / `--workspace PATH`。 */
const parseArgs = (argv) => {
  const values = new Map();
  for (let i = 0; i < argv.length; i += 1) {
    if (!argv[i].startsWith('--')) continue;
    const key = argv[i].slice(2);
    const next = argv[i + 1];
    if (next !== undefined && !next.startsWith('--')) {
      values.set(key, next);
      i += 1;
    }
  }
  const port = Number(values.get('port') ?? 0);
  return {
    port: Number.isInteger(port) && port >= 0 ? port : 0,
    workspaceRoot: values.get('workspace') ?? process.cwd(),
  };
};

const args = parseArgs(process.argv.slice(2));
const host = new WebDemoHost({ port: args.port, workspaceRoot: args.workspaceRoot });
const info = await host.listen();
console.log(`[web] UI        ${info.url}`);
console.log(`[web] workbench ${info.workbenchUrl}`);
console.log(`[web] token     ${info.token}`);
console.log('[web] 打开 UI 输入任务；Ctrl+C 退出。');

let closing = false;
const shutdown = async () => {
  if (closing) return;
  closing = true;
  console.log('\n[web] 关闭中…');
  await host.close();
  process.exit(0);
};
process.on('SIGINT', () => void shutdown());
process.on('SIGTERM', () => void shutdown());
