/**
 * 宿主侧最小 SSE 客户端（M74）。
 *
 * 数据面两路并用（与 docs/API.md §2.3 同一口径）：
 *  1. `GET /state` 拿投影快照（首屏/每次事件后刷新）；
 *  2. `EventSource` 订阅 `/events?token=`（命名事件 = SessionEvent.type），事件到达即刷新投影。
 *
 * 本文件只做呈现：不解析会话语义、不重投影；投影口径在服务器（SessionProjector）。
 */
const EVENT_TYPES = [
  'user',
  'assistant',
  'reasoning',
  'tool_call',
  'tool_result',
  'system',
  'todo',
  'plan',
  'question',
  'turn_diff',
  'model',
  'rollback',
  'session_meta',
];

class WebWorkbenchClient {
  constructor() {
    this.status = document.querySelector('#status');
    this.prompt = document.querySelector('#prompt');
    this.run = document.querySelector('#run');
    this.hint = document.querySelector('#hint');
    this.messages = document.querySelector('#messages');
    this.ask = document.querySelector('#ask');
    this.askBody = document.querySelector('#ask-body');
    this.config = undefined;
    this.sessionId = undefined;
    this.source = undefined;
    this.renderTimer = undefined;
  }

  async boot() {
    this.run.addEventListener('click', () => {
      this.start().catch((error) => this.fail(error));
    });
    this.prompt.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) {
        this.run.click();
      }
    });
    this.config = await (await fetch('/api/config')).json();
    this.setStatus(`就绪 · workbench ${this.config.workbenchUrl}`, 'live');
  }

  setStatus(text, tone = '') {
    this.status.textContent = text;
    this.status.className = `status ${tone}`.trim();
  }

  fail(error) {
    this.setStatus(`失败：${error instanceof Error ? error.message : String(error)}`, 'error');
    this.run.disabled = false;
  }

  async start() {
    const prompt = this.prompt.value.trim();
    if (prompt === '') {
      this.setStatus('请先输入任务', 'error');
      return;
    }
    this.run.disabled = true;
    this.messages.replaceChildren();
    this.ask.hidden = true;
    const response = await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ prompt }),
    });
    const body = await response.json();
    if (!response.ok) throw new Error(body.error ?? `HTTP ${response.status}`);
    this.sessionId = body.sessionId;
    this.setStatus('运行中 · SSE 已订阅', 'live');
    this.subscribe(this.sessionId);
    await this.refreshState();
  }

  subscribe(sessionId) {
    this.source?.close();
    const url =
      `${this.config.workbenchUrl}/api/sessions/${encodeURIComponent(sessionId)}/events` +
      `?token=${encodeURIComponent(this.config.token)}`;
    this.source = new EventSource(url);
    this.source.onopen = () => this.setStatus('直播中 · EventSource 已连接', 'live');
    this.source.onerror = () => this.setStatus('SSE 断线（浏览器会自动重连带 Last-Event-ID）', 'error');
    for (const type of EVENT_TYPES) {
      this.source.addEventListener(type, (event) => {
        let parsed;
        try {
          parsed = JSON.parse(event.data);
        } catch {
          return;
        }
        if (parsed.type === 'assistant') {
          this.run.disabled = false;
        }
        this.scheduleRender();
      });
    }
  }

  scheduleRender() {
    if (this.renderTimer !== undefined) clearTimeout(this.renderTimer);
    this.renderTimer = setTimeout(() => {
      this.renderTimer = undefined;
      this.refreshState().catch((error) => this.fail(error));
    }, 60);
  }

  async refreshState() {
    if (this.sessionId === undefined) return;
    const url =
      `${this.config.workbenchUrl}/api/sessions/${encodeURIComponent(this.sessionId)}/state` +
      `?token=${encodeURIComponent(this.config.token)}`;
    const response = await fetch(url);
    if (!response.ok) throw new Error(`state HTTP ${response.status}`);
    this.renderState(await response.json());
  }

  renderState(state) {
    this.messages.replaceChildren();
    for (const message of state.messages ?? []) {
      const item = document.createElement('li');
      item.className =
        message.kind === 'tool' ? 'tool' : message.role === 'user' ? 'user' : 'assistant';
      const who = document.createElement('span');
      who.className = 'who';
      who.textContent =
        message.kind === 'tool'
          ? `tool:${message.toolName ?? '?'}${message.ok === false ? '（失败）' : ''}`
          : String(message.role ?? 'notice');
      const text = document.createElement('span');
      text.textContent = String(message.content ?? '');
      item.append(who, text);
      this.messages.append(item);
    }
    this.renderAsk(state.pendingAsk);
  }

  renderAsk(pendingAsk) {
    this.askBody.replaceChildren();
    if (pendingAsk === undefined || (pendingAsk.questions ?? []).length === 0) {
      this.ask.hidden = true;
      return;
    }
    this.ask.hidden = false;
    for (const question of pendingAsk.questions) {
      const wrap = document.createElement('div');
      const title = document.createElement('p');
      title.className = 'question';
      title.textContent = question.question;
      const options = document.createElement('div');
      options.className = 'options';
      for (const option of question.options ?? []) {
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = option.label;
        button.addEventListener('click', () => {
          this.answer(question.id, option.label).catch((error) => this.fail(error));
        });
        options.append(button);
      }
      wrap.append(title, options);
      this.askBody.append(wrap);
    }
  }

  async answer(questionId, label) {
    const url =
      `${this.config.workbenchUrl}/api/sessions/${encodeURIComponent(this.sessionId)}/answers` +
      `?token=${encodeURIComponent(this.config.token)}`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ answers: [{ id: questionId, selected: [label] }] }),
    });
    if (!response.ok) throw new Error(`answers HTTP ${response.status}`);
    this.ask.hidden = true;
    await this.refreshState();
  }
}

const app = new WebWorkbenchClient();
app.boot().catch((error) => app.fail(error));
