# 发布流程

> **一句话**：发布 = 一个可复核的提交 + 一个与包内容一致的 tag + 一次可回读的 registry 发布。
> 前置自检：`npm run publish:check`（token / publishConfig / 版本冲突 / HEAD 与 tag 对齐）。

## 1. 版本策略

- 独立 semver；alpha 阶段 `0.1.0-alpha.N`，发布 tag `alpha`，不使用 `latest`。
- 破坏性变更（含公开符号、子路径、配置默认值）必须在 CHANGELOG 里以 **BREAKING** 标注。
- 应用仓钉版本；内核发版后由应用仓升级并跑全量回归，不在应用仓直接改内核内部。

## 2. 发布前

1. `npm run verify` —— 全量门禁绿灯（typecheck / boundary / arch / style / maturity /
   wiring / drift / build / coverage / typecheck:scripts / stress / api / view / cross）。
2. `npm run clean:tsc` —— 干净检出编译（HEAD 快照；只在发布前跑，不进日常 verify）。
3. `npm run publish:check` —— 必须转绿：
   - npm token 有效；
   - `publishConfig` 与包名正确；
   - 版本未在 registry 存在；
   - HEAD 与 `v<version>` tag 一致（tag 冻结在宿主实际消费的提交）。
4. 打包冒烟由 CI 在空目录安装 tarball 后执行。手工复查时可使用：

   ```bash
   npm pack --pack-destination .tmp
   # 空目录
   npm install <tgz>
   node -e "import('@omniharness/kernel').then(async m => { const k = await m.OmniKernel.create({ workspaceRoot: process.cwd() }); console.log(k.capabilities()); await k.close(); })"
   ```

## 3. 版本收尾

1. `package.json` / `package-lock.json` 版本号 +1；
2. `CHANGELOG.md` 顶部加同版本段（只写已发生的事；不写计划）；
3. `git commit -m "chore(release): 0.1.0-alpha.N"`；
4. `git tag -a v0.1.0-alpha.N -m "..."`。

## 4. 发布

```bash
npm publish --tag alpha
```

发布后立即回读：

```bash
npm view @omniharness/kernel@alpha version dist-tags
```

把版本与回读结果写入 `CHANGELOG.md`（不写进其它文档：会过期的数字不落文档）。

## 5. 发布后验证

- 空目录 `npm install @omniharness/kernel@alpha`，跑 `OmniKernel.create()` + `runTask()`；
- 跑 `node examples/headless.mjs`；
- 应用仓升级 vendored 版本并跑 `kernel:check` / typecheck / web 测试；
- 任一步失败：先修内核或应用，再发下一个 alpha；不要原地覆盖已发布版本。

## 6. 跨仓顺序

```text
内核：verify → tag → publish → 回读
应用：升级依赖 → kernel:check（导入闭包 ⊆ 承诺面）→ 全量回归 → 钉版本提交
```

`npm run cross:check` 会核对 Rust 真源形状、`cargo test`、应用导入闭包与影子面；
应用仓缺失时 SKIP（显式 `OMNI_APP_REPO` / `OMNI_APP_CONTRACT_REQUIRED=1` 时失败）。

## 7. CI

- Ubuntu/Windows 全量验证和装包冒烟，Ubuntu 加跑容器探针。
- 仓内 [Rust 工程](../rust/README.md) 自动构建；`rust_repo` 仅用于额外 Rust 消费仓。
- `app_repo` 启用应用仓检查。私有仓令牌用 `RUST_REPO_TOKEN` 和 `APP_REPO_TOKEN`。

发布本身不自动化：需要人工确认 token、tag 与版本号三者一致。
