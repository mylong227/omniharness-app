## 0.1.0-alpha.16 — 2026-11-08（巡检闭环：AG-UI 公开 / 协议判据 / 账实收敛，未 npm publish）

> 详见 [docs/AUDIT-2026-11-08-CLOSURE.md](docs/AUDIT-2026-11-08-CLOSURE.md)。

### Added

- **AG-UI 提升为公开子路径** `@omniharness/kernel/agui`（`src/agui.ts`）：`AgUiHttpServer` /
  `AgUiEventStream` / `AgUiEventMapper` 与全部事件类型；AG-UI 从「全部入口不可达」变为可达
  （不可达从 14 文件 / 3,280 行降到 6 文件 / 1,618 行）。判据 `tests/contract/aguiServeWiring.test.ts`（5 例）。
- **ACP 服务端判据** `tests/unit/acpServer.test.ts`（4 例）：initialize 能力声明、new → prompt →
  cancel → close、重复 close 幂等、未声明的 `session/delete` 按 `-32601` 拒绝、requireAuth 拒绝。
- **MCP v2 客户端判据** `tests/unit/mcpStatelessClient.test.ts`（7 例）：`server/discover` + 每请求
  `_meta`、tools、MRTR 重试、无 inputHandler fail-closed、`subscriptions/listen`、关闭/错误/反向请求。
- **Windows 原生沙箱判据** `tests/unit/windowsNativeSandbox.test.ts`（4 例）：包装命令与命令文件落盘、
  非 Windows 拒绝、定位器缺失 fail-closed、裁决面与 restricted 同源；`WindowsNativeSandbox`
  增加平台/定位器注入缝。
- **`planCheck` 章节标题状态对账**：`### Mxx … ✅/⏳` 必须与状态账一致，变异用例见
  `gateMutation.test.ts` 绕过#5。

### Changed

- **MCP 默认连接器**：`McpServersBridge` 缺省从 `SdkMcpConnector` 改为 `SdkPreferredMcpConnector`
  （SDK 优先；stdio 失败回落手写 `mcpConnector`，后者支持 2026-07-28 无状态协商）。
- **覆盖率地板**：全局 58/58/73/71 → 60/60/73/72（新基线 60.91/73.66/72.85/60.91）。
- 测试规模：237 文件 / 1145 用例 → **248 文件 / 1200 用例**。
- **固定文案配置化（全量）**：新增 `TextCatalog`（加载 / 形状校验 / `{name}` 渲染一份实现）与
  `KernelTexts`，把 `src/**` 内 **3,235 处**中文文案（含工具结果、协议报错、校验诊断、
  `throw` 文案）外置到 `defaults/kernel-texts.json`（**2,260 键**，`模块.上下文.类别.序号`；
  模板变量 `{argN}`）；另有 `tool-exposure.json`（9 类别词表）、`report-texts.json`
  （沙箱能力表 / 信任清单 / 能力卡）、`tool-result-texts.json`（`plan_present` 交互）四个分域目录，
  并补齐 9 条工具参数说明。协议层经 `protocolsSupport.ts` 单一支撑面取用，不直插 `kernel/util`。
  配置加载器自举报错走 `defaults/bootstrap-texts.json` + `BootstrapTexts`；浏览器 bundle 的投影
  标签改由宿主注入 `ProjectSessionLabels`。判据：`kernelTexts.test.ts` 全仓扫描
  **1,122 文件 / 0 残留**（`src/**` 已无任何中文字符串字面量）；`reportTexts` /
  `toolExposureLexicon` / `toolResultTexts` 渲染逐字。复审口径见
  [docs/AUDIT-2026-11-08-TEXTS.md](docs/AUDIT-2026-11-08-TEXTS.md)。
- **上帝类重构（两轮，闭环到 0 超预算）**：`ContextCompactor`→`CompactionStateCodec`（825→704 行、
  21→16 方法）；`ConfigError`→`ConfigFieldGuard` + `configFieldSpecs`（23→12 方法）；
  `LongHorizonProtocol`→`LongHorizonStateStore`（25→16）；`Rfc3161Verifier`→`Rfc3161TokenParser` +
  `Rfc3161TrustResolver` + 三个阶段方法（973→671 行、23→13、最大方法 404→148）；
  `ResponsesModel`→`ResponsesStreamAccumulator`（25→17）；`McpStatelessClient`→
  `McpStatelessSubscriptions` / `McpMrtrAnswers` / `McpStatelessRequestMeta`（22→12）；
  `TemporalFactGraph`→四个协作类（23→12）；`OmniKernelAssembler.assemble` 189→116；
  `SessionRecorder`→`SessionRetrievalIndex`（23→19）；`FileLock`/`SessionProjector` 小步收敛。
  压缩标记收敛到 `contracts/ports/context/compactionMarker.ts` 单一来源；AST 去重
  `String(String(x))` 361 处 / 117 文件。`npm run god:report -- --check`：**744 类 0 超预算**
  （唯一白名单是纯文案 facade `HarnessTexts`），见
  [docs/AUDIT-2026-11-09-GOD-CLASSES.md](docs/AUDIT-2026-11-09-GOD-CLASSES.md)。

### Fixed

- **ROADMAP 账实漂移**：M22/M23 章节标题从 ⏳ 改回 ✅（状态账早已 done）。
- **WIRING 过期陈述**：ACP 显式深路径、AG-UI `./agui`、`sdkPreferredMcpConnector` 回归并默认注入、
  `config.mcpServers` auth 已接线、`./*` 通配已删除、omniError 走显式深路径。
- **README 沙箱措辞**：明确「非 strict 落 `PolicySandbox` + warn，`OMNI_SANDBOX_STRICT=1` 才启动失败」，
  不再让读者把缺省读成 OS 级隔离。

---

## 0.1.0-alpha.15 — 2026-11-08（P1 信任边界收敛 + 成熟度清零，未 npm publish）


> 本版**合并** alpha.14（未 npm publish）的全部内容与 2026-11-08 夜的本轮收敛：P1 信任边界（交互式沙箱包装 / RFC3161 证书链 / 页面内请求拦截）、16 件 `L0-unverified` 清零、MCP 客户端反向请求、覆盖率二次收紧、跨仓消费契约层。
### Added（2026-11-08 深夜：成熟度清零 + MCP 反向请求 + 2 处缺陷修复）

- **`maturity:check` 报 0 件 `L0-unverified`**（原 16 件）：插件分发 4 件（静态扫描 / 分级 / 包读取 /
  私有技能源）、wasm 隔离 3 件（内存声明 / 资产类型 / 执行器，含**真实执行**手写 wasm）、
  自主调度 1 件、资产装配 1 件、repo-map 投送 1 件、进化闭环 6 件，全部补本仓判据后升 L1，
  不删徽章、不留空头支票。新增判据 15 个文件 / 95 例；判据规模 222 文件 / 1050 用例 →
  **237 文件 / 1145 用例**。
- **缺陷（写判据时实锤）**：`PrivateSkillSource.bundleFiles` 把「包数超限」的 throw 写在 try 里被
  自己的 catch 吞掉（超限时 `sync()` 报「0 安装 0 拒绝」——恰好是注释承诺不做的假象）；
  `EliteReentryDiscovery.enqueue` 超限用 `shift()` 丢掉**最老**重入候选，与「旧复核优先」相反。
  两处均已修复并由 `privateSkillSource.test.ts` / `evolutionCandidateFlow.test.ts` 钉死。\n- **MCP 客户端反向请求**（`McpClientOptions.serverRequests`）：此前服务端发起的 `sampling/createMessage`\n  / `roots/list` 一律回 `-32601`——客户端永远不被当成「支持 sampling 的宿主」，该能力面事实上不可用。\n  现由调用方按需注入处理器：`initialize` 只**如实声明**已注入的反向能力（`sampling` / `roots`），\n  请求按方法分派、同 id 回 result；未注入仍回 `-32601`（不让对端等到超时），处理器抛错回 `-32603`\n  且原因可读，关闭后不再写传输。判据 `tests/unit/mcpClient.test.ts`（8 例，此前 McpClient 零判据）。\n  `resources/subscribe` 保持**有意不实现**：2026-07-28 协议已由 `subscriptions/listen`（已实现+已判据）\n  取代，能力声明面也从未谎报 `subscribe`（`m6-mcp-capability-honest` 把守）。

### Added（2026-11-08 夜：剩余项收敛——沙箱执行包装补全 / RFC3161 证书链）

- **`shell_interactive` 补上 OS 沙箱命令包装**：此前只有 `shell` 经 `commandWrapper` 把命令包进
  选中后端，`shell_interactive` 只做策略裁决就直通终端——同一个 profile 两条执行路径两种隔离语义。
  现两条路径都在 `configToolRegistry` 单点注入同一 `commandWrapper`（先按原始命令裁决，再把通过的
  文本包进沙箱）；新增 `tests/unit/shellSandboxWrapping.test.ts`（4 例：包装生效 / 策略拒绝不包装 /
  交互式包装 / 未注入零变更）。顺带修正 `SandboxManager.EXECUTION_UNWIRED` 与 `src/sandbox.ts` 的
  过期注释（集合已为空 = 已接线；本机可用性另由能力表与各后端 `probe()` 如实描述）。
- **RFC3161 证书链校验**（`Rfc3161CertificateChain`，经 `./receipts` 导出）：`trust.kind:'chain'`
  提供叶子 + 中间链 + **显式固定信任根**，校验逐级签名、**genTime 时刻**有效期、叶子 EKU
  `id-kp-timeStamping`（必须 critical）、keyUsage（digitalSignature / nonRepudiation）、叶子非 CA、
  可选 TSA policy 名单；信任根为空即 fail-closed，令牌自带自签根不算数。untrusted 结论不降级为
  「只验签名」：`chainChecked/chainTrusted` 与 `signatureChecked/signatureVerified` 分层上报。
  判据 `tests/unit/rfc3161Chain.test.ts`（11 例，用 `tests/unit/rfc3161CertificateFixture.ts`
  手写 DER 生成真实证书链、node:crypto 真签名）；仍不验 CRL/OCSP 与完整 RFC 5280 策略链
  （离线复核器不出网，见 RECEIPTS §3）。
- **浏览器页面内请求拦截**（`BrowserRequestGuard`）：导航守卫此前只判 `goto` 目标 URL，页面脚本
  随后访问内网/云元数据完全绕过。现 CDP `Fetch`（Request 阶段逐条 `continueRequest` /
  `failRequest(BlockedByClient)`）与 Playwright `page.route` 两条引擎都过同一套 egress 判定；
  `data:`/`blob:`/`about:` 放行（不产生出站），`file:` 等本地协议拒绝；判定异常 fail-closed；
  同 URL 判定在单会话内缓存（上限 1024）。`Fetch` 域不可用时如实 warn 并返回 false（导航层
  守卫仍生效，不假装已拦截）。判据 `tests/unit/browserRequestGuard.test.ts`（6 例）。

- **覆盖率地板二次收紧**：全局 56/56/72/70 → **58/58/73/71**（基线 59.45 / 73.94 / 72.57），
  并新增 5 个域地板（evolution 85/88、capability 81/90、plugin 42/62、autonomy 29/34、
  maintenance 83/98）与 `protocols/mcp`（39/58）——本轮补齐判据的域从此纳入「只升不降」；
  目录地板共 16 个；另加 **8 个逐文件地板**（toolCallPairs / toolExposurePlanner / serverAuthGuard /\n  layeredCodeGraph / provenanceIssuer / packStaticScanner / privateSkillSource / evolutionKernel），\n  挡住「单文件整体塌掉但同目录其它文件补分」的退化。实测见 `vitest.config.ts` 头注。

### Added（2026-11-08 傍晚：跨仓消费契约 + APP 收敛，不涉及包内容）

- **跨仓门禁增加 TS 消费层**（`scripts/lib/appContractCheck.mjs`，`AppContractCheck`）：
  内核从自己的承诺面出发核对真实应用仓——①钉定必须是 `file:vendor/omniharness-kernel-<版本>.tgz`；
  ②已安装版本必须等于钉定；③应用 `src/**` 的 `@omniharness/kernel[/…]` 导入 ⊆ 内核 `exports`
  且只允许出现在 `src/host/kernel/` 对接面；④`src/host/extensions/**` 声明的符号名不得与内核
  承诺名重合。承诺面解析**穿透 curated 子路径的再导出桶**（`export { … } from` / `export *`）——
  只扫直接声明会让 `./sandbox` / `./mcp` / `./maintenance` 承诺的能力整类漏检。
  用例：`tests/unit/appContractCheck.test.ts`（6 例）+ `crossRepoCheck.test.ts` 消费层集成 2 例。
- **仓角色拆清**：旧 `crossRepoCheck` 把含 `crates/omni-core` 的仓称 `appRepo`（实为 Rust 消费仓），
  真实 TS 应用仓从未被核对；现拆为 `resolveRustRepo`（`OMNI_RUST_REPO` / `../omniharness`）与
  `resolveConsumerRepo`（`OMNI_APP_REPO` / `../omniharness-app`）。缺 TS 应用仓 SKIP，
  显式 `OMNI_APP_REPO` 或 `OMNI_APP_CONTRACT_REQUIRED=1` 时失败；版本钉定落后内核工作树只记 note。
- CI `cross-repo` job 改用 `OMNI_RUST_REPO`（语义与 `exportsClosure` 的 `OMNI_APP_ROOT` 对齐）。

### Docs（2026-11-08 傍晚）

- `docs/BOUNDARY.md` 增加「跨仓消费契约」两层表与 curated 子路径穿透口径；
- `docs/AUDIT-2026-11-08.md` §7 记录第三轮（应用侧 11 个影子名字清零 + 内核侧两层门禁）。

### Cross-repo（应用仓，同批）

- 应用侧影子扫描修复两处漏检（curated 键拼成目录、再导出名单未解析）后，`IsolationLadderFactory` /
  `SdkPreferredMcpConnector` / `SessionGc` / `SessionStorageLocation` / `TmpSweep` 连同 6 个类型
  共 11 个名字判红；应用删除 5 件影子（约 760 行），消费点改经 `src/host/kernel/` 对接面，
  生成器支持 curated 桶落点，域文件 18 → 19，`kernel:check` 复绿。

### Added（2026-11-08 巡检 §5 收尾：覆盖率 / RFC3161 真验签 / 沙箱 canary / 双内核同步）

- **覆盖率门禁**：引入 `@vitest/coverage-v8` 与 `vitest.config.ts` 阈值（statements/lines 56、branches 72、functions 70 作为「只升不降」地板；基线 57.63 / 73.17 / 71.75）；`npm run coverage`
  进入 `verify`（用覆盖率模式取代重复的 `npm test`，只跑一遍），`coverage/` 入 gitignore。
  `smoke` 同时执行 `examples/embed.mjs`（README 首条命令不再只被文本检查）。
- **RFC3161 真验签**：新增 `DerElement`（有界 DER 读取）/`Rfc3161Oids`/`Rfc3161Verifier`——
  解析 TimeStampResp → PKIStatusInfo → TSTInfo → messageImprint（按声明哈希 OID 重算并常量时间比较）
  → CMS SignerInfo 签名（signedAttrs 与 messageDigest 校验；SPKI/证书信任输入；1 MiB 上限；
  解析异常一律结构化返回）。`AuditPacks.verify` 增加第 4 个可选 `anchorTrust`，锚定结论给出
  `ANCHOR_VERIFIED` / `ANCHOR_MALFORMED` / `ANCHOR_IMPRINT_MISMATCH` / `ANCHOR_SIGNATURE_INVALID` /
  `ANCHOR_UNTRUSTED` / `ANCHOR_UNSUPPORTED_HASH`；`AuditBundles.verify` 透传；`Rfc3161Verifier`
  与类型经 `./receipts` 导出。独立复核 CLI 不再把「有令牌」当「已锚定」：`anchored` 恒 false、
  `compliant` 不可达，新增 `warnings[ANCHOR_UNVERIFIED]` 与 `anchorTokenContainsDigest` 形态字段。
- **Gemini 形状守卫**：非流式 2xx 走共享 `ModelResponseShape`；`promptFeedback.blockReason` ⇒
  结构化 `ModelCallError`（status 200 / retryable false，不返回空成功）；无 candidate 且无
  blockReason ⇒ malformed。
- **Seatbelt 每命令隔离**：profile 改为每次 `wrapCommand` 独立 `mkdtemp`（0600）、实例内记录并在
  `cleanup()`/退出清理，构造期清扫 1 小时以上的陈旧目录——消除并发命令共享一份可写 profile 的
  重写窗口（该层无 spawn 后钩子，无法逐条立即删除，已在类注释写明）。
- **真实沙箱 canary**：新增 `scripts/sandboxCanary.mjs`（`SandboxCanary`，结构自检 + `--real`
  真实 docker 两种模式；以宿主式执行还原 shell 工具路径，断言宿主 canary 标记不出现在 stdout/
  stderr 且宿主文件未创建）。CI 在 ubuntu 以 `OMNI_SANDBOX_CANARY_REQUIRED=1` 执行 `--real`；
  无 docker 的机器明确 SKIP（必需模式下 FAIL），不再只有构造级判据。新增 `npm run sandbox:canary`。
- **双内核同步**：`dangerous-commands.json` 增加声明式 `flagSets`（`rm` 的递归∧强制），TS
  `DangerousCommands` 改为从单一真源加载（删除硬编码表）；Rust `crates/omni-core` 的 `build.rs`
  修复真源解析（`OMNI_KERNEL_SRC` → 兄弟 checkout → 打包 dist，缺失即可行动 panic），并实现同语义
  结构判定与组件级路径包含（Windows 大小写折叠）。`cargo test -p omni-core` 83 通过。
- **覆盖率按目录收紧（2026-11-08 巡检 §6.1）**：`vitest.config.ts` 在全局地板之外增加目录地板
  （core 77/84、receipts 86/89、security 79/90、sandbox 69/79、model 60/74、context 65/70、
  util 75/80、contracts 87/98、protocols 28/51、kernel 59/70，均为 lines/functions），
  用 `**/*.ts` 形态覆盖嵌套文件；实测值向下取整 1–2 点作为「只升不降」地板。
- **跨仓漂移门禁（2026-11-08 巡检 §6.2）**：新增 `scripts/crossRepoCheck.mjs`（`CrossRepoCheck`）——
  三层核对：真源 `dangerous-commands.json` 形状（patterns/flagSets）、Rust 消费侧契约
  （`build.rs` 的 `OMNI_KERNEL_SRC` 与兄弟 checkout 候选、`sandbox.rs` 的 `DANGEROUS_FLAG_SETS`
  与 `path_contains`）、`cargo test -p omni-core` 可执行证据；无应用仓时明确 SKIP，
  `OMNI_CROSS_REPO_REQUIRED=1` 时 SKIP 即失败。`npm run cross:check` 进入 `verify`（有兄弟仓时真跑）；
  CI 新增 `cross-repo` job：同时 checkout 应用仓与 Rust 工具链后以 REQUIRED 模式执行。

### Fixed（2026-11-08 核心质量巡检闭环，最新）

- **信任边界**：审批缓存键改用无损 shell 词法（`cacheKeyOf`），`echo 'a && rm -rf ~'` 与未加引号
  形式不再同键（P0）；`permission.rules` 写入路径要求至少一个约束（无约束规则等于 allow-all）；
  escalation 缺省提升件改 fail-closed，并新增 `SANDBOX_STRENGTH` 校验拒绝弱于基准的提升档；审计包/审计束空证据不再 `ok`（`EMPTY_PACK`/`EMPTY_BUNDLE`），内嵌证书签名
  经 signed envelope 真验，新增可选 out-of-band `expected`（`COMMITMENT_MISMATCH`/`UNVERIFIED`），
  锚定改为诚实的 `anchorTokenContainsDigest` + `ANCHOR_UNVERIFIED`（containment 不再判 compliant）；
  `SecretRedactor` 覆盖 `providerKeys`/`*Key`；Guardian 提示加随机 nonce 数据封套并带 args；
  Seatbelt SBPL 转义 + profile 移出可写工作区；HMAC 空键告警。
- **模型层**：新增 `ModelResponseShape`——四个适配器 2xx 统一形状守卫（error 信封 / 必需数组），
  杜绝裸 `TypeError` 与静默空成功（P0）；`TokenCount` + `CostBudget` 归一，畸形 usage 不再把
  `spentUsd` 变 NaN（硬预算恢复阻断），快照与 `budget_status` 自报 `unmeasuredModels`（P0）；
  OpenAI 流式工具调用按 index/id 分桶（缺 index 的多调用不再互相覆盖），Anthropic 补合成 tool id，
  Responses 走 `ToolArgumentParser`（parseError）/data-only SSE/`onToolInput`（P0/P1）；
  `ModelHttpErrors` 统一 400 请求 dump 且始终带 `responseBody`（上下文溢出恢复对 OpenAI 生效）；
  SSE 增 16 MiB 帧上限、`data:` 精确剥一个空格；空文本不回传 `text`。
- **核心循环**：`resume` 同步占位单飞（消除 TOCTOU）；取消工具批 flush 已完成调用的事件；
  检索索引按 id 幂等（P0/P1）；LoopGuard 软时限不再早退、编辑振荡命中即清窗；TurnDiff 每回合重置；
  spill/flush fail-soft；workflow 传递 `verificationState` 并标注未验证；GoalRunner 按回合取证与
  真实迭代数；checkpoint 跨实例共享 live source，auto 快照改单键滚动。
- **上下文与存储**：6 处 tmp+rename 收敛到 `AtomicFileWriter`（唯一临时名 / 有界重试 /
  `writeBytes`/`writeSync`）；附件内容寻址写入校验摘要；JSONL BOM；SQLite 坏行容错；KV 前缀按
  字面匹配；压缩摘要跳过合成 user 消息（真实任务不再被 diff 顶掉）；RepoMap 排除控制流关键字；
  ToolIndex 参数名可检索；ContextImageBudget 只降级图片；DeterministicCompressor 加字节预算；
  LongHorizon 进度按字节安全裁剪；补齐 3 个只存在于注释的测试并发掘 corpusWalker 等价判据。
- **传输与协议**：WS upgrade `head` 透传 + `flush()`（首帧不再丢）；关闭帧绕过背压
  （1002/1007/1009 不再丢）；握手校验 `Upgrade`/`Sec-WebSocket-Version`（400/426）；
  LSP 头窗口 64 KiB 上限并与帧上限共用错误面。
- **重复实现收敛**：路径包含统一到 `WorkspaceGuard`（realpath，四个 OS 沙箱与容器同语义）；
  policy/restricted 合并为 `CommandPolicy`（两档现在真正执行 rm 旗标集规则）；工具调用配对四处
  合一为 `ToolCallPairs`；`CancelledError.is` 单源；corpus walker 同步/异步共用同一 gate；
  六个脚本目录遍历与两个 import 扫描器收敛到 `SourceGraph`。
- **校验装置**：`reachability.mjs` 变为可 import 的 `ReachabilityAudit`——`wiring:check` /
  `plan:check` 进程内调用，不再 spawn、不依赖 `.audit/reach.json`；计划门禁错误归因带
  code/signal/stderr；`api:check` golden 缺失 fail-closed 且上限检查先于 `--update-golden`；
  `prepack` 接入 `exportsClosure`、`build` 断言 dist 产物；`view:check` 认副作用/裸内建；
  新增 `style:check`（src 零 `function`/`console.log`）与 `doc:check`（README 计数）；
  `contractTestImports` 白名单改为 `package.json#exports` 派生；`verifyReceipts` 空包退出 1。
- **文档账实**：`README` / `BOUNDARY` / `MATH` / `WIRING` / 本文件按实测对齐——215 文件 / 1007 用例；
  src 143,405 行（contracts 10.5K / kernel 119K / protocols 11.5K）；可达性 19,581 / 显式入口口径
  3,280 行 / 335 个入口；`m4-source-lines` 预算按先例登记为 145,500（+6K 巡检）。
- **巡检报告**：`docs/AUDIT-2026-11-08.md` 更新为闭环清单（修复项、复核证据、诚实边界）。

### BREAKING

- **静态门面删除**：`ConfigBuilder.buildXxx` / `EigenSpectrum.xxx` / `UnifiedDiff.xxx` /
  `CommandCanonicalizer.xxx` 改为实例入口（`configBuilder` / `eigenSpectrum` / `unifiedDiff` /
  `commandCanonicalizer`，或自行 `new`）。迁移说明见 `docs/API.md` §8.1。
- **路由定价统一 per-1M**：新配置写 `inputPer1M/outputPer1M`；旧 per-1k 读取时自动 ×1000。
- **判别联合**：`SandboxDecision` 拒绝必须带 `reason`+`category`；`ImageContent` 必须给 `url` 或 `data`。
- **类型改名**：安全域 `TrustTier` → `ContentTrustTier`。

### Fixed（2026-11-07 全量审计：P0 15 / P1 57 / P2 / P3 分批闭环）

- **P0**：`sketch_write` 纳入写类工具；unshare 补网络命名空间；Guardian 否定语义 fail-closed；
  工作台/AG-UI/MCP 服务端补 Host 头防线（DNS rebinding）；审计包畸形载荷不再抛裸 `JcsError`；
  浏览器进程树按真实可执行名回收；新增 `BrowserNavigationGuard` 给 CDP/Playwright 导航接 egress；
  主循环门禁异常补配对事件、失败结果不再沉淀为成功模板、resume 回填检索索引；Anthropic
  `tool_use`/`tool_result` 配对与五通路流完整性。
- **P1**：AES-GCM scrypt 迁移 + 无密钥源 fail-closed；凭据全文本打码；发布者信任锚定；
  HMAC 台账；provenance 无签名不再判合格；四沙箱路径边界；egress DNS 逐 IP 复核；OAuth
  https/超时/响应上限；ReDoS 预筛与工具上限；`errorCode` 机读码；回执导出 flush；pending
  有界淘汰；close 回收插件 worker；语料缓存 stale-while-revalidate；MCP 工具归属表与反向
  请求回错；插件前缀/孤儿回收；GoalChecker 严格解析；`boundaryCheck`/`planCheck` 加固；
  出厂技能数据重写（删除不存在的脚本与文档）；README/BOUNDARY/defaults 账实对齐。
- **P2**：重复实现收敛——GENESIS、图片 token、裁决联合、有界 JSONL 三连、LCS 三份、验签三份、
  定价单位（`RoutePrice` per-1M，旧 per-1k 读取迁移）、推理七档、MCP `required` 元素校验、
  会话列举（Jsonl/Sqlite）、`DigestEquals` 常量时间摘要比较、四处静态门面别名 shim、
  错误信息提取（12 个带方法体 + 89 个内联文件收敛到 `ErrorMessage`）；语义/边界修复——
  JsonFileKv 原型污染与键序、CryptoVault 单飞、JSONL append TOCTOU、Zip/KDF 越界、sdkClient NaN id、Retry 监听器、
  连接上限、glob/grep 子树遍历、单飞 maxBytes、定价 NaN/负数、`SandboxDecision`/`ImageContent`
  判别联合、`TodoStatus`、`EventFactory.rollback`；删除「只写不读」的会话旁路摘要通道。
- **P3**：18 文件去 BOM；`console.warn` 归零；Ed25519 随机源改 `randomBytes`；worktree 目录
  唯一化；插件 HMAC 常量时间；0600 仅 POSIX 的账面；孤儿 JSDoc 清理。

### Docs

- 新增 `docs/AUDIT-CLOSURE-2026-11-07.md`：批次提交表、P0/P1 证据、P2/P3 收敛清单与**诚实边界**
  （不可回溯的哈希口径、protocolsSupport 21 符号上限、Sqlite 能力边界、unshare/浏览器/ReDoS
  的防护范围）。

### Changed（2026-11-08 核心解耦与应用侧通用件收编）

- **核心装配面收敛**：`ToolGate` 的 8 个位置参数改为 `ToolGateOptions`；`TurnRunner` 的 14 个
  位置参数改为 `TurnRunnerOptions`。深路径消费方需同步迁移（顶层公开面不变）。
- **工具执行职责拆分**：`StepToolExecutor` 抽出 `ToolCallStager`（批级事件按模型调用序提交）与
  `ToolResultPipeline`（打码 → 外溢 → 注入隔离 → 沙箱标注 → 附件外置 → 监督上报），执行器只保留
  门禁/钩子/执行编排；`ToolCallStager`/`ToolResultPipeline` 判据见 `tests/unit/toolCallStager.test.ts`。
- **重复实现收敛**：删除 `AppendOnlyEventLog` 的 5 个事件构造快捷方法（生产零消费，测试改用
  `eventFactory` + `append`）；`SessionRecorder` 的两个倒扫查询合并为 `lastTextOf`；`LoopGuard`
  两处 FNV-1a 实现合并；`ToolPort` 增加可选 `lastFailure` 读取面，移除三处重复的结构断言。
- **应用侧通用件收编（内核侧）**：新增 `kernel/maintenance` 与 `./maintenance` 子路径——
  `SessionStorageLocation`（会话目录单一事实源）/ `SessionGc`（keepNewest + 年龄 + 总量封顶 +
  孤儿附件）/ `TmpSweep`（本仓前缀临时产物清扫）。`SessionGc` 顺带修复「注入时钟只作用于会话组、
  附件回收仍用 `Date.now()`」的判据漂移。
- **装配工厂收编（内核侧）**：`IsolationLadderFactory.builtin()`（wasm 档可达；os 档缺省
  fail-closed）经 `./sandbox` 导出；`SdkPreferredMcpConnector`（SDK 优先、stdio 手写回退、url
  不回退且如实留痕）经 `./mcp` 导出。应用侧对应的 5 个影子实现可在升级时删除（本仓不代改应用仓）。

### Changed（2026-11-08 上帝类拆解与环境开关收敛）

- **`createOmniKernel` 1533 → 33 行 barrel**：句柄类 / 装配顺序 / 回执装配 / 事件端口 / 类型 /
  纯工具拆为 6 个文件；`src/index.ts` 与 `src/embed.ts` 的导入路径与公开面零改动。
- **`Agent` 764 → 585 行**：抽出 `AgentSessionRuntime`（在跑会话登记 / 取消 / write-behind /
  回卷 / 收尾），主循环只保留回合编排；回卷与登记的身份一致反注册语义逐字保留。
- **`TurnRunner` 846 → 606 行**：抽出 `TurnCompletionJudge`（证据下限 → 完成闸门 → reviewer →
  未完成待办），完成判定的有界性（闸门/reviewer 每回合至多一次）与 `unverified` 语义不变。
- **`StepContextBuilder` 611 → 386 行**：抽出 `RepoMapInjector`（查询推导 / 任务形状闸 /
  混合检索 / 降档）与 `ContextPrefixMeter`（相邻请求前缀复用率），两者各自可独立测试。
- **`StepToolExecutor` 941 → 592 行**：在 `ToolCallStager` / `ToolResultPipeline` 之外再抽出
  `ToolExecutionGuard`（只读瞬态重试 / 看门狗 / 取消竞速），执行器只保留门禁/钩子/编排。
- **核心环境开关收敛**：新增 `RuntimeFlags` 作为 `OMNI_*` 键名、默认值与关闭语义的唯一解析处；
  Agent / StepContextBuilder / StepToolExecutor / LoopGuard / AgentLimits / AgentCompactor /
  TaskComplexityClassifier / SessionInjector 不再各自解析 `process.env`。
- **判据**：`tests/unit/toolResultPipeline.test.ts` 3 例（打码先于外溢 / 注入隔离保留附件 /
  策略拒绝与命令非零退出不计健康失败）；全量 `npm test` 152 文件 / 778 用例全绿。

### Added（2026-11-08 固定文案外置：`defaults/harness-texts.json`）

- 新增 `HarnessTexts` 文案目录 + 声明式 `Shape` 校验（缺键/错型 fail-closed）：系统提示、
  平台方言段、失控纠偏、完成闸门回灌、待办纠偏、规划要求、续跑引导、收尾检查清单、
  回合失败留痕全部改为 JSON 数据。
- 移除 `defaultPromptFragments.ts` / `loopGuard.ts` / `turnCompletionJudge.ts` /
  `taskComplexityClassifier.ts` / `resumeGuidance.ts` / `preCompletionChecklist.ts` /
  `agent.ts` 中的对应硬编码长文案；改文案只改 `defaults/harness-texts.json`。
- 模板占位符统一为 `{name}`，渲染后残留占位符由 `tests/unit/harnessTexts.test.ts` 判据拦截。
- 新增 `defaults/tool-texts.json` + `defaults/tool-param-texts.json` + `ToolTexts`：
  52 个 `TOOL_NAMES` 的工具描述与 134 条参数 schema 字段说明全部外置；工具定义只保留
  `ToolTexts.description(TOOL_NAMES.x)` / `ToolTexts.parameter(TOOL_NAMES.x, 'path')`；
  缺条目时构造 fail-closed。判据 `tests/unit/toolTexts.test.ts` 逐值核对枚举与文案表一一对应。

### Added（M31 应用侧模型探针/注入度量收编 + 状态值表）

- **应用侧三件通用件迁入内核**：`ModelCapabilityProbe`（模型能力探针）、
  `InjectionSnapshotAggregator` + `InjectionMetric`（注入度量编排）共 702 行；
  新增 `./eval` 子路径一次性导出，应用侧升级 tgz 后可删除三份影子。
- **源码行预算明确放宽**：`m4-source-lines` 由 138,000 → 139,000，判据标题登记
  「+1K=M31（632 行；交换条件：应用侧退役两份影子）」。
- **工具参数 schema 文案外置**：`defaults/tool-param-texts.json` 收录 134 条
  `tool.path` 字段说明；工具定义统一 `ToolTexts.parameter(TOOL_NAMES.x, 'path')`。
- **状态值表化（枚举等价）**：全文 28 组字符串联合状态（待办 / 工作流 / 监督 / 验证 / 工具错误码 /
  图节点 / 隔离 / 信任 / 内容信任 / 工作区信任 / 决策 / 检索角色 / 审批 / 规则 / 计划 / 遥测 /
  沙箱动作与拒绝分类 / 审查 / 推理档位等）改为 `as const` 唯一值表，类型由值表推导；
  监督内核 `MODE_ORDER` 直接复用 `SAFE_MODES`，不再手写第二份状态数组。
- 判据：`tests/unit/evalDiagnostics.test.ts`（六探针全过 + TP/FN/FP/TN 可复算）、
  `tests/unit/statusEnums.test.ts`（8 组值表完整/去重）、`tests/unit/toolTexts.test.ts`
  （52 工具描述 + 参数路径读取）。

## 0.1.0-alpha.13 — 2026-11-07（vendored tgz 发布，未 npm publish）

### Added（M29 审计 canonical 单一真源：auditCanonical → 内核 Jcs，2026-11-07）

- **Jcs 深度护栏补齐**：`MAX_DEPTH = 64`（口径取自审计域历史实现；超限抛 `JcsError` fail-closed，防环/防炸栈——回执载荷是内核受控的扁平结构，对既有 receipts 消费方零行为变更）。

- **exports 承诺闭包 += `kernel/receipts/jcs.js`**：审计哈希链的序列化口径收敛为内核 Jcs 单一实现（M26 遗留闭环项）。逐字节对齐结论钉死于判据：JSON 合法值域内与历史 AuditCanonical 输出恒同；差异只在 JSON 非法值——历史实现宽松改写（NaN→null / Date→{} / 数组 undefined→null，哈希静默盖住被改写的值），Jcs fail-closed 拒绝。**迁移即加固**：JSON 合法输入的历史审计报告逐字节可验（链头哈希不变），JSON 非法输入从静默改写变为显式拒绝。

- 判据：`tests/unit/jcsAuditAlignment.test.ts` 4 例（逐字 golden / 深度护栏 / fail-closed 矩阵 / 链头稳定性）。

## 0.1.0-alpha.12 — 2026-11-07（vendored tgz 发布，未 npm publish）

### Added（M28 插话词表配置化：defaults/interjection.json + omniharness.json interjection 段，2026-11-07）

- **插话词表全链配置化**（ssrfPolicy 同款链路）：`InterjectionClassifier` 的打断词 / 关联词 /
  确认句正则 / 停用词 / 三个判定旋钮（上下文条数 / 单条截断 / 重合阈值）此前写死在类常量里，
  现迁入 `defaults/interjection.json`（改数据不改代码）+ `InterjectionLexicon`
  （fail-closed 校验 + 逐键**替换**覆盖 + 出厂单例）+ `omniharness.json` 的 `interjection` 段
  （`interjectionConfigValidator` 加载期与运行时同源校验，configFactory 透传 ResolvedConfig）。
  零配置行为与迁移前逐字一致（判据①逐字钉住 27/30/34 词 + 正则源串 + 三旋钮）。
- 判据：`tests/unit/interjectionConfig.test.ts` 5 例（历史逐字 / fail-closed 矩阵 / 覆盖语义 /
  消费点真读配置 + 透传 + 加载闸门 / 反硬编码守卫）；`m28-interjection-config` 判据入 plan:check。

### Added（M27 兼容层清零：SDK 客户端族重审迁入 + 凭据打码单一事实源，2026-11-07）

- **SDK 客户端族**（重审迁入，推翻 2026-11-03「零引用」清零裁决——前提已失效，且 rpc 域自此
  服务端/客户端两半齐备）：`SdkSocket` 契约（server 端口）+ `SdkClient`（JSON-RPC 请求-响应 +
  通知订阅，请求超时/挂起清理/就绪语义齐备）+ `WebSocketSdkSocket`（Node 22 全局 WebSocket /
  注入工厂双形态）。**判据当场抓获真 bug**：`bindSocket` 对 onClose 分两次注册被「最后一次
  注册生效」语义覆盖，S14「就绪前 close 兑现 opened」在应用原实现中静默失效——已修
  （单一 onClose 注册），应用升级后同步受益。
- **凭据打码单一事实源** `SecretRedactor`：递归打码（键名像凭据即遮 / env·headers 只遮凭据名 /
  auth 整遮）+ `maskKey`（前 3 后 4，短 Key 全遮）——收敛 CLI dump / 服务端回传 / Key 展示
  三处独立实现的口径分裂。
- 判据：`tests/unit/sdkAndSecrets.test.ts` 6 例（call roundtrip / RPC error / 超时 / 通知订阅 /
  close 打断挂起 / S14 形态 / 事件映射 / 全局缺失 fail-closed / 打码矩阵）。

### Added（M26 应用侧终盘收编：kernel-compat 通用件 + 影子清偿，2026-11-07）

- **影子清偿前置**：`exports` 承诺闭包 += `kernel/rpc/jsonRpc` + `kernel/transport` 三件——内核早有同名实现
  （compat 清零时下沉），应用侧逐字节影子副本可随下次发版退役；迁移桥 252 → 315 条深路径（M21 预置形态）。
- **适配器补全族**（端口全在内核契约，实现归位）：审批档 `AskApproval` / `PlanApproval` /
  `GuardianApproval`（LLM 审查 + 预检直判）/ `BUILTIN_APPROVAL_RULES`（rm/del 拦截单一真源）；
  升级 `AskEscalation` / `AutoEscalation`；事件扇出 `CompositeEventPort`（fail-soft）；
  KV 三件套 `MemoryKv` / `JsonFileKv`（原子写）/ `SqliteKv`（node:sqlite 惰性加载 + 失败路径注入缝）。
- **vault 族**：`VaultPort` 契约 + `CryptoVault`（AES-256-GCM，主密钥级联：环境变量 → 密钥文件 0600 →
  自动生成）+ `EnvVault` + `CredentialResolver`（环境变量优先、保险库回退，hydrateEnv 只填未设置项）。
- **trace 自省族**：只读自省契约（Entry/Filter/ReadRequest/ReadResult/Port）+ `ReadonlyTraceReader`
  （冻结快照、seq=源流下标）+ `SessionEventReader`（JSONL 存档读取、路径穿越拒绝、归档冷存储回落）。
- **util/config 补全族**：`Retry`（指数退避 + 全抖动 + 测试时钟注入）、`JsonObjectFile`、`LocalDay`
  （时区归属单点）、`MimeType`（fail-closed 唯一事实源）、`PortablePath`（~/$VAR/%VAR% 展开 compact 往返）、
  `QuantileSketch`（GK 风格流式分位）、`ConfigRebase`（跨工作区重基，工作区耦合端口显式剔除）。
- **skill 签名 + asset 收编**：`SkillManifestSigner`（声明式技能子集 Ed25519 签名/验签）+
  `AssetPackCodec`（.ohb 容器 + 非对称验签，ADR-0011）/ `AssetPackInstaller`（五步流水线：验签→全量预检→
  入册→入账→报告；整包原子 + 档位只收紧 + 无台账拒装 + 写入失败补偿撤销）。
- **核心循环/观测补全**：`InterjectionClassifier`（插话分流六步判定，零模型调用）+
  `CacheMissAttributionAnalyst`（未命中分因七分支，"假读数"≠"真未命中"）+ `CacheHitRateWatch`
  （命中率坍塌告警，内核 `cacheHitRateCollector` 头注引用闭合）。
- 判据：`tests/unit/adapterCompletions.test.ts` 43 例（白名单派生不变量 / fail-closed / KV 三后端行为对齐 /
  GCM 认证失败矩阵 / 归档回落实搬 / GK 实测误差带 / 五步流水线 / 档位只收紧 / 补偿撤销 / 插话六步 /
  分因优先级）；`m26-*` 七条 auto 判据入 plan:check。诚实边界修正：QuantileSketch 头注的
  「确定性秩误差 ≤ εn」与实测不符（最坏 ≈0.07n 单调流 / 0.18n 随机流），改为实测带 + 恢复路径。

## 0.1.0-alpha.11 — 2026-11-07（vendored tgz 发布，未 npm publish）

### Added（M24 评测闭环与收尾，2026-11-07）

- **长任务 fixture 重建**（M22 最大遗留）：规格驱动生成器 + 23 个合成任务四件套（tasks/fixtures/verifiers/solutions），四族覆盖（结构化进度/库实现/修 bug/跨文件状态）；fixture 自带 `package.json`（type=commonjs）防沙箱 ESM 污染；**self-check 23/23 全绿**（参考解全过机械验收），dry-run 可用，跑分自动化仍待应用仓 CLI。
- 消费侧字面量漂移清偿：四文件策略表（toolResultSpiller/provenanceTracker/subagentTypes/acpQuestionUplink）全部收敛 TOOL_NAMES 单一来源（gate 永久把守）。
- 文档账实：README↔代码符号一致性 gate 锁定（「createOmniKernel 不存在」核实为审计误报）。

### Fixed（M23 断线清偿：盘点 6 缺失 + 5 畸形，2026-11-07）

- **ssrfPolicy 接线（安全级）**：用户配置的出站策略表此前声明/校验/透传三层齐全但运行时
  只喂内置默认档（静默不生效）。现在组合根 `resolveSsrfPolicy` 解析一次随 seed 下发，
  `web_fetch` 两处 egress 校验（首查 + 每跳重定向）消费注入表；未配置行为逐字不变。
- **plugin 端到端通电**：开启 `plugin.enabled` 此前只装配句柄不装载——现在
  `createOmniKernel` 启动即 `loadInstalled()`（逐件告警不断链）；`capabilities()` 补
  mediaStack / pluginStack / capabilityStack 三栈真实汇报；plugin / capability 入
  passthroughSections（ResolvedConfig 副本此前恒 undefined）。
- **工具面一致性**：补 `tests/unit/toolNames.test.ts`（源文件头注承诺却从未落盘的
  「单一来源」判据：已注册⊆表 / 表自洽 / 漂移哨兵）；loopGuard 写类口径从第二套字面量
  收敛到 TOOL_NAMES（新写类工具的振荡守卫此前会静默失效）；`spillMaxRings` 死字段删除；
  默认工具数注释 31/36→37/45（实测口径）等四处注释账实差。
- **eval runner**：任务目录缺失从裸抛错改为可行动指引（fixture 重建待办在案）。
- 审计纠偏如实入账：observability metrics 并非悬空（`TraceExporterAssembly.wrap` 已实现
  metrics 腿）；`pluginProfile` 与 locale/chatMode 同属应用层字段，非内核缺口。

### Added（M22 认知域重入：plugin / eval / media 自 attic 迁回，2026-11-07）

- **plugin 体系**（31+8 文件）：manifest 校验 / 权限门禁（fail-closed）/ 注册表与安装 /
  node:vm 沙箱 / 技能包 A–C 分级 / Worker 进程隔离 / HMAC 打包。新装配缝
  `PluginStackAssembler`：`plugin.enabled !== true` 即 undefined（加载外部代码 opt-in），
  权限白名单缺省 denyAll、`plugin.permissions` 显式放行（值域机检）；`pluginStack` 切片入
  `ResolvedConfig`；`defaultTools` 返回值增加裸注册表（插件工具注册落点，注册-只读视图
  防 execute 绕过审批/沙箱——原 2026-10-21 安全模型原样保留）。
- **eval 评测口径库**（4 文件）：`abMetrics`（pass@k / pass^k / 配对 bootstrap 固定种子）、
  `longMemEval`（LongMemEval-S 本地检索命中，直连 LongTermMemoryPort）、`longTaskCatalog`
  （fail-closed 校验 / 隔离沙箱 / 验证执行 / 自检）、`tracePatchPlanner`（失败→四步补丁计划）；
  执行入口 `scripts/eval/longTasks.mjs`。诚实边界：20 个合成 fixture 未随档幸存，待重建。
- **media 多模态栈**（53 文件）：GIF 全链解码 / PNG 编码 / 媒体嗅探 / 帧采样（零第三方依赖）+
  ffmpeg/ffprobe 适配器 + `view_image`/`view_media` 工具。`MediaStack` 恒装配随种子下行
  （GIF 零外部依赖，视频路径如实降级）；`RuntimeLimits` 声明式补 `media` 段（并发=4）；
  `mediaConfigValidator` 入配置校验链。
- 定位依据见 ARCHITECTURE §7.4（M4 孤儿归档的重裁：中枢 = 完整能力集，孤儿判据不再成立）；
  spark / genesis 维持不迁（experimentalPaths 在案）。

## 0.1.0-alpha.10 — 2026-11-07

### Changed（M21 Phase 3：域生成器解析源对齐承诺清单 + 承诺面 +1，2026-11-07）

- **承诺清单 +1**：`kernel/composition/runtime.js` 入列（app 域生成器黄标实战——B1 给
  `Runtime` 的新家未入 alpha.9 清单，黄标 → `kernel:check` 红 → 按设计倒逼内核扩承诺面；
  251 → 252 条）。该路径本就经 B1 成为 `Runtime` 的唯一家，应用合法消费。
- 应用侧（OmniHarness-app）：域生成器解析源改为「内核承诺清单第一优先 + dist 回退黄标」
  ——现有映射与索引候选都先过承诺过滤；stale 自续（指向已从承诺面消失的路径）在生成期
  即暴露，硬门禁由 kernel:check 的「导入 ⊆ 清单」承担。M21 至此两层全部落地。

## 0.1.0-alpha.9 — 2026-11-07

### Changed（BREAKING：迁移桥显式化，M21 Phase 2，2026-11-07）

- **`package.json#exports` 删除 `"./*.js"` / `"./*"` 通配**——内部路径不再自动公开。
  替代：**251 条显式深路径闭包**（唯一已知消费者 OmniHarness-app 的全部实际导入，
  由 `scripts/exportsClosure.mjs` 从应用源码生成）+ 原有 curated 子路径保留。
- 双向机检防漂移：内核侧（plan:check `m21-explicit-exports`）每条导出必须指向存在的
  dist 产物；应用侧（kernel:check）实际导入必须 ⊆ 显式清单——内核删条目 / 应用新消费
  未列条目，都在 install/CI 期红。
- 兼容性：直接深路径消费本就不承诺兼容（alpha 纪律）；已知消费者仅本应用，已全量
  回归验证。设计见 [RESEARCH-2026-11C.md](docs/RESEARCH-2026-11C.md)（Phase 3 生成器
  解析源对齐仍 open）。

## 0.1.0-alpha.8 — 2026-11-07

> 自 v0.1.0-alpha.7 tag 以来：M19 核心循环韧性 + M20 审计交付编码 + receipts OOP
> Phase A（审计链领域类化）。判据与复盘见 [ROADMAP.md](docs/ROADMAP.md)。

### Added（审计交付编码：压缩 / 口令加密 / 分片，M20，2026-11-07）

- **`AuditDeliveries.encode/decode`**（`@omniharness/kernel/receipts`）：JCS → gzip
  （缺省开，重复性事件流实测 >50% 收缩）→ 口令加密（scrypt N=2^15/r=8/p=1 +
  AES-256-GCM 认证加密）→ 分片（每片独立 sha256）→ `manifest.json +
  part-*.bin`——审计包/披露包从此可经不可信信道与归档场景交付。
- **分层口径**：编码不复核——解码只做传输完整性（分片摘要/字节数/内容摘要/GCM 认证，
  问题码 `AUDIT_DELIVERY_*`），语义复核仍走 `AuditBundles/DisclosurePacks.verify` 同一
  路径；`digest.txt` 对外锚定口径不受编码影响。
- **运行时/CLI 接通**：`kernel.exportAuditBundle(..., delivery?)` 直出交付编码；CLI
  `verifyBundle.mjs manifest.json trust.json --passphrase=…` 零出网复核（+gzip 魔数
  透明解压）；文档 API §1.12 / RECEIPTS §1.6。
- 诚实边界：加密护机密性，完整性与来源仍由签名 + 信任根承担，口令强度是宿主责任。
- 判据：`m20-audit-delivery`；契约 6 例 + embed 1 例；ROADMAP M20（含 scrypt maxmem
  踩坑记录）；迁移桥收窄单独立项决定入决策日志。

### Added（核心循环韧性：任务解决能力一大步，M19，2026-11-07）

- **模型重试与熔断默认开**：`modelRetry`/`modelCircuitBreaker` 修「文档宣称默认开、
  代码 opt-in」矛盾——裸 429/超时不再直接杀死整个 runTask；显式 `false` 才关闭。
- **步级可重试恢复**：可重试模型错误（模型层退避已耗尽）在回合内限额重试 2 次
  （重建上下文重新调用），转录留【模型瞬时错误】痕迹；超限仍走【回合失败】fail-closed。
- **过载降级装配**：`fallbackModel` 从死代码变成活能力——config 字段一键配置，主模型
  529/503 即切备用模型并留痕【模型过载】。
- **毒工具结构化反馈**：同一工具连续失败 3 次（成功清零；门禁拒绝/解析失败不计入），
  下一步上下文注入【工具异常】点名提示 + 错误摘要 + 改道建议——模型不再在坏工具上
  原样重试烧光步预算。
- **工具调用看门狗**：单次 JS 工具执行墙钟上限（缺省 600s，`toolCallTimeoutMs` 可调、
  0 关闭）——挂死且无视取消信号的工具不再冻结整回合，超时补可读失败结果供模型换道。
- **测试债收口**：新增 `tests/unit/loopResilience.test.ts`（9 例：LoopGuard 四检测器 /
  ToolScheduler 并行与屏障 / RetryingModel 分类与取消穿透）+ agentLoopAudit 扩 5 例
  （G/G2/H/I/J）。
- 判据：`m19-loop-resilience`（六项事实全部机检）；复盘见 [ROADMAP.md](docs/ROADMAP.md) M19。

## 0.1.0-alpha.7 — 2026-11-07

> 自 v0.1.0-alpha.6 tag（f362434）以来的全部工作：M8 效率收口 → M9 硬化 → M10 缺口补完 →
> M11 一次接入 → M12–M17 审计闭环 → M18 选择性披露。含 BREAKING：顶层 `AgentFactory`
> 符号位让给 `createOmniKernel`（M11）。判据与复盘见 [ROADMAP.md](docs/ROADMAP.md)。

### Fixed（测试仪器：tamper 判据去随机化，2026-11-07）

- `m11-embed-receipts-persist-tamper` 原以「改签名尾两字符为 AA」制造篡改，但 Ed25519 的
  S 分量已模 L ⇒ 签名末字节高 4 bit 恒为 0 ⇒ base64url 尾两字符以 ~1/16 概率恰为 'AA'，
  篡改退化为空转（存档原样通过复核，fail-closed 判据假警报、verify 间歇红）。改为改首
  字符（完整 6 bit，必然改变解码字节）；内核检出能力经探测实证无损（113/113 真篡改
  全部被拒）。

### Changed（形状守卫收敛为声明式 schema，2026-11-07）

- 新增内部件 `src/kernel/util/shapeGuard.ts`：极小组合子集（`objectOf` / `arrayOf` /
  `literal` / `matching` / `optional` / `nullable` / 叶子判定），校验策略表达为**数据**；
- 审计链五处手写形状守卫（auditPack 回执信封 / auditBundle / disclosurePack /
  executionCertificate / executionGraph）全部迁移为 schema 声明——检查语义全仓一个
  执行点，读 schema 如读类型；行为不变（判定语义由既有契约判据钉死），组合子直接
  用例见 `tests/unit/shapeGuard.test.ts`。

### Added（选择性披露：最小披露仍可验，M18，2026-11-07）

- **`buildDisclosurePack` / `signDisclosurePack` / `verifyDisclosurePack` /
  `disclosurePackDigest`**（`@omniharness/kernel/receipts`）：只交子集事件仍可离线
  复核的最小披露交付物——每条披露事件附 M14 包含证明锚回证书 Merkle 根，未选事件
  不出包，回执链裁剪到证书绑定的必需前缀（第 1 条到最大绑定条数）。
- **`kernel.exportDisclosurePack([{sessionId, indices}], directory?)`**：一次接入路径
  同步开放，落盘 `disclosure.json + trust.json + digest.txt`；CLI
  `scripts/verifyBundle.mjs` 按包内 `kind` 自动识别审计包/披露包。
- 判据：`tests/contract/disclosurePack.test.ts`（6 例：roundtrip / 最小化 / 篡改矩阵
  7 项 / 回执前缀 / 签名语义 / 叶子不变式）+ embed 内核级 1 例 +
  `tests/property/disclosurePack.property.test.ts`（2 条属性）；ROADMAP
  `m18-selective-disclosure`。

### Added（审计包运行时闭环，M17，2026-11-06）

- **`kernel.exportAuditBundle(sessionIds, directory?)`**：逐会话取事件、签发执行证书
  （绑定全局回执链当前尾）、打包、整包签名，落盘 `bundle.json + trust.json + digest.txt`；
  返回 `{directory,bundlePath,trustPath,digestPath,digest,signed}`。
- **链作用域修正**：回执链是 issuer 单链跨会话共享；证书绑定「签发时链尾前缀」，
  复核在全局链按 `receiptCount` 取第 count 条比对 `tailHash`，不再按会话过滤回执
  （过滤会破坏 `previousReceiptHash` 连续性）。
- 判据：embed 契约单会话 + 多会话同 issuer 链两例；`verifyAuditBundle` 复核通过；
  `m17-runtime-audit-bundle`。

### Added（审计包：单文件离线交付，M16，2026-11-06）

- **`buildAuditBundle` / `verifyAuditBundle` / `signAuditBundle` / `auditBundleDigest`**
  （`@omniharness/kernel/receipts`）：把「事件流 + 执行证书 + 回执链 + 执行图」打成一个
  可交付 JSON，一次复核四层——事件完整性/顺序/条数、回执链尾绑定（含验签）、执行图
  （节点/委派锚定/单根无环）、整包签名；逐层问题码可读。
- **离线 CLI**：`node scripts/verifyBundle.mjs bundle.json trust.json`（零出网；
  0=通过 / 1=复核失败 / 2=输入非法）。
- 判据：`tests/contract/auditBundle.test.ts`（4 例：roundtrip / 事件篡改 / 回执篡改+重复会话 /
  图缺失 / 签名伪造）；研究底稿 §9；ROADMAP `m16-audit-bundle`。

### Added（执行图谱系：多智能体可验证，M15，2026-11-06）

- **`ExecutionGraph`**（`@omniharness/kernel/receipts`）：节点 = 每次运行的执行证书，
  边 = 父会话在哪个事件里委派了子会话（可锚定 `delegationEventHash`）；整图签名。
- 离线复核 `verifyExecutionGraph`：逐节点重算证书、逐边锚定父事件（哈希 + 子会话 id）、
  结构单根/无环/单父（Kahn）、图签名（无信任根如实标 `UNPROVEN_ORIGIN`）。
  多父 / 环 / 多根 / 委派哈希错位分别返回可读问题码。
- 判据：`tests/contract/executionGraph.test.ts`（4 例）+ 属性
  `tests/property/executionGraph.property.test.ts`（随机树/删边/加环/改事件）；
  研究底稿 [RESEARCH-2026-11B.md](docs/RESEARCH-2026-11B.md) §8；ROADMAP `m15-execution-graph`。

### Added（执行证书：运行级可复核，M14，2026-11-06）

- **事件 Merkle 树**（`@omniharness/kernel/receipts`）：JCS 规范化叶子 + 域分离哈希 +
  奇数上提（不做末项复制，避免 `eventCount` 歧义）；`proveEventInclusion` /
  `verifyInclusion` 支持**单事件溯源**（无需交出整份日志）。
- **执行证书** `buildExecutionCertificate` / `signExecutionCertificate` /
  `verifyExecutionCertificate`：绑定 `{sessionId, eventCount, eventRoot}`，可选绑定
  回执链尾 `{issuerId, receiptCount, tailHash}` 与工具面摘要；签名对 `JCS(cert)`，
  收证方凭信任根离线验签。篡改/删改/换序/跨会话/换回执尾分别返回可读问题码。
- **研究底稿** [docs/RESEARCH-2026-11B.md](docs/RESEARCH-2026-11B.md)：问题、构造、
  安全论证、10k 事件实测（建树/证书约 0.8–0.9 s，单条验证 ~0.5 ms）、明确未做
  （witness 网络 / 公共透明日志 / 零知识选择性披露）。
- 判据：`tests/contract/executionCertificate.test.ts`（5 例）+ 属性
  `tests/property/merkleCertificate.property.test.ts`（5 属性）；ROADMAP `m14-execution-certificate`。

### Added（数学覆盖二期：调度 / 估算 / 覆盖率 / 回执并发，M13，2026-11-06）

- 属性测试从 5 文件 / 20 属性扩到 **9 文件 / 32 属性**（零第三方依赖、固定 seed、失败按
  `seed+trial` 复现）：
  - `fairScheduler`：等权会话服务量差额 ≤2、并发 ≤ limit、统计自洽、排队取消不占调度；
  - `tokenEstimator`：追加字符单调不减、消息列表 = 逐条之和、消息开销恒定、缓存不改变结果；
  - `rewardCoverage`：samples/verified/coverage 自洽、轮次差分可加、探针异常归不可验证；
  - `receiptsConcurrency`：异步 signer 下任意 N 并发 seq 连续/前驱成链，任意时刻摘要 = 链尾。
- [docs/MATH.md](docs/MATH.md) 覆盖矩阵同步（新增 4 行）；SFQ 从「示例级判据」升级为属性判据，
  仍不声称 regret/偏差界的证明。

### Added（架构图谱 + 数学不变量，M12，2026-11-06）

- **架构机检**：`npm run arch:check`（`scripts/archCheck.mjs`）——运行时依赖图 Tarjan SCC
  无环（`import type` 不计）、跨层边规则（contracts 叶子 / protocols 单一支撑面 /
  kernel→protocols 仅 `adapters/mcp` 与 `composition`）、[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)
  依赖快照与代码一致（`npm run arch:update` 重新生成）；已并入 `npm run verify`。
- **契约层收口**：`OmniError`/`ErrorCode` 与 `API_VERSION` 迁到 `contracts/`，根
  `src/omniError.ts` / `src/version.ts` 保留兼容再导出——消除 `contracts → 根入口`
  回指（运行时边），依赖图上的契约层成为真正叶子。
- **数学不变量**：新增零依赖确定性属性测试骨架 `tests/property/harness.ts`（mulberry32 +
  固定 seed + 失败定位到 seed/trial）；5 文件 / 20 属性覆盖 JCS（幂等/键序/良构/数字）、
  0/1 背包（与暴力枚举最优值对拍/可行性/确定性）、UCB1（冷启动/夹取/确定性/记账）、
  BM25（批量等价/词频单调/增量替换/排序）、哈希链与事件日志（确定性/前缀/水合/越界）。
- **诚实边界**：[docs/MATH.md](docs/MATH.md) 给出覆盖矩阵与三层口径（形式证明 / 属性测试 /
  示例判据），明确「属性测试不是证明」，并列出未覆盖项（形式化验证、regret 界、浮点误差界等）。
- 判据：ROADMAP `m12-arch-graph` / `m12-math-invariants`。

### Added（一次接入全部能力：顶层 `createOmniKernel`，2026-11-06）

- **`createOmniKernel(options)`**（顶层第 60 个符号；完整选项/句柄类型经
  `@omniharness/kernel/embed`）：把「宿主真正用起来」所需的胶水收进内核一次——主循环、内置
  工具/记忆/技能/计划/检索、工作台 HTTP/SSE、MCP 客户端（`config.mcpServers`）、MCP 服务端
  发布（`mcpServe`，缺省关）、长期运行遥测（`telemetry`，缺省关）、回执链（每次工具调用
  自动入链 + Ed25519 签名）一次装配；文件型存储还会自动扫描历史会话（工作台重启后侧边栏
  仍在）；宿主只留 6 行（`examples/embed.mjs`）。此前这些接线要每个宿主各写一遍
  （应用仓库的生成式对接面 + 122 文件 `kernel-compat` 的成因）。
- **BREAKING（顶层符号位交换）**：`AgentFactory` 移出顶层（下沉为内部件；`new Agent(runtime)`
  等价，且它从未被公开文档外的消费者使用），第 60 位让给 `createOmniKernel`；需要按运行时
  造 Agent 的调用方改用 `Agent` 构造器。`scripts/api-golden.json` 同批更新。
- **可核对的「全部能力」外形**：`kernel.capabilities()` 实时回答工具数 / 工作台地址 / 回执
  条数 / MCP 工具 / 审批 / 沙箱 / embedding / evolution / native / telemetry，不靠读代码猜。
- **安全默认不放宽**：模型缺省 `MockModel`（零凭据演示，且**不**读本机凭据）；审批缺省仍是
  `DenyApproval`、沙箱仍是 OS 隔离探测；工作台回环 `127.0.0.1:0`；MCP 未配置零连接。
- **生命周期收口**：`close()` 幂等，按「取消在跑回合 → 关 MCP → 落回执 → 冲刷事件 → 关工作台」
  顺序释放；`config` 透传任意 `OmniHarnessConfig` 字段，新增内核能力不需要同步改接入接口。
- **审计闭环（回执跨重启）**：`receipts.persist` 把回执链落到 `<workspace>/.omniharness/receipts/
  <issuerId>.jsonl`（append-only）并持久化 Ed25519 私钥（0600）；重启时 `ReceiptChain.adopt`
  逐条校验同 issuer / seq 连续 / 前驱相接后**续写不分叉**，启动即用 `verifyAuditPack` 复核既有链。
  坏行 / 断链 / 签名被改 / 有签名历史但密钥丢失 / 已签名链上 `sign:false` 一律 fail-closed。
  判据：`tests/contract/embedOneCall.test.ts` 的 `m11-embed-receipts-persist*`。
- **运行级执行证书接入**：`receipts.certificates` 在每个 `runTask/resume/fork` 结束后自动签发并
  落盘 `{certificate, signature}`（事件 Merkle 根 + 回执链尾 + 工具面摘要）；也可显式
  `kernel.certificate(sessionId)`。收证方用 `verifyExecutionCertificate(events, signed, {trustStore, receipt})`
  离线复核；改事件/删事件/换顺序/链尾不符均可检出。判据 `m11-embed-execution-certificate`。
- **审计三件套导出**：`kernel.receipts.exportBundle(dir?)` 一次写出 `pack.json` +
  `trust.json` +（有签名时）`summary.json`，第三方可直接用 `verifyAuditPack(pack, trust, summary)`
  或独立实现 `scripts/verifyReceipts.mjs` 离线复核；尾条被改/删由摘要的 `EXPECTED_MISMATCH` 检出。
  判据 `m11-embed-audit-bundle`。
- **单文件审计包接入（M16）**：`kernel.exportAuditBundle([sessionId])` 一次写出
  `bundle.json`（事件 + 执行证书 + 回执链，整包签名）+ `trust.json` + `digest.txt`；
  收证方用 `verifyAuditBundle(signed, {trustStore})` 或 `scripts/verifyBundle.mjs` 零出网复核；
  改事件/改回执/换证书/伪造签名全部 `ok:false`。判据 `m11-embed-full-audit-bundle`。
- 判据：`tests/contract/embedOneCall.test.ts`（工具回合 + 工作台投影 + 审计包真实验签 +
  MCP 客户端连接/反注册 + MCP 服务端健康与关端口 + 事件扇出 + 未签名语义 + config 透传 +
  非回环无令牌 fail-closed）；`m11-embed-minimal` 机检示例只经顶层、≤60 行、只调一次
  `createOmniKernel`；示例 `examples/embed.mjs`；文档 `docs/API.md` §1 / README 快速开始。

### Hardened（M10 缺口补完：取消传播 / 尾摘要签发 / mcpServers 装配，2026-11-06）

- **取消传播真正生效**：工具执行器与 `ToolContext.signal` 竞速（`StepToolExecutor.raceAbort`），
  用户停止不再等 60s 工具自然结束；`ToolScheduler` 穿透 `CancelledError`（不再吞成 failed
  ToolResult）；`ask_user` 等待期取消会清理 `WorkbenchHub` 挂起提问并释放会话锁；取消原因
  （`user`/`timeout`/`custom`）原样透传，不再折叠。
- **回执尾条可信摘要（签发侧）**：`ReceiptChain.summary()` 产出 `{issuerId, receiptCount, tailHash}`，
  `signSummary()` 用回执同一 signer 对 `JCS(summary)` 签名；`verifyAuditPack(pack, trustStore,
  signedSummary)` 验签并比对条数与尾哈希——尾条被改/被删由 `EXPECTED_MISMATCH` 检出，改摘要
  由 `SIGNATURE_INVALID` 检出；无 signer 时拒绝签发（不产出「看起来像承诺」的对象）。
- **`config.mcpServers` 真正装配**：字段进入 `OmniHarnessConfig`/`ResolvedConfig` 并由
  `ConfigFactory` 透传；新增 `startMcpServers(runtime)`（`@omniharness/kernel/mcp`），缺省用
  `SdkMcpConnector`（stdio / Streamable HTTP+SSE）逐台连接，经 `McpGateway` 把远端工具注册进
  工具面，`close()` 反注册；`auth` 的 bearer/oauth 令牌由 `McpAuthProvider` 真正变成
  `Authorization` 头（缺失即 fail-closed，不发匿名请求）。MCP 客户端栈因此从零入边转为可达。
- 判据：`tests/contract/cancellationPropagation.test.ts`、`receiptSummary.test.ts`、
  `mcpServersWiring.test.ts`、`tests/unit/mcpAuthProvider.test.ts`；ROADMAP M10 三条判据。

### Hardened（M9 硬化收口：接线审计 / 毛边 / 压力，2026-11-06）

- **接线审计有了机检**（`npm run wiring:check`，并入 verify 与 `plan:check`）：可达性图从
  「只从 `src/index.ts` 起算」改为**全部 8 个公开入口为根**——旧口径把 7 个子路径入口整棵判成
  死代码（127 文件 / 19,858 行），修正后为 42 文件 / 8,303 行；每个「src 内零入边且入口不可达」
  的模块必须在 [docs/WIRING.md](docs/WIRING.md) 逐条落账（接线/入口/内部保留/删除），
  文档引用的源码路径必须真实存在。
- **声明未接线修复**：README「哈希链化遥测 / 晋升台账可复核」的实现（`JsonlRuntimeTelemetry`、
  `PromotionHistoryService`、`HashChainPromotionLedger`）接进 `governance` 子路径；隔离阶梯
  `IsolationLadder` + 内置 wasm 执行器接进 `sandbox`；MRTR 三个 handler 接进 `mcp`，
  `McpHttpAssemblyOptions.inputRequired` 提供注入口（缺省关闭，显式接线才产生 `input_required`）。
- **毛边打磨（16 条回归判据）**：
  - 回执链 `append` 在异步 signer/anchor 下**并发分叉**（8 个并发全部拿到 seq 1）——队列队尾
    现在真正前移；此前 100 并发「零分叉」判据只测了同步路径，是假绿；
  - 工作台：非法 request-target 不再让进程因未处理拒绝退出（400）；`http.port` 真正生效
    （旧实现硬编码 `listen(0)`）；SSE 回放期重复投递去重 + **8 MiB 背压上限**（慢/挂起客户端
    不再无限占内存，超限断开由 EventSource 带 `Last-Event-ID` 续传）；`/answers` 校验回答 id
    与挂起问题精确匹配（错位/过期/重复 409，非法形状 400）；`decodeURIComponent`/null body/
    畸形审计包统一 400；`close()` 幂等；
  - `verifyAuditPack` 对畸形包 fail-closed（`MALFORMED_PACK`，不再抛裸 TypeError），并新增可选
    第三参 `{receiptCount, tailHash}`：线性链自身无法检出尾条被改/被删（没有后继绑定它），
    带外可信摘要给出时以 `EXPECTED_MISMATCH` 检出；
  - `MemoryStorage.append` 桶缺失时不再静默丢事件；`JCS` 孤立代理项按 `JSON.stringify` 转义
    （不再产出非法 UTF-8），非纯 JSON 对象（Date/Map/类实例）fail-closed；
  - MCP：CORS 预检免鉴权（浏览器 Bearer 客户端不再在预检阶段 401）、显式 `corsOrigin` 真正
    通过 Origin 防线；`McpServeRunner` 回退路径不再丢掉调用方的 `gate`（stdio 工具不再无审批）；
    `McpHttpAssembly` 使用 `runtime.gate`（计划态 / supervisor / RBAC 不再被外部调用绕过）；
  - 1,800+ 层嵌套工具参数不再让 `LoopGuard` 抛 RangeError 打崩整轮（深度上限 + 兜底）；
  - `sessionId` 空串与字面量 `_` 不再共用同一个存档文件，超长 id 报可行动错误。
- **压力/全面测试**：`tests/stress` 三文件 9 用例（20k 事件日志、40 会话 JSONL、350 回执链、
  20 并发 SSE、100 状态投影、1 MiB 请求体边界、200 步会话、8 并行工具、10 MiB 载荷），
  `npm run stress` 并入 `npm run verify`（独立 `vitest.stress.config.ts`，不拖慢 `npm test`）。
- **清账**：12 个零引用、零判据、注释指向已删模块（plugin / SDK / A2A / 应用层）的文件删除；
  `m4-zero-inbound` 改用「全部入口」口径。公开面不变（60/60）。

### Polished（M8 效率与内存收口：先测量后优化，2026-11-06）

- **仓内基准 harness**（`npm run bench`）：五探针 + 归因矩阵 + 冷热分离 + 内存滞留中位数采样，
  内核自身效率与内存从此可复现量化（此前历史性能结论全部引用仓外已删目录，不可复现）；
- **每步序列化短路三连**：前缀指纹 toolCalls 身份键缓存（**14.2×**）、工具 schema 序列化
  统一走 `schemaTextOf` 身份缓存（**137×**）、压缩游标引用相等短路（快路径零编码）——
  e2e 150 步会话热稳态 **1.08 → 0.74–0.86 ms/步（−20~−31%）**；
- **事件日志失效即重建快照**：`SessionRecorder.allEvents()`（每步 5+ 次全量读取扇出点）
  从每步 O(n) 浅拷贝改为 O(1) 引用返回（6000 事件稳态 **226×**）；快照冻结（fail-closed），
  `all()` 公开契约不变；
- **TokenEstimator 单例共享**：容量分解器与压缩器两套并行缓存栈合一，原生下沉单一事实源
  （内存收益≈噪声，如实记录；保留理由是消冗余与口径统一）；
- 调研底稿 [docs/RESEARCH-2026-11.md](docs/RESEARCH-2026-11.md)：静态分析与实测的偏差
  诚实记录——「4-6 份转录副本」被加固后的仪器证伪大半（真值 2.04×；首版 5.1× 是首跑
  混入语料索引的仪器污染）；冷索引 3.1s 一次性成本是全程最大单项，P3 五项按
  「实测过关才做」全部不做（理由逐条在案）。公开面不变（60/60），判据 `m8-*` 五条入账。

## 0.1.0-alpha.6 — 2026-11-04

> v0.1.0-alpha.6 tag（f362434）交付内容：M0–M6 + M4 + 对接参考文档。2026-11-05 起被应用
> vendored 钉版；2026-11-06 之后的增量（M8–M18）记入上方 alpha.7。

### Polished（工作台桥接层上线加固，同日第二遍打磨）

- `close()` 在有活跃 SSE 时**挂死**（node:http 的 close 等连接）→ 追踪并优雅结束全部活跃流；
- 跨端口浏览器 UI 需要 CORS → 回环回显默认（同 MCP 端口径）+ `corsOrigin` 收紧 + OPTIONS 预检免鉴权；
- EventSource 无法设头 → `?from=<seq>` 首连接续传 + `retry: 3000` 重连提示（`?token=` 鉴权口径写进 README）；
- 请求体无上限（DoS 面）→ 1 MiB 上限 413（drain 后回包，非 destroy）；坏 JSON 400 不落 500；路径命中方法不对 405；
- 长任务期间投影像卡死 → 进行中工具调用呈现 `pending: true`（结果到达自动消失，仍逐字节确定）；
- 历史会话侧边栏 → `discoverSessions` 钩子并入 `GET /api/sessions`（fail-soft 不 fail-silent）。

### Added（工作台桥接层，m6-workbench-bridge）

- **`@omniharness/kernel/workbench` 子路径**：把「UI 只做呈现」所需的全部内核侧设施一次备齐——
  - `WorkbenchHub`：`EventPort`（按会话扇出 + 全量直播缓冲 + 会话注册表）与 `UserResponder`
    （提问桥：`ask_user` 挂起 → HTTP 回答 → await resolve）双端口合一；
  - `WorkbenchServer`：SSE 事件直播（`Last-Event-ID`=seq 断线续传、15s 心跳）、`/state`
    一次投影快照、`/answers` 回答端点（409 防重放）、`/api/audit/verify` 审计复核；
    Bearer/`?token=`/cookie 鉴权，非回环绑定强制令牌（复用 `ServerAuthGuard`）；
  - `projectSession`：事件流 → 视图状态（消息流/reasoning 挂接/工具结果配对工具名/待办/计划/
    用量/回滚墓碑/挂起提问）的**确定性纯函数**，前端零事件语义知识。
- `examples/workbench.mjs`：端到端演示——3 行接线 → 脚本模型调 `ask_user` → 假浏览器经 SSE
  收帧、经 state 发现挂起提问并 POST 回答 → 模型拿到真答案完成回合 → 审计复核。
- 公开面不变（60/60，golden 一致）；判据 `m6-workbench-bridge` 入 M6 状态账。

### Docs（对接参考与浏览器投影收尾）

- **`docs/API.md` 全量对接文档**：包结构与子路径分工、最小 headless 接入、工作台 HTTP/SSE
  全量协议（鉴权/CORS/状态码/续传/心跳）、浏览器三种完整用例（会话 hook、提问弹窗、审计页）、
  `WorkbenchState`/`WorkbenchMessage`/`SessionEvent` 字段表、自定义 `ModelPort`/`ToolPort`、
  回执签发与离线复核；每条签名以源码为准（`runTask` 的第 4 参只给新会话命名，续跑用
  `agent.resume`——误把既有 id 交给 `runTask` 会用新事件流覆盖旧存档）。
- **`@omniharness/kernel/workbench-view` 子路径**：`projectSession` / `mergeEvents` 的浏览器
  安全出口（零 `node:`、零 I/O、可直接打包）；`workbenchViewPurity` 判据递归检查 re-export
  运行时图，`view:check` 在 build 后复核 `dist` 产物同一边界。

## 0.1.0-alpha.5 — 2026-11-04

> 执行 [PLAN-2026-11.md](docs/PLAN-2026-11.md)：M4 切片 → M5 立信 → M6 通电。
> 依据 [AUDIT-2026-11.md](docs/AUDIT-2026-11.md) 的盘点事实。完整归档：git tag `attic/2026-11-03`。

### Added（M5 立信）

- **RFC 8785 JCS 规范化**（零依赖，7 条附录向量逐字节一致；NaN/Infinity fail-closed 抛错）。
- **动作级签名回执链**：`{payload, signature, anchors}` 三键信封、`SHA256(utf8(JCS(payload)))`
  链式哈希、单 issuer 单线性链、并发追加互斥序列化（100 并发零分叉）。
- **锚定**：jose Ed25519 签名（裸 payload 字节）+ RFC 3161 TSA 客户端（手写最小 DER TSQ，
  可注入 fetch）；无 TSA/无网如实 `anchors: []`，绝不为凑数伪造锚。
- **离线独立复核器**：`verifyAuditPack`（kernel）+ `scripts/verifyReceipts.mjs`（**独立实现**
  JCS/SHA-256，不 import 内核——第三方可离线复核的可行性证明）。零出网；`ok`（链结构）与
  `compliant`（合规档）分层；篡改四类（改 payload / 删首条 / 换锚 / 重排）全部可检出且失败码可读。
- `docs/RECEIPTS.md`：与 IETF draft-marques-asqav-compliance-receipts 逐字段映射 + 未实现项清单
  （保留期 / witness quorum / counterparty binding / CMS 完整验证）。

### Added（M6 通电）

- **provenanceIssuer 提公开面**（`@omniharness/kernel/governance`）：出证/复核经公开入口可用；
  `examples/audit-pack.mjs` 端到端演示（产出 → 复核 → 篡改检出 → 出处证书）。
- **MCP HTTP 服务端通电**（`@omniharness/kernel/mcp`）：`McpHttpAssembly` 经组合根装配
  2026-07-28 无状态服务端；外部 MCP 调用与本地同过审批/沙箱门禁；端到端用例真实起服断言。

### Changed（行为，均有负例测试）

- **缺省审批 = 缺省拒绝**：未注入 `approvals` 落 `DenyApproval`（旧缺省 `AutoApproval` 全放行）。
- **缺省沙箱 = 探测 OS 级隔离**：Landlock / Windows 原生写隔离可用即用之；探测不到落回
  `PolicySandbox` 并**显式告警**（黑名单不是隔离）；`OMNI_SANDBOX_STRICT=1` 时探测失败即拒绝启动。
- **并行工具事件按模型调用序落盘**（此前完成序——重放不可字节复现）。
- **压缩确定性重建**：LLM 摘要路径整体移除；产物 = 任务目标（user 原文摘录）+ 历史经过 +
  确定性工具台账 + 交接便签——同输入逐字节同输出、零模型调用、不可降级；user 请求不再可能被压丢。
- `rollback` 不再擦自己的历史：截断后落自包含 `rollback` 墓碑事件（旧实现留悬空 tool_result → 厂商 400）。
- **"无损收缩"名副其实**：`collapseBlankLines`（删行尾空白/压空行）从收缩管线移除——它会在模型
  看到之前改写补丁上下文；`compress()` 里降为显式 opt-in。
- MCP capability 诚实：删除指向从未实现的 `resources/subscribe` 处理器的声明（2026-07-28 订阅走
  `subscriptions/listen`）。

### Removed（M4 切片；完整归档 `attic/2026-11-03`）

- `protocols/a2a` 整树（贴 v1.0 标签的 v0.3 线格式）、隐喻算子栈（共振场/QEC/免疫/信念/退火/
  CRISPR/固化/刻蚀/元素/对称破缺/禁闭/涡环 + 燧编排 + Genesis 桥）、`kernel/plugin`、
  `kernel/media`、`kernel/asset`、`kernel/eval` 长任务目录、`context/rankVeto`、80+ 零引用孤儿。
- 依赖：`openid-client`（零 import）、`croner`（唯一消费者已删）；`sharp`/`unpdf`/`@huggingface/transformers`
  随媒体栈移除；`yaml` 升为直接依赖。
- 配置键：`resonantField`/`memoryAnnealing`/`qec`/`immuneMonitoring`/`belief`/`skillEditing`/
  `capabilityCrystallization`/`insightEtching`/`elementComposer`/`symmetryBreaking`/`confinement`/
  `vortexRing`/`genesis`/`sparkAutoRun`/`a2a`/`media`。

### Changed（门禁与证据层）

- 证据层修复：上游判据回迁 40 件（414→436 用例）；12 件降级 `L0-unverified`（注明恢复路径）；
  新门禁 `maturity:check`（L1+ 必带证据，机检）。
- 门禁加固（四个绕过各配**变异判据**）：双语引号 import、protocolsSupport 精确匹配、
  `export * as` 展开计数、人工复核记录限定 §6 且 id 必须存在；`contracts` 零 `node:` 内建（规则 6）。
- **API golden 快照**：公开符号增删/改名必须显式 `--update-golden`；顶层 60/60。
- 工具类导出下沉 `@omniharness/kernel/tools`；新增子路径 `receipts`/`sandbox`/`governance`/`mcp`。
- `tests/` 纳入 typecheck（`tsconfig.test.json`，修出 21 处潜伏类型错误）。

### BREAKING

- 公开面 60 符号重排（工具类/receipts 类型面移子路径）；顶层新增回执核心 6 符号。
- 上述配置键与子路径 `dist/protocols/a2a`/`dist/kernel/{spark,genesis,media,plugin,asset,eval}` 消失。
- 缺省审批/沙箱语义见上；依赖缺省放行或黑名单口径的调用方需显式注入。

## 0.1.0-alpha.4 — 2026-11-03

### Added

- **子路径导出（迁移桥）**：`exports` 增加 `"./*.js"` / `"./*"` → `dist/*`，让第一个消费者
  OmniHarness 在**公开面迁移期**按内部模块路径接入（应用仓库已删掉 143,883 行重复内核副本）。
  **不是兼容承诺**：顶层仍是唯一稳定面（59 / 60）；子路径随迁移完成即删除，见 BOUNDARY「迁移桥」。

### Changed

- 无公开面变化；版本 `0.1.0-alpha.4`。

## 0.1.0-alpha.3 — 2026-11-03

**应用形状清零**（第二遍收口：把「不属于内核」的残留整棵子树删掉）。公开 API 不变（59 / 60）。

### Removed

- `contracts/ports/tui/`、`contracts/ports/license/`、`contracts/ports/server/audit{Format,Query}.ts`、
  `contracts/ports/enterprise/`、`kernel/adapters/enterprise/`、`kernel/security/oidcClient.ts`、
  `kernel/sdk/sdkClient.ts`、`contracts/schema/codeGenerator.ts`、`defaults/cliHelp.json`。
  合计 **19 文件 / 约 2.5K 行**，逐项确认零引用（`tsc` + 29 文件 170 用例为裁判）。
- 以上均不在公开面，`api:check` 仍为 59 / 60。

### Changed

- `docs/BOUNDARY.md` 新增「应用形状清零」节；`compat/` 表里 `oidcClient` / `sdkClient`
  的去向从「下沉内核」改为「删除」（下沉只保证能跑，不保证只剩内核）。

### Known issues

- **未执行 `npm publish`**（无发布凭据）：`npm pack` + 空目录安装 + headless 已跑通；
  正式发布需先 `npm login` 或提供 `NPM_TOKEN`。

## 0.1.0-alpha.2 — 2026-11-03

**beta 硬化（M3）落地**。公开 API 面不变（59 / 60），但 `decisionEngine` 有 alpha 破坏性变更。

### Added

- **契约测试扩容**：新增 `tests/contract/` —— 审批语义 13 例、沙箱语义 8 例、门禁接线 6 例；
  原三份契约用例（事件顺序 / 回放 / 压缩）同目录归位。共 **6 文件 32 例，只经公开入口**。
- `tests/unit/decisionEngineInjection.test.ts`（3 例）：钉住「配置了引擎却没实现 ⇒ 构建报错」。

### Changed

- **`adapters/laya` 移出内核**（9 文件 + `decisionEngineResolver` + Python 资产）：第三方 venv
  绑定不属于通用内核面，实现回到应用仓库。内核保留 `DecisionEngineConfig` 并新增注入缝
  `decisionEnginePort`；`mode` 非 `off` 却未注入实现时 `ConfigFactory.build` **直接报错**
  （此前会静默 new 出 Laya 实现）。
- `@beta` 组从四组 18 文件收敛为**三组 9 文件**（`user` / `monitoring` / `live`），
  裁决标记与「不进公开面」纪律不变。
- **测试总数 25 文件 / 140 例 → 29 文件 / 170 例**；`plan:check` 的 `m3-contract-coverage`
  由人工判据改为机检（`tests/contract` ≥30 例），`m3-adapters-beta-marked` 口径 18 → 9。

### Known issues

- **未执行 `npm publish`**（无发布凭据）：`npm pack` + 空目录安装 + headless 已跑通；
  正式发布需先 `npm login` 或提供 `NPM_TOKEN`。

## 0.1.0-alpha.1 — 2026-11-03

**规划闭环 + 发布就绪**。公开 API 面不变（59 / 60）。

### Added

- **唯一规划源** `docs/ROADMAP.md`：里程碑 M0–M3、判据表（auto / manual）、人工复核记录、
  发布记录、决策日志；「下一版做什么」不再散落在 BOUNDARY 的一句话里。
- **规划对账门禁** `scripts/planCheck.mjs` + `npm run plan:check`（已并入 `npm run verify`）：
  状态账与代码事实**双向**对账——标 ✅ 必须判据全过，标 ⏳ 必须至少一条不过
  （既防提前记账，也防做完不记账）。
- **公开面计数单一实现** `scripts/publicSurface.mjs`：`apiSurface.mjs` 与 `planCheck.mjs` 共用，
  避免两处数字漂移。
- **CI** `.github/workflows/verify.yml`：`ubuntu-latest` + `windows-latest` 双平台跑
  `npm ci → npm run verify → node examples/headless.mjs`。
- **发布元数据**：`private: false`、`publishConfig.access: public`、`files[]` 收入
  `docs/ROADMAP.md`。

### Changed

- `docs/BOUNDARY.md` 的「下一步」移交 ROADMAP；本文件只保留**已经发生**的变更，
  发布记录只写「就绪」与「已发布」中真正发生的那一个。
- README 增加规划入口与 `npm run plan:check` 说明。

### Known issues

- **未执行 `npm publish`**（无发布凭据）：`0.1.0-alpha.1` 处于「发布就绪」，
  `npm pack` + 空目录安装 + headless 已跑通，见 ROADMAP §7。

## 0.1.0-alpha.0 — 2026-11-02

首次以「独立内核」形态收口。**不承诺兼容**（alpha）。

### Added

- **独立组合根** `kernel/composition/runtime.ts`：`Runtime.createRuntime(config)` 可在任意 Node
  进程里装配 `Agent`，不再依赖应用层 `apps/composition`。
- **公开入口** `src/index.ts`：58 / 60 个符号（`npm run api:check` 机检），
  覆盖组合根、主循环、端口与默认适配器。
- **契约测试** `tests/`：22 文件 / 135 用例，只依赖 `src/` 与 Node 内置；
  含一次「只经公开入口」的 headless 回合。
- **20 行 headless 示例** `examples/headless.mjs` 与 `npm run smoke`。
- **构建资产复制** `scripts/build.mjs`：`dangerous-commands.json`、worker mjs、laya py
  随 `dist` 发布（此前 `tsc` 不搬运，运行期 ENOENT）。
- **独立安装** `package-lock.json`；`node_modules` 不再是应用仓库的 junction。
- **`npm pack` 冒烟**：空目录安装 tarball 后可直接跑通 headless。

### Changed

- `src/compat/` 10 个「从应用借来的共享件」全部下沉：
  - `jsonRpc` → `kernel/rpc/`
  - 行传输 / WebSocket 编解码 → `kernel/transport/`
  - `serverAuthGuard`、`oidcClient` → `kernel/security/`
  - `safeFs`、`serveInstance` → `kernel/util/`
  - `serviceKeys` → `kernel/composition/`
- `contracts/sdk/sdkClient.ts` → `kernel/sdk/`（契约层不放实现）。
- `TuiRenderer` 删除：内核只保留 `ConsoleLiveView` 需要的两个纯 ANSI 片段。
- **契约反向依赖清零**（依赖规则 1 归零）：限制类型族（`RuntimeLimitsConfig` 等 10 个接口）
  与 `Spectrum` 下沉 `contracts/ports/`；A2A 协议数据（`a2aProtocol` + `TaskHandler`）移入
  `contracts/ports/a2a/`，新增 `A2aServerPort` / `A2aClientPort` 端口，
  `OmniHarnessRuntime.a2a` 只认端口（实现类在 protocols 侧 `implements`）。公开面 58 → 59。
- **协议穿透收口**：`protocols` → `kernel` 的 76 条散点 import 收敛为唯一支撑面
  `kernel/protocolsSupport.ts`（30 个文件改走该边，纯 re-export 零逻辑，只导出实际消费符号）；
  新增 `npm run boundary:check` 分层边界机检（fail-closed，四条规则），
  首跑即抓出 `kernel/adapters/mcp` → `protocols/mcp` 的 5 处存量穿透并声明为窄例外。
- **适配器归属裁决**（授权自主裁决）：`adapters/laya`（厂商绑定，待移出）、`adapters/user` /
  `adapters/monitoring` / `adapters/live`（端口默认实现，保留）四组共 18 文件标 `@beta`，
  处置理由与迁移路径记入 `docs/BOUNDARY.md`；组内符号不进公开面（api:check 把守）。
- **机检收口**：`boundary:check` 升至五条规则（新增规则 5「契约纯净」——contracts 只许相对
  路径导入，零 `node:` 内置、零第三方包）；新增 **`npm run verify`** 一键机检入口
  （typecheck + boundary:check + test + build + api:check）；README / BOUNDARY 同步终态
  （公开面 59/60、25 文件 140 用例、机检入口与裁决记录）。
- **契约测试扩容**（22 → 25 文件 / 135 → 140 用例）：
  - 事件顺序：`session_meta` 首条、`seq` 严格递增、`tool_result` 永不先于 `tool_call`、
    数量守恒、最终答案在最后结果之后、端口所见 = 存储落盘；
  - 会话落盘回放：JsonlStorage 跨实例（重启模拟）往返一致、`replay` 不改写历史、
    `resume` 历史严格前缀 + `seq` 延续；
  - 压缩不变量：确定性无损收缩只动空白且幂等、折叠后工具轮配对（无孤儿 tool / 无悬空
    toolCall）、前导 system 原样钉住。
- 清理最后一个再导出别名：`kernel/adapters/tool/toolHandler.ts` 删除，5 个引用方直连
  contracts（`ToolHandler` 单一引入路径）。
- **支撑面收窄**：`a2aTaskExecutor` 生产默认（子代理工厂 / Agent 主循环 / FilteredToolPort）
  挪到组合根 `kernel/composition/a2aBridge.ts`，经 `buildSubagent` / `runTask` / `filterTools`
  注入缝装配（**alpha 破坏性**：三项构造选项改必填，缺省即装配期报错）；
  fail-closed 工具收窄**策略**留在协议层、**机制**注入。`AgentPort` 扩展 `eventsOf` /
  `cancelCurrentRun` / 可选 `sessionId`（协议桥只认端口）；新增 contracts `ToolRegistryPort`
  （MCP 网关不再感知 `RegistryToolPort` 具体类）。支撑面 27 → 21 符号（全基础设施），
  协议层对 `core` / `subagent` 的感知归零。

### Removed

- `src/compat/` 目录整体删除；`src` 内零 `apps/` import。

### Known issues

- `npm publish` 未执行（无发布凭据）；包已可 `npm pack`（0.1.0-alpha.0，不承诺兼容）。
- `adapters/laya` 长期应迁回应用仓库（已标 `@beta`，迁移路径见 BOUNDARY 裁决表）。
