# `defaults/` —— 随包发布的内建默认数据

这里的 JSON 是**数据**，不是代码。它们此前写死在 `.ts` 实现里，改一条网段、加一家模型厂商、
换一个端点地址都要改代码重新发布，或在多个文件间手工同步（CLI 的 `ADAPTER_PRESETS` 就曾是
`providerPresets.ts` 的手工副本；`https://api.openai.com/v1` 曾在 `cliBuildConfig` 与 `configBuilder`
里各写一遍）。现在改数据即可，用户特有的差异走 `omniharness.json` 或环境变量覆盖。

## 文件与消费方

| 文件             | 内容                                                | 单一来源实现                                          | 覆盖入口                                                         |
| ---------------- | --------------------------------------------------- | ----------------------------------------------------- | ---------------------------------------------------------------- |
| `ssrf.json`      | 云元数据主机 / 内网域名后缀 / IPv4 私有保留网段     | `src/kernel/security/ssrfPolicy.ts`（`DEFAULT_SSRF_POLICY`） | `omniharness.json` 的 `ssrfPolicy`                               |
| `providers.json` | 大模型厂商目录（端点 / 模型 / 推理档位 / CLI 映射） | `src/kernel/config/providerPresets.ts`（`ProviderPresets`）  | `omniharness.json` 的 `providerPresets`                          |
| `endpoints.json` | 适配器兜底端点/模型/凭据 env 名 + 各服务端点地址    | `src/kernel/util/endpointDefaults.ts`（`EndpointDefaults`）  | CLI/配置文件显式值 > 该适配器的 env > 本文件（服务端点见 `env`） |
| `limits.json`    | 运维限制（HTTP/预览源/浏览器/工具缺省限额）            | `src/kernel/util/runtimeLimits.ts`（`RuntimeLimits`）        | `omniharness.json` 的 `limits` > 数据里的 `env` > 本文件         |
| `interjection.json` | 插话词表（打断词 / 关联词 / 确认句正则 / 停用词 / 判定旋钮） | `src/kernel/core/steering/interjectionLexicon.ts`（`InterjectionLexicon`） | `omniharness.json` 的 `interjection`（逐键替换，缺省键回落本文件） |
| `harness-texts.json` | 模型可见固定文案（19 段：系统提示 / 纠偏 / 闸门 / 规划 / 续跑 / 收尾 / Guardian 审查 / 目标评审 / 记忆抽取 / diff 审查 / 上下文裁剪 / 运行期提示 / 工作流注入 / 压缩重建 / 长时程 primer / 合成消息前缀 / 能力探针 / RLVR 生成） | `src/kernel/util/harnessTexts.ts`（`HarnessTexts`） | 当前随包发布；后续可接 `omniharness.json` 文本覆盖段 |
| `tool-texts.json` | 工具定义描述（52 个 `TOOL_NAMES` 一一对应） | `src/kernel/util/toolTexts.ts`（`ToolTexts`） | 当前随包发布；缺条目时工具构造 fail-closed |
| `tool-param-texts.json` | 工具参数 schema 字段说明（`tool.path` 扁平键） | `src/kernel/util/toolTexts.ts`（`ToolTexts.parameter`） | 当前随包发布；缺条目时工具构造 fail-closed |

八个文件都由 `src/kernel/util/builtinDefaults.ts` 按**模块相对路径**读包根下的 `defaults/`（不做 cwd 推断），
结果缓存。**文件缺失 / 不可读 / 不是合法 JSON 一律抛错**（fail-closed）：安全默认档读不到时静默退化成空表，
等于护栏「看着还在、实际更松」。

> 发布要求：`package.json#files` 必须含 `defaults`，否则安装后启动即报错（这是刻意的响亮失败，不是静默放宽）。

## `ssrf.json`

三个字段**都必须存在且为数组**（缺任一段会被 `security/ssrfPolicy.ts` 当场拒绝）：

| 字段               | 含义                                     | 匹配方式                                      |
| ------------------ | ---------------------------------------- | --------------------------------------------- |
| `metadataHosts`    | 云元数据端点主机名 / IP                  | 精确匹配（`allowMetadata` 无法覆盖，恒拦）    |
| `internalSuffixes` | 内网 / 本机域名后缀，**必须以 `.` 开头** | `endsWith` 匹配（`localhost` 另有显式判定）   |
| `ipv4Blocks`       | `[基点, 前缀长度]` 形式的私有 / 保留网段 | CIDR 包含判定；同时作用于 IPv6 内嵌 IPv4 写法 |

`ipv4Blocks` 各项的由来（改动前请先想清楚「拦更多还是放更多」）：

| 网段          | 前缀 | 用途                                       |
| ------------- | ---- | ------------------------------------------ |
| `0.0.0.0`     | 8    | 本网络                                     |
| `10.0.0.0`    | 8    | 私有                                       |
| `100.64.0.0`  | 10   | CGNAT（运营商级 NAT）                      |
| `127.0.0.0`   | 8    | 环回                                       |
| `169.254.0.0` | 16   | 链路本地（**含云元数据 169.254.169.254**） |
| `172.16.0.0`  | 12   | 私有                                       |
| `192.0.0.0`   | 24   | IETF 协议分配                              |
| `192.168.0.0` | 16   | 私有                                       |
| `198.18.0.0`  | 15   | 基准测试                                   |
| `224.0.0.0`   | 4    | 组播                                       |
| `240.0.0.0`   | 4    | 保留（含 `255.255.255.255`）               |

**变更纪律**：这里的任何改动都会改变**所有未配置用户**的拦截面，须在看板登记并写明理由。
只想对自己环境生效，请写 `omniharness.json`：

```json
{ "ssrfPolicy": { "internalSuffixes": [".localhost", ".corp", ".mycompany"] } }
```

语义是**替换**（不是合并）：写了哪一项就整体替换哪一项，**显式给空数组**表示清空该项（显式且危险，不静默）。
非法条目（坏 CIDR、越界前缀、不以 `.` 开头的后缀、含空白的主机）一律抛错。

## `providers.json`

```json
{
  "presets": [
    {
      "id": "deepseek",
      "label": "DeepSeek",
      "adapter": "openai",
      "cliAdapters": ["openai"],
      "baseUrl": "https://api.deepseek.com",
      "defaultModel": "deepseek-v4-flash",
      "needsKey": true,
      "models": ["deepseek-v4-flash"],
      "reasoningEffort": ["none", "low", "medium", "high"],
      "notes": "来源 / 实测日期 / 为何这么配（纯文档字段）"
    }
  ]
}
```

| 字段              | 必填 | 说明                                                               |
| ----------------- | ---- | ------------------------------------------------------------------ |
| `id`              | 是   | 厂商标识，`providerKeys` 的键；**唯一**，不含空白                  |
| `label`           | 是   | UI 展示名（允许空格，如 `Moonshot Kimi`）                          |
| `adapter`         | 是   | `openai` / `anthropic` / `responses`——模型构造用哪个适配器         |
| `cliAdapters`     | 否   | 哪些 `--model-adapter` 取值应解析到本厂商，**缺省 `[adapter]`**    |
| `baseUrl`         | 是   | `http(s)://` 端点                                                  |
| `defaultModel`    | 是   | 启用该厂商时的默认模型                                             |
| `needsKey`        | 是   | 是否必需 Key（本地 Ollama 为 `false`）                             |
| `models`          | 是   | `/v1/models` 不可用时的兜底清单（可为空数组）                      |
| `reasoningEffort` | 否   | 该厂商合法的 `reasoning_effort` 档位；空/缺省 = 不暴露推理强度下拉 |
| `notes`           | 否   | 维护说明（来源、实测日期、遗留问题）；不参与任何判定               |

**加一家厂商只需改本文件**：追加一条记录即可，CLI（`--model-adapter` 反查、`providerKeys` 凭据兜底）、
服务端（厂商卡片 / Key 探测 / 运行时模型构造）与 UI 都从这一份派生。若它的 CLI 归属与 `adapter` 不同
（如 Ollama 的 `adapter` 是 `openai`、但 CLI 侧属 `llamacpp`），**显式写 `cliAdapters`**——不要另开映射表，
那正是此前两处漂移的根因。

用户可覆盖或追加（按 `id` **整条替换**，新 `id` **追加**；不做字段级继承，缺字段会被拒绝）：

```json
{
  "providerPresets": [
    {
      "id": "corp-gateway",
      "label": "公司自建网关",
      "adapter": "openai",
      "baseUrl": "https://llm-gateway.corp/v1",
      "defaultModel": "internal-1",
      "needsKey": true,
      "models": ["internal-1"]
    }
  ]
}
```

## `endpoints.json`

**适配器兜底**（`modelAdapters`）与**服务端点**（`services`）两段。前者是「连厂商都没选」时的最后一道默认，
后者是各功能模块自己要用的地址。

```json
{
  "modelAdapters": [
    {
      "id": "openai",
      "baseUrl": "https://api.openai.com/v1",
      "model": "gpt-4o-mini",
      "requiresApiKey": true,
      "apiKeyEnv": "OPENAI_API_KEY",
      "baseUrlEnv": "OPENAI_BASE_URL",
      "modelEnv": "OPENAI_MODEL",
      "notes": "改动理由 / 与哪个预设不可合并"
    }
  ],
  "services": [
    {
      "id": "pluginRegistryIndex",
      "url": "https://registry.omniharness.dev/index.json",
      "env": "OMNI_REGISTRY_URL",
      "notes": "…"
    }
  ]
}
```

| `modelAdapters` 字段 | 必填 | 说明                                                                              |
| -------------------- | ---- | --------------------------------------------------------------------------------- |
| `id`                 | 是   | 适配器标识（`--model-adapter` 取值：`openai`/`anthropic`/`responses`/`llamacpp`） |
| `baseUrl`            | 是   | 兜底端点（http(s)）                                                               |
| `model`              | 是   | 兜底模型名                                                                        |
| `requiresApiKey`     | 是   | 是否必须给 Key（本地 Ollama 为 `false`）                                          |
| `apiKeyEnv`          | 否   | Key 的环境变量名（**同时用于拼错误提示**，改名后提示自动跟随）                    |
| `baseUrlEnv`         | 否   | 端点的环境变量名                                                                  |
| `modelEnv`           | 否   | 模型名的环境变量名                                                                |
| `notes`              | 否   | 维护说明（为什么是这个值、与哪个预设不可合并）                                    |

生效优先级（`cliBuildConfig.buildModel` 与 `configBuilder.buildRouterAdapter` 同一口径）：
**CLI / 配置文件显式值 > `xxxEnv` 环境变量 > 本文件的 `baseUrl` / `model`**。

| `services` 字段 | 必填 | 说明                                                                   |
| --------------- | ---- | ---------------------------------------------------------------------- |
| `id`            | 是   | 服务标识（调用方按字面量取用；**拼错即抛错**，不会静默拿到 undefined） |
| `url`           | 是   | 地址；支持 `{port}` 模板（由调用方代入）                               |
| `env`           | 否   | 可覆盖该地址的环境变量名                                               |
| `notes`         | 否   | 维护说明                                                               |

现有服务端点：`pluginRegistryIndex`（插件市场索引，env `OMNI_REGISTRY_URL`）、
`gitRemoteBase`（SWE-bench 克隆远端基址）、`githubApiBase`（GitHub Contents API，env `GITHUB_API_URL`，
沿用 GitHub Actions 标准名，故 GHE 环境天然生效）、`cdpProbeUrl` / `cdpVersionPath`（浏览器 CDP 自检）、
`webSearchBrave` / `webSearchTavily`（Web 搜索端点，env `BRAVE_SEARCH_URL` / `TAVILY_SEARCH_URL`）、
`hfMirror`（HuggingFace 镜像，env `OMNI_HF_ENDPOINT`）、`geminiBase`（Gemini 原生 API 基址，env
`GEMINI_BASE_URL`；配置项 `baseUrl` 仍优先）。

**别把 `endpoints.json` 与 `providers.json` 合并**：厂商预设按**厂商**组织、可被用户整体覆盖；
适配器兜底按**适配器**组织、是「没选厂商」时的兜底。合并会让「用户覆盖某厂商」意外改掉适配器兜底。
最典型的例子是 Ollama：`endpoints.json` 的 `llamacpp` 兜底是 `http://localhost:11434`（原生 `/api/chat`），
而 `providers.json` 的 `ollama` 预设是 `http://localhost:11434/v1`（OpenAI 兼容层）——**两者都对，勿统一**。

## `limits.json`

**运维限制**：HTTP 主服务的收头/请求时限、并发连接数、请求体上限、静态缓存上限；工作区网页预览源
的同名三项；A2A 互操作的调用/投递/传输超时、缺省页大小与游标有效期、任务与推送桶上限、入站请求体上限；
工具族缺省限额（`web_fetch` 的超时与响应体上限、shell 并发与队列上限）；媒体抽帧的 ffmpeg 并发；浏览器
（CDP/Playwright）的动作/加载/CDP/建连/启动/探测/空闲关闭超时；LSP 的请求/诊断等待超时；维护巡检与
会话保留策略（keepNewest / 年龄 / 总量、临时清扫阈值、周期间隔）。这些值此前写死在
`HttpServer` / `PreviewServer` / `A2aClient` / `A2aPushNotifications` / `A2aTaskStore` / `A2aTaskPager` /
`HttpA2aTransport` / `HttpA2aServerTransport` / `WebFetchTool` / `FairSessionScheduler` 装配处 /
`MediaStackAssembler` / `CdpClient` / `ChromeProcess` /
`BrowserSession` / `PlaywrightBrowserSession` / `BrowserAvailability` / `BrowserScreenshotTool` /
`BrowserActTool` / `LspProcessAdapter` / `LspJsonRpcConnection` / `SessionGc` / `TmpSweep` /
`MaintenanceRunner` 里，改一次要改代码重发。

```json
{
  "http": {
    "headersTimeoutMs": { "value": 30000, "env": "OMNI_HTTP_HEADERS_TIMEOUT_MS", "notes": "…" },
    "maxBodyBytes": { "value": 8388608, "env": "OMNI_HTTP_MAX_BODY_BYTES", "notes": "…" }
  },
  "preview": {
    "maxConnections": { "value": 64, "env": "OMNI_PREVIEW_MAX_CONNECTIONS", "notes": "…" }
  },
  "a2a": {
    "clientTimeoutMs": { "value": 60000, "env": "OMNI_A2A_CLIENT_TIMEOUT_MS", "notes": "…" },
    "webhookTimeoutMs": { "value": 10000, "env": "OMNI_A2A_WEBHOOK_TIMEOUT_MS", "notes": "…" },
    "pageSize": { "value": 50, "env": "OMNI_A2A_PAGE_SIZE", "notes": "…" },
    "pageTokenTtlMs": { "value": 86400000, "env": "OMNI_A2A_PAGE_TOKEN_TTL_MS", "notes": "…" },
    "maxPushConfigsPerTask": {
      "value": 20,
      "notes": "单任务 push 配置上限（env 仍由 LimitEnv 宽松解释）"
    },
    "maxPushTasks": { "value": 500, "notes": "push 配置桶总数上限" },
    "maxTasks": { "value": 500, "notes": "A2A 任务记录上限" },
    "maxArtifactsPerTask": { "value": 200, "notes": "单任务产出上限" },
    "transportSendTimeoutMs": {
      "value": 10000,
      "notes": "出站 send 空闲超时（env 仍由 LimitEnv 宽松解释）"
    },
    "transportReadTimeoutMs": { "value": 30000, "notes": "入站读超时" },
    "transportMaxBodyBytes": { "value": 1048576, "notes": "入站请求体上限" }
  },
  "tools": {
    "webFetchTimeoutMs": { "value": 30000, "env": "OMNI_WEB_FETCH_TIMEOUT_MS", "notes": "…" },
    "webFetchMaxBytes": { "value": 200000, "env": "OMNI_WEB_FETCH_MAX_BYTES", "notes": "…" },
    "shellConcurrency": {
      "value": 8,
      "notes": "前台 shell 并发上限（env 仍由 LimitEnv 宽松解释）"
    },
    "shellQueuePerSession": { "value": 64, "notes": "单会话 shell 排队上限" },
    "shellQueueTotal": { "value": 256, "notes": "全部会话 shell 排队总上限" }
  },
  "media": {
    "processConcurrency": {
      "value": 4,
      "notes": "ffmpeg/ffprobe 并发进程上限（env 仍由 LimitEnv 宽松解释）"
    }
  },
  "browser": {
    "actionTimeoutMs": { "value": 10000, "env": "OMNI_BROWSER_ACTION_TIMEOUT_MS", "notes": "…" },
    "loadTimeoutMs": { "value": 30000, "env": "OMNI_BROWSER_LOAD_TIMEOUT_MS", "notes": "…" },
    "commandTimeoutMs": { "value": 20000, "env": "OMNI_BROWSER_COMMAND_TIMEOUT_MS", "notes": "…" },
    "connectTimeoutMs": { "value": 15000, "env": "OMNI_BROWSER_CONNECT_TIMEOUT_MS", "notes": "…" },
    "launchTimeoutMs": { "value": 30000, "env": "OMNI_BROWSER_LAUNCH_TIMEOUT_MS", "notes": "…" },
    "probeTimeoutMs": { "value": 5000, "env": "OMNI_BROWSER_PROBE_TIMEOUT_MS", "notes": "…" },
    "idleCloseMs": { "value": 180000, "env": "OMNI_BROWSER_IDLE_CLOSE_MS", "notes": "…" }
  },
  "lsp": {
    "requestTimeoutMs": { "value": 15000, "env": "OMNI_LSP_REQUEST_TIMEOUT_MS", "notes": "…" },
    "diagnosticsTimeoutMs": {
      "value": 5000,
      "env": "OMNI_LSP_DIAGNOSTICS_TIMEOUT_MS",
      "notes": "…"
    }
  },
  "maintenance": {
    "keepNewest": { "value": 50, "notes": "会话保留条数（配置最低 1：0 = 清空全部，属脚枪）" },
    "maxAgeDays": { "value": 90, "notes": "会话年龄阈值（天）" },
    "maxBytes": { "value": 4294967296, "notes": "会话存档总量上限" },
    "tmpOlderThanMs": { "value": 86400000, "notes": "临时目录清扫阈值" },
    "intervalHours": { "value": 6, "notes": "serve 周期巡检间隔" }
  }
}
```

> **`maintenance` 段为什么没有 `env`**：这四个环境变量（`OMNI_GC_KEEP` / `OMNI_GC_MAX_AGE_DAYS` /
> `OMNI_GC_MAX_BYTES` / `OMNI_MAINTENANCE_INTERVAL_HOURS`）由 `MaintenanceRunner` 按**旧语义**解释——
> 写错就忽略并回落，绝不让维护因一个坏环境变量停摆。本段只承载"出厂值 + 配置覆盖"，环境变量在
> `MaintenanceRunner` 里叠在配置之下：**显式选项 > 配置段 > env > 本文件**。
>
> **`tools.shell*` 与 `media.processConcurrency` 为什么也没有 `env`**：同一条理由——`OMNI_SHELL_*` 与
> `OMNI_MEDIA_PROCESS_CONCURRENCY` 由调用点的 `LimitEnv.int` 宽松解释（写错回落），数据只提供默认值，
> 配置段作为更高优先的严格层：**配置段 > env > 本文件**。把 env 名写进数据会绕过 `LimitEnv` 的宽松语义。

| 字段    | 必填 | 说明                                                                |
| ------- | ---- | ------------------------------------------------------------------- |
| `value` | 是   | 出厂默认值（正整数，区间由 `RuntimeLimits` 的 `SCHEMA` 定义）       |
| `env`   | 否   | 可覆盖该项的环境变量名（形如 `OMNI_XXX`；**全局唯一**，重名即拒绝） |
| `notes` | 否   | 维护说明（为什么是这个值、何时该改）；不参与任何判定                |

**必须给全每段的每个键**（缺键即抛错）：缺一项就等于「默认值悄悄改了」，比启动失败更难查。
未知段 / 未知键 / 非整数 / 越界 / env 重名也一律在构造期抛错（fail-closed）。

生效优先级：**`omniharness.json` 的 `limits` 段 > 数据里 `env` 字段声明的环境变量 > 本文件的 `value`**。
只写要覆盖的项即可（逐键覆盖，不是整段替换）：

```json
{ "limits": { "http": { "headersTimeoutMs": 45000, "maxConnections": 4096 } } }
```

配置段与数据文件**同源校验**（`limitsConfigValidator` 直接调用 `RuntimeLimits.validateConfig`）：
未知段/未知键、非整数、越界一律拒绝启动——这些值直接决定「服务会不会被慢速头拖死 / 被大请求体打爆」，
静默回落默认值是最危险的一种"看起来配了"。

## `interjection.json`

**插话词表**（M28，2026-11-07）：`core/steering/interjectionClassifier` 此前把七组数据写死在类
常量里——调一条词、换一个阈值都要改代码重发。现全部迁入本文件。

| 字段              | 出厂值  | 说明                                                                                     |
| ----------------- | ------- | ---------------------------------------------------------------------------------------- |
| `interruptMarkers` | 27 条  | 「停止当前 / 换个任务」词表；小写化**子串**命中即判**无关**（优先级最高）                 |
| `relatedMarkers`   | 30 条  | 「同一任务」关联词表；子串命中即判**相关**                                                |
| `ackPattern`       | 正则源串 | 短确认句；**整句全匹配**（编译旗标 `i` 固定在代码侧——旗标进数据会诱导写出 `g` 这类带状态旗标） |
| `stopTokens`       | 34 条  | 词面重合停用词（中文双字切分 + 英文词统一剔除）——不剔除时「帮我查一下…」与「帮我改一下…」会被误判成同一话题 |
| `contextMessages` | `12`    | 上下文最多取几条消息（1–200）                                                             |
| `contextChars`    | `2000`  | 单条消息截断长度（1–1000000）                                                             |
| `overlapRatio`    | `0.15`  | 词面重合比例阈值（0–1）：新文本非停用词至少这么多比例出现在最近对话中才算相关              |

判定优先级「打断 > 关联 > 短确认 > 词面重合 > 新话题」是**代码口径**，不随数据变。

**必须给全每键**（缺键即抛错）：缺一项就等于「默认词表悄悄变了」。未知键 / 重复条目 /
空串条目 / 不可编译的正则 / 数值越界一律在构造期抛错（fail-closed）；本文件缺失 / 不可解析
让进程启动即失败——空打断词表意味着「算了/停止」全部失效，绝不静默退化。

**变更纪律**：改本文件会改变所有未配置用户的插话分流面。只想对自己环境生效，写
`omniharness.json`（语义是**逐键替换**，不是合并：写了哪键整体替换哪键，缺省键回落本文件；
**显式空数组 = 清空该词表**——显式且危险，不静默）：

```json
{ "interjection": { "relatedMarkers": ["接着", "补充", "再迭代一轮"] } }
```

配置段与出厂档**同源校验**（`interjectionConfigValidator` 直接调用 `InterjectionLexicon.resolve`）：
未知键 / 非法条目 / 坏正则 / 越界一律拒绝启动。词表不是安全放宽面（只影响话题分流启发），
故不列入 `workspaceTrust` 敏感键。

## 改完怎么验

```bash
npm run typecheck && npm test          # 钉住「默认值与历史逐字一致」与端点/限制数据回归
npm run boundary:check                # contracts 纯净面 + 分层方向
npm run wiring:check                  # 配置字段的「声明→装配→运行时→消费」四段接线
npx vitest run tests/unit/endpointDefaults.test.ts tests/unit/limitEnv.test.ts
```

`tests/unit/endpointDefaults.test.ts` 里有一条**反硬编码守卫**：它会扫描 `src/**` 的代码行（注释除外），
若 `api.openai.com` / `api.anthropic.com` / `localhost:11434` / `registry.omniharness.dev` / `api.github.com`
/ `github.com/` / `/json/version` 再次出现在实现里（而不是本目录的数据文件），测试直接失败。

`tests/unit/hardcodeAudit.test.ts` 是上面那些「具体字面量守卫」的**一般化版本**：它调用清单脚本，
断言**已迁移的消费者里一条 ≥1000 的运维数值字面量都没有**（不管是不是旧值），且 `src` 里没有
`LimitEnv.int('OMNI_X', <数字>)` 这种「env 名 + 内联默认值」的老写法。行内注 `hardcode-exempt`
可豁免（当前仅 SSE `retry:` 协议值与 PowerShell 清理探针的本地超时两条，见看板 §195）。

`tests/unit/runtimeLimits.test.ts` 有同形的守卫：`httpServer.ts` 不得再出现 `30_000` / `60_000` / `2048` /
`8 * 1024 * 1024`，`previewServer.ts` 不得再出现 `15_000` / `30_000` / `maxConnections = 64`，
`a2aClient.ts` 不得再出现 `60_000`、`a2aPushNotifications.ts` 不得再出现 `DEFAULT_WEBHOOK_TIMEOUT_MS`、
`a2aTaskPager.ts` 不得再出现 `DEFAULT_PAGE_SIZE` / `DEFAULT_TTL_MS`、`webFetchTool.ts` 不得再出现
`DEFAULT_MAX_BYTES` / `DEFAULT_TIMEOUT_MS` / `200_000`，`sessionGc.ts` 不得再出现 `DEFAULT_KEEP_NEWEST = 50` /
`90 * 24` / `4 * 1024 * 1024 * 1024`、`tmpSweep.ts` 不得再出现 `DEFAULT_AGE_MS = 24 * 60 * 60 * 1000`、
`maintenanceRunner.ts` 不得再出现 `DEFAULT_INTERVAL_HOURS = 6`、`lspJsonRpcConnection.ts` 不得再出现
`DEFAULT_REQUEST_TIMEOUT_MS = 15000`、`lspProcessAdapter.ts` 不得再出现
`DEFAULT_DIAGNOSTICS_TIMEOUT_MS = 5000`，浏览器族的 `cdpClient.ts` / `chromeProcess.ts` /
`browserAvailability.ts` / `browserSession.ts` / `playwrightBrowserSession.ts` 与两个浏览器工具
也不得再写死各自的超时/空闲关闭值——
这些值只能来自本目录的 `limits.json`。该判据还实构造一个 `HttpServer` 断言连接级参数就是配置值
（"声明未接线"在结构判据里也会被抓）；`webFetchTool.test.ts` 另有两例断言 `web_fetch` 的缺省值
真的来自限额（注入后调用参数与工具说明同时变化）；`maintenanceRunner.test.ts` 有一例断言
`limits.maintenance.tmpOlderThanMs` 真的改变了清扫结果（阈值 10 天时 2 天前的条目不被删）；
`lspProcess.test.ts` 有一例用 1ms 请求超时对真实 mock LSP 断言 fail-closed；
`browserActFallback.test.ts` 有一例把 `limits.browser.idleCloseMs` 设成 5ms，断言空闲后真的自动关闭。
