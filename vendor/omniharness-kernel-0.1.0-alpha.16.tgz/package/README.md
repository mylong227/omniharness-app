# OmniKernel

> **可嵌入的 agent 中枢：模型是大脑，内核是中枢神经系统，应用只是壳。**
> 可审计、fail-closed、模型中立。

OmniKernel 是从 [OmniHarness](https://github.com/mylong227/OmniHarness) 切出的独立内核项目。
中枢只做三件事：

1. **让大脑看得准（所见即所得）**——上下文组装 / repo 地图 / 语义检索 / 技能 / 长期记忆，
   把「所见」准确组装给模型，而不是让它裸猜；
2. **让大脑动得了手（每步可审计）**——跑 agent 主循环、管住工具与审批，把每一步落成可回放的事件；
3. **让想错的拦得住（可验证而非口说）**——证据台账 / 完成闸门 fail-closed / 签名回执链 /
   RLVR 可验证奖励晋升台账；内核不承诺「生成时正确」，承诺「可验证、可拦截、可晋升」。

大脑由 `ModelPort` 可插拔（OpenAI 兼容 / Anthropic / llama.cpp / 自写适配器同权）；
CLI / Web / Desktop 是壳，留在 OmniHarness——**应用是内核的第一个消费者，不是内核的上游**。
谁负责什么、通没通电、还有哪些域待从原项目迁入：见
[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) §7「组织架构图谱」（目录 = 内容域，层级 = 组织）。

## 四个不变量

| 不变量 | 含义 |
| ------ | ---- |
| **可审计** | 会话事件追加式落盘、可按 `seq` 回放；动作级**签名回执链**（JCS 规范化 + 单 issuer 线性链 + RFC 3161 锚定 + 独立复核器，见 `docs/RECEIPTS.md`）与哈希链化遥测/晋升台账可复核；模型与工具之间没有"看不见的步骤" |
| **fail-closed** | 审批/升级/完成闸门缺省拒绝；沙箱缺省探测 OS 级隔离，探测不到时**非 strict 落 `PolicySandbox` 并 warn（明确不是隔离）**，`OMNI_SANDBOX_STRICT=1` 才启动失败；读不到安全数据就启动失败，不静默放行 |
| **模型中立** | 只认 `ModelPort`；OpenAI 兼容 / Anthropic / llama.cpp / 自写适配器同权 |
| **可嵌入** | 无 CLI 依赖；组合根 `Runtime` + 主循环 `Agent` 即可在任意 Node 进程里跑 |

## 安装

```bash
npm i @omniharness/kernel
```

要求 Node.js ≥ 22.14。下面的示例只 `import '@omniharness/kernel'`；在仓库内开发则先
`npm ci && npm run build` 再跑。

## 快速开始

```bash
npm ci
npm run build
node examples/embed.mjs
```

`examples/embed.mjs` 的核心只有 6 行——**一次 `OmniKernel.create()` 就拿到全部宿主侧能力**
（主循环 + 内置工具/记忆/技能 + 工作台 HTTP/SSE + 回执链 + MCP 客户端；未配置的能力零开销）：

```js
import { OmniKernel } from '@omniharness/kernel';

const kernel = await OmniKernel.create({
  workspaceRoot: process.cwd(),
  model, // 任意 ModelPort；缺省 MockModel 可零凭据先跑通
});
const result = await kernel.runTask('把端口改成 8787');
console.log(result.finalText, kernel.capabilities()); // 哪些能力已通电，一眼可见
await kernel.close(); // 幂等：取消在跑回合 → 关 MCP → 落回执 → 关工作台
```

工作台地址在 `kernel.capabilities().workbench.url`；回执包经 `kernel.receipts.pack()`
导出、`verifyAuditPack` 离线复核；`receipts: { persist: true }` 会把链与私钥落盘并在
重启后续写（坏链/丢钥 fail-closed），`certificates: true` 还会在每回合后自动签发运行级
执行证书（事件 Merkle 根 + 回执链尾），`kernel.receipts.exportBundle()` 一次导出
`pack.json` + `trust.json` + `summary.json` 供第三方离线复核，`kernel.exportAuditBundle([id])`
则交付含事件 + 证书 + 回执 + 整包签名的单文件审计包；MCP 客户端在 `config.mcpServers`
非空时自动连接，`mcpServe: true` 则把本内核作为 MCP 服务端发布（外部客户端与本地同一道
审批/沙箱门禁）；`telemetry: true` 自动落长期运行哈希链（`kernel.telemetry.verify()` 可复核）。
每一项都可关（`workbench: false` / `receipts: false`），其余内核配置经 `config` 透传。
完整选项、能力对照表与手动接线方式见 [docs/API.md](docs/API.md) §1；
`OmniKernel` 等完整类型经 `@omniharness/kernel/embed` 导入。

`examples/headless.mjs` 保留为**手动接线**对照（20 行，显式挑六个端口）。
从源码跑时把 import 换成 `../dist/index.js`；发布后用包名即可。

## 目录

| 路径 | 内容 |
| ---- | ---- |
| `src/contracts` | 端口 / 类型 / 错误 / schema —— **零实现**，公开 30 个符号 |
| `src/kernel` | 主循环、上下文、工具、门禁、审计、存储、编排、组合根、一次接入 |
| `src/protocols` | ACP / MCP / AG-UI（取用内核能力只经 `kernel/protocolsSupport.ts` 单一支撑面） |
| `tests/` | 纯内核测试（无 CLI / Web 夹具），`npm test`；压力套件 `tests/stress` 经 `npm run stress` |
| `scripts/` | `build.mjs`（tsc + 运行时资产复制）、`apiSurface.mjs`（公开面门禁）、`boundaryCheck.mjs`（分层边界机检）、`archCheck.mjs`（架构图谱：运行时无环/跨层边/快照）、`wiringCheck.mjs`（接线审计：公开入口/零入边/文档落账）、`workbenchViewCheck.mjs`（浏览器安全子路径产物门禁） |
| `defaults/` | 随包发布的策略 / 厂商 / 限制数据（改数据不改代码） |
| `examples/` | embed（一次接入）/ headless（手动接线）/ workbench / audit-pack 示例 |

## 公开 API

唯一稳定入口是 `@omniharness/kernel`（`src/index.ts`），当前 **60 / 60** 个符号：

- **组合根**：**`OmniKernel.create()`（一次接入全部宿主侧能力）**、`Runtime`、`ConfigFactory`、`OmniHarnessConfig`、`ResolvedConfig`、`OmniHarnessRuntime`
- **主循环**：`Agent`、`AgentResult`、`AgentPort`
- **端口**：`ModelPort` / `ToolPort` / `StoragePort` / `EventPort` / `ApprovalPort` / `SandboxPort` / `EscalationPort` 等
- **默认适配器**：`MockModel`、`OpenAiCompatibleModel`、`AnthropicModel`、`MemoryStorage`、`JsonlStorage`、
  `SilentEventPort`、`AutoApproval`、`DenyApproval`、`RuleApproval`、`PassthroughSandbox`、`PolicySandbox`
- **回执/审计（顶层核心）**：`ReceiptChain`、`verifyAuditPack`、`JoseReceiptSigner`
- **子路径**：`OmniKernel` / 选项 / 句柄类型经 `@omniharness/kernel/embed`；
  `payloadHashOf` / `GENESIS_HASH` / `jcs` 等完整面经 `@omniharness/kernel/receipts`；
  6 个内置演示工具经 `@omniharness/kernel/tools`；浏览器投影经 `@omniharness/kernel/workbench-view`；
  MCP 服务端/客户端装配经 `@omniharness/kernel/mcp`；AG-UI HTTP/SSE 适配经 `@omniharness/kernel/agui`；
  宿主维护（会话保留 / 临时产物清扫）经 `@omniharness/kernel/maintenance`；
  模型能力探针与注入度量经 `@omniharness/kernel/eval`

内部路径不承诺兼容；新增顶层导出必须先回答「谁会用」，并由 `npm run api:check` 守住 ≤60。
M11 把顶层第 60 位给了 `OmniKernel.create()`（`AgentFactory` 下沉为内部件，经 `Runtime`/`Agent`
直接构造），更细的选项/句柄类型走 `@omniharness/kernel/embed`。
边界事实见 [docs/BOUNDARY.md](docs/BOUNDARY.md)；**下一版做什么、凭什么算做完**见
[docs/ROADMAP.md](docs/ROADMAP.md)（唯一规划源，`npm run plan:check` 对账）；
**代码怎么分层、依赖往哪走**见 [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)；
**每个目录属于哪个职能组、负责什么、通没通电**见同文件 §7「组织架构图谱」；
**算法不变量与覆盖边界**见 [docs/MATH.md](docs/MATH.md)。

## 开发

```bash
npm ci                 # 独立安装（不再依赖应用仓库的 node_modules）
npm run verify         # 一键机检：typecheck×2 + boundary + arch + style + maturity + wiring + build + coverage + doc + stress + api + view + plan + cross
npm run boundary:check # 分层边界机检（可单独跑，fail-closed）
npm run cross:check    # 跨仓契约：Rust 真源 + cargo test（有兄弟仓时）+ 应用消费契约（钉定/导入闭包/影子面）
npm run wiring:check   # 接线审计：全部显式公开入口为根、零入边逐条落账（[docs/WIRING.md](docs/WIRING.md)）
npm run arch:check     # 架构图谱：运行时依赖无环 + 跨层边合法 + [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) 快照
npm run arch:update    # 重新生成架构快照（改依赖后运行）
npm run stress         # 压力套件（tests/stress，独立配置，不拖慢 npm test）
npm run coverage       # 覆盖率门禁（verify 内使用；v8 地板：60/60/73/72 + 16 个目录地板 + 11 个逐文件地板）
npm run sandbox:canary # 真实沙箱 canary（无 docker 时明确 SKIP；CI ubuntu 以 REQUIRED=1 跑 --real）
npm run plan:check     # 规划对账：ROADMAP 状态账 ↔ 代码事实（需先 build）
npm pack               # 打包冒烟
```

`npm test` 当前 **248 文件 / 1200 用例**（alpha.16 发布候选）（数字以 `npm test` 尾部输出为准；2026-11-08 跨仓消费契约补充后复测对齐），锁契约面：事件顺序、
会话落盘回放、压缩确定性、审批/沙箱语义、门禁接线、回执链与篡改检测、MCP HTTP 端到端、
门禁变异自证（`tests/contract/` 只经公开入口）；`boundary:check` 守六条规则——契约零反向依赖
且纯净零 `node:` 内建、protocols 单一支撑面（精确匹配）、组合根 / MCP 桥已声明例外、src 零 apps 引用。

`@maturity` 成熟度元数据由 `maturity:check` 机检：每条 `@maturityEvidence` 必须指向真实存在的
判据文件；L1+ 主张必须带证据；无法在本仓验证的主张降级 `L0-unverified` 并注明恢复路径。

规划闭环的规则只有一条：**文档里的 ✅ 必须由判据证明，判据过了也不许不记账**。
`plan:check` 双向对账，因此「改状态」永远等于「跑一次命令」。里程碑、判据与决策日志见
[docs/ROADMAP.md](docs/ROADMAP.md)。

要求 Node.js ≥ 22.14（用到 `node:sqlite`）。

## 工作台 UI 接入

> **完整 API 文档（含全部对接用例）**：[docs/API.md](docs/API.md)——工作台桥 / 内核嵌入 /
> 自定义模型与工具 / 回执审计 / 事件类型参考 / 错误码总表。
>
> 浏览器端本地重投影用 `@omniharness/kernel/workbench-view`（`projectSession` / `mergeEvents`，
> 零 `node:`、可直接打包；与服务器 `/state` 同一实现），服务端桥用上面的 `workbench` 子路径。

内置一套**完整的桥接层**（`@omniharness/kernel/workbench`），任何 Web UI 只做呈现。
最短路径是上面的 `OmniKernel.create()`——工作台已随内核启动，地址在
`kernel.capabilities().workbench.url`；需要自己控制端口/令牌/历史侧边栏时才手动接线：

```ts
import { WorkbenchServer } from '@omniharness/kernel/workbench';

const wb = WorkbenchServer.create({ storage, http: { host: '127.0.0.1', port: 0 } });
ConfigFactory.build({ storage, events: wb.hub, userResponder: wb.hub, ... });
await wb.listen();
```

| 端点 | 作用 |
| ---- | ---- |
| `GET /api/sessions/:id/events` | **SSE 直播**（历史回放 + 实时推送；`Last-Event-ID`=seq 断线续传） |
| `GET /api/sessions/:id/state` | 一次投影快照：消息流 / 工具结果（配对工具名与 ok）/ 待办 / 计划 / 用量 / 挂起提问 |
| `POST /api/sessions/:id/answers` | 回答 `ask_user` 挂起提问（`WorkbenchHub` 把 `UserResponder.ask` 的 await 桥到 HTTP） |
| `POST /api/audit/verify` | 审计包离线复核（M5 语义：`ok`=链结构、`compliant`=合规档） |

鉴权：Bearer / `?token=` / cookie（缺省回落 `OMNI_SERVE_TOKEN`）；非回环绑定必须配令牌。
**EventSource 无法设请求头**——浏览器 SSE 用 `new EventSource('/api/sessions/:id/events?token=…')`；
断线重连浏览器自动带 `Last-Event-ID`，**首次连接**的续传起点用 `?from=<seq>`。
CORS 默认回环回显（跨端口 UI 开箱即用），可用 `corsOrigin` 收紧；历史会话侧边栏用
`discoverSessions` 钩子并入 `GET /api/sessions`。
端到端演示（含 SSE 帧、提问闭环、投影、审计）：`node examples/workbench.mjs`。

## 与 OmniHarness 的关系

```
OmniHarness (应用)  ──依赖──▶  OmniKernel (本项目)
        │                          │
        └── CLI / Web / Desktop    └── contracts + kernel + protocols
```

- 依赖方向只有 **app → kernel → contracts**；内核不知道 CLI / HTTP / React 的存在。
- 内核独立 semver；应用钉版本，每发一个 alpha 跑一次全量回归。
- 应用需要改内核内部时，先在内核开 issue，不直接改。

## License

Apache-2.0。见 [LICENSE](LICENSE) 与 [NOTICE](NOTICE)。
