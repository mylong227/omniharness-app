# 架构（OmniKernel）

> **一句话**：可嵌入的 agent 内核 = 四层单向依赖 + 一个组合根 + 一组可替换端口；模型只是其中一个端口，
> 换模型不改内核，换宿主不改主循环。
>
> 机检：`npm run boundary:check`（源码文本规则）、`npm run arch:check`（运行时依赖图：环 / 跨层边 /
> 本文件快照一致）。刷新本文快照：`npm run arch:update`。

## 1. 四层与依赖方向

```text
entry      src/*.ts（14 个根文件：index / embed / tools / receipts / sandbox / governance /
           mcp / agui / workbench / workbench-view / maintenance / eval / omniError / version）
   │  可依赖任意层——入口只做再导出，不承载业务
   ▼
kernel     src/kernel（主循环 / 上下文 / 门禁 / 适配器 / 组合根 / 回执）
   │  只依赖 contracts + kernel；protocols 仅两处已声明例外（见下）
   ▼
protocols  src/protocols（MCP / ACP / AG-UI 协议实现）
   │  只依赖 contracts + protocols；取用内核能力只经 kernel/protocolsSupport.ts
   ▼
contracts  src/contracts（端口 / 类型 / 错误 / schema / 版本常量）——依赖图的叶子
```

| # | 规则 | 落点与判据 |
| - | ---- | ---------- |
| 1 | `contracts` 只能依赖 `contracts`，且零 `node:` 内建、零第三方包 | `scripts/boundaryCheck.ts` 规则 1/5/6；`scripts/archCheck.ts`（`contracts` 跨层边只许指向自己） |
| 2 | `protocols` 取用内核能力只经 `src/kernel/protocolsSupport.ts`（纯 re-export，零逻辑） | 同上规则 2：按**精确路径**匹配，同名目录不算放行 |
| 3 | `kernel` 不依赖 `protocols`；例外仅 `src/kernel/composition/`（装配层）与 `src/kernel/adapters/mcp/` → `protocols/mcp/`（MCP 桥） | 同上规则 3 |
| 4 | `src` 内不得出现 `apps/` 引用（应用层不在本仓） | 同上规则 4 |

两份脚本分工明确：`boundary:check` 看**文本**（import 写法、契约纯度、apps 引用），`arch:check` 看**图**
（Tarjan SCC 找运行时环、跨层边是否落在声明例外里、`import type` 不计运行时边）。两者都是 fail-closed：
违规即退出码 1。

## 1.1 三个横切入口

| 入口 | 类 / 位置 | 纪律 |
| ---- | --------- | ---- |
| 配置 | `KernelEnv` + `ENV`（`src/kernel/config/kernelEnv.ts`）；`ConfigSections`（`configSections.ts`） | 全仓唯一可读 `process.env` 的类；变量名经 `ENV` 登记表类型检查；124 字段配置按 7 个语义分区提供冻结只读视图；裸 `runtime.config.*` 读取为 0（boundary 规则 9；`config.bareReads` 预算 0） |
| 工具副作用 | `ToolExecutionGate`（`src/kernel/core/stepToolExecutor.ts`） | 审批 → 沙箱 → 授权 → CTA 一条链；`ShellTool` 不重复裁决 |
| 非工具副作用 | `EffectExecutor`（`src/kernel/core/effects/effectExecutor.ts`） | 长时程验证 / workflow 隔离提交统一走“裁决 → 审计 → 执行”；拒绝抛 `EffectDeniedError` |
| 会话 | `Session` + `SessionStateStore`（`src/kernel/core/session/`） | 身份 / 跨回合状态 / 回合计数 / close 生命周期 / 当前回合租约由 Agent 持有，无静态可变状态 |

工具路径与非工具路径**不互相包一层**：前者已由 ToolExecutionGate 统一门禁，后者走 EffectExecutor；
重复裁决会让“同一副作用两次 check”成为新的不一致源。

## 2. 组合根链路

```text
宿主
 └─ OmniKernel.create(input)                       src/kernel/bootstrap/omniKernel.ts
     ├─ OmniKernelAssembler.assemble               src/kernel/bootstrap/omniKernelAssembler.ts
     │   ├─ 回执链 / 工作台 hub / 事件扇出（先建，配置里的 events、userResponder 指向它们）
     │   ├─ ConfigFactory.build(partial)           → ResolvedConfig（端口 + 缺省填充）
     │   ├─ Runtime.createRuntime(config)          → OmniHarnessRuntime
     │   ├─ new Agent(runtime)                     → 主循环
     │   └─ 插件装载 / MCP 客户端 / MCP 服务端发布（可选项，失败即整体失败）
     └─ new OmniKernel(parts)                      句柄：runTask / resume / fork / cancel / close
```

- `ConfigFactory.build`（`src/kernel/config/configFactory.ts`）是 `ResolvedConfig` 的**唯一构造者**：
  宿主只提供 `OmniHarnessConfig` 的局部（端口实例与开关），端口缺省值、栈装配、校验都在组合根内部完成。
  `Runtime.createRuntime` 消费它，把端口登记进 `Container`（`ServiceKeys.model` / `tools` / `storage` /
  `events` / `sandbox` / `approvals`），并顺手构造 `ToolGate`、`SupervisorKernel`、各类台账；
  之后 `runtime.config` 是只读事实源，`OmniKernel.config` 原样转发。宿主不自造 `ResolvedConfig`。
- 组合根是**唯一**可以同时看见所有端口与所有适配器的地方；`kernel/core` 与 `kernel/context` 只认端口，
  所以它们对适配器零 import。
- 不用一次接入的宿主可走三步：`ConfigFactory.build` + `Runtime.createRuntime` + `new Agent(runtime)`
  （`examples/headless.mjs` 即此路径），`Runtime.createRuntime` 的返回值同时是「端口逃生口」。
- 缺省值一律 fail-closed：模型 `MockModel`（不读本机凭据）、审批 `DenyApproval`、沙箱探测 OS 级隔离、
  提权沙箱 `FAIL_CLOSED_ELEVATED_SANDBOX`（拒绝升级）、MCP 未配置即零连接。

## 3. 主循环

```text
Agent.runTask(prompt)                      src/kernel/core/agent.ts
 └─ continueSession                        预留会话槽位（并发同 sessionId 单飞）→ hydrate 历史 → 开场注入
    └─ runSessionTurn                     SessionStateStore.of(sessionId) 取会话级状态
       ├─ AgentStepAssembler.assemble     装配回合执行器（src/kernel/core/agentStepAssembler.ts）
       └─ TurnRunner.run                 回合内 0..n 步循环
          └─ StepRunner.run              一步 = Context → Model → ToolBatch
             ├─ StepContextBuilder.buildMessages   事件日志投影为消息 + 本轮可见工具集
             ├─ ModelPort.generate                 单次模型请求（AbortSignal 贯穿，取消即中断）
             └─ StepToolExecutor.run               ToolGate → 执行 → 事件记录
```

- **回合策略（`TurnPolicy`）**：步数上限、token 预算（软/硬）、成本信封、失控护栏统一在
  `src/kernel/core/turn/turnPolicy.ts` 的 `TurnPolicy` 值对象（R16，2026-11-28 类型化）；
  装配项按「策略 / 服务 / 完成判定」三组收敛进 `TurnRunnerOptions`（6 项），完成口径由
  `TurnCompletionJudge` 裁决。
- **`StepToolExecutor`** 是工具调用的唯一落地链：`ToolGate`（审批 / 沙箱 / 计划态 / 监督否决 / 角色）
  → 资源域闸与并行调度 → 执行（语义等价时 native FFI 接管，否则 JS 实现；任何环节抛错都不回退重跑）
  → 结果管线 → 事件落流。门禁拒绝、解析失败、链路异常都要补录一条失败 `tool_result`。
- **事件**只经 `SessionRecorder` 写入 `AppendOnlyEventLog` 并广播；回执观察者挂在事件出口外层旁路签链，
  不改变消费者语义。

## 4. 三层生命周期与状态归属

| 层 | 持有者 / 生命周期 | 状态归属 | 收尾 |
| -- | ----------------- | -------- | ---- |
| 会话 | `AgentSessionRuntime` + `SessionStateStore`（Agent 实例持有，跨回合） | 前缀计量（`ContextPrefixMeter`）、工具暴露稳定集（`ToolPlanState`，跨回合只增） | 释放单飞槽位、write-behind flush、全量落盘；状态按 LRU 上限 64 个会话整条回收 |
| 回合 | `TurnRunner`（每回合新建） | 预算累计与读数（逐步捕获）、完成判定状态（闸门 / reviewer / 待办）、成本信封基线 | `closeTurn` 产出 `TurnOutcome`（`steps` / `truncated` / `aborted` / `verificationState`），读数入 `AgentTurnFinalizer` 台账 |
| 步 | `StepRunner`（每回合新建） | 本步投影与实测：`usageOfLastStep` / `contextOfLastStep` / `toolCallsOfLastStep` | 事件经 recorder 落流；步级无跨回合状态 |

归属原则：**状态跟着它的最外层复用处走**。会话级状态若退回进程级静态表，Runtime 之间就不再隔离；
回合级状态若留到下一回合，失败回合的读数与基线就会污染下一步。`SessionStateStore` 因此没有静态可变状态，
`TurnRunner` / `StepRunner` 因此每回合、每步重建。

上下文投影的归属也在步：`StepContextBuilder` 把事件日志投影成消息列表，压缩游标跨步复用、压缩本身
确定性（见 §6），工具 schema 预算按本轮可见集计算——投影是**步**的函数，不是全局状态。

## 5. 扩展点

| 想扩展 | 端口（契约） | 注入点 |
| ------ | ------------ | ------ |
| 模型厂商 | `ModelPort`（`src/contracts/ports/model/model.ts`） | `ConfigFactory.build({ model })`；`OmniKernel.create({ model })`（字符串快捷经 `defaults/providers.json` 预设） |
| 工具 | `ToolPort` / `ExtraTool` | `build({ tools, extraTools })` |
| 存储 | `StoragePort` | `build({ storage })`；`OmniKernel.create({ storage })` |
| 审批 / 提权 | `ApprovalPort` / `EscalationPort` | `build({ approvals, escalation })`；`create({ approvals })` |
| 沙箱 | `SandboxPort` | `build({ sandbox })`；`create({ sandbox })` |
| 事件 / UI | `EventPort` / `UserResponder` | `build({ events, userResponder })`；`create({ workbench })` 时再扇出一路 |
| 检索 | `RetrievalPort` / `EmbeddingPort` | `build({ retrieval, embedding })` |
| MCP | `McpConnectorPort` / `McpServerConfig` | `OmniKernel.create({ mcp: { connector }, mcpServers, mcpServe })` |

纪律：先定端口（`src/contracts/ports/`），再写实现（`src/kernel/` 或 `src/protocols/`）；新增公开符号
先进子路径，顶层只留稳定面（`npm run api:check` 锁 60）；新增能力必须同时有判据与接线落账。

## 6. 四个不变量

| 不变量 | 实现落点 | 判据 |
| ------ | -------- | ---- |
| 事件 append-only | `src/kernel/core/appendOnlyEventLog.ts`：只有 `append` / `hydrate` 追加；唯一删减是 `rewindTo`，只许向后截断，越界或非整数即抛错（不静默夹取） | `tests/contract/eventOrdering.test.ts`、`tests/property/hashEventLog.property.test.ts`、`tests/contract/replayDeterminism.test.ts` |
| `tool_call` 必配 `tool_result` | `src/kernel/core/loop/toolCallPairing.ts`（+ `toolCallStager.ts`）是唯一写入入口，按 callId 暂存、按模型调用序落流，异常出口补录失败结果 | `tests/unit/toolCallPairs.test.ts`、`tests/unit/toolCallStager.test.ts` |
| 压缩确定性 | `src/kernel/context/contextCompactor.ts` + `deterministicCompressor.ts`：同输入同字节输出，压缩状态可重建、可审计 | `tests/contract/compactionDeterminism.test.ts`、`tests/unit/compactionInvariant.test.ts` |
| 回执链线性 | `src/kernel/receipts/receiptChain.ts`：单 issuer、`seq` 连续、`previousReceiptHash` 指向前一条 `payloadHash`（创世为 64 个 `0`）；进程内互斥队列串行 append，载入即全链校验 | `tests/contract/receiptChain.test.ts`、`tests/contract/receiptTamper.test.ts`、`tests/unit/receiptChainBounded.test.ts` |

## 7. 目录导航

| 路径 | 内容 |
| ---- | ---- |
| `src/contracts` | 端口 / 类型 / 错误 / schema / 版本常量（叶子层，零实现） |
| `src/kernel/core` | `Agent` / `TurnRunner` / `StepRunner` / `StepToolExecutor` / `ToolGate` / 会话状态 / 循环护栏（`core/loop`、`core/session`、`core/steering`、`core/planning`） |
| `src/kernel/context` | 上下文组装、投影、压缩、token 估算、检索与 repo-map |
| `src/kernel/adapters` | 模型 / 存储 / 审批 / 沙箱 / 工具 / MCP / 记忆等端口实现 |
| `src/kernel/composition` | 组合根：`Runtime.createRuntime`（端口登记、`ToolGate`、监督内核）与 `ServiceKeys` |
| `src/kernel/config` | `ConfigFactory`（`ResolvedConfig` 唯一构造者）、配置校验、各栈装配 |
| `src/kernel/bootstrap` | `OmniKernel.create`、装配器与句柄类型（一次接入） |
| `src/kernel/receipts` | JCS 规范化、回执链、执行证书 / 审计包、锚定 |
| `src/protocols` | MCP / ACP / AG-UI 协议实现（只经 `kernel/protocolsSupport.ts` 取内核能力） |
| `src/*.ts` | 公开子路径入口；`src/index.ts` 是唯一稳定面 |

<!-- arch:report:start -->
<!-- 本块由 `npm run arch:update` 生成；`npm run arch:check` 校验，勿手改。 -->

## 依赖图快照（机检）

| 层 | 文件 | 行 | 层内边 | 跨层边 |
| -- | ---- | -- | ----- | ------ |
| entry | 17 | 831 | 1 | 264 |
| contracts | 686 | 13,985 | 87 | 0 |
| kernel | 1835 | 147,452 | 2002 | 146 |
| protocols | 211 | 12,908 | 115 | 34 |

- 运行时依赖环：**0**（Tarjan SCC，`import type` 不计）
- 跨层违规：**0**
- 公开入口/根文件（`src/*.ts`，17 个）：`src/adapters-public.ts` · `src/agui.ts` · `src/embed.ts` · `src/eval.ts` · `src/governance.ts` · `src/index.ts` · `src/maintenance.ts` · `src/mcp.ts` · `src/omniError.ts` · `src/protocols-public.ts` · `src/receipts.ts` · `src/runtime-public.ts` · `src/sandbox.ts` · `src/tools.ts` · `src/version.ts` · `src/workbench-view.ts` · `src/workbench.ts`

### 高扇入模块 Top 10

| 模块 | 入边 |
| ---- | ---- |
| `src/kernel/util/errorMessage.ts` | 118 |
| `src/kernel/util/logger.ts` | 112 |
| `src/contracts/ports/tool/toolNames.ts` | 83 |
| `src/kernel/config/kernelEnv.ts` | 68 |
| `src/kernel/util/toolTexts.ts` | 52 |
| `src/kernel/util/harnessTexts.ts` | 43 |
| `src/kernel/receipts/jcs.ts` | 27 |
| `src/kernel/protocolsSupport.ts` | 24 |
| `src/kernel/util/arrayAt.ts` | 23 |
| `src/protocols/mcp/mcpProtocol.ts` | 22 |
<!-- arch:report:end -->
