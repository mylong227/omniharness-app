/**
 * 一行接入全部能力（`@omniharness/kernel/embed`）。
 *
 * 对照 `headless.mjs`（手动挑六个端口）：这里只给工作区与模型，工作台、回执链、
 * MCP 客户端（未配置则零连接）全部由 `OmniKernel.create` 一次装配。
 *
 * 运行（仓库内先 `npm run build`）：`node examples/embed.mjs`
 * 安装后（`npm i @omniharness/kernel`）：同样一条命令。
 */
import { mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import {
  AutoApproval,
  MemoryStorage,
  MockModel,
  PassthroughSandbox,
  OmniKernel,
} from '@omniharness/kernel';

const kernel = await OmniKernel.create({
  workspaceRoot: await mkdtemp(join(tmpdir(), 'omni-embed-example-')),
  model: new MockModel(), // 换成真实 ModelPort（OpenAiCompatibleModel / AnthropicModel / 自实现）
  storage: new MemoryStorage(),
  approvals: new AutoApproval(), // 演示放行；生产用 RuleApproval / 缺省 DenyApproval
  sandbox: new PassthroughSandbox(), // 演示零隔离；生产用缺省 OS 探测
  receipts: { persist: true }, // 回执链落盘：重启后仍可续写/复核
  maxSteps: 4,
});

try {
  const result = await kernel.runTask('用一句话介绍自己');
  const caps = kernel.capabilities();
  console.log(`[model] ${caps.model} / [storage] ${caps.storage} / [tools] ${caps.tools}`);
  console.log(`[workbench] ${caps.workbench?.url ?? '(off)'}`);
  console.log(`[receipts] ${caps.receipts?.count ?? 0} 条（signed=${String(caps.receipts?.signed)}）`);

  if (caps.workbench !== undefined) {
    const state = await (
      await fetch(`${caps.workbench.url.replace('/health', '')}/api/sessions/${result.sessionId}/state`)
    ).json();
    console.log(`[state] ${state.messages.length} 条消息（工作台只做呈现）`);
  }
  await kernel.receipts?.flush();
  console.log(`[audit] 回执链长 ${kernel.receipts?.chain.length() ?? 0}，可导出审计包`);
  console.log(`[audit] 存档 ${kernel.receipts?.receiptsPath ?? '(内存)'}`);
  console.log(`[done] ${result.finalText}`);
} finally {
  await kernel.close();
}
