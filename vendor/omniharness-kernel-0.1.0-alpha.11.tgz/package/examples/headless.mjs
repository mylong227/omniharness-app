/**
 * 20 行 headless 示例：不依赖 CLI / Web / TUI，直接把内核嵌进进程。
 *
 * 运行（仓库内，先 `npm run build`）：`node examples/headless.mjs`
 * 安装后（`npm i @omniharness/kernel`）：同样一条命令。
 */
import { mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import {
  Agent,
  AutoApproval,
  ConfigFactory,
  MemoryStorage,
  MockModel,
  PassthroughSandbox,
  Runtime,
  SilentEventPort,
} from '@omniharness/kernel';

const workspaceRoot = await mkdtemp(join(tmpdir(), 'omni-kernel-example-'));
const config = ConfigFactory.build({
  workspaceRoot,
  maxSteps: 4,
  model: new MockModel(), // 换成一个真实 ModelPort 即可接任意厂商
  storage: new MemoryStorage(),
  events: new SilentEventPort(),
  approvals: new AutoApproval(),
  sandbox: new PassthroughSandbox(),
});
const result = await new Agent(Runtime.createRuntime(config)).runTask('用一句话介绍自己');
console.log(result.finalText);
