/**
 * 审计包端到端演示（M5 退出条件 / M6.1，PLAN §6.4）：
 *
 *   1. 只经公开入口产出回执链（3 条动作、含签名与锚定）；
 *   2. 导出审计包并经**独立复核器**（scripts/verifyReceipts.mjs 同款语义）复核通过；
 *   3. 篡改任一字节（改 payload）→ 复核失败，失败码可读；
 *   4. 出处证书（ProvenanceIssuer）与回执链同场：诚实纪律一脉相承。
 *
 * 运行（先 npm run build）：node examples/audit-pack.mjs
 */
import { spawnSync } from 'node:child_process';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';

const kernel = await import(
  pathToFileURL(join(process.cwd(), process.argv[2] ?? 'dist', 'index.js')).href
);
const governance = await import(
  pathToFileURL(join(process.cwd(), process.argv[2] ?? 'dist', 'governance.js')).href
);

// ---- 1) 产出回执链（签发面：本地 Ed25519 信任根 + 假 TSA 锚内嵌哈希） ----
const signer = await kernel.JoseReceiptSigner.create({ kid: 'demo-key' });
const trust = { 'demo-key': signer.publicSpki() };
const chain = new kernel.ReceiptChain({
  issuerId: 'demo-issuer',
  signer,
  anchor: {
    // 演示用锚定端口：令牌内嵌载荷哈希（形态合规；真实部署用 kernel.Rfc3161Anchor + TSA URL）
    anchor: async (payloadHash) => [
      {
        kind: 'rfc3161',
        anchoredAt: new Date().toISOString(),
        token: Buffer.concat([Buffer.from('demo-tsa|'), Buffer.from(payloadHash, 'hex')]).toString('base64'),
      },
    ],
  },
});
const anchorFor = async (receipt) => [
  {
    kind: 'rfc3161',
    anchoredAt: new Date().toISOString(),
    token: Buffer.concat([
      Buffer.from('demo-tsa|'),
      Buffer.from(kernel.payloadHashOf(receipt.payload), 'hex'),
    ]).toString('base64'),
  },
];
const tsaNote = { anchor: anchorFor };
void tsaNote;

for (const name of ['read_file', 'grep', 'write_file']) {
  await chain.append({
    sessionId: 'demo-session',
    action: { kind: 'tool_call', toolName: name, argsDigest: createHash('sha256').update(name).digest('hex').slice(0, 16), ok: true },
  });
}
const pack = { issuerId: 'demo-issuer', exportedAt: new Date().toISOString(), receipts: chain.export() };

// ---- 2) 独立复核通过 ----
const dir = mkdtempSync(join(tmpdir(), 'omni-audit-pack-'));
const packPath = join(dir, 'pack.json');
const trustPath = join(dir, 'trust.json');
writeFileSync(packPath, JSON.stringify(pack, null, 2));
writeFileSync(trustPath, JSON.stringify(trust, null, 2));
const okRun = spawnSync(process.execPath, ['scripts/verifyReceipts.mjs', packPath, trustPath], { encoding: 'utf8' });
const okVerdict = JSON.parse(okRun.stdout);
console.log('[1] 合法包复核:', okVerdict.ok && okVerdict.compliant ? 'OK（compliant）' : JSON.stringify(okVerdict.problems));

// ---- 3) 篡改 → 失败码可读 ----
const forged = structuredClone(pack);
forged.receipts[1].payload.action.argsDigest = 'TAMPERED';
const forgedPath = join(dir, 'forged.json');
writeFileSync(forgedPath, JSON.stringify(forged, null, 2));
const badRun = spawnSync(process.execPath, ['scripts/verifyReceipts.mjs', forgedPath, trustPath], { encoding: 'utf8' });
const badVerdict = JSON.parse(badRun.stdout);
console.log('[2] 篡改包复核:', badVerdict.ok ? '未检出（失败！）' : `REJECTED —— ${badVerdict.problems.map((p) => p.code).join(', ')}`);

// ---- 4) 出处证书（ProvenanceIssuer，同一诚实纪律） ----
const cert = new governance.ProvenanceIssuer({
  verify: () => ({ ok: true, count: 3 }),
  list: () => [
    {
      asset: 'demo-pack',
      kind: 'skill',
      hash: createHash('sha256').update('demo').digest('hex'),
      prev: '0'.repeat(64),
    },
  ],
}).build({
  packName: 'demo-pack',
  issuedAt: new Date().toISOString(),
  assets: [{ name: 'demo-pack' }],
});
const check = governance.ProvenanceIssuer.verify(cert, { trustedPublicKeys: [] });
console.log(
  '[3] 出处证书复核:',
  check.signatureChecked === false && check.ok
    ? 'OK（无信任根如实 signatureChecked:false；链覆盖锚点与逐资产重算通过）'
    : JSON.stringify(check),
);

rmSync(dir, { recursive: true, force: true });
// 守卫：合法包 compliant；篡改包必被拒；无信任根时出处证书必须如实 signatureChecked:false。
if (!okVerdict.compliant || badVerdict.ok || check.signatureChecked !== false || !check.ok) {
  console.error('审计包演示失败——上方任一断言不成立。');
  process.exit(1);
}
console.log('audit-pack 演示全绿：产出 → 复核 → 篡改检出 → 出处证书。');
