/**
 * 工作台接入端到端演示（m6-workbench-bridge）：**UI 只做呈现**。
 *
 * 演示五件事（全部经公开入口 / `@omniharness/kernel/workbench`）：
 *   1. 三行接线：`events: wb.hub` + `userResponder: wb.hub` + `wb.listen()`；
 *   2. SSE 直播：一个「假浏览器」连 `/api/sessions/:id/events`，逐帧计数事件；
 *   3. 提问桥闭环：模型调 `ask_user` → state 端点出现 pendingAsk → 假 UI POST answers
 *      → 模型拿到答案继续跑（全程 await，内核零轮询）；
 *   4. state 投影：一次 GET 拿到消息流/用量（UI 渲染输入）；
 *   5. 审计复核：`POST /api/audit/verify` 离线复核一份真实回执包。
 *
 * 运行（先 `npm run build`）：`node examples/workbench.mjs`
 */
import { Agent, AutoApproval, ConfigFactory, MemoryStorage, PassthroughSandbox, Runtime } from '@omniharness/kernel';
import { WorkbenchServer } from '@omniharness/kernel/workbench';

const hardStop = setTimeout(() => {
  console.error('[demo] 30s 兜底退出——有环节挂起');
  process.exit(1);
}, 30_000);
hardStop.unref();

// ---- 脚本模型：第 1 步调 ask_user，第 2 步读答案收尾 ----
let step = 0;
const model = {
  name: 'scripted-ask',
  generate: async (request) => {
    step += 1;
    if (step === 1) {
      return {
        toolCalls: [
          {
            id: 'c1',
            name: 'ask_user',
            arguments: {
              questions: [
                { id: 'q1', question: '部署到哪个环境？', options: [{ label: 'A（推荐）' }, { label: 'B' }] },
              ],
            },
          },
        ],
      };
    }
    // 第 2 步：从投影消息里确认答案已经回流（工具结果含所选选项）
    const sawAnswer = JSON.stringify(request.messages).includes('A');
    return { text: sawAnswer ? '完成：用户在 ask_user 中选择了 A。' : '完成（未见答案——桥断了）。' };
  },
};

// ---- 1) 三行接线 ----
const storage = new MemoryStorage();
const wb = WorkbenchServer.create({ storage, http: { host: '127.0.0.1', port: 0 } });
const config = ConfigFactory.build({
  workspaceRoot: process.cwd(),
  maxSteps: 4,
  model,
  storage,
  events: wb.hub, // ← 事件直播
  userResponder: wb.hub, // ← 提问桥
  approvals: new AutoApproval(),
  sandbox: new PassthroughSandbox(),
});
const agent = new Agent(Runtime.createRuntime(config));

const address = await wb.listen();
console.log(`[workbench] ${address.url}`);
const runP = agent.runTask('问我要部署环境并汇报。');

// ---- 2) 假浏览器：等会话出现 → SSE 订阅（真实 UI 用 EventSource）----
await new Promise((r) => setTimeout(r, 80));
const { sessions } = await (await fetch(`http://127.0.0.1:${String(address.port)}/api/sessions`)).json();
const sessionId = sessions[0].sessionId;
const controller = new AbortController();
let sseFrames = 0;
void (async () => {
  const sse = await fetch(`http://127.0.0.1:${String(address.port)}/api/sessions/${sessionId}/events`, {
    headers: { accept: 'text/event-stream' },
    signal: controller.signal,
  });
  const decoder = new TextDecoder();
  for await (const chunk of sse.body) {
    sseFrames += 1;
    const type = /^event: (.+)$/m.exec(decoder.decode(chunk))?.[1] ?? '?';
    process.stdout.write(`  [sse] ${type}\n`);
  }
})().catch(() => undefined);

// ---- 3) 假 UI 的回答循环：轮询 state（呈现层的事）→ 出现 pendingAsk 就 POST ----
const answerLoop = (async () => {
  for (let i = 0; i < 100; i++) {
    await new Promise((r) => setTimeout(r, 80));
    const state = await (await fetch(`http://127.0.0.1:${String(address.port)}/api/sessions/${sessionId}/state`)).json();
    if (state.pendingAsk === undefined) continue;
    const q = state.pendingAsk.questions[0];
    console.log(`  [ui] 收到提问: ${q.question}`);
    const answer = { id: q.id, selected: [q.options[0].label] };
    await fetch(`http://127.0.0.1:${String(address.port)}/api/sessions/${sessionId}/answers`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ answers: [answer] }),
    });
    console.log(`  [ui] 已回答: ${answer.selected[0]}`);
    return;
  }
  throw new Error('演示失败：100 次轮询未见挂起提问');
})();

const result = await runP;
await answerLoop;
await new Promise((r) => setTimeout(r, 120)); // 让收尾事件流过 SSE

// ---- 4) state 投影（UI 渲染输入）----
const state = await (await fetch(`http://127.0.0.1:${String(address.port)}/api/sessions/${sessionId}/state`)).json();
console.log(`[state] ${state.messages.length} 条消息 / ${state.usage.length} 条用量：`);
for (const m of state.messages) {
  const who = m.kind === 'tool' ? `tool:${m.toolName}${m.ok === false ? '(失败)' : ''}` : (m.role ?? 'notice');
  process.stdout.write(`  ${who}: ${String(m.content).slice(0, 60).replace(/\n/g, ' ')}\n`);
}

// ---- 5) 审计复核（工作台审计页的后端）----
const audit = await (
  await fetch(`http://127.0.0.1:${String(address.port)}/api/audit/verify`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ pack: { issuerId: 'demo', exportedAt: 'x', receipts: [] } }),
  })
).json();
console.log(`[audit] 空包复核 → ${JSON.stringify(audit)}`);

console.log(`[done] SSE 送达 ${String(sseFrames)} 帧；finalText=${result.finalText ?? '(无)'}`);
controller.abort();
await wb.close();
clearTimeout(hardStop);
const ok =
  sseFrames > 0 &&
  String(result.finalText ?? '').includes('A') &&
  state.messages.some((m) => m.kind === 'tool' && m.toolName === 'ask_user');
if (!ok) {
  console.error('[demo] 断言不成立：SSE 无帧 / 答案未回流 / ask_user 未发生');
  process.exit(1);
}
console.log('workbench 演示全绿：接线 → 直播 → 提问桥闭环 → 投影 → 审计。');
