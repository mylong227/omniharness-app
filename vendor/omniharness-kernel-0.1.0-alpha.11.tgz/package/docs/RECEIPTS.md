# RECEIPTS.md —— 回执链与 IETF 合规回执草案的逐字段对齐

> **性质**：M5 立信的对齐口径记录（PLAN §6.4）。字段**语义**对齐
> [draft-marques-asqav-compliance-receipts](https://datatracker.ietf.org/doc/draft-marques-asqav-compliance-receipts/)；
> **明确不做**法律合规声明。措辞纪律：说「可用于支撑 EU AI Act Art.12(1) 的自动记录义务」，
> 不说「合规」；法务口径由使用者自负。

## 1. 复核流程（给不信任我们的第三方）

```text
签发：agent 动作 → ReceiptPayload → JCS 字节 → SHA256 = payloadHash
      ├─ previousReceiptHash = 上一条 payloadHash（创世 = 64 个 '0'）
      ├─ 有信任根：Ed25519(JCS 字节) → ReceiptSignature（kid + base64url）
      └─ 有 TSA：RFC 3161 令牌（内嵌 payloadHash）→ ReceiptAnchor

离线复核（零出网，两种实现互为对照）：
  kernel/  AuditPacks.verify(pack, trustStore)      ← 与签发共享 JCS 实现
  scripts/ verifyReceipts.mjs <pack> [trust.json] ← 独立实现（不 import 内核）
两份实现均核对：seq 连续、前驱链接、payload 规范形态（JCS 幂等）、
签名（仅当提供 trustStore——没查如实报 signatureChecked:false）、
锚定（非空且令牌内嵌本回执哈希）。
```

### 1.1 签发侧持久化（M11 闭环）

`createOmniKernel({ receipts: { persist: true, issuerId } })` 把链落到：

```text
<workspace>/.omniharness/receipts/<issuerId>.jsonl          # 一行一条 ActionReceipt（append-only）
<workspace>/.omniharness/receipts/<issuerId>.jsonl.key.pem  # PKCS#8 PEM，0600（私钥，勿提交）
```

- 重启后 `ReceiptChain` 以 `previous` 接管既有回执：同 issuer、seq 连续、前驱相接、receiptId 唯一，
  任一不满足即启动失败（`adopt` fail-closed）；
- 有信任根时启动即对既有链跑一次 `AuditPacks.verify`，签名被改/断链在启动期就红；
- 有签名历史但密钥文件丢失 ⇒ 拒绝新建密钥冒充原签发身份；已签名链上 `sign:false` ⇒ 拒绝；
- `.gitignore` 建议排除 `.omniharness/`；密钥不要进仓库（本仓已加）。
- 边界：持久化只解决「跨重启续写」，**不承诺保留期/异地副本**（retention 仍属使用方，见 §3）；
  同一 `issuerId` 是**单写者**语义（无跨进程锁）：多进程同时写同一链会分叉，需要并行时用不同
  `issuerId` 或在宿主侧串行化。

### 1.2 运行级执行证书（M14 接入）

`createOmniKernel({ receipts: { certificates: true } })` 在每次 `runTask/resume/fork` 结束后
自动签发并落盘 `<证书目录>/<sessionId>.json`：

```text
{ certificate: { version, sessionId, eventCount, eventRoot, receipt?, toolSurfaceDigest?, issuedAt },
  signature: { alg, kid, value } }
```

- `eventRoot` = 事件流 Merkle 根（叶子/内部域分离、奇数上提）；
- `receipt` = 签发时刻的回执链尾绑定 `{issuerId, receiptCount, tailHash}`；
- 复核：`ExecutionCertificates.verify(events, signed, { trustStore, receipt? })`；
- 证书只证明完整性/顺序/归属，不证明内容为真；无 witness 时不能防整体重写。

### 1.3 审计三件套导出

`kernel.receipts.exportBundle(dir?)` 一次写出：

```text
<dir>/pack.json      AuditPack（issuerId + exportedAt + receipts[]）
<dir>/trust.json     TrustStore（kid → SPKI PEM；自签场景）
<dir>/summary.json   SignedReceiptSummary（有签名器才产出）
```

第三方复核：`AuditPacks.verify(pack, trust, summary)` 或独立实现
`node scripts/verifyReceipts.mjs pack.json trust.json`。缺省目录
`<workspace>/.omniharness/audit-bundles/<issuer>-<时间>`；有 `summary` 时尾条被改/删会由
`EXPECTED_MISMATCH` 检出。

### 1.4 单文件审计包（M16）

`kernel.exportAuditBundle([sessionId])` 写 `bundle.json` + `trust.json` + `digest.txt`：
包内是「事件流 + 执行证书 + 回执链（+ 可选执行图）」并整包签名；复核用
`AuditBundles.verify(signed, { trustStore })` 或 `scripts/verifyBundle.mjs`。
与三件套的分工：三件套轻、动作级；单文件包大、归档取证级，一次报告证书/回执/图/签名问题码。

### 1.5 选择性披露包（M18：最小披露仍可验）

事件流含无关敏感载荷、只想交出能证明事实的子集时，`kernel.exportDisclosurePack(
[{sessionId, indices}], dir?)` 写 `disclosure.json` + `trust.json` + `digest.txt`：

- 每条披露事件附 M14 包含证明，锚回证书 Merkle 根；**未选事件不出包**；
- 回执链只带「第 1 条到最大绑定条数」的必需前缀（单 issuer 单链：中间回执不可跳过）；
- 复核 `DisclosurePacks.verify(signed, { trustStore })`；CLI 同一条命令，按包内 `kind`
  自动识别审计包/披露包；
- 诚实边界：不证明未披露事件存在/不存在；前缀含未披露会话的动作回执（单链固有泄露面）；
  证书绑定回执而包内无前缀 ⇒ `RECEIPT_BINDING_MISMATCH`（比审计包更严一档）。

### 1.6 交付编码（M20：压缩 / 口令加密 / 分片）

交付物经不可信信道或归档时，§1.4/§1.5 的单文件 JSON 可再包一层**传输编码**
（`AuditDeliveries.encode/decode`，或 `kernel.exportAuditBundle(..., delivery)` 直出）：

```text
JCS(交付对象) → gzip（缺省开）→ [口令加密: scrypt(N=2^15,r=8,p=1) + AES-256-GCM]
             → 按 shardBytes 分片 → manifest.json(kind=audit-delivery) + part-*.bin
```

- 复核：`node scripts/verifyBundle.mjs manifest.json trust.json [--passphrase=口令]`——
  CLI 按清单回同目录取分片、逐片 sha256、解密（GCM 认证失败即 `AUDIT_DELIVERY_AUTH_FAILED`）、
  解压、内容摘要比对，然后走与 §1.4/§1.5 完全相同的复核路径；
- 分层口径：**编码不复核**——解码只证明「字节在传输中没被改、口令正确」；包完整性 /
  顺序 / 来源仍由 §1.4/§1.5 的证书与签名承担；
- 两个摘要口径：`digest.txt`（包体 JCS，对外锚定，编码不影响）与 manifest
  `contentDigest`（交付对象含签名信封的传输级完整性锚）分开使用，不要混比；
- 诚实边界：加密护机密性；口令强度是交付方责任；scrypt 参数随 manifest 明文记录
  （非机密），复核方零出网可解。

## 2. 逐字段映射

| 草案概念（ACTA-RECEIPTS） | 本实现（`src/contracts/ports/receipts/`） | 一致性说明 |
| ------------------------ | ---------------------------------------- | ---------- |
| 规范化 RFC 8785 JCS | `kernel/receipts/jcs.ts`（UTF-16 码元序键 + ES6 数字） | 字节级一致；两份实现（kernel 与 CLI）互验 |
| 单 issuer 单线性链 | `ReceiptPayload.issuerId` + `previousReceiptHash` | 创世全零对齐；并发追加互斥序列化（m5-chain-linear） |
| 链哈希 `SHA256(JCS(payload))` | `ReceiptChain.hashOf`（`kernel/receipts/receiptChain.ts`） | 一致 |
| 信封 `{payload, signature, anchors}` | `ActionReceipt`（三键同形） | 一致 |
| 签名算法（EdDSA）+ `kid` | `ReceiptSignature { alg:'EdDSA', kid, value }` | value = 对**裸 payload 字节**的 Ed25519（非 JWS signing input——首版口径错误被 m5-tamper-detect 抓出并修正） |
| 信任根按 `kid` 查公钥 | 复核方 `TrustStore`（kid → SPKI PEM） | 签发方无权指定复核方信任根 |
| RFC 3161 锚定（必填） | `ReceiptAnchor { kind:'rfc3161', token }`；`Rfc3161Anchor`（最小 TSQ，certReq=true） | 离线复核校验令牌内嵌 payloadHash（形态级）；**完整 CMS 验签未实现**（见 §3） |
| 无锚即不合规 | 复核器 `anchored:false` ⇒ `compliant:false` | 一致 |
| 签名「没查 ≠ 查过」 | `signatureChecked:false`（无信任根时） | 一致（继承 provenanceIssuer 纪律） |
| 查无依据申报 | `UNPROVEN_ORIGIN` + `unproven[]` | 一致 |

## 3. 未实现项（诚实清单）

| 项 | 草案要求 | 现状 | 补齐路径 |
| -- | -------- | ---- | -------- |
| **RFC 3161 令牌完整验证** | 复核时验 CMS 签名与 TSA 证书链 | 只做形态 + 内嵌哈希匹配 | 引入 ASN.1/CMS 解析（零依赖手写或接受新依赖，需权衡） |
| **保留期（retention）** | 法规下限（EU ≥6 个月，HIPAA 6 年） | 无——存储策略属使用方 | 提供 pack 导出 + 文档建议；不代管存储 |
| **witness quorum** | 多见证人锚定 | 单 TSA | `AnchorPort` 已是数组语义，扩展为多源聚合即可 |
| **counterparty binding** | `counterparty_binding.envelope_hash`（跨 agent 委托绑定） | 无 | A2A 按 v1.0 重基时一并设计 |
| **法律合规声明** | — | **有意不做** | 见头部措辞纪律 |
| `payloadHash` 显式字段 | 草案信封含 payload 哈希字段 | 由复核器重算（不落盘，避免「声称值 vs 实算值」双源漂移） | 若草案强制要求字段，加 `payloadHash` 并以重算比对 |

## 4. 与本仓其他审计机制的关系

- **会话事件日志**：`SessionEvent` JSONL（模型所见的事实源）。M5 回执链是**对事件的
  推论层**（动作 → 回执），事件日志上链仍未做（README 的表述已在收尾修正）。
- **provenanceIssuer**（governance/）：出处证书的诚实纪律（覆盖锚点防删头、收证方独立
  重算、unproven 申报、signatureChecked）由本实现**逐条继承**；M6 将把它接上回执链并提公开面。
- **遥测与晋升台账**：`HashChain`（NUL 分隔链）与 `HashChainPromotionLedger` 是本实现的
  前身；格式不同（无 JCS），不复用。

## 5. 执行证书（运行级证明，M14）

回执链覆盖「动作」，不覆盖模型消息/系统事件，也不绑定事件顺序与条数。执行证书补上这一层：

| 绑定 | 字段 | 作用 |
| ---- | ---- | ---- |
| 事件内容+顺序+条数 | `eventRoot`（Merkle，叶子/内部域分离、奇数上提） | 改/删/换序必变 |
| 会话 | `sessionId` | 防止跨会话拼接 |
| 回执链尾 | `receipt {issuerId, receiptCount, tailHash}` | 事件流与动作链互相咬合 |
| 工具面 | `toolSurfaceDigest`（可选） | 证明本次暴露的工具集 |
| 签发方 | `signature`（对 `JCS(cert)`） | 凭信任根离线验签 |

- 单条事件可生成**包含证明**（`EventMerkle.proveEvent` / `ExecutionCertificates.verifyEventInclusion`），
  无需交出整份日志即可证明归属；
- 安全边界：能证明完整性与顺序，**不能**证明内容本身为真；无外部 witness 时，
  签发方仍可整体重写一份自洽的新历史（见 RESEARCH-2026-11B §3）。
- 开销：10k 事件建树/证书约 0.8–0.9 s，单条验证 ~0.5 ms；宿主在导出审计包时显式调用，
  不进入每步热路径。
