# RECEIPTS.md —— 回执链与 IETF 合规回执草案的逐字段对齐

> **性质**：M5 立信的对齐口径记录（PLAN §6.4）。字段**语义**对齐
> [draft-marques-asqav-compliance-receipts](https://datatracker.ietf.org/doc/draft-marques-asqav-compliance-receipts/)；
> **明确不做**法律合规声明。措辞纪律：说「可用于支撑 EU AI Act Art.12(1) 的自动记录义务」，
> 不说「合规」；法务口径由使用者自负。

## 1. 复核流程（给不信任我们的第三方）

```text
签发：agent 动作 → ReceiptPayload → JCS 字节 → SHA256 = payloadHash
      ├─ previousReceiptHash = 上一条 payloadHash（创世 = 64 个 '0'）
      ├─ 有信任根：Ed25519(JCS 字节) → ReceiptSignature（kid + base64url）
      └─ 有 TSA：RFC 3161 令牌（内嵌 payloadHash）→ ReceiptAnchor

离线复核（零出网，两种实现互为对照）：
  kernel/  verifyAuditPack(pack, trustStore)      ← 与签发共享 JCS 实现
  scripts/ verifyReceipts.mjs <pack> [trust.json] ← 独立实现（不 import 内核）
两份实现均核对：seq 连续、前驱链接、payload 规范形态（JCS 幂等）、
签名（仅当提供 trustStore——没查如实报 signatureChecked:false）、
锚定（非空且令牌内嵌本回执哈希）。
```

## 2. 逐字段映射

| 草案概念（ACTA-RECEIPTS） | 本实现（`src/contracts/ports/receipts/`） | 一致性说明 |
| ------------------------ | ---------------------------------------- | ---------- |
| 规范化 RFC 8785 JCS | `kernel/receipts/jcs.ts`（UTF-16 码元序键 + ES6 数字） | 字节级一致；两份实现（kernel 与 CLI）互验 |
| 单 issuer 单线性链 | `ReceiptPayload.issuerId` + `previousReceiptHash` | 创世全零对齐；并发追加互斥序列化（m5-chain-linear） |
| 链哈希 `SHA256(JCS(payload))` | `payloadHashOf`（`kernel/receipts/receiptChain.ts`） | 一致 |
| 信封 `{payload, signature, anchors}` | `ActionReceipt`（三键同形） | 一致 |
| 签名算法（EdDSA）+ `kid` | `ReceiptSignature { alg:'EdDSA', kid, value }` | value = 对**裸 payload 字节**的 Ed25519（非 JWS signing input——首版口径错误被 m5-tamper-detect 抓出并修正） |
| 信任根按 `kid` 查公钥 | 复核方 `TrustStore`（kid → SPKI PEM） | 签发方无权指定复核方信任根 |
| RFC 3161 锚定（必填） | `ReceiptAnchor { kind:'rfc3161', token }`；`Rfc3161Anchor`（最小 TSQ，certReq=true） | 离线复核校验令牌内嵌 payloadHash（形态级）；**完整 CMS 验签未实现**（见 §3） |
| 无锚即不合规 | 复核器 `anchored:false` ⇒ `compliant:false` | 一致 |
| 签名「没查 ≠ 查过」 | `signatureChecked:false`（无信任根时） | 一致（继承 provenanceIssuer 纪律） |
| 查无依据申报 | `UNPROVEN_ORIGIN` + `unproven[]` | 一致 |

## 3. 未实现项（诚实清单）

| 项 | 草案要求 | 现状 | 补齐路径 |
| -- | -------- | ---- | -------- |
| **RFC 3161 令牌完整验证** | 复核时验 CMS 签名与 TSA 证书链 | 只做形态 + 内嵌哈希匹配 | 引入 ASN.1/CMS 解析（零依赖手写或接受新依赖，需权衡） |
| **保留期（retention）** | 法规下限（EU ≥6 个月，HIPAA 6 年） | 无——存储策略属使用方 | 提供 pack 导出 + 文档建议；不代管存储 |
| **witness quorum** | 多见证人锚定 | 单 TSA | `AnchorPort` 已是数组语义，扩展为多源聚合即可 |
| **counterparty binding** | `counterparty_binding.envelope_hash`（跨 agent 委托绑定） | 无 | A2A 按 v1.0 重基时一并设计 |
| **法律合规声明** | — | **有意不做** | 见头部措辞纪律 |
| `payloadHash` 显式字段 | 草案信封含 payload 哈希字段 | 由复核器重算（不落盘，避免「声称值 vs 实算值」双源漂移） | 若草案强制要求字段，加 `payloadHash` 并以重算比对 |

## 4. 与本仓其他审计机制的关系

- **会话事件日志**：`SessionEvent` JSONL（模型所见的事实源）。M5 回执链是**对事件的
  推论层**（动作 → 回执），事件日志上链仍未做（README 的表述已在收尾修正）。
- **provenanceIssuer**（governance/）：出处证书的诚实纪律（覆盖锚点防删头、收证方独立
  重算、unproven 申报、signatureChecked）由本实现**逐条继承**；M6 将把它接上回执链并提公开面。
- **遥测与晋升台账**：`HashChain`（NUL 分隔链）与 `HashChainPromotionLedger` 是本实现的
  前身；格式不同（无 JCS），不复用。
