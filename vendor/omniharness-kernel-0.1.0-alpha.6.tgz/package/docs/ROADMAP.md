# 路线图（唯一规划源）

> **性质**：现行规划，不是提案。本文件回答三个问题：**做到哪了、下一件是什么、凭什么说做完了**。
> **机检**：`npm run plan:check`（已并入 `npm run verify`）。状态账与代码事实不一致即红。
> **边界事实**见 [BOUNDARY.md](BOUNDARY.md)；**变更历史**见 [../CHANGELOG.md](../CHANGELOG.md)；**每日动作**见 git log。

---

## 1. 规划怎么闭环

```text
目标 → 判据 → 工作项 → 证据 → 状态回写 → plan:check 对账 → （下一轮）
```

四条纪律，每条都可执行、可复核：

1. **状态只有两种**：`✅ done` / `⏳ open`。「做到一半」一律记 `open`，不发明第三种状态。
2. **双向对账**（`scripts/planCheck.mjs`）：
   - 标 `done` ⇒ 该里程碑判据**全部**通过（禁止提前记账）；
   - 标 `open` ⇒ 判据**至少一条不通过**（禁止做完不记账）。
3. **判据分两类**：`auto` 由脚本读仓库事实（文件 / 数字 / 边界机检）；`manual` 必须在
   [§6 人工复核记录](#6-人工复核记录)留下 `日期 + 判据 id + 证据` 行，否则视为未通过。
4. **一项工作 = 一个判据 + 一条证据**：没有证据的改动不进状态账；判据不通过就不许翻 ✅。

> 为什么这样设计：这个项目最容易犯的两个错，是「文档说做完了但代码没跟上」和「代码做完了但文档停在旧状态」。
> 单向门禁只能防前者；双向对账把后者也变成红灯。

---

## 2. 北极星（D90 / D180）

以 2026-11-03 为起点（`10 h/周`预算，与切分方案一致）：

| 时点 | 判据 | 当前 |
| ---- | ---- | ---- |
| **D90（2027-02-01）** | 至少 1 个**外部**安装或使用反馈（npm 下载 / issue / 下游仓库钉版本） | ⏳ 0（尚未发布到 npm） |
| **D90** | OmniHarness 钉内核版本并跑通全量回归 | ⏳ 未开始 |
| **D180（2027-05-02）** | 公开面仍 ≤60；按行为分面的契约测试 ≥30 例；`npm run verify` 全绿不靠人肉 | ✅ 59 / 60；契约 32 例（单元总 170） |
| **D180** | 适配器归属裁决执行完（`laya` 移出、`@beta` 组复核） | ✅ laya 已迁出；`@beta` 三组 9 文件 |

北极星不达标时的**默认动作是收缩，不是加功能**：不拆仓、不加公开面、不写第二套 CLI。

---

## 3. 状态账

> `plan:check` 直接解析下表。改状态 = 改这一行；判据 id 必须在 §5 有实现。

| 里程碑 | 状态 | 预算 | 判据 |
| ------ | ---- | ---- | ---- |
| M0 切分收口 | ✅ done | 68 h（已完成） | m0-boundary, m0-no-compat, m0-public-cap, m0-tests, m0-headless-imports |
| M1 发布就绪（alpha.1） | ✅ done | 10 h | m1-publishable, m1-files, m1-changelog, m1-readme, m1-ci, m1-dist |
| M2 第一个外部消费（D90） | ⏳ open | 20 h | m2-consumer |
| M3 beta 硬化（alpha.2） | ✅ done | 30 h | m3-laya-migrated, m3-adapters-beta-marked, m3-support-surface, m3-contract-coverage |
| M5 立信（回执链） | ✅ done | 40 h | m5-jcs-conformance, m5-receipts-contract-suite, m6-provenance-public |
| M6 通电与沙箱收口 | ✅ done | 30 h | m6-mcp-server-wired, m6-mcp-capability-honest, m6-sandbox-failclosed, m6-examples-public, m6-workbench-bridge |
| M4 切片收口（盘点并账） | ✅ done | 20 h | m4-metaphor-zero, m4-zero-inbound, m4-source-lines, m4-unreachable-lines, m4-gate-bypass, m4-maturity-evidence, m4-public-45 |

---

## 4. 里程碑

### M0 切分收口 ✅

从 OmniHarness 切出独立内核并证明「删掉应用它还能跑」。判据与复现命令见
[BOUNDARY.md §当前状态](BOUNDARY.md#当前状态可复现判据)，这里只留结论：边界五条规则全绿、
`src/compat` 清零、公开面 59/60、切分时 25 文件 140 用例（M3 扩容后 29 文件 170 用例）、
headless 示例只经公开入口。

### M1 发布就绪（alpha.1）✅

**目标**：让「发一个 alpha」成为一个可重复的动作，而不是一次手工事故。

| 工作项 | 产出 |
| ------ | ---- |
| 规划闭环 | 本文件 + `scripts/planCheck.mjs` + `npm run plan:check` 并入 `verify` |
| 发布元数据 | `private: false`、`publishConfig.access: public`、`files[]` 覆盖路线图 |
| 版本纪律 | 版本 `0.1.0-alpha.1`；CHANGELOG 顶条与 `package.json` 同版本 |
| 使用者入口 | README 首屏即可跑通；四不变量 + 快速开始 + 指向本路线图 |
| CI | `.github/workflows/verify.yml`：`npm ci` → `npm run verify` → headless 冒烟 |

**退出条件**：§3 的六条 `m1-*` 判据全过；`npm pack` 后空目录安装可跑（见 §7 发布记录）。
**不在 M1**：真正执行 `npm publish`（需要凭据，记在 §7）。

> `m1-ci` 只证明**工作流存在且调用同一条命令**，不伪装成「CI 已经绿」。双平台首跑结论在
> 首次推送后回填 §6，作为人工复核而不是 auto 判据——执行器的结果不是本地可复现事实。

### M2 第一个外部消费（D90）⏳

**目标**：证明内核不是只有作者能用的库。

**现状（2026-11-03 深夜，实测）**：

- 内核侧已就绪：`npm pack` 3.09 MB / 3474 文件，空目录安装 + headless 跑通；
- **阻塞 1（发布）**：本机未登录 npm（`npm whoami` → `ENEEDAUTH`，无 `NPM_TOKEN` / `~/.npmrc`）。
  已尝试 `npm login --auth-type=web`，流程需要浏览器确认，无头会话无法完成 ⇒ 只能停在
  「发布就绪 + 本地 tag / tarball」；
- **应用接入已推进到分支**：OmniHarness 的 `migration/kernel-package` 分支完成 6,529 处导入重写、
  删除 1,914 个文件 / **143,883 行**内嵌副本；`tsc`（含 web）、`build`、`arch:gate` 全绿。
  **未合并**：75 个测试文件 / 93 例失败待分流（内核源码级不变量测试回迁内核、CLI 子进程测试按新布局
  调整、`check.mjs` 导入铁律放行包路径）。顺序与判据见 [M2_APP_MIGRATION.md](M2_APP_MIGRATION.md)。

工作项（按顺序，不并行）：

1. 发布 alpha 到 registry（需要凭据）后，应用改为**钉版本依赖**（替换 `file:../omniharness-kernel`）；
2. 完成分支上的 75 个测试文件分流，`check.mjs` 放行包路径，再合并应用 main 并跑全量回归；
3. 收集第一批反馈：装不上 / 类型不对 / 文档看不懂，各记一条 issue 模板；
4. 合并后删除内核的**迁移桥**子路径导出（BOUNDARY「迁移桥」），把应用剩余导入收敛到顶层。

**退出条件**：`m2-consumer`（人工判据）——应用钉版本 + 全量回归绿 + 日期与证据写入 §6。

### M3 beta 硬化（alpha.2）✅

**目标**：把「能跑」变成「敢用」。四件事全部落地（2026-11-03）：

| 工作项 | 结果 | 证据 |
| ------ | ---- | ---- |
| 归属裁决执行 | `adapters/laya`（9 文件 + Python 资产）与 `decisionEngineResolver` 移出内核；应用仓库保留实现 | `m3-laya-migrated`；内核只留 `decisionEnginePort` 注入缝，`mode` 非 off 却未注入即**构建期报错** |
| @beta 组复核 | 三组 9 文件全部带 `@beta 归属裁决`，符号仍不进公开面 | `m3-adapters-beta-marked` |
| 支撑面收窄 | `protocolsSupport` 21 符号（15 值 + 6 类型） | `m3-support-surface` |
| 契约覆盖面 | `tests/contract` 6 文件 **32 例**：事件顺序 / 回放 / 压缩 / 审批语义 / 沙箱语义 / 门禁接线，只经公开入口 | `m3-contract-coverage`；`npm test` 29 文件 170 例 |

**行为变更（alpha 破坏性，已记 CHANGELOG）**：配置 `decisionEngine.mode` 非 `off` 时必须注入
`decisionEnginePort`；此前由内核直接 new 出 `LayaDecisionEngine`，现在内核不再持有厂商绑定实现。

---

## 5. 判据实现映射

| 判据 id | 类别 | 判什么 | 实现在哪 |
| ------- | ---- | ------ | -------- |
| `m0-boundary` | auto | 五条分层规则 | `scripts/boundaryCheck.mjs` |
| `m0-no-compat` | auto | `src/compat` 不存在 | `scripts/planCheck.mjs` |
| `m0-public-cap` | auto | 公开面 ≤60 | `scripts/publicSurface.mjs` |
| `m0-tests` | auto | ≥20 测试文件 / ≥100 用例 | `scripts/planCheck.mjs` |
| `m0-headless-imports` | auto | 示例只 import 公开入口 | `scripts/planCheck.mjs` |
| `m1-publishable` | auto | 非 private + public access + engines | `scripts/planCheck.mjs` |
| `m1-files` | auto | `files[]` 每项存在 | `scripts/planCheck.mjs` |
| `m1-changelog` | auto | CHANGELOG 顶条 = 包版本 | `scripts/planCheck.mjs` |
| `m1-readme` | auto | 四不变量 + 快速开始 + 指向本文件 | `scripts/planCheck.mjs` |
| `m1-ci` | auto | 工作流跑 `npm run verify` | `scripts/planCheck.mjs` |
| `m1-dist` | auto | `dist` 入口与声明可加载 | `scripts/planCheck.mjs` |
| `m2-consumer` | manual | 应用钉版本 + 全量回归 | 本文件 §6 |
| `m3-laya-migrated` | auto | `adapters/laya` 已移出 | `scripts/planCheck.mjs` |
| `m3-adapters-beta-marked` | auto | 三组 9 文件带裁决标记 | `scripts/planCheck.mjs` |
| `m3-support-surface` | auto | 支撑面 ≤21 符号 | `scripts/planCheck.mjs` |
| `m3-contract-coverage` | auto | `tests/contract` 用例 ≥30 | `scripts/planCheck.mjs` |

---

## 6. 人工复核记录

> `manual` 判据**只认这张表**：没有行 = 未通过。一行 = 一次复核，写日期、判据 id、可复核的证据（链接 / 命令输出摘要）。

| 日期 | 判据 | 证据 |
| ---- | ---- | ---- |
| 2026-11-04 | m4-metaphor-zero | 3b9a977（隐喻栈+燧+Genesis 拆线）与 df80bed/1328fd2（孤儿清扫）；登记于 ExperimentalPaths |
| 2026-11-04 | m5-receipts-contract-suite | 869c647（JCS）+ 4ae8f1c（链/锚/复核器，变异判据四连全红自证）+ 6572c5d（RECEIPTS.md）|
| 2026-11-04 | m6-mcp-server-wired | cffe5e0（McpHttpAssembly 端到端 + capability 谎报修正 + provenance/governance 通电）+ 8684bbe（沙箱 fail-closed）|
| 2026-11-04 | m6-workbench-bridge | e8c1457（Hub+投影）+ 123da76（SSE/续传/审计端点）+ c09548f（端到端示例：提问桥真机闭环）|

---

## 7. 发布记录

| 版本 | 日期 | 动作 | 证据 |
| ---- | ---- | ---- | ---- |
| 0.1.0-alpha.1 | 2026-11-03 | 发布**就绪**（未 `npm publish`，无凭据） | `npm pack` + 空目录安装 + `node examples/headless.mjs` 跑通 |
| 0.1.0-alpha.2 | 2026-11-03 | 发布**就绪**（未 `npm publish`：`npm whoami` → `ENEEDAUTH`，无 token） | `npm pack` 3.14 MB / 3529 文件（laya 已不在包内、tests 零泄漏）；空目录安装 + headless 跑通；`npm publish --dry-run` 通过 |
| 0.1.0-alpha.3 | 2026-11-03 | 发布**就绪**（同上，无凭据） | 应用形状清零（19 文件 / 2.5K 行）；`npm pack` 后空目录安装 + headless 跑通；`verify` 29 文件 170 例、59 / 60 |

> 纪律：发布记录只写**已经发生**的事。「就绪」与「已发布」分开写，避免把 `npm pack` 成功说成已上线。
> **待执行**（有凭据时，一条命令）：`npm publish --tag alpha`（`publishConfig` 已钉 `access: public` + `tag: alpha`，
> 不会误发到 `latest`）。

---

## 8. 不在计划内（以及什么条件下才考虑）

| 不做 | 触发条件 |
| ---- | -------- |
| 拆独立 git 仓库 / 上 npm workspaces | 出现真实外部消费者，且它要求独立版本节奏；否则只是把目录换成 `package.json` |
| 新增顶层导出 | 公开面先回到 ≤55 再谈；每个新增必须写「谁会用」 |
| 第二套 CLI / Web / TUI | 内核不做体验层；应用需要时在内核开 issue |
| 重写内核 | 债务在结构不在代码；重写只消除理解成本，不消除维护成本 |
| 自动发布流水线 | 先有 ≥2 次人工发布记录，且发布事故为 0 |

---

## 9. 风险

| 风险 | 症状 | 对策 |
| ---- | ---- | ---- |
| 账实再次漂移 | 文档写 ✅、`plan:check` 红 | 双向对账；翻状态必须同一 commit 带判据证据 |
| 公开面偷偷长回 | `api:check` 顶到 60 | 新符号先进子路径；`@beta` 组不得上顶层 |
| 判据变脆（重构即红） | 判据依赖具体文件名/措辞 | 判据只钉**事实**（文件存在、数字上限、命令退出码），不钉实现细节 |
| 单人 10 h/周 排期失真 | 里程碑连续两轮无进展 | 砍工作项而不是砍判据；必要时把里程碑拆小 |
| alpha 被当成稳定版 | 下游直接上生产 | README 与 CHANGELOG 首行同步标注「不承诺兼容」 |

---

## 10. 决策日志

| 日期 | 决策 | 理由 |
| ---- | ---- | ---- |
| 2026-11-03 | 本文件是**唯一规划源**；BOUNDARY 只记边界事实 | 规划与事实分离，避免两份文档各说各话 |
| 2026-11-03 | `plan:check` 采用**双向对账** | 单向门禁只能防提前记账，防不了做完不记账 |
| 2026-11-03 | M1 只到「发布就绪」，不含 `npm publish` | 无发布凭据；把「就绪」和「已发布」分开写才诚实 |
| 2026-11-03 | `adapters/laya` 迁出，改 `decisionEnginePort` 注入 | 第三方 venv 绑定不进通用内核；注入缝让应用保留实现，内核不静默丢弃配置 |
| 2026-11-03 | 契约覆盖由人工判据改为机检（`tests/contract` ≥30 例） | 人工判据容易写成愿望；用例数可数、可回归 |
| 2026-11-03 | **应用形状清零**：TUI / license / server-audit / enterprise / SDK / codegen / CLI 帮助整棵删除 | 「切出来」只保证能跑，不保证只剩内核；零引用 + 编译与全量测试是唯一裁判 |
| 2026-11-03 | 应用迁移**先行**：先删重复副本、用子路径桥接，测试分流随后 | 公开面只有 59 符号，一次性收敛到顶层不可行；先拿到「单一源码」再逐步收窄，桥有删除条件 |
| 2026-11-02 | 先同仓独立包，不拆双仓 | 10 h/周下双仓必然漂移（切分方案 §4） |

---

## 11. 迭代节奏

- **每轮开始（30 min）**：`npm run plan:check` 对账 → 只挑一个里程碑 → 只做它的一条工作项。
- **每轮结束（10 min）**：判据证据 + 翻状态 + CHANGELOG（若对外可见）+ 同一 commit。
- **每月**：复核 §2 北极星；连续两轮无进展就砍范围，不延期。
- **每个 alpha**：应用侧升一次依赖并跑全量回归，回归结果记入 §6。

