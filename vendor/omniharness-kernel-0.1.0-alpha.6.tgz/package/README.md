# OmniKernel

> **可嵌入的 agent 内核：可审计、fail-closed、模型中立。**

OmniKernel 是从 [OmniHarness](https://github.com/mylong227/OmniHarness) 切出的独立内核项目。
它只做三件事：**跑 agent 主循环、管住工具与审批、把每一步落成可回放的事件**。
CLI / Web / Desktop 留在 OmniHarness——**应用是内核的第一个消费者，不是内核的上游**。

## 四个不变量

| 不变量 | 含义 |
| ------ | ---- |
| **可审计** | 会话事件追加式落盘、可按 `seq` 回放；动作级**签名回执链**（JCS 规范化 + 单 issuer 线性链 + RFC 3161 锚定 + 独立复核器，见 `docs/RECEIPTS.md`）与哈希链化遥测/晋升台账可复核；模型与工具之间没有"看不见的步骤" |
| **fail-closed** | 审批/升级/完成闸门缺省拒绝；沙箱缺省探测 OS 级隔离，探测不到 + strict 即启动失败；读不到安全数据就启动失败，不静默放行 |
| **模型中立** | 只认 `ModelPort`；OpenAI 兼容 / Anthropic / llama.cpp / 自写适配器同权 |
| **可嵌入** | 无 CLI 依赖；组合根 `Runtime` + 主循环 `Agent` 即可在任意 Node 进程里跑 |

## 安装

```bash
npm i @omniharness/kernel
```

要求 Node.js ≥ 22.14。下面的示例只 `import '@omniharness/kernel'`；在仓库内开发则先
`npm ci && npm run build` 再跑。

## 快速开始

```bash
npm ci
npm run build
node examples/headless.mjs
```

`examples/headless.mjs` 全文（20 行，只用公开入口）：

```js
import { mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import {
  Agent, AutoApproval, ConfigFactory, MemoryStorage,
  MockModel, PassthroughSandbox, Runtime, SilentEventPort,
} from '@omniharness/kernel';

const workspaceRoot = await mkdtemp(join(tmpdir(), 'omni-kernel-'));
const config = ConfigFactory.build({
  workspaceRoot, maxSteps: 4,
  model: new MockModel(), // 换成一个真实 ModelPort 即可接任意厂商
  storage: new MemoryStorage(), events: new SilentEventPort(),
  approvals: new AutoApproval(), sandbox: new PassthroughSandbox(),
});
const result = await new Agent(Runtime.createRuntime(config)).runTask('用一句话介绍自己');
console.log(result.finalText);
```

从源码跑时把 import 换成 `../dist/index.js`；发布后用包名即可。

## 目录

| 路径 | 内容 |
| ---- | ---- |
| `src/contracts` | 端口 / 类型 / 错误 / schema —— **零实现**，公开 30 个符号 |
| `src/kernel` | 主循环、上下文、工具、门禁、审计、存储、编排、组合根 |
| `src/protocols` | ACP / MCP / AG-UI（取用内核能力只经 `kernel/protocolsSupport.ts` 单一支撑面） |
| `tests/` | 纯内核测试（无 CLI / Web 夹具），`npm test` |
| `scripts/` | `build.mjs`（tsc + 运行时资产复制）、`apiSurface.mjs`（公开面门禁）、`boundaryCheck.mjs`（分层边界机检）、`workbenchViewCheck.mjs`（浏览器安全子路径产物门禁） |
| `defaults/` | 随包发布的策略 / 厂商 / 限制数据（改数据不改代码） |
| `examples/` | headless / audit-pack / workbench 示例 |

## 公开 API

唯一稳定入口是 `@omniharness/kernel`（`src/index.ts`），当前 **60 / 60** 个符号：

- **组合根**：`Runtime`、`ConfigFactory`、`AgentFactory`、`OmniHarnessConfig`、`ResolvedConfig`、`OmniHarnessRuntime`
- **主循环**：`Agent`、`AgentResult`、`AgentPort`
- **端口**：`ModelPort` / `ToolPort` / `StoragePort` / `EventPort` / `ApprovalPort` / `SandboxPort` / `EscalationPort` 等
- **默认适配器**：`MockModel`、`OpenAiCompatibleModel`、`AnthropicModel`、`MemoryStorage`、`JsonlStorage`、
  `SilentEventPort`、`AutoApproval`、`DenyApproval`、`RuleApproval`、`PassthroughSandbox`、`PolicySandbox`
- **回执/审计（顶层核心）**：`ReceiptChain`、`verifyAuditPack`、`JoseReceiptSigner`
- **子路径**：`payloadHashOf` / `GENESIS_HASH` / `jcs` 等完整面经 `@omniharness/kernel/receipts`；
  6 个内置演示工具经 `@omniharness/kernel/tools`；浏览器投影经 `@omniharness/kernel/workbench-view`

内部路径不承诺兼容；新增顶层导出必须先回答「谁会用」，并由 `npm run api:check` 守住 ≤60。
边界事实见 [docs/BOUNDARY.md](docs/BOUNDARY.md)；**下一版做什么、凭什么算做完**见
[docs/ROADMAP.md](docs/ROADMAP.md)（唯一规划源，`npm run plan:check` 对账）。

## 开发

```bash
npm ci                 # 独立安装（不再依赖应用仓库的 node_modules）
npm run verify         # 一键机检：typecheck×2 + boundary + maturity + test + build + api + view + plan
npm run boundary:check # 分层边界机检（可单独跑，fail-closed）
npm run plan:check     # 规划对账：ROADMAP 状态账 ↔ 代码事实（需先 build）
npm pack               # 打包冒烟
```

`npm test` 当前 **77 文件 / 458 用例**（含 40 个自上游回迁的判据文件），锁契约面：事件顺序、
会话落盘回放、压缩确定性、审批/沙箱语义、门禁接线、回执链与篡改检测、MCP HTTP 端到端、
门禁变异自证（`tests/contract/` 只经公开入口）；`boundary:check` 守六条规则——契约零反向依赖
且纯净零 `node:` 内建、protocols 单一支撑面（精确匹配）、组合根 / MCP 桥已声明例外、src 零 apps 引用。

`@maturity` 成熟度元数据由 `maturity:check` 机检：每条 `@maturityEvidence` 必须指向真实存在的
判据文件；L1+ 主张必须带证据；无法在本仓验证的主张降级 `L0-unverified` 并注明恢复路径。

规划闭环的规则只有一条：**文档里的 ✅ 必须由判据证明，判据过了也不许不记账**。
`plan:check` 双向对账，因此「改状态」永远等于「跑一次命令」。里程碑、判据与决策日志见
[docs/ROADMAP.md](docs/ROADMAP.md)。

要求 Node.js ≥ 22.14（用到 `node:sqlite`）。

## 工作台 UI 接入

> **完整 API 文档（含全部对接用例）**：[docs/API.md](docs/API.md)——工作台桥 / 内核嵌入 /
> 自定义模型与工具 / 回执审计 / 事件类型参考 / 错误码总表。
>
> 浏览器端本地重投影用 `@omniharness/kernel/workbench-view`（`projectSession` / `mergeEvents`，
> 零 `node:`、可直接打包；与服务器 `/state` 同一实现），服务端桥用上面的 `workbench` 子路径。

内置一套**完整的桥接层**（`@omniharness/kernel/workbench`），任何 Web UI 只做呈现：

```ts
import { WorkbenchServer } from '@omniharness/kernel/workbench';

const wb = WorkbenchServer.create({ storage, http: { host: '127.0.0.1', port: 0 } });
ConfigFactory.build({ storage, events: wb.hub, userResponder: wb.hub, ... });
await wb.listen();
```

| 端点 | 作用 |
| ---- | ---- |
| `GET /api/sessions/:id/events` | **SSE 直播**（历史回放 + 实时推送；`Last-Event-ID`=seq 断线续传） |
| `GET /api/sessions/:id/state` | 一次投影快照：消息流 / 工具结果（配对工具名与 ok）/ 待办 / 计划 / 用量 / 挂起提问 |
| `POST /api/sessions/:id/answers` | 回答 `ask_user` 挂起提问（`WorkbenchHub` 把 `UserResponder.ask` 的 await 桥到 HTTP） |
| `POST /api/audit/verify` | 审计包离线复核（M5 语义：`ok`=链结构、`compliant`=合规档） |

鉴权：Bearer / `?token=` / cookie（缺省回落 `OMNI_SERVE_TOKEN`）；非回环绑定必须配令牌。
**EventSource 无法设请求头**——浏览器 SSE 用 `new EventSource('/api/sessions/:id/events?token=…')`；
断线重连浏览器自动带 `Last-Event-ID`，**首次连接**的续传起点用 `?from=<seq>`。
CORS 默认回环回显（跨端口 UI 开箱即用），可用 `corsOrigin` 收紧；历史会话侧边栏用
`discoverSessions` 钩子并入 `GET /api/sessions`。
端到端演示（含 SSE 帧、提问闭环、投影、审计）：`node examples/workbench.mjs`。

## 与 OmniHarness 的关系

```
OmniHarness (应用)  ──依赖──▶  OmniKernel (本项目)
        │                          │
        └── CLI / Web / Desktop    └── contracts + kernel + protocols
```

- 依赖方向只有 **app → kernel → contracts**；内核不知道 CLI / HTTP / React 的存在。
- 内核独立 semver；应用钉版本，每发一个 alpha 跑一次全量回归。
- 应用需要改内核内部时，先在内核开 issue，不直接改。

## License

Apache-2.0。见 [LICENSE](LICENSE) 与 [NOTICE](NOTICE)。
