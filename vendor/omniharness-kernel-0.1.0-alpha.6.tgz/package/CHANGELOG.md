# Changelog

## 0.1.0-alpha.6 — 2026-11-04

### Polished（工作台桥接层上线加固，同日第二遍打磨）

- `close()` 在有活跃 SSE 时**挂死**（node:http 的 close 等连接）→ 追踪并优雅结束全部活跃流；
- 跨端口浏览器 UI 需要 CORS → 回环回显默认（同 MCP 端口径）+ `corsOrigin` 收紧 + OPTIONS 预检免鉴权；
- EventSource 无法设头 → `?from=<seq>` 首连接续传 + `retry: 3000` 重连提示（`?token=` 鉴权口径写进 README）；
- 请求体无上限（DoS 面）→ 1 MiB 上限 413（drain 后回包，非 destroy）；坏 JSON 400 不落 500；路径命中方法不对 405；
- 长任务期间投影像卡死 → 进行中工具调用呈现 `pending: true`（结果到达自动消失，仍逐字节确定）；
- 历史会话侧边栏 → `discoverSessions` 钩子并入 `GET /api/sessions`（fail-soft 不 fail-silent）。

### Added（工作台桥接层，m6-workbench-bridge）

- **`@omniharness/kernel/workbench` 子路径**：把「UI 只做呈现」所需的全部内核侧设施一次备齐——
  - `WorkbenchHub`：`EventPort`（按会话扇出 + 全量直播缓冲 + 会话注册表）与 `UserResponder`
    （提问桥：`ask_user` 挂起 → HTTP 回答 → await resolve）双端口合一；
  - `WorkbenchServer`：SSE 事件直播（`Last-Event-ID`=seq 断线续传、15s 心跳）、`/state`
    一次投影快照、`/answers` 回答端点（409 防重放）、`/api/audit/verify` 审计复核；
    Bearer/`?token=`/cookie 鉴权，非回环绑定强制令牌（复用 `ServerAuthGuard`）；
  - `projectSession`：事件流 → 视图状态（消息流/reasoning 挂接/工具结果配对工具名/待办/计划/
    用量/回滚墓碑/挂起提问）的**确定性纯函数**，前端零事件语义知识。
- `examples/workbench.mjs`：端到端演示——3 行接线 → 脚本模型调 `ask_user` → 假浏览器经 SSE
  收帧、经 state 发现挂起提问并 POST 回答 → 模型拿到真答案完成回合 → 审计复核。
- 公开面不变（60/60，golden 一致）；判据 `m6-workbench-bridge` 入 M6 状态账。

### Docs（对接参考与浏览器投影收尾）

- **`docs/API.md` 全量对接文档**：包结构与子路径分工、最小 headless 接入、工作台 HTTP/SSE
  全量协议（鉴权/CORS/状态码/续传/心跳）、浏览器三种完整用例（会话 hook、提问弹窗、审计页）、
  `WorkbenchState`/`WorkbenchMessage`/`SessionEvent` 字段表、自定义 `ModelPort`/`ToolPort`、
  回执签发与离线复核；每条签名以源码为准（`runTask` 的第 4 参只给新会话命名，续跑用
  `agent.resume`——误把既有 id 交给 `runTask` 会用新事件流覆盖旧存档）。
- **`@omniharness/kernel/workbench-view` 子路径**：`projectSession` / `mergeEvents` 的浏览器
  安全出口（零 `node:`、零 I/O、可直接打包）；`workbenchViewPurity` 判据递归检查 re-export
  运行时图，`view:check` 在 build 后复核 `dist` 产物同一边界。

## 0.1.0-alpha.5 — 2026-11-04

> 执行 [PLAN-2026-11.md](docs/PLAN-2026-11.md)：M4 切片 → M5 立信 → M6 通电。
> 依据 [AUDIT-2026-11.md](docs/AUDIT-2026-11.md) 的盘点事实。完整归档：git tag `attic/2026-11-03`。

### Added（M5 立信）

- **RFC 8785 JCS 规范化**（零依赖，7 条附录向量逐字节一致；NaN/Infinity fail-closed 抛错）。
- **动作级签名回执链**：`{payload, signature, anchors}` 三键信封、`SHA256(utf8(JCS(payload)))`
  链式哈希、单 issuer 单线性链、并发追加互斥序列化（100 并发零分叉）。
- **锚定**：jose Ed25519 签名（裸 payload 字节）+ RFC 3161 TSA 客户端（手写最小 DER TSQ，
  可注入 fetch）；无 TSA/无网如实 `anchors: []`，绝不为凑数伪造锚。
- **离线独立复核器**：`verifyAuditPack`（kernel）+ `scripts/verifyReceipts.mjs`（**独立实现**
  JCS/SHA-256，不 import 内核——第三方可离线复核的可行性证明）。零出网；`ok`（链结构）与
  `compliant`（合规档）分层；篡改四类（改 payload / 删首条 / 换锚 / 重排）全部可检出且失败码可读。
- `docs/RECEIPTS.md`：与 IETF draft-marques-asqav-compliance-receipts 逐字段映射 + 未实现项清单
  （保留期 / witness quorum / counterparty binding / CMS 完整验证）。

### Added（M6 通电）

- **provenanceIssuer 提公开面**（`@omniharness/kernel/governance`）：出证/复核经公开入口可用；
  `examples/audit-pack.mjs` 端到端演示（产出 → 复核 → 篡改检出 → 出处证书）。
- **MCP HTTP 服务端通电**（`@omniharness/kernel/mcp`）：`McpHttpAssembly` 经组合根装配
  2026-07-28 无状态服务端；外部 MCP 调用与本地同过审批/沙箱门禁；端到端用例真实起服断言。

### Changed（行为，均有负例测试）

- **缺省审批 = 缺省拒绝**：未注入 `approvals` 落 `DenyApproval`（旧缺省 `AutoApproval` 全放行）。
- **缺省沙箱 = 探测 OS 级隔离**：Landlock / Windows 原生写隔离可用即用之；探测不到落回
  `PolicySandbox` 并**显式告警**（黑名单不是隔离）；`OMNI_SANDBOX_STRICT=1` 时探测失败即拒绝启动。
- **并行工具事件按模型调用序落盘**（此前完成序——重放不可字节复现）。
- **压缩确定性重建**：LLM 摘要路径整体移除；产物 = 任务目标（user 原文摘录）+ 历史经过 +
  确定性工具台账 + 交接便签——同输入逐字节同输出、零模型调用、不可降级；user 请求不再可能被压丢。
- `rollback` 不再擦自己的历史：截断后落自包含 `rollback` 墓碑事件（旧实现留悬空 tool_result → 厂商 400）。
- **"无损收缩"名副其实**：`collapseBlankLines`（删行尾空白/压空行）从收缩管线移除——它会在模型
  看到之前改写补丁上下文；`compress()` 里降为显式 opt-in。
- MCP capability 诚实：删除指向从未实现的 `resources/subscribe` 处理器的声明（2026-07-28 订阅走
  `subscriptions/listen`）。

### Removed（M4 切片；完整归档 `attic/2026-11-03`）

- `protocols/a2a` 整树（贴 v1.0 标签的 v0.3 线格式）、隐喻算子栈（共振场/QEC/免疫/信念/退火/
  CRISPR/固化/刻蚀/元素/对称破缺/禁闭/涡环 + 燧编排 + Genesis 桥）、`kernel/plugin`、
  `kernel/media`、`kernel/asset`、`kernel/eval` 长任务目录、`context/rankVeto`、80+ 零引用孤儿。
- 依赖：`openid-client`（零 import）、`croner`（唯一消费者已删）；`sharp`/`unpdf`/`@huggingface/transformers`
  随媒体栈移除；`yaml` 升为直接依赖。
- 配置键：`resonantField`/`memoryAnnealing`/`qec`/`immuneMonitoring`/`belief`/`skillEditing`/
  `capabilityCrystallization`/`insightEtching`/`elementComposer`/`symmetryBreaking`/`confinement`/
  `vortexRing`/`genesis`/`sparkAutoRun`/`a2a`/`media`。

### Changed（门禁与证据层）

- 证据层修复：上游判据回迁 40 件（414→436 用例）；12 件降级 `L0-unverified`（注明恢复路径）；
  新门禁 `maturity:check`（L1+ 必带证据，机检）。
- 门禁加固（四个绕过各配**变异判据**）：双语引号 import、protocolsSupport 精确匹配、
  `export * as` 展开计数、人工复核记录限定 §6 且 id 必须存在；`contracts` 零 `node:` 内建（规则 6）。
- **API golden 快照**：公开符号增删/改名必须显式 `--update-golden`；顶层 60/60。
- 工具类导出下沉 `@omniharness/kernel/tools`；新增子路径 `receipts`/`sandbox`/`governance`/`mcp`。
- `tests/` 纳入 typecheck（`tsconfig.test.json`，修出 21 处潜伏类型错误）。

### BREAKING

- 公开面 60 符号重排（工具类/receipts 类型面移子路径）；顶层新增回执核心 6 符号。
- 上述配置键与子路径 `dist/protocols/a2a`/`dist/kernel/{spark,genesis,media,plugin,asset,eval}` 消失。
- 缺省审批/沙箱语义见上；依赖缺省放行或黑名单口径的调用方需显式注入。

## 0.1.0-alpha.4 — 2026-11-03

### Added

- **子路径导出（迁移桥）**：`exports` 增加 `"./*.js"` / `"./*"` → `dist/*`，让第一个消费者
  OmniHarness 在**公开面迁移期**按内部模块路径接入（应用仓库已删掉 143,883 行重复内核副本）。
  **不是兼容承诺**：顶层仍是唯一稳定面（59 / 60）；子路径随迁移完成即删除，见 BOUNDARY「迁移桥」。

### Changed

- 无公开面变化；版本 `0.1.0-alpha.4`。

## 0.1.0-alpha.3 — 2026-11-03

**应用形状清零**（第二遍收口：把「不属于内核」的残留整棵子树删掉）。公开 API 不变（59 / 60）。

### Removed

- `contracts/ports/tui/`、`contracts/ports/license/`、`contracts/ports/server/audit{Format,Query}.ts`、
  `contracts/ports/enterprise/`、`kernel/adapters/enterprise/`、`kernel/security/oidcClient.ts`、
  `kernel/sdk/sdkClient.ts`、`contracts/schema/codeGenerator.ts`、`defaults/cliHelp.json`。
  合计 **19 文件 / 约 2.5K 行**，逐项确认零引用（`tsc` + 29 文件 170 用例为裁判）。
- 以上均不在公开面，`api:check` 仍为 59 / 60。

### Changed

- `docs/BOUNDARY.md` 新增「应用形状清零」节；`compat/` 表里 `oidcClient` / `sdkClient`
  的去向从「下沉内核」改为「删除」（下沉只保证能跑，不保证只剩内核）。

### Known issues

- **未执行 `npm publish`**（无发布凭据）：`npm pack` + 空目录安装 + headless 已跑通；
  正式发布需先 `npm login` 或提供 `NPM_TOKEN`。

## 0.1.0-alpha.2 — 2026-11-03

**beta 硬化（M3）落地**。公开 API 面不变（59 / 60），但 `decisionEngine` 有 alpha 破坏性变更。

### Added

- **契约测试扩容**：新增 `tests/contract/` —— 审批语义 13 例、沙箱语义 8 例、门禁接线 6 例；
  原三份契约用例（事件顺序 / 回放 / 压缩）同目录归位。共 **6 文件 32 例，只经公开入口**。
- `tests/unit/decisionEngineInjection.test.ts`（3 例）：钉住「配置了引擎却没实现 ⇒ 构建报错」。

### Changed

- **`adapters/laya` 移出内核**（9 文件 + `decisionEngineResolver` + Python 资产）：第三方 venv
  绑定不属于通用内核面，实现回到应用仓库。内核保留 `DecisionEngineConfig` 并新增注入缝
  `decisionEnginePort`；`mode` 非 `off` 却未注入实现时 `ConfigFactory.build` **直接报错**
  （此前会静默 new 出 Laya 实现）。
- `@beta` 组从四组 18 文件收敛为**三组 9 文件**（`user` / `monitoring` / `live`），
  裁决标记与「不进公开面」纪律不变。
- **测试总数 25 文件 / 140 例 → 29 文件 / 170 例**；`plan:check` 的 `m3-contract-coverage`
  由人工判据改为机检（`tests/contract` ≥30 例），`m3-adapters-beta-marked` 口径 18 → 9。

### Known issues

- **未执行 `npm publish`**（无发布凭据）：`npm pack` + 空目录安装 + headless 已跑通；
  正式发布需先 `npm login` 或提供 `NPM_TOKEN`。

## 0.1.0-alpha.1 — 2026-11-03

**规划闭环 + 发布就绪**。公开 API 面不变（59 / 60）。

### Added

- **唯一规划源** `docs/ROADMAP.md`：里程碑 M0–M3、判据表（auto / manual）、人工复核记录、
  发布记录、决策日志；「下一版做什么」不再散落在 BOUNDARY 的一句话里。
- **规划对账门禁** `scripts/planCheck.mjs` + `npm run plan:check`（已并入 `npm run verify`）：
  状态账与代码事实**双向**对账——标 ✅ 必须判据全过，标 ⏳ 必须至少一条不过
  （既防提前记账，也防做完不记账）。
- **公开面计数单一实现** `scripts/publicSurface.mjs`：`apiSurface.mjs` 与 `planCheck.mjs` 共用，
  避免两处数字漂移。
- **CI** `.github/workflows/verify.yml`：`ubuntu-latest` + `windows-latest` 双平台跑
  `npm ci → npm run verify → node examples/headless.mjs`。
- **发布元数据**：`private: false`、`publishConfig.access: public`、`files[]` 收入
  `docs/ROADMAP.md`。

### Changed

- `docs/BOUNDARY.md` 的「下一步」移交 ROADMAP；本文件只保留**已经发生**的变更，
  发布记录只写「就绪」与「已发布」中真正发生的那一个。
- README 增加规划入口与 `npm run plan:check` 说明。

### Known issues

- **未执行 `npm publish`**（无发布凭据）：`0.1.0-alpha.1` 处于「发布就绪」，
  `npm pack` + 空目录安装 + headless 已跑通，见 ROADMAP §7。

## 0.1.0-alpha.0 — 2026-11-02

首次以「独立内核」形态收口。**不承诺兼容**（alpha）。

### Added

- **独立组合根** `kernel/composition/runtime.ts`：`Runtime.createRuntime(config)` 可在任意 Node
  进程里装配 `Agent`，不再依赖应用层 `apps/composition`。
- **公开入口** `src/index.ts`：58 / 60 个符号（`npm run api:check` 机检），
  覆盖组合根、主循环、端口与默认适配器。
- **契约测试** `tests/`：22 文件 / 135 用例，只依赖 `src/` 与 Node 内置；
  含一次「只经公开入口」的 headless 回合。
- **20 行 headless 示例** `examples/headless.mjs` 与 `npm run smoke`。
- **构建资产复制** `scripts/build.mjs`：`dangerous-commands.json`、worker mjs、laya py
  随 `dist` 发布（此前 `tsc` 不搬运，运行期 ENOENT）。
- **独立安装** `package-lock.json`；`node_modules` 不再是应用仓库的 junction。
- **`npm pack` 冒烟**：空目录安装 tarball 后可直接跑通 headless。

### Changed

- `src/compat/` 10 个「从应用借来的共享件」全部下沉：
  - `jsonRpc` → `kernel/rpc/`
  - 行传输 / WebSocket 编解码 → `kernel/transport/`
  - `serverAuthGuard`、`oidcClient` → `kernel/security/`
  - `safeFs`、`serveInstance` → `kernel/util/`
  - `serviceKeys` → `kernel/composition/`
- `contracts/sdk/sdkClient.ts` → `kernel/sdk/`（契约层不放实现）。
- `TuiRenderer` 删除：内核只保留 `ConsoleLiveView` 需要的两个纯 ANSI 片段。
- **契约反向依赖清零**（依赖规则 1 归零）：限制类型族（`RuntimeLimitsConfig` 等 10 个接口）
  与 `Spectrum` 下沉 `contracts/ports/`；A2A 协议数据（`a2aProtocol` + `TaskHandler`）移入
  `contracts/ports/a2a/`，新增 `A2aServerPort` / `A2aClientPort` 端口，
  `OmniHarnessRuntime.a2a` 只认端口（实现类在 protocols 侧 `implements`）。公开面 58 → 59。
- **协议穿透收口**：`protocols` → `kernel` 的 76 条散点 import 收敛为唯一支撑面
  `kernel/protocolsSupport.ts`（30 个文件改走该边，纯 re-export 零逻辑，只导出实际消费符号）；
  新增 `npm run boundary:check` 分层边界机检（fail-closed，四条规则），
  首跑即抓出 `kernel/adapters/mcp` → `protocols/mcp` 的 5 处存量穿透并声明为窄例外。
- **适配器归属裁决**（授权自主裁决）：`adapters/laya`（厂商绑定，待移出）、`adapters/user` /
  `adapters/monitoring` / `adapters/live`（端口默认实现，保留）四组共 18 文件标 `@beta`，
  处置理由与迁移路径记入 `docs/BOUNDARY.md`；组内符号不进公开面（api:check 把守）。
- **机检收口**：`boundary:check` 升至五条规则（新增规则 5「契约纯净」——contracts 只许相对
  路径导入，零 `node:` 内置、零第三方包）；新增 **`npm run verify`** 一键机检入口
  （typecheck + boundary:check + test + build + api:check）；README / BOUNDARY 同步终态
  （公开面 59/60、25 文件 140 用例、机检入口与裁决记录）。
- **契约测试扩容**（22 → 25 文件 / 135 → 140 用例）：
  - 事件顺序：`session_meta` 首条、`seq` 严格递增、`tool_result` 永不先于 `tool_call`、
    数量守恒、最终答案在最后结果之后、端口所见 = 存储落盘；
  - 会话落盘回放：JsonlStorage 跨实例（重启模拟）往返一致、`replay` 不改写历史、
    `resume` 历史严格前缀 + `seq` 延续；
  - 压缩不变量：确定性无损收缩只动空白且幂等、折叠后工具轮配对（无孤儿 tool / 无悬空
    toolCall）、前导 system 原样钉住。
- 清理最后一个再导出别名：`kernel/adapters/tool/toolHandler.ts` 删除，5 个引用方直连
  contracts（`ToolHandler` 单一引入路径）。
- **支撑面收窄**：`a2aTaskExecutor` 生产默认（子代理工厂 / Agent 主循环 / FilteredToolPort）
  挪到组合根 `kernel/composition/a2aBridge.ts`，经 `buildSubagent` / `runTask` / `filterTools`
  注入缝装配（**alpha 破坏性**：三项构造选项改必填，缺省即装配期报错）；
  fail-closed 工具收窄**策略**留在协议层、**机制**注入。`AgentPort` 扩展 `eventsOf` /
  `cancelCurrentRun` / 可选 `sessionId`（协议桥只认端口）；新增 contracts `ToolRegistryPort`
  （MCP 网关不再感知 `RegistryToolPort` 具体类）。支撑面 27 → 21 符号（全基础设施），
  协议层对 `core` / `subagent` 的感知归零。

### Removed

- `src/compat/` 目录整体删除；`src` 内零 `apps/` import。

### Known issues

- `npm publish` 未执行（无发布凭据）；包已可 `npm pack`（0.1.0-alpha.0，不承诺兼容）。
- `adapters/laya` 长期应迁回应用仓库（已标 `@beta`，迁移路径见 BOUNDARY 裁决表）。
