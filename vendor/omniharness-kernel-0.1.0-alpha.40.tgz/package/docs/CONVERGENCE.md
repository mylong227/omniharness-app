# 收敛基线（2026-11-22）

> **一句话**：这份文件取代「里程碑账本」，回答一个问题——**系统有没有在变胖，凭什么说没有**。
> 机检：`npm run drift:check`；预算：`defaults/convergence-budget.json`（单一来源）。
> 历史里程碑/调研稿已移入 `history/` 或删除；需要追溯时用 `git log`，不再作为门禁。

---

## 1. 五条不可协商的结构规则

1. **一个副作用出口**：shell / fs / git / browser / verify / subprocess 全部经同一 `Executor`，
   强制携带 `{ signal, auditSink, sandbox, sessionId }`；任何绕过它的 spawn 视为缺陷。
2. **一个会话聚合根**：跨回合状态（前缀计量 / 工具稳定集 / 压缩游标 / 校准 / 预算）
   挂在 `Session` 上；禁止模块级 `WeakMap` 或每回合重建关键状态。
3. **一个回合策略对象**：`TurnPolicy` 收拢步数 / 预算 / 时限 / 完成口径；
   新增能力优先做中间件，不新增 `TurnRunnerOptions` 字段。
4. **一份配置 schema**：zod 单源生成类型、默认值、校验、文档；env 只作覆盖层。
5. **一条行为基准**：真实任务的成功率 / 成本 / 步数 / 时延，是「做完了」的唯一证据。

---

## 2. 漂移预算（只降不升）

`npm run drift:check` 实测 13 项指标，任何一项超预算即红。完整口径见
`defaults/convergence-budget.json` 的 `note` 字段；摘要：

| 维度 | 指标 | 为什么测它 |
| ---- | ---- | ---------- |
| 体量 | `src.lines` / `src.files` / `src.exportClasses` | 防「拆文件 / 拆类」绕过行数上限 |
| 公开面 | `pkg.subpaths` | 18 条语义入口（2 根 + 16 curated），不是顶层 60 符号也不是深路径 |
| 配置 | `config.envNames` / `config.envSites` / `config.fields` | 配置面宽度与直读点 |
| 回合 | `core.turnRunnerOptions` | 回合 = 19 个可选协作者的笛卡尔积 |
| 测试 | `tests.sourceText` | 用 lint 冒充测试的文件数 |
| 过程 | `scripts.lines` / `verify.gates` | 门禁不得反超产品代码 |
| 死代码 | `reach.indexUnreachableLines` | 子路径导出洗白不了的不可达行 |
| 文档 | `docs.bytes` | 会过期的数字不许写进文档 |

**上调流程**：`drift:check --update` 只下调；确需上调必须 `--force` 并在提交说明写清
「旧值为什么不可达」。禁止再把「提额理由」写进判据标题。

---

## 3. 迁移顺序（按依赖排序）

| # | 事项 | 状态 | 完成判据 |
| - | ---- | ---- | -------- |
| 1 | 删除死代码与未接线栈 | ✅ 第一波 | `src.*` 预算下降；零入边台账不悬空；跨仓消费的子路径保留 |
| 2 | 修三条副作用旁路 | ✅ | 长时程验证 / workflow 隔离提交 / `plan_present` 全部过门禁且可取消 |
| 3 | `Session` 聚合根 | ✅ | `SessionSlotRegistry` 已删除；`SessionStateStore` 存 `Session` 聚合（身份 / 回合计数 / close），LRU 驱逐真正关闭 |
| 4 | `TurnPolicy` + `Executor` | ✅ 双入口 | `TurnRunnerOptions` 6；工具走 `ToolExecutionGate`，非工具走 `EffectExecutor`；`spawn` 白名单规则 7 |
| 5 | 配置单源 | 🟡 字段瘦身 | env 单入口（`process.env` 1 处）；140 字段 7 分区视图；`runtime.config` 裸读 **0**（boundary 规则 9）；字段总数到 60 仍需产品取舍 |
| 6 | 文本回归 TS | ✅ | `KernelTexts.get` 调用点 0；文案在调用点内联 |
| 7 | 子路径收敛 | ✅ | 18 条（2 根 + 16 curated 语义入口；深路径 0）；应用 248 条已全部迁到 contracts/adapters/runtime/protocols 四桶，`consumer:check` 基线 9；≤10 受 16 个公开 curated 入口约束，18 是保留公开入口的下限 |
| 8 | 行为基准 | ✅ | fixture 摘要 + 参考解自检（`bench/behavior-baseline.json`，CI 跑）；真实模型基线 `bench/longtask-model-baseline.json`（deepseek-flash，23 任务）：pass@1 0.783 / 757k tokens / 5 verify fail |
| 9 | 默认路径外代码 | ✅ | 135 个索引不可达文件全部由 `offpath-policy.json` 分类（可选适配器 / 离线评测 / 协议 / 类型 / 公开入口）；未分类即红 |

**残余（需要外部输入，不是代码欠账）**：配置到 30 需产品决定删哪些开关；真实模型跑分需要
凭据（本机已用用户配置的 DeepSeek 凭据跑出基线，CI 不复跑以免产生费用）。

---

## 4. 目标（与 `drift:check` 同口径）

当前值不写进文档：**以 `npm run drift:check` 输出为准**（文档里的数字会过期，预算不会）。

| 指标 | 90 天目标 |
| ---- | --------- |
| `src.lines` | ≤90,000 |
| `src.files` | ≤350 |
| `pkg.subpaths` | ≤18（16 curated + 2 根） |
| `config.envNames` | ≤30 |
| `config.envSites` | ≤20 |
| `config.fields` | ≤60 |
| `core.turnRunnerOptions` | ≤6 |
| `tests.sourceText` | 0 |
| `verify.gates` | ≤8 |
| `reach.indexUnreachableLines` | ≤2,000 |

顶层公开符号 **60** 不变：这是对外承诺，也是减法中唯一不能动的东西。

---

## 5. 验收命令

```bash
npm run verify           # 16 道门禁（含 offpath / drift / boundary / arch / wiring / api / cross）
npm run drift:check      # 14 项结构预算（只降不升）
npm run bench:behavior   # 23 fixture 摘要 + 参考解自检（CI 跑）
npm run consumer:check   # 应用深路径导入棘轮（有应用仓时；只降不升）
(cd ../omniharness-app && npm run verify)  # 应用全量：typecheck / web test / build / smoke / desktop
```

五条都绿 = 本轮收敛的机检证据集。真实模型跑分另见 `npm run eval:longtasks`（需凭据）。
