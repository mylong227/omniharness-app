# OmniKernel

> **可嵌入的 agent 内核：可审计、fail-closed、模型中立。**

OmniKernel 是从 [OmniHarness](https://github.com/mylong227/OmniHarness) 切出的独立内核项目。
它只做三件事：**跑 agent 主循环、管住工具与审批、把每一步落成可回放的事件**。
CLI / Web / Desktop 留在 OmniHarness——**应用是内核的第一个消费者，不是内核的上游**。

## 四个不变量

| 不变量 | 含义 |
| ------ | ---- |
| **可审计** | 会话事件追加式落盘，哈希链 / 审计导出可复核；模型与工具之间没有"看不见的步骤" |
| **fail-closed** | 审批、沙箱、升级、完成闸门缺省拒绝；读不到安全数据就启动失败，不静默放行 |
| **模型中立** | 只认 `ModelPort`；OpenAI 兼容 / Anthropic / llama.cpp / 自写适配器同权 |
| **可嵌入** | 无 CLI 依赖；组合根 `Runtime` + 主循环 `Agent` 即可在任意 Node 进程里跑 |

## 安装

```bash
npm i @omniharness/kernel
```

要求 Node.js ≥ 22.14。下面的示例只 `import '@omniharness/kernel'`；在仓库内开发则先
`npm ci && npm run build` 再跑。

## 快速开始

```bash
npm ci
npm run build
node examples/headless.mjs
```

`examples/headless.mjs` 全文（20 行，只用公开入口）：

```js
import { mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import {
  Agent, AutoApproval, ConfigFactory, MemoryStorage,
  MockModel, PassthroughSandbox, Runtime, SilentEventPort,
} from '@omniharness/kernel';

const workspaceRoot = await mkdtemp(join(tmpdir(), 'omni-kernel-'));
const config = ConfigFactory.build({
  workspaceRoot, maxSteps: 4,
  model: new MockModel(), // 换成一个真实 ModelPort 即可接任意厂商
  storage: new MemoryStorage(), events: new SilentEventPort(),
  approvals: new AutoApproval(), sandbox: new PassthroughSandbox(),
});
const result = await new Agent(Runtime.createRuntime(config)).runTask('用一句话介绍自己');
console.log(result.finalText);
```

从源码跑时把 import 换成 `../dist/index.js`；发布后用包名即可。

## 目录

| 路径 | 内容 |
| ---- | ---- |
| `src/contracts` | 端口 / 类型 / 错误 / schema —— **零实现**，公开 30 个符号 |
| `src/kernel` | 主循环、上下文、工具、门禁、审计、存储、编排、组合根 |
| `src/protocols` | ACP / MCP / A2A / AG-UI（取用内核能力只经 `kernel/protocolsSupport.ts` 单一支撑面） |
| `tests/` | 纯内核测试（无 CLI / Web 夹具），`npm test` |
| `scripts/` | `build.mjs`（tsc + 运行时资产复制）、`apiSurface.mjs`（公开面门禁）、`boundaryCheck.mjs`（分层边界机检） |
| `defaults/` | 随包发布的策略 / 厂商 / 限制数据（改数据不改代码） |
| `examples/` | headless 示例 |

## 公开 API

唯一稳定入口是 `@omniharness/kernel`（`src/index.ts`），当前 **59 / 60** 个符号：

- **组合根**：`Runtime`、`ConfigFactory`、`AgentFactory`、`OmniHarnessConfig`、`ResolvedConfig`、`OmniHarnessRuntime`
- **主循环**：`Agent`、`AgentResult`、`AgentPort`
- **端口**：`ModelPort` / `ToolPort` / `StoragePort` / `EventPort` / `ApprovalPort` / `SandboxPort` / `EscalationPort` 等
- **默认适配器**：`MockModel`、`OpenAiCompatibleModel`、`AnthropicModel`、`MemoryStorage`、`JsonlStorage`、
  `SilentEventPort`、`AutoApproval`、`DenyApproval`、`RuleApproval`、`PassthroughSandbox`、`PolicySandbox`
- **工具**：`ShellTool`、`ReadFileTool`、`WriteFileTool`、`EditFileTool`、`GlobTool`、`GrepTool`

内部路径不承诺兼容；新增顶层导出必须先回答「谁会用」，并由 `npm run api:check` 守住 ≤60。
边界事实见 [docs/BOUNDARY.md](docs/BOUNDARY.md)；**下一版做什么、凭什么算做完**见
[docs/ROADMAP.md](docs/ROADMAP.md)（唯一规划源，`npm run plan:check` 对账）。

## 开发

```bash
npm ci                 # 独立安装（不再依赖应用仓库的 node_modules）
npm run verify         # 一键机检：typecheck + boundary:check + test + build + api:check + plan:check
npm run boundary:check # 分层边界机检（可单独跑，fail-closed）
npm run plan:check     # 规划对账：ROADMAP 状态账 ↔ 代码事实（需先 build）
npm pack               # 打包冒烟
```

`npm test` 当前 **29 文件 / 170 用例**，锁六条契约面：事件顺序、会话落盘回放、压缩不变量、
审批语义、沙箱语义、门禁接线（`tests/contract/` 共 32 例，只经公开入口）；
`boundary:check` 守五条规则——契约零反向依赖且纯净、protocols 单一支撑面、
组合根 / MCP 桥已声明例外、src 零 apps 引用。

规划闭环的规则只有一条：**文档里的 ✅ 必须由判据证明，判据过了也不许不记账**。
`plan:check` 双向对账，因此「改状态」永远等于「跑一次命令」。里程碑、判据与决策日志见
[docs/ROADMAP.md](docs/ROADMAP.md)。

要求 Node.js ≥ 22.14（用到 `node:sqlite`）。

## 与 OmniHarness 的关系

```
OmniHarness (应用)  ──依赖──▶  OmniKernel (本项目)
        │                          │
        └── CLI / Web / Desktop    └── contracts + kernel + protocols
```

- 依赖方向只有 **app → kernel → contracts**；内核不知道 CLI / HTTP / React 的存在。
- 内核独立 semver；应用钉版本，每发一个 alpha 跑一次全量回归。
- 应用需要改内核内部时，先在内核开 issue，不直接改。

## License

Apache-2.0。见 [LICENSE](LICENSE) 与 [NOTICE](NOTICE)。
