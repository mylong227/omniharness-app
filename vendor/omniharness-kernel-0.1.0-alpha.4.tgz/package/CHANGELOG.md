# Changelog

## 0.1.0-alpha.4 — 2026-11-03

### Added

- **子路径导出（迁移桥）**：`exports` 增加 `"./*.js"` / `"./*"` → `dist/*`，让第一个消费者
  OmniHarness 在**公开面迁移期**按内部模块路径接入（应用仓库已删掉 143,883 行重复内核副本）。
  **不是兼容承诺**：顶层仍是唯一稳定面（59 / 60）；子路径随迁移完成即删除，见 BOUNDARY「迁移桥」。

### Changed

- 无公开面变化；版本 `0.1.0-alpha.4`。

## 0.1.0-alpha.3 — 2026-11-03

**应用形状清零**（第二遍收口：把「不属于内核」的残留整棵子树删掉）。公开 API 不变（59 / 60）。

### Removed

- `contracts/ports/tui/`、`contracts/ports/license/`、`contracts/ports/server/audit{Format,Query}.ts`、
  `contracts/ports/enterprise/`、`kernel/adapters/enterprise/`、`kernel/security/oidcClient.ts`、
  `kernel/sdk/sdkClient.ts`、`contracts/schema/codeGenerator.ts`、`defaults/cliHelp.json`。
  合计 **19 文件 / 约 2.5K 行**，逐项确认零引用（`tsc` + 29 文件 170 用例为裁判）。
- 以上均不在公开面，`api:check` 仍为 59 / 60。

### Changed

- `docs/BOUNDARY.md` 新增「应用形状清零」节；`compat/` 表里 `oidcClient` / `sdkClient`
  的去向从「下沉内核」改为「删除」（下沉只保证能跑，不保证只剩内核）。

### Known issues

- **未执行 `npm publish`**（无发布凭据）：`npm pack` + 空目录安装 + headless 已跑通；
  正式发布需先 `npm login` 或提供 `NPM_TOKEN`。

## 0.1.0-alpha.2 — 2026-11-03

**beta 硬化（M3）落地**。公开 API 面不变（59 / 60），但 `decisionEngine` 有 alpha 破坏性变更。

### Added

- **契约测试扩容**：新增 `tests/contract/` —— 审批语义 13 例、沙箱语义 8 例、门禁接线 6 例；
  原三份契约用例（事件顺序 / 回放 / 压缩）同目录归位。共 **6 文件 32 例，只经公开入口**。
- `tests/unit/decisionEngineInjection.test.ts`（3 例）：钉住「配置了引擎却没实现 ⇒ 构建报错」。

### Changed

- **`adapters/laya` 移出内核**（9 文件 + `decisionEngineResolver` + Python 资产）：第三方 venv
  绑定不属于通用内核面，实现回到应用仓库。内核保留 `DecisionEngineConfig` 并新增注入缝
  `decisionEnginePort`；`mode` 非 `off` 却未注入实现时 `ConfigFactory.build` **直接报错**
  （此前会静默 new 出 Laya 实现）。
- `@beta` 组从四组 18 文件收敛为**三组 9 文件**（`user` / `monitoring` / `live`），
  裁决标记与「不进公开面」纪律不变。
- **测试总数 25 文件 / 140 例 → 29 文件 / 170 例**；`plan:check` 的 `m3-contract-coverage`
  由人工判据改为机检（`tests/contract` ≥30 例），`m3-adapters-beta-marked` 口径 18 → 9。

### Known issues

- **未执行 `npm publish`**（无发布凭据）：`npm pack` + 空目录安装 + headless 已跑通；
  正式发布需先 `npm login` 或提供 `NPM_TOKEN`。

## 0.1.0-alpha.1 — 2026-11-03

**规划闭环 + 发布就绪**。公开 API 面不变（59 / 60）。

### Added

- **唯一规划源** `docs/ROADMAP.md`：里程碑 M0–M3、判据表（auto / manual）、人工复核记录、
  发布记录、决策日志；「下一版做什么」不再散落在 BOUNDARY 的一句话里。
- **规划对账门禁** `scripts/planCheck.mjs` + `npm run plan:check`（已并入 `npm run verify`）：
  状态账与代码事实**双向**对账——标 ✅ 必须判据全过，标 ⏳ 必须至少一条不过
  （既防提前记账，也防做完不记账）。
- **公开面计数单一实现** `scripts/publicSurface.mjs`：`apiSurface.mjs` 与 `planCheck.mjs` 共用，
  避免两处数字漂移。
- **CI** `.github/workflows/verify.yml`：`ubuntu-latest` + `windows-latest` 双平台跑
  `npm ci → npm run verify → node examples/headless.mjs`。
- **发布元数据**：`private: false`、`publishConfig.access: public`、`files[]` 收入
  `docs/ROADMAP.md`。

### Changed

- `docs/BOUNDARY.md` 的「下一步」移交 ROADMAP；本文件只保留**已经发生**的变更，
  发布记录只写「就绪」与「已发布」中真正发生的那一个。
- README 增加规划入口与 `npm run plan:check` 说明。

### Known issues

- **未执行 `npm publish`**（无发布凭据）：`0.1.0-alpha.1` 处于「发布就绪」，
  `npm pack` + 空目录安装 + headless 已跑通，见 ROADMAP §7。

## 0.1.0-alpha.0 — 2026-11-02

首次以「独立内核」形态收口。**不承诺兼容**（alpha）。

### Added

- **独立组合根** `kernel/composition/runtime.ts`：`Runtime.createRuntime(config)` 可在任意 Node
  进程里装配 `Agent`，不再依赖应用层 `apps/composition`。
- **公开入口** `src/index.ts`：58 / 60 个符号（`npm run api:check` 机检），
  覆盖组合根、主循环、端口与默认适配器。
- **契约测试** `tests/`：22 文件 / 135 用例，只依赖 `src/` 与 Node 内置；
  含一次「只经公开入口」的 headless 回合。
- **20 行 headless 示例** `examples/headless.mjs` 与 `npm run smoke`。
- **构建资产复制** `scripts/build.mjs`：`dangerous-commands.json`、worker mjs、laya py
  随 `dist` 发布（此前 `tsc` 不搬运，运行期 ENOENT）。
- **独立安装** `package-lock.json`；`node_modules` 不再是应用仓库的 junction。
- **`npm pack` 冒烟**：空目录安装 tarball 后可直接跑通 headless。

### Changed

- `src/compat/` 10 个「从应用借来的共享件」全部下沉：
  - `jsonRpc` → `kernel/rpc/`
  - 行传输 / WebSocket 编解码 → `kernel/transport/`
  - `serverAuthGuard`、`oidcClient` → `kernel/security/`
  - `safeFs`、`serveInstance` → `kernel/util/`
  - `serviceKeys` → `kernel/composition/`
- `contracts/sdk/sdkClient.ts` → `kernel/sdk/`（契约层不放实现）。
- `TuiRenderer` 删除：内核只保留 `ConsoleLiveView` 需要的两个纯 ANSI 片段。
- **契约反向依赖清零**（依赖规则 1 归零）：限制类型族（`RuntimeLimitsConfig` 等 10 个接口）
  与 `Spectrum` 下沉 `contracts/ports/`；A2A 协议数据（`a2aProtocol` + `TaskHandler`）移入
  `contracts/ports/a2a/`，新增 `A2aServerPort` / `A2aClientPort` 端口，
  `OmniHarnessRuntime.a2a` 只认端口（实现类在 protocols 侧 `implements`）。公开面 58 → 59。
- **协议穿透收口**：`protocols` → `kernel` 的 76 条散点 import 收敛为唯一支撑面
  `kernel/protocolsSupport.ts`（30 个文件改走该边，纯 re-export 零逻辑，只导出实际消费符号）；
  新增 `npm run boundary:check` 分层边界机检（fail-closed，四条规则），
  首跑即抓出 `kernel/adapters/mcp` → `protocols/mcp` 的 5 处存量穿透并声明为窄例外。
- **适配器归属裁决**（授权自主裁决）：`adapters/laya`（厂商绑定，待移出）、`adapters/user` /
  `adapters/monitoring` / `adapters/live`（端口默认实现，保留）四组共 18 文件标 `@beta`，
  处置理由与迁移路径记入 `docs/BOUNDARY.md`；组内符号不进公开面（api:check 把守）。
- **机检收口**：`boundary:check` 升至五条规则（新增规则 5「契约纯净」——contracts 只许相对
  路径导入，零 `node:` 内置、零第三方包）；新增 **`npm run verify`** 一键机检入口
  （typecheck + boundary:check + test + build + api:check）；README / BOUNDARY 同步终态
  （公开面 59/60、25 文件 140 用例、机检入口与裁决记录）。
- **契约测试扩容**（22 → 25 文件 / 135 → 140 用例）：
  - 事件顺序：`session_meta` 首条、`seq` 严格递增、`tool_result` 永不先于 `tool_call`、
    数量守恒、最终答案在最后结果之后、端口所见 = 存储落盘；
  - 会话落盘回放：JsonlStorage 跨实例（重启模拟）往返一致、`replay` 不改写历史、
    `resume` 历史严格前缀 + `seq` 延续；
  - 压缩不变量：确定性无损收缩只动空白且幂等、折叠后工具轮配对（无孤儿 tool / 无悬空
    toolCall）、前导 system 原样钉住。
- 清理最后一个再导出别名：`kernel/adapters/tool/toolHandler.ts` 删除，5 个引用方直连
  contracts（`ToolHandler` 单一引入路径）。
- **支撑面收窄**：`a2aTaskExecutor` 生产默认（子代理工厂 / Agent 主循环 / FilteredToolPort）
  挪到组合根 `kernel/composition/a2aBridge.ts`，经 `buildSubagent` / `runTask` / `filterTools`
  注入缝装配（**alpha 破坏性**：三项构造选项改必填，缺省即装配期报错）；
  fail-closed 工具收窄**策略**留在协议层、**机制**注入。`AgentPort` 扩展 `eventsOf` /
  `cancelCurrentRun` / 可选 `sessionId`（协议桥只认端口）；新增 contracts `ToolRegistryPort`
  （MCP 网关不再感知 `RegistryToolPort` 具体类）。支撑面 27 → 21 符号（全基础设施），
  协议层对 `core` / `subagent` 的感知归零。

### Removed

- `src/compat/` 目录整体删除；`src` 内零 `apps/` import。

### Known issues

- `npm publish` 未执行（无发布凭据）；包已可 `npm pack`（0.1.0-alpha.0，不承诺兼容）。
- `adapters/laya` 长期应迁回应用仓库（已标 `@beta`，迁移路径见 BOUNDARY 裁决表）。

