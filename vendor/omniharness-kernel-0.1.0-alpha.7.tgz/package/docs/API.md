# API 文档 —— 对接参考（含完整用例）

> **对象**：把 OmniKernel 嵌进宿主进程、为它造工作台 UI、或对它的执行做审计复核的开发者。
> **口径**：所有签名与行为以本仓源码与测试为准（每条 API 都有对应判据）；子路径不承诺兼容
> （见 [BOUNDARY.md](BOUNDARY.md)），顶层 60 符号被 golden 快照锁定（改公开面必须 `--update-golden` + CHANGELOG）。
> 端到端可运行示例：[examples/embed.mjs](../examples/embed.mjs)（一次接入全部能力）、
> [examples/headless.mjs](../examples/headless.mjs)（手动接线）、
> [examples/workbench.mjs](../examples/workbench.mjs)（工作台全流程）、
> [examples/audit-pack.mjs](../examples/audit-pack.mjs)（回执/审计）。

---

## 0. 包结构：一个顶层 + 八个能力子路径

```ts
import { createOmniKernel } from '@omniharness/kernel';  // 顶层：稳定面（60 符号，golden 锁定）
import type { OmniKernelInput } from '@omniharness/kernel/embed'; // 完整选项/句柄类型（同一实现的类型面）
import { ... } from '@omniharness/kernel/workbench';     // 工作台服务器（宿主进程，依赖 node:http）
import { ... } from '@omniharness/kernel/workbench-view'; // 纯投影（浏览器安全，零 node:）
import { ... } from '@omniharness/kernel/receipts';      // 回执链完整面（含 jcs / TrustStore / payloadHashOf）
import { ... } from '@omniharness/kernel/sandbox';       // OS 级沙箱族 + 能力探测表
import { ... } from '@omniharness/kernel/governance';    // 出处出证（ProvenanceIssuer）
import { ... } from '@omniharness/kernel/mcp';           // MCP 服务端装配（HTTP + stdio runner）
import { ... } from '@omniharness/kernel/tools';         // 6 个内置演示工具（Shell/ReadFile/…）
```

| 子路径 | 给谁用 | 一句话 |
| ------ | ------ | ------ |
| 顶层 | 所有宿主 | 内核主循环、组合根、`createOmniKernel`、回执核心、审批/沙箱基线件 |
| `embed` | **宿主（类型面）** | `OmniKernel` / 选项 / 句柄类型（`createOmniKernel` 的完整类型面；函数本身在顶层） |
| `workbench` | **宿主进程** | 工作台 HTTP 服务器 + 事件/提问双端口 Hub |
| `workbench-view` | **浏览器** | `projectSession`/`mergeEvents` 纯投影（零 `node:`，可直接打包） |
| `receipts` | 宿主 / 复核方 | 回执链完整 API（签发、锚定、规范化） |
| `sandbox` | 宿主 | OS 级隔离后端 + 本机能力探测 |
| `governance` | 宿主 / 审计 | 技能包出处出证与独立复核 |
| `mcp` | 宿主 | 2026-07-28 无状态 MCP 服务端装配（HTTP）与 stdio runner |
| `tools` | 演示/测试 | 内置工具类（真实系统注入自己的 ToolPort） |

---

## 1. 最小接入：一次调用拿到全部能力（顶层 `createOmniKernel`）

### 1.1 六行跑通（推荐）

```ts
import { createOmniKernel, OpenAiCompatibleModel } from '@omniharness/kernel';

const kernel = await createOmniKernel({
  workspaceRoot: process.cwd(),
  model: new OpenAiCompatibleModel({
    baseUrl: 'https://api.deepseek.com',
    apiKey: process.env.DEEPSEEK_API_KEY ?? '',
    model: 'deepseek-v4-flash',
  }),
  maxSteps: 12,
});
try {
  const result = await kernel.runTask('把 src/config.ts 的端口改成 8787');
  console.log(result.finalText);
  console.log(kernel.capabilities()); // 哪些能力真的开了：工具数 / 工作台地址 / 回执数 / MCP 工具…
} finally {
  await kernel.close(); // 幂等：取消在跑回合 → 关 MCP → 落回执 → 关工作台
}
```

把 `model` 换成任意 `ModelPort` 即接任意厂商；缺省不传则是 `MockModel`（零凭据演示，
会打一条 `embed.model.default_mock` warn，**不会**静默读取本机凭据）。

### 1.2 缺省装配了什么

| 能力 | 缺省行为 | 句柄 | 关闭 / 覆盖 |
| ---- | -------- | ---- | ----------- |
| 主循环 + 内置工具/记忆/技能/计划/待办/检索 | 走 `ConfigFactory` 的完整内置装配（35 个左右工具，随配置变化） | `kernel.agent` / `kernel.runtime` | `config` 透传；`config.tools` 可整体替换工具面 |
| 会话持久化 | `JsonlStorage(<workspace>/.omniharness/sessions)`，可按 `seq` 回放 | `kernel.storage` | `storage` 传 `MemoryStorage` / 自定义 `StoragePort` |
| 工作台（SSE / state / answers / audit） | 回环 `127.0.0.1:0` 启动，`close()` 关闭；文件型存储自动扫描历史会话（重启后侧边栏仍在） | `kernel.workbench.server` / `.hub` / `.url` | `workbench: false` 或 `{host,port,token,corsOrigin,discoverSessions}` |
| 回执链 | 每次工具调用自动入链；缺省现场生成 Ed25519 并签名；`persist:true` 时跨重启续链 | `kernel.receipts.pack()` / `.signSummary()` / `.trustStore()` | `receipts: false`；`sign:false` 如实未签名；可注入 `signer` / `anchor` |
| 运行级执行证书（M14） | `certificates:true` 时每次 `runTask/resume/fork` 结束自动签发并落盘；也可显式 `kernel.certificate(sessionId)` | 证书文件 / `kernel.certificate()` | `certificates:false`（缺省）/ 目录路径 |
| MCP 客户端 | 仅当 `mcpServers` 非空时连接（stdio / HTTP+SSE + auth），`close()` 反注册 | `kernel.mcp.tools` | `mcpServers` + `mcp.connector/timeoutMs/allowedServers` |
| MCP **服务端**发布 | 缺省关闭；`mcpServe: true` 时回环启动 `/mcp`（与本地同一道审批/沙箱门禁） | `kernel.mcpServe.url` | `mcpServe: false`（缺省）/ `{host,port,path,token,corsOrigin}` |
| 长期运行遥测（哈希链） | 缺省不构造；`telemetry: true` 落 `<workspace>/.omniharness/telemetry` | `kernel.telemetry.record/read/verify` | `telemetry: false` / `{dir,path}` / 注入 `RuntimeTelemetryPort` |
| 审批 / 沙箱 | 仍是内核安全默认：`DenyApproval` + OS 隔离探测（fail-closed） | `kernel.runtime.approvals` / `.sandbox` | `approvals` / `sandbox` 显式注入 |
| 能力清单 | 每次调用实时取数，不缓存过期状态 | `kernel.capabilities()` | — |

> **不替宿主做的两件事**（如实）：① 交互式 OAuth 授权码回环需宿主显式跑
> （`mcpAuthFlow` 是可用实现，内核不在启动时开回调）；② 进程退出不会替你 `close()`——
> 宿主应在 `finally` / 信号处理里调用（幂等）。
>
> **回执密钥的诚实边界**：缺省签名器是**本次进程内现场生成**的 Ed25519 密钥，
> `trustStore()` 给出的公钥只对这条链有效——跨进程/重启要对账，请注入持久私钥
> （`receipts.signer`）或改用 `ReceiptChain` 自行管理签发身份。`sign:false` 时回执如实
> `signature:null`，`signSummary()` 会拒绝签发（不产出「看起来像承诺」的对象）。
> 自动回执覆盖**内核主循环的工具调用**；外部 MCP 客户端经 `mcpServe` 调进来的调用
> 与本地同过审批/沙箱门禁，但不在这条自动回执链上（需要时由宿主在 MCP 侧另行签发）。

MCP 服务端最小用法：

```ts
const kernel = await createOmniKernel({
  workspaceRoot, model,
  mcpServe: { token: 'secret' }, // 非回环绑定必须给令牌
});
console.log(kernel.mcpServe?.url); // http://127.0.0.1:<port>/mcp
// GET 同一 URL 是健康/能力自述；POST 是 2026-07-28 无状态 JSON-RPC。
// 外部调用与本地同一道 gate（审批/沙箱/计划态/RBAC），不因来自网络而豁免。
```

### 1.3 输入选项（全部可选）

| 字段 | 类型 | 说明 |
| ---- | ---- | ---- |
| `workspaceRoot` | `string` | 工具工作区 / 沙箱白名单根，缺省 `process.cwd()` |
| `model` | `ModelPort` | 缺省 `MockModel`（零凭据演示） |
| `storage` | `StoragePort` | 缺省 `JsonlStorage`（落 `<workspace>/.omniharness/sessions`） |
| `approvals` | `ApprovalPort` | 缺省 `DenyApproval`（fail-closed） |
| `sandbox` | `SandboxPort` | 缺省探测 OS 级隔离（探测不到落 `PolicySandbox` + warn） |
| `maxSteps` | `number` | 缺省 `0`（不限） |
| `config` | `Partial<OmniHarnessConfig>` | **任意内核配置透传**：内存 / 技能 / 预算 / 计划态 / RBAC / selfVerify / 遥测 / modelRouter / longTermMemory / skill 池…；新增内核能力不需要改本接口 |
| `workbench` | `boolean \| {host, port, token, corsOrigin, discoverSessions}` | `false` 关闭；缺省回环启动 |
| `mcpServers` | `readonly McpServerConfig[]` | 缺省读 `config.mcpServers` |
| `mcp` | `{connector?, timeoutMs?, allowedServers?}` | MCP 客户端覆盖（测试可注入假连接器） |
| `mcpServe` | `boolean \| {host, port, path, token, corsOrigin, bodyLimitBytes, readTimeoutMs}` | MCP **服务端**发布；缺省关（外部客户端调本内核时开） |
| `telemetry` | `boolean \| {dir?, path?} \| RuntimeTelemetryPort` | 长期运行遥测；`true` 自动落盘哈希链，缺省沿用 `config.runtimeTelemetry` |
| `receipts` | `boolean \| {issuerId?, signer?, sign?, anchor?, toolCalls?, persist?, certificates?}` | `false` 关闭；缺省自动签工具回执；`persist:true` 落盘续链；`certificates:true` 自动签运行证书 |

**优先级**：顶层便利字段 > `config` 同名字段 > 本文件缺省值。`config` 里给 `events` /
`userResponder` 时，工作台仍会收到事件（事件端口扇出），但提问桥以显式 `userResponder` 为准。

### 1.4 句柄

```ts
interface OmniKernel {
  workspaceRoot: string;
  config: ResolvedConfig;          // 已解析配置（全部端口）
  runtime: OmniHarnessRuntime;     // 逃生口：任何没被代理的能力都按内核契约直接用
  agent: Agent;                    // runTask / resume / fork / replay / eventsOf / cancelCurrentRun
  model: ModelPort;
  storage: StoragePort;
  workbench?: { server; hub; host; port; url; token };
  mcp?: { bridge; tools: readonly string[] };
  mcpServe?: { server; host; port; url };
  receipts?: {
    chain; issuerId; signed; anchored; persisted; certificates;
    receiptsPath?; certificatesPath?; keyPath?;
    flush(): Promise<void>;
    pack(): AuditPack;
    signSummary(): Promise<SignedReceiptSummary>;
    trustStore(): Readonly<Record<string, string>>;
  };
  certificatesDir?: string;        // certificates:true 时的落盘目录
  certificate(sessionId): Promise<SignedExecutionCertificate>;
  telemetry?: RuntimeTelemetryPort;   // record/read/verify；未启用为 undefined
  runTask(prompt, images?, files?, sessionId?): Promise<AgentResult>;
  resume(sessionId, prompt, images?, files?): Promise<AgentResult>;
  fork(sourceSessionId, prompt, images?, files?): Promise<AgentResult>;
  cancel(reason?, sessionId?): void;
  capabilities(): OmniKernelCapabilities;
  close(): Promise<void>;          // 幂等
}
```

`capabilities()` 的外形：`{ workspaceRoot, model, storage, tools, skills, longTermMemory, planMode,
approvals, sandbox, workbench?, mcp?, mcpServe?, receipts?, embedding, evolution, native, telemetry }`；
`receipts` 内含 `{issuerId, signed, anchored, persisted, certificates, count}`。
它回答的是「这台内核此刻**真的**有哪些能力」，而不是「配置里写了什么」。

### 1.5 手动接线（完全控制端口）

需要自己挑每一个端口时，走顶层 `ConfigFactory` + `Runtime` + `Agent`（`examples/headless.mjs` 全文）：

```ts
import {
  Agent, AutoApproval, ConfigFactory, MemoryStorage, MockModel,
  PassthroughSandbox, Runtime, SilentEventPort,
} from '@omniharness/kernel';

const config = ConfigFactory.build({
  workspaceRoot: '/path/to/project',   // 工具的工作区（沙箱白名单根）
  maxSteps: 8,                          // 单任务步数上限
  model: new MockModel(),               // 换成任意 ModelPort 实现（见 §4.2）
  storage: new MemoryStorage(),         // 事件落盘（生产用 JsonlStorage）
  events: new SilentEventPort(),        // 事件广播（工作台接 WorkbenchHub，见 §2）
  approvals: new AutoApproval(),        // 显式注入放行；不注入 = 缺省拒绝（见 §4.4）
  sandbox: new PassthroughSandbox(),    // 显式注入零隔离对照；不注入 = 探测 OS 隔离（见 §4.4）
});
const result = await new Agent(Runtime.createRuntime(config))
  .runTask('把 src/config.ts 的端口改成 8787');
// result.finalText / result.sessionId
```

`Agent.runTask` 签名（第 4 参只影响**新会话的命名**，不加载历史）：

```ts
runTask(
  prompt: string,
  images?: readonly ImageContent[],
  files?: readonly FileAttachment[],
  sessionId?: string,          // 仅命名新会话（宿主预绑定 id）；不会 hydrate 旧事件
): Promise<AgentResult>
```

- **续跑既有会话**用 `agent.resume(sessionId, prompt, images?, files?)`——它先
  `storage.load(sessionId)` 再继续；**分叉**用 `agent.fork(sourceSessionId, prompt, …)`（新 id，不改源会话）。
- ⚠️ 不要把**已存在的 sessionId** 交给 `runTask`：它按新会话建空事件日志，回合结束会以新流覆盖
  该 id 的存档——看起来像「续跑」，实际是丢历史。要续跑就走 `resume`。
- `result.sessionId` 用于后续 `storage.load(sessionId)` 与工作台端点；`result.finalText` / `steps` /
  `events` / `truncated` / `aborted` 均在 `AgentResult` 上如实返回（`truncated=true` 不等于任务完成）。

### 1.6 接入成本（可机检）

| 接入方式 | 宿主代码 | 判据 |
| -------- | -------- | ---- |
| 一次接入（推荐） | **6 行核心**：选 `workspaceRoot` + `model`，`createOmniKernel` → `runTask` → `capabilities` → `close` | `m11-embed-minimal`：`examples/embed.mjs` 只经顶层、非注释代码 ≤60 行、只调一次 `createOmniKernel` |
| 手动接线 | 约 25 行 `ConfigFactory` + 3 行工作台 + 4 行 MCP + 回执签发/导出各若干行；每多一种能力就多一段胶水 | `examples/headless.mjs` 保留为对照 |

`tests/contract/embedOneCall.test.ts`（16 例）把「一次接入 = 全部能力」逐项钉住：工具回合、
工作台投影/重启后发现历史会话、审计包真实验签、MCP 客户端连接/反注册、MCP 服务端发布、
显式事件扇出、未签名回执语义、`config` 透传、非回环无令牌 fail-closed、遥测哈希链落盘、
回执跨重启续链/篡改拒绝/丢钥拒绝、运行级执行证书签发与复核、审计三件套导出、单文件审计包。
新增能力时**先加进 `./embed` 的装配与这份判据**，而不是让消费者再写一层。

### 1.7 审计闭环：回执跨重启续链

```ts
const kernel = await createOmniKernel({
  workspaceRoot,
  model,
  receipts: { persist: true, issuerId: 'my-audit-chain' },
});

await kernel.runTask('改代码并跑测试');
await kernel.receipts?.flush();
// 存档：<workspace>/.omniharness/receipts/my-audit-chain.jsonl（一行一条，append-only）
// 私钥：<workspace>/.omniharness/receipts/my-audit-chain.jsonl.key.pem（0600，勿提交）
const pack = kernel.receipts?.pack();
verifyAuditPack(pack, kernel.receipts?.trustStore()); // 本进程即可离线复核
await kernel.close();

// 下一个进程（同工作区、同 issuerId、同 persist 路径）：
const resumed = await createOmniKernel({ workspaceRoot, model, receipts: { persist: true, issuerId: 'my-audit-chain' } });
resumed.receipts?.chain.length(); // = 上一进程条数；后续 append 从链尾继续，不分叉
```

fail-closed 语义（均已判据化）：存档坏行 / seq 断档 / 前驱不接 / 签名被改 ⇒ 启动失败；
**有签名历史但密钥文件丢失** ⇒ 拒绝新建密钥冒充原签发身份；已签名链上 `sign:false` ⇒ 拒绝。
并发边界：同一 `issuerId` 的存档是**单写者**语义（未实现跨进程锁）；多个内核进程同时写同一链
会分叉——需要并行时给每个进程不同 `issuerId`，或在宿主侧串行化。

### 1.8 运行级执行证书（M14）

回执证明「每个动作被签发」；执行证书证明「这整段事件流完整、顺序未被换、且与回执链尾是同一次运行」。

```ts
const kernel = await createOmniKernel({
  workspaceRoot, model,
  receipts: { persist: true, certificates: true, issuerId: 'my-audit-chain' },
});
const result = await kernel.runTask('改代码并跑测试');
// 自动落盘：<证书目录>/<sessionId>.json
// 证书目录缺省在回执存档旁 certificates/；也可显式给路径。

// 显式签发（不依赖 certificates:true）：
const signed = await kernel.certificate(result.sessionId);

// 收证方离线复核（事件流 + 证书 + 信任根）：
import { verifyExecutionCertificate } from '@omniharness/kernel/receipts';
const events = await kernel.agent.eventsOf(result.sessionId);
const verdict = verifyExecutionCertificate(events, signed, {
  trustStore: kernel.receipts?.trustStore(),
  // 可选：把签发时刻的链尾摘要钉进来（防「事件流与回执链不是同一次运行」）
  receipt: kernel.receipts?.chain.summary(),
});
// verdict.ok / problems[]（EVENT_ROOT_MISMATCH / RECEIPT_BINDING_MISMATCH / SIGNATURE_INVALID…）
```

边界（与 M14 一致）：证明完整性/顺序/条数与回执尾绑定，**不**证明事件内容为真；无外部
witness 时不能防签发方整体重写一份自洽历史。

### 1.9 审计三件套导出

```ts
const bundle = await kernel.receipts?.exportBundle(); // 可选显式目录
// <directory>/pack.json     审计包（回执数组）
// <directory>/trust.json    { kid: SPKI PEM }（自签场景）
// <directory>/summary.json  链尾摘要签名（未签名链不产出此文件）
// 第三方零出网复核（两种实现互为对照）：
//   verifyAuditPack(pack, trust, summary)
//   node scripts/verifyReceipts.mjs pack.json trust.json
```

缺省目录是 `<workspace>/.omniharness/audit-bundles/<issuer>-<时间>`；`summary.json` 让收证方
能检出**尾条被改/被删**（线性链自身对尾条没有后继绑定）。

### 1.10 单文件审计包（M16：完整运行证明）

需要把「事件流 + 执行证书 + 回执链 + 整包签名」一次性交给收证方时：

```ts
const exported = await kernel.exportAuditBundle([result.sessionId]);
// <dir>/bundle.json   已签名 AuditBundle（事件 + 证书 + 回执 [+ 执行图]）
// <dir>/trust.json    { kid: SPKI PEM }
// <dir>/digest.txt    auditBundleDigest(bundle)（可公告/锚定）

verifyAuditBundle(exported.signed, { trustStore: kernel.receipts?.trustStore() });
// 或零出网 CLI：node scripts/verifyBundle.mjs bundle.json trust.json
```

与 §1.9 的分工：三件套轻、适合动作级复核；单文件审计包大、适合归档取证，一次报告
「证书 / 回执链 / 执行图 / 整包签名」全部问题码。改任意事件、改回执、换证书、伪造签名
都会使 `ok:false`。

### 1.11 选择性披露包（M18：最小披露仍可验）

事件流里有与本次争议无关的敏感载荷、只想交出「能证明事实的那部分」时：

```ts
const events = await kernel.agent.eventsOf(result.sessionId);
const exported = await kernel.exportDisclosurePack([
  { sessionId: result.sessionId, indices: [0, events.length - 1] }, // 只披露首尾两条
]);
// <dir>/disclosure.json  已签名 DisclosurePack（子集事件 + 各自包含证明 + 必需回执前缀）
// <dir>/trust.json / digest.txt（JCS SHA-256，可公告/锚定）

verifyDisclosurePack(exported.signed, { trustStore: kernel.receipts?.trustStore() });
// 或零出网 CLI（按 kind 自动识别审计包/披露包）：
//   node scripts/verifyBundle.mjs disclosure.json trust.json
```

- 每条披露事件经 M14 包含证明锚回证书 Merkle 根——完整性/顺序/条数承诺不因最小披露松动；
- 未选事件**不出包**；回执链只带「第 1 条到最大绑定条数」的必需前缀；
- 诚实边界：不证明未披露事件存在/不存在；回执前缀含未披露会话的动作回执（单链固有泄露面）；
- 与 §1.10 的分工：审计包交全量（归档取证），披露包交子集（最小披露）。

---

## 2. 工作台桥（`@omniharness/kernel/workbench`）

### 2.1 三行接线（宿主进程）

```ts
import { readdir } from 'node:fs/promises';
import { WorkbenchServer } from '@omniharness/kernel/workbench';

const wb = WorkbenchServer.create({
  storage,                                    // StoragePort（历史回放事实源）
  http: { host: '127.0.0.1', port: 0,         // port 0 = 内核分配；token 缺省回落 OMNI_SERVE_TOKEN
          token: 'dev-token' },               // 非回环绑定必须配令牌（fail-closed）
  corsOrigin: 'loopback',                     // 默认值；精确 origin/'*' 也只对回环页面实际生效
  // 可选：历史会话侧边栏数据源（这里以 JSONL 会话目录为例；宿主可换成自己的索引）
  discoverSessions: async () =>
    (await readdir('/path/to/sessions'))
      .filter((file) => file.endsWith('.jsonl'))
      .map((file) => file.slice(0, -'.jsonl'.length)),
});
const config = ConfigFactory.build({
  /* …同 §1… */
  events: wb.hub,          // ← 事件直播（WorkbenchHub 实现 EventPort）
  userResponder: wb.hub,   // ← 提问桥（WorkbenchHub 实现 UserResponder）
});
await wb.listen();         // → { host, port, url }
```

> CORS 的边界（别被选项名误导）：`corsOrigin` 只决定**回显哪些响应头**；鉴权守卫
> `ServerAuthGuard` 仍然只接受**回环 Origin**（localhost / 127.0.0.1 / [::1]）。因此
> `corsOrigin: '*'` 也不会让 `https://app.example.com` 直接调用 `/api/*`（实际请求 401）；
> 远程部署请走同源反向代理，或把 UI 与内核放在同一回环源下。

### 2.2 HTTP API 参考

鉴权（`/api/*` 全部要求；`/health` 免）：`Authorization: Bearer <token>`（fetch/WS）·
`?token=<token>`（**EventSource 用这个**——它无法设头）· cookie `omni_serve_token`。
CORS：默认回环 origin 回显（跨端口 UI 开箱即用）；`OPTIONS` 预检免鉴权。请求体上限 1 MiB。
注意：带 `Origin` 的请求仍要过 `ServerAuthGuard` 的**回环 Origin** 检查——非回环页面即使拿到
令牌也会 401（见 §2.1 的 CORS 边界）。

| 方法 + 路径 | 作用 | 成功 | 错误 |
| ----------- | ---- | ---- | ---- |
| `GET /health` | 存活探针（免鉴权） | 200 `{ok,service}` | — |
| `GET /api/sessions` | 会话列表（hub 活跃 ∪ discoverSessions 去重） | 200 `{sessions:[{sessionId,source:'live'\|'discovered',eventCount?,lastSeq?,startedAt?}]}` | 401 |
| `GET /api/sessions/:id/events` | **SSE 直播**（历史回放 → 实时；`Last-Event-ID` 头 / `?from=<seq>` 续传） | 200 `text/event-stream` | 401 |
| `GET /api/sessions/:id/state` | 一次投影快照（`WorkbenchState`） | 200 | 401 / 500 |
| `GET /api/sessions/:id` | 同 state（「点开一个会话」） | 200 | 401 |
| `POST /api/sessions/:id/answers` | 回答挂起提问 | 200 `{ok:true}` | 400 坏 body · **409 无挂起提问（防重放）** · 413 |
| `POST /api/audit/verify` | 审计包离线复核 | 200 `AuditPackVerdict` | 400 · 413 · 500（复核器自身异常） |
| 任意未知路径 | — | — | 404；路径命中但方法不对 → 405 |

#### SSE 协议细节

```
retry: 3000                 ← 流首行：浏览器重连间隔

id: 12                      ← 事件 seq（自动重连时回传为 Last-Event-ID 头）
event: tool_result          ← SessionEvent.type
data: {"id":"…","type":"tool_result",…}   ← 完整 SessionEvent JSON

: ping                      ← 15s 心跳注释帧（保活）
```

- 续传起点：自动重连带 `Last-Event-ID` 头；**首次连接**用 `?from=<seq>`（EventSource 首连无法设头）；
- 无 `seq` 的旧存档事件：仅在没有续传起点时发送；
- 数据源 = `mergeEvents(storage.load(id), hub直播缓冲)`——进程启动前的历史与直播流同序合并、按 `event.id` 去重。

#### curl 速查

```bash
curl http://127.0.0.1:PORT/health
curl -H 'Authorization: Bearer dev-token' http://127.0.0.1:PORT/api/sessions
curl -N -H 'Authorization: Bearer dev-token' 'http://127.0.0.1:PORT/api/sessions/SESS/events?from=0'
curl -X POST -H 'Authorization: Bearer dev-token' -H 'content-type: application/json' \
  -d '{"answers":[{"id":"q1","selected":["A（推荐）"]}]}' \
  http://127.0.0.1:PORT/api/sessions/SESS/answers
```

### 2.3 浏览器用例 A：`useWorkbenchSession`（React Hook，完整实现）

数据面两路并用：**首屏** `GET /state` 拿全量投影 → **SSE 从头回放**原始事件并累积 →
一旦回放追上快照的 `lastSeq`，改用浏览器本地 `projectSession`（`@omniharness/kernel/workbench-view`，
纯函数、零 node:）重投影——与服务器同一实现同一口径，前端零事件语义知识。

> **不能**用 `?from=<lastSeq>` 起流：服务端只发送 `seq > from` 的事件，本地事件缓冲里没有历史，
> 第一帧到达后 `projectSession` 会把历史消息全部"投影掉"（UI 看起来像消息突然消失）。
> 要本地重投影就必须让 SSE 从流首回放；`?from=`/`Last-Event-ID` 是给"只要增量、不重投影"的
> 客户端（或断线续传）用的。

```tsx
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  mergeEvents, projectSession,
  type AskAnswer, type PendingAsk, type WorkbenchState,
} from '@omniharness/kernel/workbench-view';
import type { SessionEvent } from '@omniharness/kernel';

const EVENT_TYPES = [
  'user', 'assistant', 'reasoning', 'tool_call', 'tool_result', 'system',
  'todo', 'plan', 'question', 'turn_diff', 'model', 'rollback', 'session_meta',
] as const;

export function useWorkbenchSession(baseUrl: string, token: string, sessionId: string): {
  state: WorkbenchState | undefined;
  connected: boolean;
  answer: (answers: readonly AskAnswer[]) => Promise<void>;
} {
  const [state, setState] = useState<WorkbenchState>();
  const [connected, setConnected] = useState(false);
  const eventsRef = useRef<readonly SessionEvent[]>([]);
  const pendingAskRef = useRef<PendingAsk | undefined>(undefined);
  const snapshotSeqRef = useRef<number | undefined>(undefined);
  const snapshotEmptyRef = useRef(false);
  const disposedRef = useRef(false);

  const reproject = useCallback(() => {
    setState(projectSession(eventsRef.current, pendingAskRef.current));
  }, []);

  useEffect(() => {
    let es: EventSource | undefined;
    disposedRef.current = false;
    eventsRef.current = [];
    const q = encodeURIComponent;
    const stateUrl = `${baseUrl}/api/sessions/${q(sessionId)}/state`;

    // 旧存档（无 seq）无法判定"回放追上"，退回 /state 快照；只对这类会话多花请求。
    let refreshing = false;
    const refreshSnapshot = async (): Promise<void> => {
      if (refreshing) return;
      refreshing = true;
      try {
        const res = await fetch(stateUrl, { headers: { authorization: `Bearer ${token}` } });
        const snapshot = (await res.json()) as WorkbenchState;
        if (disposedRef.current) return;
        pendingAskRef.current = snapshot.pendingAsk;
        setState(snapshot);
      } finally {
        refreshing = false;
      }
    };

    void (async () => {
      // ① 首屏快照：立即有内容，并拿到 lastSeq / 已存在的挂起提问。
      const res = await fetch(stateUrl, { headers: { authorization: `Bearer ${token}` } });
      const snapshot = (await res.json()) as WorkbenchState;
      if (disposedRef.current) return;
      pendingAskRef.current = snapshot.pendingAsk;
      snapshotSeqRef.current = snapshot.lastSeq;
      snapshotEmptyRef.current = snapshot.messages.length === 0;
      setState(snapshot);

      // ② 全量回放：不传 from（历史 + 直播）；?token= 是 EventSource 唯一能带凭据的方式。
      es = new EventSource(`${baseUrl}/api/sessions/${q(sessionId)}/events?token=${q(token)}`);
      es.onopen = () => setConnected(true);
      es.onerror = () => setConnected(false); // 浏览器自动重连，Last-Event-ID 会自动带上

      const onEvent = (raw: Event): void => {
        const event = JSON.parse((raw as MessageEvent<string>).data) as SessionEvent;
        eventsRef.current = mergeEvents(eventsRef.current, [event]);
        const highWater = snapshotSeqRef.current;
        // 只信**实时**提问事件：回放里的历史 question 早已被回答，不能重新弹窗。
        // 当前格式：seq > 快照高水位才是实时；无 seq 旧格式：只有空会话可直接信任
        //（有历史的旧会话由 refreshSnapshot 从 /state 取权威 pendingAsk）。
        const liveQuestion =
          highWater === undefined
            ? snapshotEmptyRef.current
            : event.seq !== undefined && event.seq > highWater;
        if (event.type === 'question' && liveQuestion) {
          const questions = (event.payload as { questions?: PendingAsk['questions'] }).questions;
          if (Array.isArray(questions)) {
            pendingAskRef.current = { sessionId, questions, askedAt: event.timestamp };
          }
        }
        if (highWater === undefined) {
          if (!snapshotEmptyRef.current) {
            void refreshSnapshot(); // 旧格式：快照仍是权威
            return;
          }
        } else {
          const lastSeq = eventsRef.current[eventsRef.current.length - 1]?.seq;
          if (lastSeq === undefined || lastSeq < highWater) return; // 回放尚未追上快照
        }
        reproject(); // 追上后：本地投影（与服务器 /state 同一实现）
      };
      for (const type of EVENT_TYPES) es.addEventListener(type, onEvent);
    })().catch(() => setConnected(false));

    return () => {
      disposedRef.current = true;
      es?.close();
    };
  }, [baseUrl, token, sessionId, reproject]);

  const answer = useCallback(
    async (answers: readonly AskAnswer[]) => {
      const response = await fetch(
        `${baseUrl}/api/sessions/${encodeURIComponent(sessionId)}/answers`,
        {
          method: 'POST',
          headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
          body: JSON.stringify({ answers }),
        },
      );
      if (!response.ok) throw new Error(`回答失败：HTTP ${String(response.status)}`);
      // /answers 已 resolve 内核里的 await；下一次 question 事件会重新置位。
      pendingAskRef.current = undefined;
      setState((prev) => (prev === undefined ? prev : { ...prev, pendingAsk: undefined }));
      if (eventsRef.current.length > 0) reproject();
    },
    [baseUrl, token, sessionId, reproject],
  );

  return { state, connected, answer };
}
```

渲染层直接吃 `WorkbenchState`（见 §2.5 类型表）——`messages` 按 `kind` 分支：
`message`（role 上色 + `reasoning` 折叠）、`tool`（`pending:true` → 转圈；`ok:false` → 红条 + `text`；
`files` → 附件 chip）、`notice`（回滚/提问提示）。

不限于 React——任何前端（Vue/Svelte/vanilla）都是同构用法：

```ts
import { mergeEvents, projectSession } from '@omniharness/kernel/workbench-view';

// history: storage 回放 / 本地已收事件；live: hub 缓冲或 SSE 增量
const view = projectSession(mergeEvents(history, live), pendingAsk);
```

### 2.4 浏览器用例 B：提问弹窗 / 侧边栏 / 审计页

**提问弹窗**——`state.pendingAsk` 非空即渲染：

```tsx
{state.pendingAsk && (
  <dialog open>
    {state.pendingAsk.questions.map((q) => (
      <fieldset key={q.id}>
        <legend>{q.header ?? q.question}</legend>
        {q.multiSelect ? <p>（可多选）</p> : null}
        {q.options === undefined ? (
          // 开放题：AskAnswer 的 custom 字段承载自由输入
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const text = String(new FormData(e.currentTarget).get('answer') ?? '');
              void answer([{ id: q.id, selected: [], custom: text }]);
            }}
          >
            <input name="answer" />
            <button type="submit">提交</button>
          </form>
        ) : (
          q.options.map((o) => (
            <button key={o.label} onClick={() => answer([{ id: q.id, selected: [o.label] }])}>
              {o.label}
            </button>
          ))
        )}
      </fieldset>
    ))}
  </dialog>
)}
```

语义：`POST /answers` resolve 内核里模型 `ask_user` 的 `await`（桥是同步语义：模型**停在原地等**，
不是轮询）；回答错位/重复 → 409；同一会话新提问会把旧 pending 以空回答放行（不静默吞）。
`AskAnswer = {id, selected: string[], custom?}`——`id` 必须回显问题 id，`custom` 用于自由输入。

**侧边栏**——`GET /api/sessions`：

```ts
const { sessions } = await (await fetch(`${base}/api/sessions`, { headers: auth })).json();
// sessions: [{sessionId, source:'live'|'discovered', eventCount?, lastSeq?, startedAt?}]
// source:'discovered' 的条目来自宿主传入的 discoverSessions 钩子（进程启动前的历史）。
```

**审计页**——`POST /api/audit/verify`（M5 复核语义）：

```ts
const verdict = await (await fetch(`${base}/api/audit/verify`, {
  method: 'POST',
  headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
  body: JSON.stringify({ pack, trustStore }),   // trustStore: { "<kid>": "<SPKI PEM>" }，可选
})).json();
// verdict.ok              结构完整（seq 连续 / 前驱哈希 / JCS 规范形态 / 验签无失败）
// verdict.receiptCount    包内回执数
// verdict.compliant       合规档 = 无任何问题 + 全链 + 全部锚定 + 签名全部被检查且有效
// verdict.signatureChecked 包级：是否每条都真的验了签（无信任根恒 false）
// verdict.problems        [{code:'CHAIN_BREAK'|'SEQ_GAP'|'NOT_CANONICAL'|'SIGNATURE_INVALID'
//                          |'UNPROVEN_ORIGIN'|'NOT_ANCHORED'|'ANCHOR_MISMATCH', seq, detail}]
//                          （'PAYLOAD_HASH_MISMATCH' 是契约保留码，当前实现不产出）
// verdict.verdicts        逐条：{seq, receiptId, chainOk, signatureChecked, signatureValid, anchored, unproven[]}
```

诚实语义（UI 文案据此）：`signatureChecked:false` = **没查**（无信任根），不是「未签名」；
`anchored:false` = 不满足合规档，是**真包但不合规**。

### 2.5 类型参考（`WorkbenchState` 全字段）

```ts
// 两个纯函数（浏览器安全子路径的完整入口）
function projectSession(
  events: readonly SessionEvent[],
  pendingAsk?: PendingAsk | undefined,   // live 挂起提问；不传 = 不显示提问态
): WorkbenchState;
function mergeEvents(
  history: readonly SessionEvent[],      // 按事件序
  live: readonly SessionEvent[],         // 按事件序
): readonly SessionEvent[];              // 按 id 去重，history 在前

interface WorkbenchState {
  readonly sessionId: string;            // 无事件时为 ''（未知会话的空投影）
  readonly startedAt?: string | undefined;   // 首事件时间戳
  readonly lastSeq?: number | undefined;     // 高水位（续传起点；旧存档无 seq 时缺省）
  readonly messages: readonly WorkbenchMessage[];  // 按事件序
  readonly todos: readonly { content: string; status: string }[];  // 最新 todo 快照
  readonly plan: unknown;                // 最新 plan 事件 payload（缺省 null）
  readonly usage: readonly unknown[];    // model 事件原始 payload（汇总口径由 UI 定）
  readonly turnDiffs: readonly string[]; // 本回合 unified diff
  readonly pendingAsk?: PendingAsk | undefined;
}
interface WorkbenchMessage {
  readonly seq: number | undefined;      // 旧存档事件无 seq
  readonly kind: 'message' | 'tool' | 'notice';
  readonly role?: 'user' | 'assistant' | 'system';   // kind=message
  readonly toolName?: string;            // kind=tool（由 tool_call 配对）
  readonly callId?: string;
  readonly ok?: boolean;
  readonly pending?: boolean;            // kind=tool：true=已发起、结果未回
  readonly files?: readonly string[];    // tool_result.files[].name
  readonly text?: string;                // kind=notice / 工具 error
  readonly content: string;              // 消息正文 / 工具 output
  readonly reasoning?: string;           // 紧邻 assistant 的 reasoning 事件
  readonly timestamp: string;
}

interface PendingAsk {
  readonly sessionId: string;
  readonly questions: readonly AskQuestion[];
  readonly askedAt: string;              // ISO 8601
}
interface AskQuestion {
  readonly id: string;                   // 答案按此 id 回显
  readonly question: string;
  readonly header?: string;
  readonly options?: readonly AskOption[];   // 缺省 = 开放题
  readonly multiSelect?: boolean;            // 缺省 false
}
interface AskOption { readonly label: string; readonly description?: string; }
interface AskAnswer {
  readonly id: string;
  readonly selected: readonly string[];  // 选中的 option.label
  readonly custom?: string;              // 自由输入
}
```

### 2.6 Node 端用例：程序化消费（非浏览器）

```ts
import { WorkbenchHub } from '@omniharness/kernel/workbench';

const hub = new WorkbenchHub();                 // 可传 { bufferLimit?: number; now?: () => string }
const unsubscribe = hub.subscribe(sessionId, (event) => {
  if (event.type === 'tool_result') console.log('工具结果到达', event.seq);
});
// hub 既是 EventPort 也是 UserResponder：
const answers = await hub.ask([{ id: 'q1', question: '继续？' }], { sessionId });
const accepted: boolean = hub.answer(sessionId, [{ id: 'q1', selected: ['是'] }]); // false = 无挂起提问
console.log(hub.pendingAsk(sessionId));   // PendingAsk | undefined（UI「等待输入」）
console.log(hub.eventsOf(sessionId));     // 内存直播缓冲（可能不含进程启动前的历史）
console.log(hub.sessionInfos());          // 会话注册表：[{sessionId,eventCount,lastSeq?,startedAt}]
unsubscribe();
// 同一会话再次 ask 会把旧 pending 以空回答放行（log.warn 'workbench.ask.superseded'）——
// 模型侧是串行等待，正常不会发生；发生了也如实放行，不静默吞。
```

---

## 3. 事件类型参考（`SessionEvent`）

会话事件是**模型所见事实源**（append-only JSONL，`seq` 单调）；工作台 SSE 的每条 `event:` 帧
就是一条完整 `SessionEvent`（`retry:` 与心跳注释帧不是事件）。

| `type` | payload 形状 | UI 呈现建议 |
| ------ | ------------ | ----------- |
| `user` | `{content, images?, files?, synthetic?}` | 用户消息气泡；`synthetic:true` = 内核注入的提示（不要当用户原话） |
| `assistant` | `{content, reasoning?, reasoningSignature?}` | 助手气泡；工具调用是**独立的 `tool_call` 事件**，不在 assistant payload 里 |
| `reasoning` | `{content}` | 折叠「思考过程」（`projectSession` 挂到紧随的 assistant；无后继时该条丢弃） |
| `tool_call` | `{callId, name, args, thoughtSignature?}` | 工具意图 chip（`args` 可能含敏感值，展示自行取舍） |
| `tool_result` | `{callId, ok, output?, error?, files?}` | 工具卡片（成功/失败/附件；`files[].name`） |
| `system` | `{content}` | 系统提示条（`OMNI_COMPACTION_V1` 前缀 = 内部记账，`projectSession` 已剔除） |
| `question` | `{questions: AskQuestion[]}` | 「模型在提问」痕迹；live 提问态以 `pendingAsk`/`/state` 为准 |
| `todo` | `{todos:[{content,status}]}` | 待办清单整幅刷新 |
| `plan` | 计划对象本身（整段 payload） | 计划面板整幅刷新 |
| `turn_diff` | `{diff}` | 「本回合改了什么」diff 视图 |
| `model` | `{usage, model?, context?}` | token/成本计量（`model` 是模型名，不是 `modelName`） |
| `rollback` | `{callId, ok, note}` | 回滚墓碑提示（M6：回滚不再抹掉自己的痕迹） |
| `session_meta` | `{workspace, model?, manifest?}` | 会话元信息（不进模型上下文；仅新会话首条） |

事件信封（所有类型共用）：`{id, type, sessionId, timestamp, seq?, payload}`——`seq` 由
`SessionRecorder` 单调编号，旧存档可能没有；SSE 的 `id:` 就是它。`payload` 为 `unknown`，
上表是各 `type` 的**实际**形状（以 `src/kernel/core/eventFactory.ts` 为准）。

---

## 4. 内核嵌入 API

### 4.1 `ConfigFactory.build` 常用字段

| 字段 | 类型 | 缺省语义（fail-closed 口径） |
| ---- | ---- | -------------------------- |
| `workspaceRoot` | `string` | **必填**；工具工作区/沙箱白名单根 |
| `model` | `ModelPort` | **类型必填**；运行时若给 `modelRouter` 则由路由替换（见 §4.2） |
| `storage` | `StoragePort` | **必填**；事件持久化（`MemoryStorage` / `JsonlStorage` / 自实现） |
| `events` | `EventPort` | 缺省 `ConsoleEventPort`；工作台接 `wb.hub`，也可包 OTLP |
| `approvals` | `ApprovalPort` | **不注入 = `DenyApproval` 全拒绝**（0.1.0-alpha.5 起的 BLOCKER 修复）；放行须显式 `AutoApproval` |
| `sandbox` | `SandboxPort` | **不注入 = 探测 OS 级隔离**（Landlock / Windows 原生写隔离）；探测不到落 `PolicySandbox`（黑名单）+ 显式告警；`OMNI_SANDBOX_STRICT=1` 时探测失败即拒绝启动 |
| `tools` | `ToolPort` | 不注入 = 内置工具注册表（shell / 文件读写编辑 / 搜索 / 网页 / 待办 / 计划 / 提问 / 子代理 / 检查点 / 回滚等）；**注入即整体替换**（默认注册表不再可用） |
| `extraTools` | `readonly ExtraTool[]` | **只在未注入 `tools` 时**追加到内置注册表；一旦注入 `tools`，`extraTools` 被忽略（要保留内置 + 加工具，请用默认注册表 + `extraTools`） |
| `userResponder` | `UserResponder` | `ask_user` 的回答端（TTY 用 Console，否则 Default；工作台注入 `wb.hub`） |
| `maxSteps` | `number` | 单任务步数上限（`0` = 不限，慎重）；类型必填，`ConfigFactory` 侧缺省落 0 |
| `compactionMaxTokens` / `compactionKeepRecent` | `number` | 压缩阈值 / 保留最近消息数（压缩是**确定性重建**，零模型调用） |
| `plan` / `planMode` | `PlanPort` / `boolean` | 计划态只读门禁（`planMode:true` 时未批准计划前写类工具被拦） |
| `todo` | `TodoPort` | 待办状态源（不注入用内存实现） |
| `modelRouter` | `ModelRouterConfig` | 按策略在多个模型间路由；给了它则替换 `model`（见 §4.2） |

### 4.2 自定义 `ModelPort`（接任意厂商）

```ts
import type { ModelPort, ModelRequest, ModelOutput } from '@omniharness/kernel';

// 你的厂商适配（示例留声明，换成本地实现即可）
declare function myHttpCall(request: ModelRequest): Promise<ModelOutput>;

const myModel: ModelPort = {
  name: 'my-model',
  async generate(request: ModelRequest): Promise<ModelOutput> {
    // request.messages: ModelMessage[]（role/content/toolCalls/toolCallId/reasoningContent…）
    // request.tools: ModelToolSpec[]（name/description/parameters；要调工具就返回 toolCalls）
    // 可选透传：request.role / temperature / maxOutputTokens / responseFormat / reasoningEffort / signal
    // 返回 {text} 或 {toolCalls:[{id,name,arguments}]}（可并存）；主循环自动续跑
    return myHttpCall(request);
  },
  // stream? 可选：不实现则内核直接等 generate 的完整输出
};
```

`ModelPort` 必填 `name` + `generate`；`stream?` 可选。`ModelOutput` 可带 `text` / `toolCalls` /
`reasoning` / `reasoningSignature` / `usage` / `finishReason`（`usage` 缺失就不计量，绝不臆造；
`finishReason='length'` 会被当成截断而不是完成）。

要点：`assistant` 消息的 `toolCalls` 与 `tool` 消息的 `toolCallId` 必须按 OpenAI 多轮格式配对
（内核保证投影合法，见 §3）；采样/上限经 `request.temperature` / `maxOutputTokens` / `role` 透传。

### 4.3 自定义 `ToolPort`

```ts
import type { ToolContext, ToolPort, ToolCall, ToolResult } from '@omniharness/kernel';

const myTools: ToolPort = {
  name: 'my-tools',
  list: () => [{ name: 'deploy', description: '…',
                 parameters: { type: 'object', properties: { env: { type: 'string' } }, required: ['env'] } }],
  execute: async (call: ToolCall, context: ToolContext): Promise<ToolResult> => {
    try {
      const output = await deploy(call.arguments, context.workspaceRoot);
      return { callId: call.id, ok: true, output: JSON.stringify(output) };
    } catch (e) {
      // 失败也要回结果（配对不变量：每个 tool_call 必须有 tool_result）
      return { callId: call.id, ok: false, error: String(e) };
    }
  },
};
// ConfigFactory.build({ tools: myTools, ... })
```

`ToolContext` 提供 `sessionId` / `workspaceRoot` / 可选 `signal`（取消下传）。门禁自动生效：
审批（`gate`）→ 沙箱 → pre/post 钩子 → 执行 → 结果记录（按模型调用序落盘）。

### 4.4 缺省语义速查（fail-closed 的真实含义）

| 项 | 不注入时 |
| -- | -------- |
| 审批 | `DenyApproval`——一切变更类工具被拒（负例：`agentGateContract` m6-approval-default-deny） |
| 沙箱 | 探测 OS 隔离 → 无则 `PolicySandbox`（黑名单，**非隔离**）+ warn；`OMNI_SANDBOX_STRICT=1` 拒绝启动 |
| 提权沙箱 | `PolicySandbox`（提权后仍拦危险命令） |
| 升级 | `DenyEscalation` |
| 用户回答 | TTY → Console；非 TTY → Default（占位回答） |

---

## 5. 回执与审计 API（`@omniharness/kernel/receipts` + 顶层）

### 5.1 签发回执链

```ts
import { createHash } from 'node:crypto';
import { ReceiptChain, JoseReceiptSigner, Rfc3161Anchor } from '@omniharness/kernel/receipts';

const sha256 = (text: string): string =>
  createHash('sha256').update(text, 'utf8').digest('hex');
const sessionId = 'sess-1';
const argsJson = JSON.stringify({ path: 'a.txt', content: '…' });

const signer = await JoseReceiptSigner.create({ kid: 'k1' });      // 或注入 privateKey
const trustStore = { k1: signer.publicSpki() };                     // 交给复核方（kid → SPKI PEM）

const chain = new ReceiptChain({
  issuerId: 'my-issuer',                                            // 单 issuer 单链
  signer,                                                           // 不注入 ⇒ signature:null（如实）
  anchor: new Rfc3161Anchor({ tsaUrl: 'https://your-tsa/stamp' }),  // 不注入/无网 ⇒ anchors:[]（如实）
});
await chain.append({ sessionId, action:
  { kind: 'tool_call', toolName: 'write_file', argsDigest: sha256(argsJson), ok: true } });
// payloadHash = SHA256(utf8(JCS(payload)))；previousReceiptHash 链式；创世 = 64 个 '0'
const pack = { issuerId: 'my-issuer', exportedAt: new Date().toISOString(), receipts: chain.export() };

// 尾条可信摘要（M10）：线性链自身无法检出尾条被改/被删（尾条没有后继绑定）。
// signSummary 用同一 signer 对 JCS(summary) 签名；随审计包一起发布给收证方。
const summary = await chain.signSummary();   // { summary: {issuerId, receiptCount, tailHash}, signature }
```

`ReceiptAction` 三形态：`tool_call{toolName,argsDigest,ok}` / `model_call{model,promptDigest,ok}` /
`checkpoint{label,eventCount}`——**摘要入链、正文不入**（参数可能含敏感值）。

### 5.2 离线复核（第三方，零出网）

```ts
import { verifyAuditPack, payloadHashOf } from '@omniharness/kernel/receipts';
const verdict = verifyAuditPack(pack, trustStore);

// 尾条绑定（可选第三参）：把「应有几条 + 尾哈希」从带外可信通道钉进来。
// 线性链里尾条没有后继来绑定它，只验链会被「改尾条 / 删尾条」骗过（ok:true）。
const signed = await chain.signSummary();
const pinned = verifyAuditPack(pack, trustStore, signed);
// pinned.ok === false 且 problems 含 EXPECTED_MISMATCH ⇒ 条数/尾哈希与签发方摘要不符；
// 含 SIGNATURE_INVALID ⇒ 摘要本身被改或签名不匹配；无信任根 ⇒ UNPROVEN_ORIGIN（没查≠通过）。
// 或完全不信任本仓代码：node scripts/verifyReceipts.mjs pack.json trust.json
// （独立实现的 JCS/SHA-256——「第三方能否复核」的可行性证明）
```

检出保证（变异判据自证）：改**非末条** payload → 后继 `CHAIN_BREAK`；删首条 → `SEQ_GAP+CHAIN_BREAK`；
换锚 → `ANCHOR_MISMATCH`（令牌必须内嵌本回执哈希）；重排 → `SEQ_GAP`。
边界要如实说：单条包（或末条）的 payload 被改时没有后继可断，结构仍自洽——有信任根时靠
`SIGNATURE_INVALID`、有锚时靠 `ANCHOR_MISMATCH`、**或给出第三参可信摘要**时靠
`EXPECTED_MISMATCH` 检出；三者都没有就是真的看不见，`signatureChecked:false`，不能把
「没查」读成「没问题」。
无信任根且有签名 → `UNPROVEN_ORIGIN` + `signatureChecked:false`；`signature:null` 则不在
`problems` 里伪造来源问题（`unproven[]` 会写 `signature:null`）。
字段映射与未实现项：[RECEIPTS.md](RECEIPTS.md)。

### 5.3 出处出证（`@omniharness/kernel/governance`）

```ts
import { ProvenanceIssuer } from '@omniharness/kernel/governance';

// ledger 由宿主提供（实现 PromotionLedgerPort：snapshotBefore/append/rollback/verify/list）
const cert = new ProvenanceIssuer(ledger).build({
  packName: 'my-pack',
  issuedAt: '2026-11-04T00:00:00.000Z',
  assets: [{ name: 'my-skill' }],   // 可选 failureSignature: 'twist:a+b'
  // identity 可选：{ publicKeySsh: () => string; sign: (payload: string) => string }
});

const check = ProvenanceIssuer.verify(cert, { trustedPublicKeys: [] }); // 收证方独立复核，不访问签发方
// 本例未注入 identity ⇒ 证书未签名（check.signatureChecked=false）；
// 若注入了 identity 但 trustedPublicKeys 为空 ⇒ 有签名但**没查**，同样 false——
// 两种情况都不能读成“验证通过”。
// 证伪点：改任一证据条目 → hash-mismatch / chain-link-broken；删首条 → anchor-mismatch；
// chain.verified=false 的证书直接不合格（ok:false），不会因为“内容是历史事实”而放行。
```

### 5.4 遥测链与晋升台账（同为 `@omniharness/kernel/governance`）

README 的「哈希链化遥测 / 晋升台账可复核」在 M9 接通公开路径：

```ts
import {
  JsonlRuntimeTelemetry, PromotionHistoryService, HashChainPromotionLedger,
} from '@omniharness/kernel/governance';

// 运行遥测：append-only JSONL + SHA256(prev ‖ canonical)，构造时从文件末尾续链。
const telemetry = new JsonlRuntimeTelemetry({ dir: '/var/lib/omni/telemetry' });
telemetry.record({
  id: 'obs-1', kind: 'selfcheck', operator: 'suite',
  configSnapshot: { maxSteps: 20 }, metrics: { latencyMs: 3 },
  verdict: 'pass', provenance: 'production',
});
telemetry.verify();          // { ok: true, count: 1 }；改任一行 ⇒ ok:false + brokenAt

// 晋升台账 + 治理台数据面：逐行独立重算（不抄台账自己的整链结论）。
const ledger = new HashChainPromotionLedger({ dir: '/var/lib/omni/ledger' });
ledger.snapshotBefore([{ name: 'skill-a', description: '…', instructions: '…' }]);
ledger.append({ name: 'skill-b', source: 'twist:a' });
const view = new PromotionHistoryService(ledger, (entry) => HashChainPromotionLedger.hashOf(entry)).view();
// view.rows[].verified：该行自算哈希 + prev 接链；view.rollbackTargets：可回滚快照锚点
```

### 5.5 执行证书（proof-carrying execution，`@omniharness/kernel/receipts`）

把「一次运行的事件流」变成离线可复核的证明：Merkle 根绑定内容/顺序/条数，可选绑定回执链尾，签名后可凭信任根验签；单条事件可生成包含证明。

```ts
import {
  buildExecutionCertificate, signExecutionCertificate, verifyExecutionCertificate,
  proveEventInclusion, verifyEventInclusion,
} from '@omniharness/kernel/receipts';

const cert = buildExecutionCertificate({
  events,                                   // SessionEvent[]（同一会话）
  receipt: {                                // 可选：与回执链尾绑定
    issuerId: chain.summary().issuerId,
    receiptCount: chain.summary().receiptCount,
    tailHash: chain.summary().tailHash,
  },
  tools: runtime.tools.list(),              // 可选：绑定工具面
});
const signed = await signExecutionCertificate(cert, signer);

const verdict = verifyExecutionCertificate(events, signed, {
  trustStore,                               // 无信任根 ⇒ UNPROVEN_ORIGIN（没查≠通过）
  receipt: { issuerId, receiptCount, tailHash },
});
// 篡改/删改/换序 ⇒ EVENT_ROOT_MISMATCH / EVENT_COUNT_MISMATCH；
// 证书被改 ⇒ SIGNATURE_INVALID；事件流与回执链不同源 ⇒ RECEIPT_BINDING_MISMATCH。

// 单条事件溯源（不必交出整份日志）
const proof = proveEventInclusion(events, 42);
verifyEventInclusion(cert, events[42], proof); // true
```

开销（10k 事件实测）：建树/证书约 0.8–0.9 s（一次性，宿主显式导出时付），单条验证 ~0.5 ms。
研究底稿：[RESEARCH-2026-11B.md](RESEARCH-2026-11B.md)。

### 5.6 执行图谱系（多运行 / 子代理，`@omniharness/kernel/receipts`）

把多次运行（父会话 + 子代理/工作流）组织成一张**可验证的树**：节点是执行证书，边是父事件流里真实存在的委派事件。

```ts
import { buildExecutionGraph, signExecutionGraph, verifyExecutionGraph } from '@omniharness/kernel/receipts';

const graph = buildExecutionGraph({
  runs: [{ events: parentEvents }, { events: childEvents }],
  edges: [{
    parentSessionId: 'root',
    childSessionId: 'child',
    delegationEventHash: eventLeafHash(delegationEvent), // 锚定到父事件
  }],
});
const signedGraph = await signExecutionGraph(graph, signer);
const verdict = verifyExecutionGraph(signedGraph, [
  { events: parentEvents }, { events: childEvents },
], { trustStore });
// 结构要求：单根、无环、每个子节点恰一个父；委派哈希未命中 ⇒ DELEGATION_MISMATCH。
```

### 5.7 审计包（单文件离线交付，`@omniharness/kernel/receipts`）

把「事件流 + 执行证书 + 回执链 + 执行图」打成一个可交付的 JSON，第三方一次复核：

```ts
import { buildAuditBundle, signAuditBundle, verifyAuditBundle, auditBundleDigest } from '@omniharness/kernel/receipts';

const bundle = buildAuditBundle({
  runs: [
    { events: rootEvents, receipts: rootChain.export() },
    { events: childEvents, receipts: childChain.export() },
  ],
  graph,                                  // 可选：M15 执行图
  exportedAt: '2026-11-06T00:00:00.000Z',
});
const signed = await signAuditBundle(bundle, signer);   // 可选：整包签名
const verdict = verifyAuditBundle(signed, { trustStore }); // 事件证书/回执链/图/签名一次跑完
auditBundleDigest(bundle);                                // 供外部公告/锚定

// 命令行离线复核（零出网）
// node scripts/verifyBundle.mjs bundle.json trust.json
```

### 5.8 选择性披露包（最小披露仍可验，`@omniharness/kernel/receipts`）

只交子集事件仍可离线复核——M14 的包含证明从证书内部升格为交付语义：

```ts
import {
  buildDisclosurePack, signDisclosurePack, verifyDisclosurePack,
  disclosurePackDigest,
} from '@omniharness/kernel/receipts';

const pack = buildDisclosurePack({
  runs: [
    // events 是全量流（只做证明源，不整体出包）；indices 指要披露的下标（0 起）。
    { events: sessionEvents, indices: [0, 4], certificate }, // 证书缺省按流重建
  ],
  receipts: issuerChain.export(),     // 全局链；按证书绑定裁剪为必需前缀
  exportedAt: '2026-11-06T00:00:00.000Z',
});
const signed = await signDisclosurePack(pack, signer);
const verdict = verifyDisclosurePack(signed, { trustStore });
disclosurePackDigest(pack);           // 供外部公告/锚定
```

复核层序：形状 → 证书自洽 → 逐条包含证明（叶子重算 + 根/条数比对）→ 回执前缀链 →
绑定比对 → 整包签名。问题码：`PROOF_INVALID` / `RECEIPT_BINDING_MISMATCH` /
`RECEIPTS_INVALID` / `SIGNATURE_INVALID` / `UNPROVEN_ORIGIN` 等。绑定存在而包内无
前缀 ⇒ 红（悬空承诺不成立）。

### 5.9 运行时导出审计包（一次接入闭环）

`createOmniKernel` 的宿主不需要手工拼 events/certificates/receipts：

```ts
const exported = await kernel.exportAuditBundle([result.sessionId]);
// exported.directory / bundlePath / trustPath / digestPath / digest / signed
// 产物：bundle.json（已签名审计包）、trust.json、digest.txt（JCS SHA-256）
```

- 证书绑定的是**全局回执链当前尾**（issuer 单链跨会话共享）；复核按证书里的 `receiptCount`
  在全局链里取第 count 条比对 `tailHash`，不按会话过滤回执。
- 多会话一起导出时，每个会话的证书各自锚定签发时的链尾前缀，全部由同一份全局链复核。
- 第三方：`node scripts/verifyBundle.mjs <directory>/bundle.json <directory>/trust.json`。

---

## 6. 其他子路径速览

| 子路径 | 关键 API | 用例位置 |
| ------ | -------- | -------- |
| `embed` | `OmniKernel` / `OmniKernelInput` / 各句柄类型（顶层 `createOmniKernel` 的类型面）——主循环 / 工作台 / 回执 / MCP 客户端一次装配；`kernel.capabilities()` 能力清单；`close()` 幂等收尾 | `examples/embed.mjs`、`tests/contract/embedOneCall.test.ts` |
| `sandbox` | `SandboxCapabilityTable.describe(root)`（本机探测表）；`LinuxLandlockSandbox` / `WindowsNativeSandbox` / `ContainerSandbox` / `RestrictedSandbox`…；`IsolationLadder` + `BuiltinWasmRunner`（四档信任-隔离阶梯） | `tests/unit/isolationLadder.test.ts`、`tests/contract/sandboxSubpathWiring.test.ts`、能力表逐条 `real/basis/actionable` |
| `governance` | `ProvenanceIssuer`；`JsonlRuntimeTelemetry`；`PromotionHistoryService` + `HashChainPromotionLedger` | `examples/audit-pack.mjs`、`tests/contract/governanceWiring.test.ts` |
| `mcp` | `McpHttpAssembly.create(runtime, {workspaceRoot, http, inputRequired?})`——外部 MCP 调用与本地同过审批/沙箱门禁；`inputRequired` 注入 `McpCompositeInputHandler([McpAskUserInputHandler, McpApprovalInputHandler])` 后启用 MRTR 往返（缺省不产生 `input_required`）；`startMcpServers(runtime)` 按 `config.mcpServers` 连接远端 MCP 服务器并把工具注册进工具面（`auth` 生效，`close()` 反注册）；`McpServeRunner` 为 stdio serve 入口 | `tests/contract/mcpServeWiring.test.ts`、`mcpMrtrWiring.test.ts`、`mcpServersWiring.test.ts` |
| `tools` | `ShellTool` / `ReadFileTool` / `WriteFileTool` / `EditFileTool` / `GlobTool` / `GrepTool` | `tests/unit/workspaceFileCoordinator.test.ts` |

---

## 7. 错误与状态码总表（工作台服务器）

| 状态 | 场景 |
| ---- | ---- |
| 200 | 成功 |
| 204 | 预检通过 |
| 400 | body 非法 JSON / 形状不对 |
| 401 | `/api/*` 缺/错令牌（Bearer / `?token=` / cookie 三选一）；或 `Origin` 不在回环白名单 |
| 404 | 未知路径 |
| 405 | 路径命中但方法不对 |
| 409 | 回答了一个不存在的挂起提问（防重放） |
| 413 | body > 1 MiB（1,048,576 字节） |
| 500 | 未预期错误（响应 `{error}`；5xx 会写 warn 日志） |

启动期错误（fail-closed，直接抛）：非回环绑定无令牌（`ServerAuthGuard.assertBindSafe`）；
strict 沙箱探测失败；`ReceiptChain` 空 issuerId。

---

## 8. 版本与兼容性

- **顶层 60 符号**由 `scripts/api-golden.json` 锁定：任何增删/改名都会让 `npm run verify` 变红，
  必须显式 `--update-golden` 并记 CHANGELOG；
- **子路径不承诺兼容**（`embed`/`workbench`/`receipts`/`sandbox`/`governance`/`mcp`/`tools`/`workbench-view`
  及 `dist/*` 直取）；依赖内部路径的调用方请在 M2 迁移桥口径下自担；
- `workbench-view` 的“浏览器安全”有**双重机检**：`tests/unit/workbenchViewPurity.test.ts` 检查源码
  运行时 re-export 图，`npm run view:check` 检查 build 后的 `dist/workbench-view.js` 图（零 `node:`、
  零服务端模块）并真实加载调用；`npm run verify` 两者都跑；
- 行为级破坏性变更（如缺省审批/沙箱语义）在 [CHANGELOG.md](../CHANGELOG.md) 的 BREAKING 小节逐条列出；
- 成熟度元数据机检：`maturity:check`（L1+ 必带证据；无法验证的主张降级 `L0-unverified` 并注明恢复路径）。
