# Changelog

## 0.1.0-alpha.7 — 2026-11-07

> 自 v0.1.0-alpha.6 tag（f362434）以来的全部工作：M8 效率收口 → M9 硬化 → M10 缺口补完 →
> M11 一次接入 → M12–M17 审计闭环 → M18 选择性披露。含 BREAKING：顶层 `AgentFactory`
> 符号位让给 `createOmniKernel`（M11）。判据与复盘见 [ROADMAP.md](docs/ROADMAP.md)。

### Fixed（测试仪器：tamper 判据去随机化，2026-11-07）

- `m11-embed-receipts-persist-tamper` 原以「改签名尾两字符为 AA」制造篡改，但 Ed25519 的
  S 分量已模 L ⇒ 签名末字节高 4 bit 恒为 0 ⇒ base64url 尾两字符以 ~1/16 概率恰为 'AA'，
  篡改退化为空转（存档原样通过复核，fail-closed 判据假警报、verify 间歇红）。改为改首
  字符（完整 6 bit，必然改变解码字节）；内核检出能力经探测实证无损（113/113 真篡改
  全部被拒）。

### Changed（形状守卫收敛为声明式 schema，2026-11-07）

- 新增内部件 `src/kernel/util/shapeGuard.ts`：极小组合子集（`objectOf` / `arrayOf` /
  `literal` / `matching` / `optional` / `nullable` / 叶子判定），校验策略表达为**数据**；
- 审计链五处手写形状守卫（auditPack 回执信封 / auditBundle / disclosurePack /
  executionCertificate / executionGraph）全部迁移为 schema 声明——检查语义全仓一个
  执行点，读 schema 如读类型；行为不变（判定语义由既有契约判据钉死），组合子直接
  用例见 `tests/unit/shapeGuard.test.ts`。

### Added（选择性披露：最小披露仍可验，M18，2026-11-07）

- **`buildDisclosurePack` / `signDisclosurePack` / `verifyDisclosurePack` /
  `disclosurePackDigest`**（`@omniharness/kernel/receipts`）：只交子集事件仍可离线
  复核的最小披露交付物——每条披露事件附 M14 包含证明锚回证书 Merkle 根，未选事件
  不出包，回执链裁剪到证书绑定的必需前缀（第 1 条到最大绑定条数）。
- **`kernel.exportDisclosurePack([{sessionId, indices}], directory?)`**：一次接入路径
  同步开放，落盘 `disclosure.json + trust.json + digest.txt`；CLI
  `scripts/verifyBundle.mjs` 按包内 `kind` 自动识别审计包/披露包。
- 判据：`tests/contract/disclosurePack.test.ts`（6 例：roundtrip / 最小化 / 篡改矩阵
  7 项 / 回执前缀 / 签名语义 / 叶子不变式）+ embed 内核级 1 例 +
  `tests/property/disclosurePack.property.test.ts`（2 条属性）；ROADMAP
  `m18-selective-disclosure`。

### Added（审计包运行时闭环，M17，2026-11-06）

- **`kernel.exportAuditBundle(sessionIds, directory?)`**：逐会话取事件、签发执行证书
  （绑定全局回执链当前尾）、打包、整包签名，落盘 `bundle.json + trust.json + digest.txt`；
  返回 `{directory,bundlePath,trustPath,digestPath,digest,signed}`。
- **链作用域修正**：回执链是 issuer 单链跨会话共享；证书绑定「签发时链尾前缀」，
  复核在全局链按 `receiptCount` 取第 count 条比对 `tailHash`，不再按会话过滤回执
  （过滤会破坏 `previousReceiptHash` 连续性）。
- 判据：embed 契约单会话 + 多会话同 issuer 链两例；`verifyAuditBundle` 复核通过；
  `m17-runtime-audit-bundle`。

### Added（审计包：单文件离线交付，M16，2026-11-06）

- **`buildAuditBundle` / `verifyAuditBundle` / `signAuditBundle` / `auditBundleDigest`**
  （`@omniharness/kernel/receipts`）：把「事件流 + 执行证书 + 回执链 + 执行图」打成一个
  可交付 JSON，一次复核四层——事件完整性/顺序/条数、回执链尾绑定（含验签）、执行图
  （节点/委派锚定/单根无环）、整包签名；逐层问题码可读。
- **离线 CLI**：`node scripts/verifyBundle.mjs bundle.json trust.json`（零出网；
  0=通过 / 1=复核失败 / 2=输入非法）。
- 判据：`tests/contract/auditBundle.test.ts`（4 例：roundtrip / 事件篡改 / 回执篡改+重复会话 /
  图缺失 / 签名伪造）；研究底稿 §9；ROADMAP `m16-audit-bundle`。

### Added（执行图谱系：多智能体可验证，M15，2026-11-06）

- **`ExecutionGraph`**（`@omniharness/kernel/receipts`）：节点 = 每次运行的执行证书，
  边 = 父会话在哪个事件里委派了子会话（可锚定 `delegationEventHash`）；整图签名。
- 离线复核 `verifyExecutionGraph`：逐节点重算证书、逐边锚定父事件（哈希 + 子会话 id）、
  结构单根/无环/单父（Kahn）、图签名（无信任根如实标 `UNPROVEN_ORIGIN`）。
  多父 / 环 / 多根 / 委派哈希错位分别返回可读问题码。
- 判据：`tests/contract/executionGraph.test.ts`（4 例）+ 属性
  `tests/property/executionGraph.property.test.ts`（随机树/删边/加环/改事件）；
  研究底稿 [RESEARCH-2026-11B.md](docs/RESEARCH-2026-11B.md) §8；ROADMAP `m15-execution-graph`。

### Added（执行证书：运行级可复核，M14，2026-11-06）

- **事件 Merkle 树**（`@omniharness/kernel/receipts`）：JCS 规范化叶子 + 域分离哈希 +
  奇数上提（不做末项复制，避免 `eventCount` 歧义）；`proveEventInclusion` /
  `verifyInclusion` 支持**单事件溯源**（无需交出整份日志）。
- **执行证书** `buildExecutionCertificate` / `signExecutionCertificate` /
  `verifyExecutionCertificate`：绑定 `{sessionId, eventCount, eventRoot}`，可选绑定
  回执链尾 `{issuerId, receiptCount, tailHash}` 与工具面摘要；签名对 `JCS(cert)`，
  收证方凭信任根离线验签。篡改/删改/换序/跨会话/换回执尾分别返回可读问题码。
- **研究底稿** [docs/RESEARCH-2026-11B.md](docs/RESEARCH-2026-11B.md)：问题、构造、
  安全论证、10k 事件实测（建树/证书约 0.8–0.9 s，单条验证 ~0.5 ms）、明确未做
  （witness 网络 / 公共透明日志 / 零知识选择性披露）。
- 判据：`tests/contract/executionCertificate.test.ts`（5 例）+ 属性
  `tests/property/merkleCertificate.property.test.ts`（5 属性）；ROADMAP `m14-execution-certificate`。

### Added（数学覆盖二期：调度 / 估算 / 覆盖率 / 回执并发，M13，2026-11-06）

- 属性测试从 5 文件 / 20 属性扩到 **9 文件 / 32 属性**（零第三方依赖、固定 seed、失败按
  `seed+trial` 复现）：
  - `fairScheduler`：等权会话服务量差额 ≤2、并发 ≤ limit、统计自洽、排队取消不占调度；
  - `tokenEstimator`：追加字符单调不减、消息列表 = 逐条之和、消息开销恒定、缓存不改变结果；
  - `rewardCoverage`：samples/verified/coverage 自洽、轮次差分可加、探针异常归不可验证；
  - `receiptsConcurrency`：异步 signer 下任意 N 并发 seq 连续/前驱成链，任意时刻摘要 = 链尾。
- [docs/MATH.md](docs/MATH.md) 覆盖矩阵同步（新增 4 行）；SFQ 从「示例级判据」升级为属性判据，
  仍不声称 regret/偏差界的证明。

### Added（架构图谱 + 数学不变量，M12，2026-11-06）

- **架构机检**：`npm run arch:check`（`scripts/archCheck.mjs`）——运行时依赖图 Tarjan SCC
  无环（`import type` 不计）、跨层边规则（contracts 叶子 / protocols 单一支撑面 /
  kernel→protocols 仅 `adapters/mcp` 与 `composition`）、[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)
  依赖快照与代码一致（`npm run arch:update` 重新生成）；已并入 `npm run verify`。
- **契约层收口**：`OmniError`/`ErrorCode` 与 `API_VERSION` 迁到 `contracts/`，根
  `src/omniError.ts` / `src/version.ts` 保留兼容再导出——消除 `contracts → 根入口`
  回指（运行时边），依赖图上的契约层成为真正叶子。
- **数学不变量**：新增零依赖确定性属性测试骨架 `tests/property/harness.ts`（mulberry32 +
  固定 seed + 失败定位到 seed/trial）；5 文件 / 20 属性覆盖 JCS（幂等/键序/良构/数字）、
  0/1 背包（与暴力枚举最优值对拍/可行性/确定性）、UCB1（冷启动/夹取/确定性/记账）、
  BM25（批量等价/词频单调/增量替换/排序）、哈希链与事件日志（确定性/前缀/水合/越界）。
- **诚实边界**：[docs/MATH.md](docs/MATH.md) 给出覆盖矩阵与三层口径（形式证明 / 属性测试 /
  示例判据），明确「属性测试不是证明」，并列出未覆盖项（形式化验证、regret 界、浮点误差界等）。
- 判据：ROADMAP `m12-arch-graph` / `m12-math-invariants`。

### Added（一次接入全部能力：顶层 `createOmniKernel`，2026-11-06）

- **`createOmniKernel(options)`**（顶层第 60 个符号；完整选项/句柄类型经
  `@omniharness/kernel/embed`）：把「宿主真正用起来」所需的胶水收进内核一次——主循环、内置
  工具/记忆/技能/计划/检索、工作台 HTTP/SSE、MCP 客户端（`config.mcpServers`）、MCP 服务端
  发布（`mcpServe`，缺省关）、长期运行遥测（`telemetry`，缺省关）、回执链（每次工具调用
  自动入链 + Ed25519 签名）一次装配；文件型存储还会自动扫描历史会话（工作台重启后侧边栏
  仍在）；宿主只留 6 行（`examples/embed.mjs`）。此前这些接线要每个宿主各写一遍
  （应用仓库的生成式对接面 + 122 文件 `kernel-compat` 的成因）。
- **BREAKING（顶层符号位交换）**：`AgentFactory` 移出顶层（下沉为内部件；`new Agent(runtime)`
  等价，且它从未被公开文档外的消费者使用），第 60 位让给 `createOmniKernel`；需要按运行时
  造 Agent 的调用方改用 `Agent` 构造器。`scripts/api-golden.json` 同批更新。
- **可核对的「全部能力」外形**：`kernel.capabilities()` 实时回答工具数 / 工作台地址 / 回执
  条数 / MCP 工具 / 审批 / 沙箱 / embedding / evolution / native / telemetry，不靠读代码猜。
- **安全默认不放宽**：模型缺省 `MockModel`（零凭据演示，且**不**读本机凭据）；审批缺省仍是
  `DenyApproval`、沙箱仍是 OS 隔离探测；工作台回环 `127.0.0.1:0`；MCP 未配置零连接。
- **生命周期收口**：`close()` 幂等，按「取消在跑回合 → 关 MCP → 落回执 → 冲刷事件 → 关工作台」
  顺序释放；`config` 透传任意 `OmniHarnessConfig` 字段，新增内核能力不需要同步改接入接口。
- **审计闭环（回执跨重启）**：`receipts.persist` 把回执链落到 `<workspace>/.omniharness/receipts/
  <issuerId>.jsonl`（append-only）并持久化 Ed25519 私钥（0600）；重启时 `ReceiptChain.adopt`
  逐条校验同 issuer / seq 连续 / 前驱相接后**续写不分叉**，启动即用 `verifyAuditPack` 复核既有链。
  坏行 / 断链 / 签名被改 / 有签名历史但密钥丢失 / 已签名链上 `sign:false` 一律 fail-closed。
  判据：`tests/contract/embedOneCall.test.ts` 的 `m11-embed-receipts-persist*`。
- **运行级执行证书接入**：`receipts.certificates` 在每个 `runTask/resume/fork` 结束后自动签发并
  落盘 `{certificate, signature}`（事件 Merkle 根 + 回执链尾 + 工具面摘要）；也可显式
  `kernel.certificate(sessionId)`。收证方用 `verifyExecutionCertificate(events, signed, {trustStore, receipt})`
  离线复核；改事件/删事件/换顺序/链尾不符均可检出。判据 `m11-embed-execution-certificate`。
- **审计三件套导出**：`kernel.receipts.exportBundle(dir?)` 一次写出 `pack.json` +
  `trust.json` +（有签名时）`summary.json`，第三方可直接用 `verifyAuditPack(pack, trust, summary)`
  或独立实现 `scripts/verifyReceipts.mjs` 离线复核；尾条被改/删由摘要的 `EXPECTED_MISMATCH` 检出。
  判据 `m11-embed-audit-bundle`。
- **单文件审计包接入（M16）**：`kernel.exportAuditBundle([sessionId])` 一次写出
  `bundle.json`（事件 + 执行证书 + 回执链，整包签名）+ `trust.json` + `digest.txt`；
  收证方用 `verifyAuditBundle(signed, {trustStore})` 或 `scripts/verifyBundle.mjs` 零出网复核；
  改事件/改回执/换证书/伪造签名全部 `ok:false`。判据 `m11-embed-full-audit-bundle`。
- 判据：`tests/contract/embedOneCall.test.ts`（工具回合 + 工作台投影 + 审计包真实验签 +
  MCP 客户端连接/反注册 + MCP 服务端健康与关端口 + 事件扇出 + 未签名语义 + config 透传 +
  非回环无令牌 fail-closed）；`m11-embed-minimal` 机检示例只经顶层、≤60 行、只调一次
  `createOmniKernel`；示例 `examples/embed.mjs`；文档 `docs/API.md` §1 / README 快速开始。

### Hardened（M10 缺口补完：取消传播 / 尾摘要签发 / mcpServers 装配，2026-11-06）

- **取消传播真正生效**：工具执行器与 `ToolContext.signal` 竞速（`StepToolExecutor.raceAbort`），
  用户停止不再等 60s 工具自然结束；`ToolScheduler` 穿透 `CancelledError`（不再吞成 failed
  ToolResult）；`ask_user` 等待期取消会清理 `WorkbenchHub` 挂起提问并释放会话锁；取消原因
  （`user`/`timeout`/`custom`）原样透传，不再折叠。
- **回执尾条可信摘要（签发侧）**：`ReceiptChain.summary()` 产出 `{issuerId, receiptCount, tailHash}`，
  `signSummary()` 用回执同一 signer 对 `JCS(summary)` 签名；`verifyAuditPack(pack, trustStore,
  signedSummary)` 验签并比对条数与尾哈希——尾条被改/被删由 `EXPECTED_MISMATCH` 检出，改摘要
  由 `SIGNATURE_INVALID` 检出；无 signer 时拒绝签发（不产出「看起来像承诺」的对象）。
- **`config.mcpServers` 真正装配**：字段进入 `OmniHarnessConfig`/`ResolvedConfig` 并由
  `ConfigFactory` 透传；新增 `startMcpServers(runtime)`（`@omniharness/kernel/mcp`），缺省用
  `SdkMcpConnector`（stdio / Streamable HTTP+SSE）逐台连接，经 `McpGateway` 把远端工具注册进
  工具面，`close()` 反注册；`auth` 的 bearer/oauth 令牌由 `McpAuthProvider` 真正变成
  `Authorization` 头（缺失即 fail-closed，不发匿名请求）。MCP 客户端栈因此从零入边转为可达。
- 判据：`tests/contract/cancellationPropagation.test.ts`、`receiptSummary.test.ts`、
  `mcpServersWiring.test.ts`、`tests/unit/mcpAuthProvider.test.ts`；ROADMAP M10 三条判据。

### Hardened（M9 硬化收口：接线审计 / 毛边 / 压力，2026-11-06）

- **接线审计有了机检**（`npm run wiring:check`，并入 verify 与 `plan:check`）：可达性图从
  「只从 `src/index.ts` 起算」改为**全部 8 个公开入口为根**——旧口径把 7 个子路径入口整棵判成
  死代码（127 文件 / 19,858 行），修正后为 42 文件 / 8,303 行；每个「src 内零入边且入口不可达」
  的模块必须在 [docs/WIRING.md](docs/WIRING.md) 逐条落账（接线/入口/内部保留/删除），
  文档引用的源码路径必须真实存在。
- **声明未接线修复**：README「哈希链化遥测 / 晋升台账可复核」的实现（`JsonlRuntimeTelemetry`、
  `PromotionHistoryService`、`HashChainPromotionLedger`）接进 `governance` 子路径；隔离阶梯
  `IsolationLadder` + 内置 wasm 执行器接进 `sandbox`；MRTR 三个 handler 接进 `mcp`，
  `McpHttpAssemblyOptions.inputRequired` 提供注入口（缺省关闭，显式接线才产生 `input_required`）。
- **毛边打磨（16 条回归判据）**：
  - 回执链 `append` 在异步 signer/anchor 下**并发分叉**（8 个并发全部拿到 seq 1）——队列队尾
    现在真正前移；此前 100 并发「零分叉」判据只测了同步路径，是假绿；
  - 工作台：非法 request-target 不再让进程因未处理拒绝退出（400）；`http.port` 真正生效
    （旧实现硬编码 `listen(0)`）；SSE 回放期重复投递去重 + **8 MiB 背压上限**（慢/挂起客户端
    不再无限占内存，超限断开由 EventSource 带 `Last-Event-ID` 续传）；`/answers` 校验回答 id
    与挂起问题精确匹配（错位/过期/重复 409，非法形状 400）；`decodeURIComponent`/null body/
    畸形审计包统一 400；`close()` 幂等；
  - `verifyAuditPack` 对畸形包 fail-closed（`MALFORMED_PACK`，不再抛裸 TypeError），并新增可选
    第三参 `{receiptCount, tailHash}`：线性链自身无法检出尾条被改/被删（没有后继绑定它），
    带外可信摘要给出时以 `EXPECTED_MISMATCH` 检出；
  - `MemoryStorage.append` 桶缺失时不再静默丢事件；`JCS` 孤立代理项按 `JSON.stringify` 转义
    （不再产出非法 UTF-8），非纯 JSON 对象（Date/Map/类实例）fail-closed；
  - MCP：CORS 预检免鉴权（浏览器 Bearer 客户端不再在预检阶段 401）、显式 `corsOrigin` 真正
    通过 Origin 防线；`McpServeRunner` 回退路径不再丢掉调用方的 `gate`（stdio 工具不再无审批）；
    `McpHttpAssembly` 使用 `runtime.gate`（计划态 / supervisor / RBAC 不再被外部调用绕过）；
  - 1,800+ 层嵌套工具参数不再让 `LoopGuard` 抛 RangeError 打崩整轮（深度上限 + 兜底）；
  - `sessionId` 空串与字面量 `_` 不再共用同一个存档文件，超长 id 报可行动错误。
- **压力/全面测试**：`tests/stress` 三文件 9 用例（20k 事件日志、40 会话 JSONL、350 回执链、
  20 并发 SSE、100 状态投影、1 MiB 请求体边界、200 步会话、8 并行工具、10 MiB 载荷），
  `npm run stress` 并入 `npm run verify`（独立 `vitest.stress.config.ts`，不拖慢 `npm test`）。
- **清账**：12 个零引用、零判据、注释指向已删模块（plugin / SDK / A2A / 应用层）的文件删除；
  `m4-zero-inbound` 改用「全部入口」口径。公开面不变（60/60）。

### Polished（M8 效率与内存收口：先测量后优化，2026-11-06）

- **仓内基准 harness**（`npm run bench`）：五探针 + 归因矩阵 + 冷热分离 + 内存滞留中位数采样，
  内核自身效率与内存从此可复现量化（此前历史性能结论全部引用仓外已删目录，不可复现）；
- **每步序列化短路三连**：前缀指纹 toolCalls 身份键缓存（**14.2×**）、工具 schema 序列化
  统一走 `schemaTextOf` 身份缓存（**137×**）、压缩游标引用相等短路（快路径零编码）——
  e2e 150 步会话热稳态 **1.08 → 0.74–0.86 ms/步（−20~−31%）**；
- **事件日志失效即重建快照**：`SessionRecorder.allEvents()`（每步 5+ 次全量读取扇出点）
  从每步 O(n) 浅拷贝改为 O(1) 引用返回（6000 事件稳态 **226×**）；快照冻结（fail-closed），
  `all()` 公开契约不变；
- **TokenEstimator 单例共享**：容量分解器与压缩器两套并行缓存栈合一，原生下沉单一事实源
  （内存收益≈噪声，如实记录；保留理由是消冗余与口径统一）；
- 调研底稿 [docs/RESEARCH-2026-11.md](docs/RESEARCH-2026-11.md)：静态分析与实测的偏差
  诚实记录——「4-6 份转录副本」被加固后的仪器证伪大半（真值 2.04×；首版 5.1× 是首跑
  混入语料索引的仪器污染）；冷索引 3.1s 一次性成本是全程最大单项，P3 五项按
  「实测过关才做」全部不做（理由逐条在案）。公开面不变（60/60），判据 `m8-*` 五条入账。

## 0.1.0-alpha.6 — 2026-11-04

> v0.1.0-alpha.6 tag（f362434）交付内容：M0–M6 + M4 + 对接参考文档。2026-11-05 起被应用
> vendored 钉版；2026-11-06 之后的增量（M8–M18）记入上方 alpha.7。

### Polished（工作台桥接层上线加固，同日第二遍打磨）

- `close()` 在有活跃 SSE 时**挂死**（node:http 的 close 等连接）→ 追踪并优雅结束全部活跃流；
- 跨端口浏览器 UI 需要 CORS → 回环回显默认（同 MCP 端口径）+ `corsOrigin` 收紧 + OPTIONS 预检免鉴权；
- EventSource 无法设头 → `?from=<seq>` 首连接续传 + `retry: 3000` 重连提示（`?token=` 鉴权口径写进 README）；
- 请求体无上限（DoS 面）→ 1 MiB 上限 413（drain 后回包，非 destroy）；坏 JSON 400 不落 500；路径命中方法不对 405；
- 长任务期间投影像卡死 → 进行中工具调用呈现 `pending: true`（结果到达自动消失，仍逐字节确定）；
- 历史会话侧边栏 → `discoverSessions` 钩子并入 `GET /api/sessions`（fail-soft 不 fail-silent）。

### Added（工作台桥接层，m6-workbench-bridge）

- **`@omniharness/kernel/workbench` 子路径**：把「UI 只做呈现」所需的全部内核侧设施一次备齐——
  - `WorkbenchHub`：`EventPort`（按会话扇出 + 全量直播缓冲 + 会话注册表）与 `UserResponder`
    （提问桥：`ask_user` 挂起 → HTTP 回答 → await resolve）双端口合一；
  - `WorkbenchServer`：SSE 事件直播（`Last-Event-ID`=seq 断线续传、15s 心跳）、`/state`
    一次投影快照、`/answers` 回答端点（409 防重放）、`/api/audit/verify` 审计复核；
    Bearer/`?token=`/cookie 鉴权，非回环绑定强制令牌（复用 `ServerAuthGuard`）；
  - `projectSession`：事件流 → 视图状态（消息流/reasoning 挂接/工具结果配对工具名/待办/计划/
    用量/回滚墓碑/挂起提问）的**确定性纯函数**，前端零事件语义知识。
- `examples/workbench.mjs`：端到端演示——3 行接线 → 脚本模型调 `ask_user` → 假浏览器经 SSE
  收帧、经 state 发现挂起提问并 POST 回答 → 模型拿到真答案完成回合 → 审计复核。
- 公开面不变（60/60，golden 一致）；判据 `m6-workbench-bridge` 入 M6 状态账。

### Docs（对接参考与浏览器投影收尾）

- **`docs/API.md` 全量对接文档**：包结构与子路径分工、最小 headless 接入、工作台 HTTP/SSE
  全量协议（鉴权/CORS/状态码/续传/心跳）、浏览器三种完整用例（会话 hook、提问弹窗、审计页）、
  `WorkbenchState`/`WorkbenchMessage`/`SessionEvent` 字段表、自定义 `ModelPort`/`ToolPort`、
  回执签发与离线复核；每条签名以源码为准（`runTask` 的第 4 参只给新会话命名，续跑用
  `agent.resume`——误把既有 id 交给 `runTask` 会用新事件流覆盖旧存档）。
- **`@omniharness/kernel/workbench-view` 子路径**：`projectSession` / `mergeEvents` 的浏览器
  安全出口（零 `node:`、零 I/O、可直接打包）；`workbenchViewPurity` 判据递归检查 re-export
  运行时图，`view:check` 在 build 后复核 `dist` 产物同一边界。

## 0.1.0-alpha.5 — 2026-11-04

> 执行 [PLAN-2026-11.md](docs/PLAN-2026-11.md)：M4 切片 → M5 立信 → M6 通电。
> 依据 [AUDIT-2026-11.md](docs/AUDIT-2026-11.md) 的盘点事实。完整归档：git tag `attic/2026-11-03`。

### Added（M5 立信）

- **RFC 8785 JCS 规范化**（零依赖，7 条附录向量逐字节一致；NaN/Infinity fail-closed 抛错）。
- **动作级签名回执链**：`{payload, signature, anchors}` 三键信封、`SHA256(utf8(JCS(payload)))`
  链式哈希、单 issuer 单线性链、并发追加互斥序列化（100 并发零分叉）。
- **锚定**：jose Ed25519 签名（裸 payload 字节）+ RFC 3161 TSA 客户端（手写最小 DER TSQ，
  可注入 fetch）；无 TSA/无网如实 `anchors: []`，绝不为凑数伪造锚。
- **离线独立复核器**：`verifyAuditPack`（kernel）+ `scripts/verifyReceipts.mjs`（**独立实现**
  JCS/SHA-256，不 import 内核——第三方可离线复核的可行性证明）。零出网；`ok`（链结构）与
  `compliant`（合规档）分层；篡改四类（改 payload / 删首条 / 换锚 / 重排）全部可检出且失败码可读。
- `docs/RECEIPTS.md`：与 IETF draft-marques-asqav-compliance-receipts 逐字段映射 + 未实现项清单
  （保留期 / witness quorum / counterparty binding / CMS 完整验证）。

### Added（M6 通电）

- **provenanceIssuer 提公开面**（`@omniharness/kernel/governance`）：出证/复核经公开入口可用；
  `examples/audit-pack.mjs` 端到端演示（产出 → 复核 → 篡改检出 → 出处证书）。
- **MCP HTTP 服务端通电**（`@omniharness/kernel/mcp`）：`McpHttpAssembly` 经组合根装配
  2026-07-28 无状态服务端；外部 MCP 调用与本地同过审批/沙箱门禁；端到端用例真实起服断言。

### Changed（行为，均有负例测试）

- **缺省审批 = 缺省拒绝**：未注入 `approvals` 落 `DenyApproval`（旧缺省 `AutoApproval` 全放行）。
- **缺省沙箱 = 探测 OS 级隔离**：Landlock / Windows 原生写隔离可用即用之；探测不到落回
  `PolicySandbox` 并**显式告警**（黑名单不是隔离）；`OMNI_SANDBOX_STRICT=1` 时探测失败即拒绝启动。
- **并行工具事件按模型调用序落盘**（此前完成序——重放不可字节复现）。
- **压缩确定性重建**：LLM 摘要路径整体移除；产物 = 任务目标（user 原文摘录）+ 历史经过 +
  确定性工具台账 + 交接便签——同输入逐字节同输出、零模型调用、不可降级；user 请求不再可能被压丢。
- `rollback` 不再擦自己的历史：截断后落自包含 `rollback` 墓碑事件（旧实现留悬空 tool_result → 厂商 400）。
- **"无损收缩"名副其实**：`collapseBlankLines`（删行尾空白/压空行）从收缩管线移除——它会在模型
  看到之前改写补丁上下文；`compress()` 里降为显式 opt-in。
- MCP capability 诚实：删除指向从未实现的 `resources/subscribe` 处理器的声明（2026-07-28 订阅走
  `subscriptions/listen`）。

### Removed（M4 切片；完整归档 `attic/2026-11-03`）

- `protocols/a2a` 整树（贴 v1.0 标签的 v0.3 线格式）、隐喻算子栈（共振场/QEC/免疫/信念/退火/
  CRISPR/固化/刻蚀/元素/对称破缺/禁闭/涡环 + 燧编排 + Genesis 桥）、`kernel/plugin`、
  `kernel/media`、`kernel/asset`、`kernel/eval` 长任务目录、`context/rankVeto`、80+ 零引用孤儿。
- 依赖：`openid-client`（零 import）、`croner`（唯一消费者已删）；`sharp`/`unpdf`/`@huggingface/transformers`
  随媒体栈移除；`yaml` 升为直接依赖。
- 配置键：`resonantField`/`memoryAnnealing`/`qec`/`immuneMonitoring`/`belief`/`skillEditing`/
  `capabilityCrystallization`/`insightEtching`/`elementComposer`/`symmetryBreaking`/`confinement`/
  `vortexRing`/`genesis`/`sparkAutoRun`/`a2a`/`media`。

### Changed（门禁与证据层）

- 证据层修复：上游判据回迁 40 件（414→436 用例）；12 件降级 `L0-unverified`（注明恢复路径）；
  新门禁 `maturity:check`（L1+ 必带证据，机检）。
- 门禁加固（四个绕过各配**变异判据**）：双语引号 import、protocolsSupport 精确匹配、
  `export * as` 展开计数、人工复核记录限定 §6 且 id 必须存在；`contracts` 零 `node:` 内建（规则 6）。
- **API golden 快照**：公开符号增删/改名必须显式 `--update-golden`；顶层 60/60。
- 工具类导出下沉 `@omniharness/kernel/tools`；新增子路径 `receipts`/`sandbox`/`governance`/`mcp`。
- `tests/` 纳入 typecheck（`tsconfig.test.json`，修出 21 处潜伏类型错误）。

### BREAKING

- 公开面 60 符号重排（工具类/receipts 类型面移子路径）；顶层新增回执核心 6 符号。
- 上述配置键与子路径 `dist/protocols/a2a`/`dist/kernel/{spark,genesis,media,plugin,asset,eval}` 消失。
- 缺省审批/沙箱语义见上；依赖缺省放行或黑名单口径的调用方需显式注入。

## 0.1.0-alpha.4 — 2026-11-03

### Added

- **子路径导出（迁移桥）**：`exports` 增加 `"./*.js"` / `"./*"` → `dist/*`，让第一个消费者
  OmniHarness 在**公开面迁移期**按内部模块路径接入（应用仓库已删掉 143,883 行重复内核副本）。
  **不是兼容承诺**：顶层仍是唯一稳定面（59 / 60）；子路径随迁移完成即删除，见 BOUNDARY「迁移桥」。

### Changed

- 无公开面变化；版本 `0.1.0-alpha.4`。

## 0.1.0-alpha.3 — 2026-11-03

**应用形状清零**（第二遍收口：把「不属于内核」的残留整棵子树删掉）。公开 API 不变（59 / 60）。

### Removed

- `contracts/ports/tui/`、`contracts/ports/license/`、`contracts/ports/server/audit{Format,Query}.ts`、
  `contracts/ports/enterprise/`、`kernel/adapters/enterprise/`、`kernel/security/oidcClient.ts`、
  `kernel/sdk/sdkClient.ts`、`contracts/schema/codeGenerator.ts`、`defaults/cliHelp.json`。
  合计 **19 文件 / 约 2.5K 行**，逐项确认零引用（`tsc` + 29 文件 170 用例为裁判）。
- 以上均不在公开面，`api:check` 仍为 59 / 60。

### Changed

- `docs/BOUNDARY.md` 新增「应用形状清零」节；`compat/` 表里 `oidcClient` / `sdkClient`
  的去向从「下沉内核」改为「删除」（下沉只保证能跑，不保证只剩内核）。

### Known issues

- **未执行 `npm publish`**（无发布凭据）：`npm pack` + 空目录安装 + headless 已跑通；
  正式发布需先 `npm login` 或提供 `NPM_TOKEN`。

## 0.1.0-alpha.2 — 2026-11-03

**beta 硬化（M3）落地**。公开 API 面不变（59 / 60），但 `decisionEngine` 有 alpha 破坏性变更。

### Added

- **契约测试扩容**：新增 `tests/contract/` —— 审批语义 13 例、沙箱语义 8 例、门禁接线 6 例；
  原三份契约用例（事件顺序 / 回放 / 压缩）同目录归位。共 **6 文件 32 例，只经公开入口**。
- `tests/unit/decisionEngineInjection.test.ts`（3 例）：钉住「配置了引擎却没实现 ⇒ 构建报错」。

### Changed

- **`adapters/laya` 移出内核**（9 文件 + `decisionEngineResolver` + Python 资产）：第三方 venv
  绑定不属于通用内核面，实现回到应用仓库。内核保留 `DecisionEngineConfig` 并新增注入缝
  `decisionEnginePort`；`mode` 非 `off` 却未注入实现时 `ConfigFactory.build` **直接报错**
  （此前会静默 new 出 Laya 实现）。
- `@beta` 组从四组 18 文件收敛为**三组 9 文件**（`user` / `monitoring` / `live`），
  裁决标记与「不进公开面」纪律不变。
- **测试总数 25 文件 / 140 例 → 29 文件 / 170 例**；`plan:check` 的 `m3-contract-coverage`
  由人工判据改为机检（`tests/contract` ≥30 例），`m3-adapters-beta-marked` 口径 18 → 9。

### Known issues

- **未执行 `npm publish`**（无发布凭据）：`npm pack` + 空目录安装 + headless 已跑通；
  正式发布需先 `npm login` 或提供 `NPM_TOKEN`。

## 0.1.0-alpha.1 — 2026-11-03

**规划闭环 + 发布就绪**。公开 API 面不变（59 / 60）。

### Added

- **唯一规划源** `docs/ROADMAP.md`：里程碑 M0–M3、判据表（auto / manual）、人工复核记录、
  发布记录、决策日志；「下一版做什么」不再散落在 BOUNDARY 的一句话里。
- **规划对账门禁** `scripts/planCheck.mjs` + `npm run plan:check`（已并入 `npm run verify`）：
  状态账与代码事实**双向**对账——标 ✅ 必须判据全过，标 ⏳ 必须至少一条不过
  （既防提前记账，也防做完不记账）。
- **公开面计数单一实现** `scripts/publicSurface.mjs`：`apiSurface.mjs` 与 `planCheck.mjs` 共用，
  避免两处数字漂移。
- **CI** `.github/workflows/verify.yml`：`ubuntu-latest` + `windows-latest` 双平台跑
  `npm ci → npm run verify → node examples/headless.mjs`。
- **发布元数据**：`private: false`、`publishConfig.access: public`、`files[]` 收入
  `docs/ROADMAP.md`。

### Changed

- `docs/BOUNDARY.md` 的「下一步」移交 ROADMAP；本文件只保留**已经发生**的变更，
  发布记录只写「就绪」与「已发布」中真正发生的那一个。
- README 增加规划入口与 `npm run plan:check` 说明。

### Known issues

- **未执行 `npm publish`**（无发布凭据）：`0.1.0-alpha.1` 处于「发布就绪」，
  `npm pack` + 空目录安装 + headless 已跑通，见 ROADMAP §7。

## 0.1.0-alpha.0 — 2026-11-02

首次以「独立内核」形态收口。**不承诺兼容**（alpha）。

### Added

- **独立组合根** `kernel/composition/runtime.ts`：`Runtime.createRuntime(config)` 可在任意 Node
  进程里装配 `Agent`，不再依赖应用层 `apps/composition`。
- **公开入口** `src/index.ts`：58 / 60 个符号（`npm run api:check` 机检），
  覆盖组合根、主循环、端口与默认适配器。
- **契约测试** `tests/`：22 文件 / 135 用例，只依赖 `src/` 与 Node 内置；
  含一次「只经公开入口」的 headless 回合。
- **20 行 headless 示例** `examples/headless.mjs` 与 `npm run smoke`。
- **构建资产复制** `scripts/build.mjs`：`dangerous-commands.json`、worker mjs、laya py
  随 `dist` 发布（此前 `tsc` 不搬运，运行期 ENOENT）。
- **独立安装** `package-lock.json`；`node_modules` 不再是应用仓库的 junction。
- **`npm pack` 冒烟**：空目录安装 tarball 后可直接跑通 headless。

### Changed

- `src/compat/` 10 个「从应用借来的共享件」全部下沉：
  - `jsonRpc` → `kernel/rpc/`
  - 行传输 / WebSocket 编解码 → `kernel/transport/`
  - `serverAuthGuard`、`oidcClient` → `kernel/security/`
  - `safeFs`、`serveInstance` → `kernel/util/`
  - `serviceKeys` → `kernel/composition/`
- `contracts/sdk/sdkClient.ts` → `kernel/sdk/`（契约层不放实现）。
- `TuiRenderer` 删除：内核只保留 `ConsoleLiveView` 需要的两个纯 ANSI 片段。
- **契约反向依赖清零**（依赖规则 1 归零）：限制类型族（`RuntimeLimitsConfig` 等 10 个接口）
  与 `Spectrum` 下沉 `contracts/ports/`；A2A 协议数据（`a2aProtocol` + `TaskHandler`）移入
  `contracts/ports/a2a/`，新增 `A2aServerPort` / `A2aClientPort` 端口，
  `OmniHarnessRuntime.a2a` 只认端口（实现类在 protocols 侧 `implements`）。公开面 58 → 59。
- **协议穿透收口**：`protocols` → `kernel` 的 76 条散点 import 收敛为唯一支撑面
  `kernel/protocolsSupport.ts`（30 个文件改走该边，纯 re-export 零逻辑，只导出实际消费符号）；
  新增 `npm run boundary:check` 分层边界机检（fail-closed，四条规则），
  首跑即抓出 `kernel/adapters/mcp` → `protocols/mcp` 的 5 处存量穿透并声明为窄例外。
- **适配器归属裁决**（授权自主裁决）：`adapters/laya`（厂商绑定，待移出）、`adapters/user` /
  `adapters/monitoring` / `adapters/live`（端口默认实现，保留）四组共 18 文件标 `@beta`，
  处置理由与迁移路径记入 `docs/BOUNDARY.md`；组内符号不进公开面（api:check 把守）。
- **机检收口**：`boundary:check` 升至五条规则（新增规则 5「契约纯净」——contracts 只许相对
  路径导入，零 `node:` 内置、零第三方包）；新增 **`npm run verify`** 一键机检入口
  （typecheck + boundary:check + test + build + api:check）；README / BOUNDARY 同步终态
  （公开面 59/60、25 文件 140 用例、机检入口与裁决记录）。
- **契约测试扩容**（22 → 25 文件 / 135 → 140 用例）：
  - 事件顺序：`session_meta` 首条、`seq` 严格递增、`tool_result` 永不先于 `tool_call`、
    数量守恒、最终答案在最后结果之后、端口所见 = 存储落盘；
  - 会话落盘回放：JsonlStorage 跨实例（重启模拟）往返一致、`replay` 不改写历史、
    `resume` 历史严格前缀 + `seq` 延续；
  - 压缩不变量：确定性无损收缩只动空白且幂等、折叠后工具轮配对（无孤儿 tool / 无悬空
    toolCall）、前导 system 原样钉住。
- 清理最后一个再导出别名：`kernel/adapters/tool/toolHandler.ts` 删除，5 个引用方直连
  contracts（`ToolHandler` 单一引入路径）。
- **支撑面收窄**：`a2aTaskExecutor` 生产默认（子代理工厂 / Agent 主循环 / FilteredToolPort）
  挪到组合根 `kernel/composition/a2aBridge.ts`，经 `buildSubagent` / `runTask` / `filterTools`
  注入缝装配（**alpha 破坏性**：三项构造选项改必填，缺省即装配期报错）；
  fail-closed 工具收窄**策略**留在协议层、**机制**注入。`AgentPort` 扩展 `eventsOf` /
  `cancelCurrentRun` / 可选 `sessionId`（协议桥只认端口）；新增 contracts `ToolRegistryPort`
  （MCP 网关不再感知 `RegistryToolPort` 具体类）。支撑面 27 → 21 符号（全基础设施），
  协议层对 `core` / `subagent` 的感知归零。

### Removed

- `src/compat/` 目录整体删除；`src` 内零 `apps/` import。

### Known issues

- `npm publish` 未执行（无发布凭据）；包已可 `npm pack`（0.1.0-alpha.0，不承诺兼容）。
- `adapters/laya` 长期应迁回应用仓库（已标 `@beta`，迁移路径见 BOUNDARY 裁决表）。
