# 边界（依赖规则 · 公开面 · 发布）

> 本仓是独立内核：`contracts` + `kernel` + `protocols`。应用层（CLI / Web / Desktop）不在本仓，
> 只从 `@omniharness/kernel` 依赖。分层与主循环见 [ARCHITECTURE.md](ARCHITECTURE.md)；
> 本文件只记**机器可判**的边界事实——会随代码变化的数字必然过期，一律以机检输出为准。

## 1. 七条边界规则

| # | 规则 | 判据 |
| - | ---- | ---- |
| 1 | **contracts 是叶子且零 `node:`**：只能依赖 `contracts`，不得回指 `kernel` / `protocols`；不得出现任何 `node:` 内建引用 | `scripts/boundaryCheck.ts` 规则 1/6；`scripts/archCheck.ts` 拒绝 `contracts` 的任何跨层边 |
| 2 | **protocols 只经单一支撑面**：取用内核能力只能 import `src/kernel/protocolsSupport.ts`（纯 re-export、零逻辑） | `boundaryCheck` 规则 2：目标路径必须**精确**以 `/kernel/protocolsSupport.ts` 结尾，同名变体不算放行 |
| 3 | **kernel 不依赖 protocols**：例外仅两处——组合根 `src/kernel/composition/`（装配层天然要构造协议实现）与 `src/kernel/adapters/mcp/` → `protocols/mcp/`（MCP 桥） | `boundaryCheck` 规则 3；`archCheck` 同口径检查图上的跨层边 |
| 4 | **src 零 apps 引用**：应用层不在本仓，任何 `apps/` 路径引用都是回指 | `boundaryCheck` 规则 4 |
| 5 | **契约纯净**：`contracts` 内只许相对路径导入，零第三方包、零实现符号 | `boundaryCheck` 规则 5 |
| 6 | **动态 import 禁模板插值**：含 `${` 的 import specifier 无法静态复核目标，一律拒绝 | `boundaryCheck` 动态 import 检查（fail-closed） |
| 7 | **副作用出口白名单**：`spawn` / `spawnSync` / `execFile` / `execFileSync` / `execSync` 调用点必须在 `defaults/effect-allowlist.json`（前缀或精确文件）内；新增调用点必须走统一 Executor 或登记理由，列表只减不增 | `boundaryCheck` 规则 7 |
| 8 | **env 单入口**：`src` 内只有 `src/kernel/config/kernelEnv.ts` 可以直接读 `process.env`；其余模块必须 `KernelEnv.raw/text/int/bool(ENV.xxx)`，变量名经 `ENV` 登记表类型检查 | `boundaryCheck` 规则 8 |
| 9 | **配置零裸读**：`src` 内不得出现 `.runtime.config.<field>` 直读，一律经 `ConfigSections` 分区视图 | `boundaryCheck` 规则 9；`drift:check` 的 `config.bareReads` 归一 |

```bash
npm run boundary:check   # 九条文本规则；任何违规即退出码 1
npm run arch:check       # 运行时依赖图：环 / 跨层边 / 本仓依赖快照一致
```

两份机检分工：`boundary:check` 查**源码文本**（import 写法、契约纯度、apps 引用），
`arch:check` 查**图结构**（Tarjan SCC 找运行时环、跨层边是否落在声明例外、`import type` 不计运行时边）。
典型绕过都已被堵：靠子串匹配混过支撑面（改精确路径匹配）、`export * as` 的命名空间导出按成员展开计数、
注释里的示例 `from '...'` 先剥注释再扫。

## 2. 当前边界事实

| 事实 | 怎么验 |
| ---- | ------ |
| `contracts` → `kernel` / `protocols` 反向依赖：0 | `npm run boundary:check` |
| 运行时依赖环：0；跨层违规：0 | `npm run arch:check` |
| 顶层公开符号：60 / 60，且与 golden 快照逐字一致 | `npm run api:check` |
| `exports` 子路径：18 条（只降不升） | `npm run drift:check`（`pkg.subpaths`） |
| 默认路径外文件：135 个索引不可达文件全部有显式分类 | `npm run offpath:check` |\n| 测试套件：全绿；**规模以 `npm test` 尾部输出为准**（文档不写死用例数） | `npm test` |
| 打包后独立可用：见 §4 冒烟步骤 | 手工 / 发布前 |
| 全量门禁：16 道串联，任一红即整体红 | `npm run verify` |

## 3. 公开面契约

**顶层 60 符号 = 唯一稳定承诺面。** `src/index.ts` 只做再导出：`contracts` 与 `kernel` 两个桶，
外加 `OmniKernel.create`、`ReceiptChain` / `AuditPacks` / `JoseReceiptSigner` 与回执相关的四个类型
（`ActionReceipt` / `ReceiptPayload` / `AuditPack` / `AuditPackVerdict`）。
`npm run api:check` 用 TypeScript AST 统计 `export *` 展开后的**真实符号数**（`export * as` 按展开成员计），
并与 `scripts/api-golden.json` 做 golden 比对：**删除、改名、新增都变红**，必须显式
`apiSurface.ts --update-golden` 并记 CHANGELOG；golden 缺失同样是红（fail-closed，缺失不等于放行）。

**子路径 18 条 = 2 根 + 16 curated 语义入口。** `package.json#exports` 分三类：

| 类别 | 数量 | 说明 |
| ---- | ---- | ---- |
| `.` 与 `./package.json` | 2 | 包根与元数据 |
| curated 能力子路径 | 16 | `embed` / `tools` / `receipts` / `sandbox` / `governance` / `mcp` / `agui` / `workbench` / `workbench-view` / `maintenance` / `eval` / `omniError` / `contracts` / `adapters` / `runtime` / `protocols`——稳定入口（再导出桶，桶内承诺的符号同属交付面） |
| 深路径闭包 | 0 | `contracts/*` / `kernel/*` / `protocols/*` 下的实现文件，逐条显式列出（无通配） |

事实必须说清：**深路径是真实 API 面，不是内部细节。** 第一个消费者按深路径逐条消费，
所以它们被写进 `exports` 承诺清单，并由 `scripts/exportsClosure.ts` 生成、`prepack` 校验
（每条导出必须指向存在的 dist 产物）。反过来，顶层 60 只决定「稳定承诺」，不决定「谁在用」。
纪律：新代码不得新增深路径依赖；`drift:check` 的 `pkg.subpaths` 把当前条数当上限，只降不升；
应用侧 248 条深路径导入由 `npm run consumer:check` 钉成基线（只降不升，新增即红）。
`./contracts` 是给应用的**迁移目标**：先迁常用端口/类型，再逐步把深路径基线降下来。

## 4. 发布边界

- **`files` 白名单（15 项）**：`dist` / `defaults` / `examples` / `CHANGELOG.md` / `LICENSE` / `NOTICE` /
  `README.md` / `docs/ARCHITECTURE.md` / `docs/API.md` / `docs/SECURITY.md` / `docs/OPERATIONS.md` /
  `docs/BOUNDARY.md` / `docs/CONVERGENCE.md` / `docs/WIRING.md` / `docs/RELEASE.md`。
  白名单之外的一切（含 `src/`、`tests/`、`scripts/` 与 `history/`）都不随包发布。
- **`prepack`**：先 `npm run build`，再跑 `scripts/exportsClosure.ts`——发布包不可能出现「导出指向不存在的文件」。
- **`npm pack` 冒烟**：`npm pack --pack-destination .tmp` → 在**空目录** `npm install <tgz>` →
  `node examples/headless.mjs`（examples 只 import 公开入口，跑通即证明包自洽）。仓库内的
  `npm run smoke` 跑同一组示例的 dist 形态。
- **干净检出编译**：`npm run clean:tsc`（`scripts/cleanCheckoutTsc.ts`）——在 HEAD 的临时 worktree 上
  跑主配置 + 测试配置两份 tsc，钉死「干净检出也能编译」；只在发布前跑，不进日常 `verify`。
- **发布前置**：`npm run publish:check` 校验 token 对 registry 验真、`publishConfig.access=public` +
  `tag=alpha`（防误发 latest）、`prepack` 存在、`v<version>` tag 与 HEAD 一致、该版本未重复发布。

## 5. 已知边界与宿主职责

内核只承诺「可复核」，不替宿主做信任与分发决策：

| 事项 | 内核做什么 | 宿主必须做什么 |
| ---- | ---------- | -------------- |
| 委托信任根分发 | `DelegationTrustRegistry` 支持进程内注册/吊销与快照序列化（`toJSON` / `save` / `load`）；跨 issuer 验签需显式给 `delegationTrust` | 决定信任谁、吊销谁，并负责把信任根安全分发到各进程；快照文件格式即分发契约，语义与保管不在内核 |
| 审计摘要分发 | 链尾摘要 `SignedReceiptSummary`（条数 + 尾哈希）可签发，用于检出尾截断 / 尾篡改 | 把摘要**带外交付**给收证方并保管；不给 witness 时，防不了签发方整体重写 |
| OAuth 回环 | `src/protocols/mcp/mcpAuthFlow.ts` 只监听 `127.0.0.1` 随机端口，校验 `state` / `iss`，换令牌并写 token store；不自动打开浏览器 | 授权 URL 的呈现与用户交互；回调端口的对外暴露面 |
| 跨进程回执锁 | `ReceiptChain` 的线性由**进程内**互斥队列 + 载入时全链校验（issuer、`seq` 连续、前驱相接、重复 id）保证 | 同一 issuer 链的多进程写入需自行串行化——内核没有跨进程回执锁，并发写入会在 adopt 时被判死 |
