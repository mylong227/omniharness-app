# 运维与嵌入（OPERATIONS）

运维与嵌入方手册：起、配、存、看、修、收。事实以源码为准。

## 1 运行要求

- Node ≥ 22.14（`engines`）。`node:sqlite` 惰性加载：不选 sqlite 的入口不受影响，选了而缺模块抛可行动错误；默认零第三方依赖，可选件（playwright-core / transformers、ffmpeg、`omni-cli`）缺失只降档（`capabilities()` 如实报）。
- 平台：沙箱按 Linux Landlock → Windows 原生（`omni-cli`/`OMNI_CLI_BIN`）→ macOS seatbelt 探测，都无则非 strict 落 `PolicySandbox`+warn（非隔离）、`OMNI_SANDBOX_STRICT=1` 启动失败；原子写唯一临时文件+rename（Windows EPERM 重试）；Windows 上 serve 持有的会话文件删除 EBUSY/EPERM，GC 记 `skipped`；0600 仅 POSIX 可靠；归属判定用 realpath。

## 2 配置体系

落点：`configFieldSpecs.ts`（字段规格）｜`configError.ts`（键白名单/别名/域校验/合并/env 层）｜`defaults/*.json`（缺或坏即启动失败）｜`OMNI_*`（运维旋钮，不进 schema）。

- 未知键/类型/枚举/env 非十进制/跨字段矛盾一律 `ConfigError`，带合法键提示与 did-you-mean（`ConfigError.knownConfigKeys()`）；合并对普通对象递归、数组/标量替换并复验。
- 优先级：嵌入方 显式注入 > 宿主加载的配置文件 > env 兜底 > `defaults/*.json`；`loadLayered` 内部 用户级 → 项目级 → profile → `bundle-patches` → `OMNIHARNESS_*` env（层内最高）。
- 信任：项目配置、工作区内 profile、bundle 补丁是工作区输入；未信任只应用 `SAFE_KEYS`，权威键（`mcpServers`/`approval`/`sandbox`/`escalation`/`baseUrl`/`providerKeys`/`plugin`/`calibratedAutonomy`）记入 `ignored`；`auto`/`passthrough` 这类降权值只能命令行给；信任存 `~/.omniharness/trust.json`（realpath + 指纹，改动需重授）。
- 凭据：显式配置（`apiKey`/`providerKeys`，Windows 可 DPAPI）> env（`OMNIHARNESS_API_KEY`、厂商 `<ID>_API_KEY`）> vault（`CryptoVault` AES-256-GCM / `EnvVault`）；`hydrateEnv` 只补未设置项，vault 读不动即抛。

| 域 | 入口 | 默认 |
| --- | --- | --- |
| 模型 | `model`（实例或 `'厂商id[:模型]'`） | `MockModel`+warn；重试 3 次、熔断开；端点兜底 `endpoints.json` |
| 存储 | `storage`/`storageAdapter` | `JsonlStorage` → `<ws>/.omniharness/sessions`；`memory/jsonl/sqlite` |
| 审批 | `approvals` | `DenyApproval`；文件枚举 `auto/deny/rules/guardian/ask/plan` |
| 沙箱 | `sandbox`/`elevatedSandbox` | 探测 OS 级，无则 `PolicySandbox`+warn；提权缺省不可 |
| 上下文窗口 | `OMNI_CONTEXT_WINDOW` | 模型名目录 > 128k（容量分母） |
| 压缩 | `compactionMaxTokens`/`compactionKeepRecent` | 0.8×窗口（显式才钉死）、保留 6、确定性收缩开 |
| 检索 | repo-map/暴露/历史 | repo-map 开、暴露 `plan`、`retrievalContext`/`semanticRecall` 关（BM25-only） |
| 记忆 | 长期记忆 | 开 → `.omniharness/longterm/memory.jsonl`；加密/primer 关、蒸馏开 |
| 回执 | `receipts` | 开、Ed25519、`toolCalls` 开；`persist`/`certificates` 关 |
| 工作台 | `workbench` | 开、`127.0.0.1:0`；token 回落 `OMNI_SERVE_TOKEN`；CORS 回环 |
| telemetry | `telemetry` | 关；开则 `.omniharness/telemetry/runtime-telemetry.log` |
| MCP | `mcpServers`/`mcpServe` | 客户端零连接；服务端关（`/mcp`、1 MiB、读 10s） |

## 3 会话与存储布局

`<ws>/.omniharness/`：`sessions/`（`<encoded id>.jsonl`、`.jsonl.summary.json`、`attachments/<sha256>.<ext>`、`archive/`）、`tasks/<slug>/`、`graph-runs/`（`.jsonl`+`.lock`）、`spill/`、`longterm/`、`receipts/`、`telemetry/`、`audit-bundles/`；文件快照 `<ws>/.omni-checkpoints/`。归属根 `~/.omniharness/`（`OMNI_HOME` 搬盘）：`sessions/`（`OMNI_SESSIONS_DIR` 覆盖）、`tmp/`（`OMNI_TMP_DIR`）、`trust.json`、`vault.key`、`mcp-tokens.json`、`serve-*.pid`。嵌入落工作区、CLI/serve 落用户级，统一走 `SessionStorageLocation`。

- 回合：同步预留（同 id 第二回合在此失败）→ hydrate → 事件 + write-behind（200ms，`append` 前缀校验失败回退全量原子写）→ 反登记 → flush → 全量或摘要 → 观测 flush；落盘失败 fail-soft（`session.persist.failed` warn）。
- 检查点每 20 步自动（纯事件）；显式 `checkpoint` 另抓文件快照（≤20 份、≤256 MiB、≤50 label）；回滚 文件→事件→内存回卷，条数不符即拒；rewind 须同步内存日志、检索索引、压缩游标、persister。
- `resume` 同 id（空 prompt = 崩溃恢复）；`fork` 复制历史到新 id。
- `close()` 幂等：cancel('shutdown') → drain（10s，`drainTimeoutMs`）→ MCP → MCP 服务端 → 插件 worker → `runtime.dispose`(LSP) → 回执/事件 flush → 工作台；超时只 warn；closed 后 `runTask` 抛错。

## 4 可观测性

- 事件流 append-only、`seq` 可回放；SSE `GET /api/sessions/:id/events`（回放+实时，`Last-Event-ID`/首次 `?from=`、15s 心跳、8 MiB 积压断开）。
- 日志 JSON 行写 stderr（stdout 只留答案），`OMNI_LOG_LEVEL` 缺省 info；`traceId` 随异步上下文传播，可注入 `X-Trace-Id`。
- `runtime.telemetry` JSONL + 哈希链 `SHA256(prev‖canonical)`，重启续链；`verify()` 报 `brokenAt`（`TELEMETRY_CHAIN_BROKEN`）。
- OTLP：`OTEL_EXPORTER_OTLP_ENDPOINT` 设了才包 span。
- `diagnostics()` 七分区（absent≠degraded）；context 含缓存读数（`prefixReuseRatio`/`cachedPromptTokens`/`gapMs`，告警 `OMNI_CACHE_HIT_WARN` 50）与工具结果预算（`spilled*` 字节、`trimmed*`/`snipped*` 字符，spill 与 trim 不叠加）。

```bash
node --version
curl -s http://127.0.0.1:<port>/health
curl -sN "http://127.0.0.1:<port>/api/sessions/<id>/events?token=<t>&from=0"
```

按 msg 定位：`model.http.error`、`model.context_overflow.recovering`、`session.persist.failed`、`sandbox.default.fallback_policy`、`plugin.load.failed`。

## 5 常见故障与处置

| 症状 | 判据 | 动作 |
| --- | --- | --- |
| 模型 401/403 | `model.http.error` 带 `status`，`retryable=false` | 查凭据链（env→vault→DPAPI）；确认 `baseUrl` 未被未信任工作区改道 |
| 模型 429/5xx | `status` 429/408/409/5xx 且 `retryable=true`，按 `Retry-After` 退避 | 已重试 3 次；持续看熔断 `retryAfterMs`，降并发或配 `fallbackModel` |
| 上下文超限 | 400 且响应体含 prompt too long / context_length | 已压缩重试一次；再失败收紧 `compactionKeepRecent`、核对 `OMNI_CONTEXT_WINDOW`、拆任务 |
| 沙箱拒绝 | 工具结果含 `[category] 原因`；`capabilities().sandbox` 为 `PolicySandbox` 即非隔离 | 注入更严档；放行走 `elevatedSandbox`+`escalation` 白名单；CI 用 strict 模式 |
| 审批挂起 | 事件停在审批 request（无 answer） | 注入真实 `approvals`（ask 无 `userResponder` 即 deny）；工作台 `POST …/answers` |
| 回执链坏/丢钥 | 启动抛 `SIGNATURE_INVALID@seq`/`CHAIN_BREAK@seq`，或「有签名历史但密钥缺失」 | 别删档；用 `trust.json` 离线复核；丢钥只能换 `issuerId` 重建 |
| 存储 ENOSPC | `session.persist.failed` warn、`append` 回退全量 | 先 `MaintenanceRunner.run({dryRun:true})`；扩盘或 `OMNI_HOME` 搬盘 |
| 工作台端口占用 | `listen` 抛 EADDRINUSE，装配失败并回收 | 用 `port: 0`，读 `capabilities().workbench.url` |
| MCP 连接失败 | `bridge.results()` 带 error，`mcp.tools` 偏少 | 核对 `command`/`url` 二选一、`env` 仅 stdio、`OMNI_MCP_ALLOWLIST` |
| 插件加载失败 | `plugin.load.failed` warn；`pluginStack=false` 即未开 | 查 `plugin.dir`/manifest/权限白名单；远程需 `OMNI_ALLOW_REMOTE_PLUGINS=1` |

## 6 维护与回收

- `@omniharness/kernel/maintenance` 导出 `SessionStorageLocation`/`SessionGc`/`TmpSweep`/`ServeInstance`/`MaintenanceRunner`；`run()` 一次做四件：扫 `tmp/` 与 OS Temp（本仓前缀且超龄）、清陈旧 serve pid、会话保留、清半截临时文件；全 best-effort。
- 会话保留：`keepNewest` 保护的最近 50 组不删，其余按 90 天与 4 GiB 淘汰（归档优先），孤儿附件按引用集 + 年龄删；层级 显式选项 > `limits.maintenance` > `OMNI_GC_*` > `defaults`；`OMNI_MAINTENANCE=off` 全关、`dryRun` 只报、周期 6h。
- 回收：`close()` 覆盖 MCP 两侧、插件 worker、LSP、回执/事件 flush、工作台；浏览器工具自带 `close()` 与空闲自动关闭（`idleCloseMs` 180s），内核不代调；`kernel/worker` 归宿主。

## 7 嵌入方检查清单

- [ ] fail-closed 默认：不注入审批 ⇒ 全拒；不注入沙箱 ⇒ 探测，探测不到是黑名单而非隔离（strict 让缺失即失败）；不注入模型 ⇒ `MockModel`+warn。
- [ ] 显式注入真实模型、审批、沙箱，用 `capabilities().securityPosture` 核对**生效值**而非配置。
- [ ] `receipts: { persist: true }`（收证再加 `certificates`）：私钥 0600、与 `trust.json` 一起备份、导出前 `flush()`。
- [ ] 工作台非回环绑定必须给 token、SSE 用 `?token=`、`corsOrigin` 别写 `*`。
- [ ] 多会话隔离：不同 `sessionId` 并发；`cancel` 传 `sessionId`（缺省取消全部）；`eventsOf` 读内存、`replay` 才广播。
- [ ] 升级前 `npm run verify` 全绿，发布前加 `clean:tsc` 与 `npm pack`。
