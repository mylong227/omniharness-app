# OmniKernel

> **可嵌入的 agent 内核：可审计、fail-closed、模型中立。**
> 模型是大脑，内核是中枢神经系统，应用只是壳。

OmniKernel 是一个不依赖 CLI / Web / TUI 的 agent 内核。宿主把 `ModelPort` 与工作区交给它，
就能得到一条可回放、可拦截、可复核的 agent 主循环。

## 四个不变量

| 不变量 | 含义 |
| --- | --- |
| **可审计** | 会话事件 append-only、按 `seq` 回放；动作级签名回执链（JCS + SHA-256 + 可选 RFC3161 锚定 + 独立复核器）；执行证书绑定事件 Merkle 根 |
| **fail-closed** | 审批 / 升级 / 完成闸门缺省拒绝；沙箱缺省探测 OS 隔离，探测不到时落 `PolicySandbox` 并明确告警（策略层不是隔离）；读不到安全数据即启动失败 |
| **模型中立** | 只认 `ModelPort`；OpenAI 兼容 / Anthropic / llama.cpp / 自写适配器同权 |
| **可嵌入** | 无 CLI 依赖；`OmniKernel.create()` 一次装配，或 `ConfigFactory + Runtime + Agent` 手动接线 |

## 安装

```bash
npm i @omniharness/kernel
```

要求 Node.js ≥ 22.14（使用 `node:sqlite`）。

## 快速开始

```js
import { OmniKernel } from '@omniharness/kernel';

const kernel = await OmniKernel.create({
  workspaceRoot: process.cwd(),
  model, // 任意 ModelPort；缺省 MockModel（零凭据）
  receipts: { persist: true }, // 可选：回执链落盘，重启续写
});

const result = await kernel.runTask('把端口改成 8787');
console.log(result.finalText, kernel.capabilities());
await kernel.close(); // 幂等：取消在跑回合 → 关 MCP → 落回执 → 关工作台
```

仓库内运行：

```bash
npm ci
npm run build
node examples/embed.mjs      # 一次接入
node examples/headless.mjs   # 手动挑六个端口
```

`examples/headless.mjs` 展示最小接线：`ConfigFactory.build({ workspaceRoot, model, storage, events, approvals, sandbox })`
→ `Runtime.createRuntime(config)` → `new Agent(runtime).runTask(prompt)`。

## 架构速览

```text
entry（src/*.ts 公开入口）
  └─ kernel（主循环 / 上下文 / 工具 / 门禁 / 存储 / 组合根 / 适配器）
       └─ protocols（MCP / ACP / AG-UI）
            └─ contracts（端口 / 类型 / 错误 / schema；零实现）
```

一次任务的主链：

```text
Agent.runTask
 └─ SessionStateStore（会话级状态：前缀计量 / 工具稳定集）
     └─ TurnRunner（回合：预算 / 完成闸门 / 读数）
         └─ StepRunner（上下文投影 → 模型 → 工具批）
             └─ StepToolExecutor（ToolGate → 沙箱 → 执行 → 事件）
```

详见 [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)。

## 公开 API

顶层唯一稳定入口是 `@omniharness/kernel`（`src/index.ts`），当前 **60 / 60** 个符号，
按职责分为：组合根（`OmniKernel` / `Runtime` / `ConfigFactory`）、主循环（`Agent`）、
端口（`ModelPort` / `ToolPort` / `StoragePort` / `ApprovalPort` / `SandboxPort` …）、
默认适配器（`MockModel` / `OpenAiCompatibleModel` / `AnthropicModel` / `MemoryStorage` /
`JsonlStorage` / `AutoApproval` / `DenyApproval` / `RuleApproval` / `PolicySandbox` …）、
回执审计（`ReceiptChain` / `AuditPacks` / `JoseReceiptSigner`）。

语义子路径（curated）：

```text
@omniharness/kernel/embed            OmniKernel 与选项/句柄类型
@omniharness/kernel/tools            内置工具实现
@omniharness/kernel/receipts         回执链 / JCS / 审计包完整面
@omniharness/kernel/sandbox          沙箱实现与隔离阶梯
@omniharness/kernel/governance       晋升台账 / 出处签发
@omniharness/kernel/mcp              MCP 客户端/服务端装配
@omniharness/kernel/agui             AG-UI HTTP/SSE 适配
@omniharness/kernel/workbench        工作台 HTTP/SSE 桥
@omniharness/kernel/workbench-view   浏览器端状态投影（零 node:）
@omniharness/kernel/maintenance      会话保留 / 临时产物清扫
@omniharness/kernel/eval             评测口径库
```

完整签名、配置字段与错误码见 [docs/API.md](docs/API.md)；安全边界见 [docs/SECURITY.md](docs/SECURITY.md)；
配置/存储/排障见 [docs/OPERATIONS.md](docs/OPERATIONS.md)。

## 开发

```bash
npm ci
npm run verify          # 一键机检（16 道门禁，见 package.json）
npm run drift:check     # 漂移预算：13 项结构指标只降不升
npm run bench:behavior  # 行为基准：23 个 fixture 摘要 + 参考解自检（CI 跑；不测模型质量）
npm run boundary:check  # 分层边界（contracts 叶子 / protocols 单一支撑面）
npm run arch:check      # 依赖图：零运行时环 + 跨层边合法 + 文档快照一致
npm run wiring:check    # 接线审计：入口完整 / 零入边落账 / 文档路径不悬空
npm run api:check       # 顶层公开面 60 + golden 快照
npm test                # 单元 / 契约 / 属性测试
npm run stress          # 压力套件（独立配置）
npm run coverage        # v8 覆盖率地板
npm run cross:check     # 跨仓契约（Rust 真源 + 应用消费闭包）\nnpm run consumer:check  # 应用深路径导入棘轮（只降不升；无应用仓时 SKIP）
npm run clean:tsc # 干净检出编译（发布前跑）
npm run sandbox:canary  # 真实沙箱 canary（无 docker 时明确 SKIP）
```

工程纪律与防漂移规则见 [docs/CONVERGENCE.md](docs/CONVERGENCE.md)，
编码规范见 [AGENTS.md](AGENTS.md)。修改代码或文档前先读这两份。

## 文档

| 文档 | 内容 |
| --- | --- |
| [ARCHITECTURE](docs/ARCHITECTURE.md) | 分层、组合根、主循环、会话/回合/步、扩展点、不变量 |
| [API](docs/API.md) | 公开符号、子路径、配置、端口契约、回执 API |
| [SECURITY](docs/SECURITY.md) | 威胁模型、门禁链、沙箱、审计/回执、污点与数据流 |
| [OPERATIONS](docs/OPERATIONS.md) | 配置、存储布局、可观测性、故障处置、维护 |
| [BOUNDARY](docs/BOUNDARY.md) | 分层边界规则与发布边界 |
| [WIRING](docs/WIRING.md) | 零入边处置台账 |
| [CONVERGENCE](docs/CONVERGENCE.md) | 防漂移预算、结构规则、迁移顺序 |
| [RELEASE](docs/RELEASE.md) | 版本与发布流程 |

## 与 OmniHarness 的关系

```text
OmniHarness（应用）──依赖──▶ OmniKernel（本仓）
     CLI / Web / Desktop          contracts + kernel + protocols
```

依赖方向只有 app → kernel → contracts。内核独立 semver；应用钉版本并在升级时跑全量回归。

## License

Apache-2.0。见 [LICENSE](LICENSE) 与 [NOTICE](NOTICE)。
